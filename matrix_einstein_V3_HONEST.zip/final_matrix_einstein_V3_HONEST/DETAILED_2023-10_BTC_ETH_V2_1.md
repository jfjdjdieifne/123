# تقرير مفصل — 2023-10 — BTC & ETH نفس الشهر نفس السنة — Matrix V2.1 — $100 / 2%


## BTCUSDT — 2023-10 — $100→$106.93 (6.93%) — 5 صفقات W=3 L=2

| # | دخول | خروج | Bias | Entry | SL | TP1 | TP2 | PnL% | $ | Bal | A | B | C | MFE | Session | Sweep Q | Disp Conv | Why |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 2023-10-06 06:00 | 2023-10-06 07:50 | BULLISH | 27423.55 | 27348.92 | 27535.52 | 28580.00 | +3.048 | +3.05 | 103.05 | A_TRAIL | B_FORTRESS | C_FORTRESS | 2.18R | LONDON_KILLZONE | 85.3 | 99.2 | BIAS BULLISH conf80 zone=PREMIUM | SWEEP SSL Q85.3 lvl=27432.12 | DISP 4.29x 87.8% conv=99.2 | FVG 27414.1-27433.0 CE=27 |
| 2 | 2023-10-06 14:00 | 2023-10-06 18:25 | BULLISH | 27527.43 | 27348.08 | 27848.99 | 28580.00 | -0.317 | -0.33 | 102.72 | SL | B_FORTRESS | C_FORTRESS | 1.53R | NY_AM_KILLZONE | 82.5 | 100.0 | BIAS BULLISH conf90 zone=PREMIUM | SWEEP SSL Q82.5 lvl=27488.5 | DISP 6.77x 100.0% conv=100.0 | FVG 27519.37-27535.49 CE |
| 3 | 2023-10-08 06:00 | 2023-10-08 14:15 | BULLISH | 27909.37 | 27848.72 | 28011.96 | 28580.00 | +2.062 | +2.12 | 104.84 | A_TRAIL | B_FORTRESS | C_FORTRESS | 3.06R | LONDON_KILLZONE | 80.0 | 100.0 | BIAS BULLISH conf80 zone=PREMIUM | SWEEP SSL Q80.0 lvl=27902.48 | DISP 3.46x 100.0% conv=100 | FVG 27901.3-27917.43 CE=2 |
| 4 | 2023-10-18 13:00 | 2023-10-18 22:35 | BEARISH | 28716.13 | 28990.13 | 28277.09 | 27175.94 | +2.823 | +2.96 | 107.80 | A_TRAIL | B_FORTRESS | C_FORTRESS | 2.09R | NY_AM_KILLZONE | 45.2 | 87.4 | BIAS BEARISH conf75 zone=PREMIUM | SWEEP BSL Q45.2 lvl=28508.83 | DISP 2.6x 87.3% conv=87.4 | FVG 28687.3-28744.96 CE=28 |
| 5 | 2023-10-20 18:00 | 2023-10-21 23:30 | BEARISH | 29794.19 | 30221.02 | 29111.28 | 27260.00 | -0.805 | -0.87 | 106.93 | SL | B_FORTRESS | C_FORTRESS | 1.11R | NY_PM_KILLZONE | 94.4 | 85.8 | BIAS BEARISH conf95 zone=PREMIUM | SWEEP BSL Q94.4 lvl=29829.47 | DISP 3.07x 72.7% conv=85.8 | FVG 29753.37-29835.0 CE=2 |

### تفصيل كل صفقة — شو شاف وشو عمل ليش


#### #1 BULLISH 2023-10-06 06:00→2023-10-06 07:50 PnL +3.048% MFE 2.18R
- **Layer1 BIAS:** BULLISH conf 80 zone PREMIUM reason HH+HL | Zone=PREMIUM | Confidence=80
- **Layer2 Sweep:** SSL lvl 27432.12 wick 27391.24 Q 85.3
- **Layer3 Disp:** BULLISH 4.29x 87.8% conv 99.2 | FVG 27414.1-27433.0 CE 27423.55
- **Layer4 Plan:** entry 27423.55 sl 27348.91658 risk 74.63 atr 20.56 sl_atr 3.63 tp1 {'price': 27535.52, 'kind': 'SWING', 'rr': 1.5, 'dist': 111.97000000000116} tp2 {'price': 28580.0, 'kind': 'HTF_DRAW', 'rr': 15.5} tp3 28580.0
- **Session:** LONDON_KILLZONE 2023-10-06 02:00 NY (Fri) | Filter 
- **MFE/MAE:** MFE 2.1767385769797767R MAE 0R | Exit A=A_TRAIL B=B_FORTRESS C=C_FORTRESS
- **Events:** 2023-10-06 06:00 OPEN entry=27423.55 sl=27348.91658 tp1=27535.52 filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(99)+OB_HELD → old Premium is new Discount for DOL 28580.0. Mitigation Block continuation per ICT. LONG only.|MID_OK; 2023-10-06 06:05 🧠 phase=ACCUMULATION | MFE=0.57R | impr=0 | fuel=0.97; 2023-10-06 06:10 🧠 phase=ACCUMULATION | MFE=0.57R | impr=0 | fuel=0.97; 2023-10-06 06:15 🧠 phase=ACCUMULATION | MFE=0.62R | impr=0 | fuel=0.97; 2023-10-06 06:20 🧠 phase=ACCUMULATION | MFE=0.62R | impr=0 | fuel=0.97; 2023-10-06 06:25 🧠 phase=ACCUMULATION | MFE=0.62R | impr=0 | fuel=0.97; 2023-10-06 06:30 🧠 phase=ACCUMULATION | MFE=0.72R | impr=0 | fuel=0.96; 2023-10-06 06:35 🧠 phase=ACCUMULATION | MFE=0.95R | impr=0 | fuel=0.94; 2023-10-06 06:40 🧠 phase=ACCUMULATION | MFE=1.59R | impr=0 | fuel=0.88; 2023-10-06 06:40 🎯 A:TP1; 2023-10-06 06:40 📣 PARTIAL_TAKEN→fortresses_active; 2023-10-06 06:45 🧠 phase=ACCUMULATION | MFE=1.59R | impr=0 | fuel=0.88; 2023-10-06 06:50 🧠 phase=ACCUMULATION | MFE=1.59R | impr=0 | fuel=0.88; 2023-10-06 06:55 🧠 phase=ACCUMULATION | MFE=1.59R | impr=0 | fuel=0.88; 2023-10-06 07:00 🧠 phase=ACCUMULATION | MFE=1.59R | impr=0 | fuel=0.88
- **Why:** BIAS BULLISH conf80 zone=PREMIUM | SWEEP SSL Q85.3 lvl=27432.12 | DISP 4.29x 87.8% conv=99.2 | FVG 27414.1-27433.0 CE=27423.55 | Filter ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(99)+OB_HELD → old Premium is new Discount for DOL 28580.0. Mitigation Block continuation per ICT. LONG only.|MID_OK

#### #2 BULLISH 2023-10-06 14:00→2023-10-06 18:25 PnL -0.317% MFE 1.53R
- **Layer1 BIAS:** BULLISH conf 90 zone PREMIUM reason HH+HL | Zone=PREMIUM | Confidence=90
- **Layer2 Sweep:** SSL lvl 27488.5 wick 27464.48 Q 82.5
- **Layer3 Disp:** BULLISH 6.77x 100.0% conv 100.0 | FVG 27519.37-27535.49 CE 27527.43
- **Layer4 Plan:** entry 27527.43 sl 27348.080013 risk 179.35 atr 26.13 sl_atr 6.86 tp1 {'price': 27848.99, 'kind': 'SWING', 'rr': 1.79, 'dist': 321.5600000000013} tp2 {'price': 28580.0, 'kind': 'HTF_DRAW', 'rr': 5.87} tp3 28580.0
- **Session:** NY_AM_KILLZONE 2023-10-06 10:00 NY (Fri) | Filter 
- **MFE/MAE:** MFE 1.5253415110119861R MAE 1.7831056593253376R | Exit A=SL B=B_FORTRESS C=C_FORTRESS
- **Events:** 2023-10-06 14:00 OPEN entry=27527.43 sl=27348.080013 tp1=27848.99 filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(100)+OB_HELD → old Premium is new Discount for DOL 28580.0. Mitigation Block continuation per ICT. LONG only.|SOFT_ABOVE_MIDNIGHT; 2023-10-06 14:05 🧠 phase=ACCUMULATION | MFE=0.56R | impr=0 | fuel=0.74; 2023-10-06 14:10 🧠 phase=ACCUMULATION | MFE=0.59R | impr=0 | fuel=0.74; 2023-10-06 14:15 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.74; 2023-10-06 14:20 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.74; 2023-10-06 14:25 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.74; 2023-10-06 14:30 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.74; 2023-10-06 14:35 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.74; 2023-10-06 14:40 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.74; 2023-10-06 14:45 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.74; 2023-10-06 14:50 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.74; 2023-10-06 14:55 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.74; 2023-10-06 15:00 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.74; 2023-10-06 15:05 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.74; 2023-10-06 15:10 🧠 phase=ACCUMULATION | MFE=0.86R | impr=0 | fuel=0.72
- **Why:** BIAS BULLISH conf90 zone=PREMIUM | SWEEP SSL Q82.5 lvl=27488.5 | DISP 6.77x 100.0% conv=100.0 | FVG 27519.37-27535.49 CE=27527.43 | Filter ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(100)+OB_HELD → old Premium is new Discount for DOL 28580.0. Mitigation Block continuation per ICT. LONG only.|SOFT_ABOVE_MIDNIGHT

#### #3 BULLISH 2023-10-08 06:00→2023-10-08 14:15 PnL +2.062% MFE 3.06R
- **Layer1 BIAS:** BULLISH conf 80 zone PREMIUM reason HH+HL | Zone=PREMIUM | Confidence=80
- **Layer2 Sweep:** SSL lvl 27902.48 wick 27890.8 Q 80.0
- **Layer3 Disp:** BULLISH 3.46x 100.0% conv 100.0 | FVG 27901.3-27917.43 CE 27909.364999999998
- **Layer4 Plan:** entry 27909.365 sl 27848.719369 risk 60.65 atr 8.54 sl_atr 7.1 tp1 {'price': 28011.96, 'kind': 'SWING', 'rr': 1.69, 'dist': 102.59500000000116} tp2 {'price': 28580.0, 'kind': 'HTF_DRAW', 'rr': 11.06} tp3 28580.0
- **Session:** LONDON_KILLZONE 2023-10-08 02:00 NY (Sun) | Filter 
- **MFE/MAE:** MFE 3.0630667765869384R MAE 0.6914262159934264R | Exit A=A_TRAIL B=B_FORTRESS C=C_FORTRESS
- **Events:** 2023-10-08 06:00 OPEN entry=27909.365 sl=27848.719369 tp1=28011.96 filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(100)+OB_HELD → old Premium is new Discount for DOL 28580.0. Mitigation Block continuation per ICT. LONG only.|MID_OK; 2023-10-08 06:05 🧠 phase=ACCUMULATION | MFE=1.08R | impr=0 | fuel=0.94; 2023-10-08 06:10 🧠 phase=ACCUMULATION | MFE=1.09R | impr=0 | fuel=0.94; 2023-10-08 06:15 🧠 phase=ACCUMULATION | MFE=1.14R | impr=0 | fuel=0.94; 2023-10-08 06:20 🧠 phase=ACCUMULATION | MFE=1.14R | impr=0 | fuel=0.94; 2023-10-08 06:25 🧠 phase=ACCUMULATION | MFE=1.22R | impr=0 | fuel=0.93; 2023-10-08 06:30 🧠 phase=ACCUMULATION | MFE=1.22R | impr=0 | fuel=0.93; 2023-10-08 06:35 🧠 phase=ACCUMULATION | MFE=1.22R | impr=0 | fuel=0.93; 2023-10-08 06:40 🧠 phase=ACCUMULATION | MFE=1.22R | impr=0 | fuel=0.93; 2023-10-08 06:45 🧠 phase=ACCUMULATION | MFE=1.22R | impr=0 | fuel=0.93; 2023-10-08 06:50 🧠 phase=ACCUMULATION | MFE=1.22R | impr=0 | fuel=0.93; 2023-10-08 06:55 🧠 phase=ACCUMULATION | MFE=1.22R | impr=0 | fuel=0.93; 2023-10-08 07:00 🧠 phase=ACCUMULATION | MFE=1.22R | impr=0 | fuel=0.93; 2023-10-08 07:05 🧠 phase=ACCUMULATION | MFE=1.40R | impr=0 | fuel=0.92; 2023-10-08 07:10 🧠 phase=ACCUMULATION | MFE=1.98R | impr=0 | fuel=0.86
- **Why:** BIAS BULLISH conf80 zone=PREMIUM | SWEEP SSL Q80.0 lvl=27902.48 | DISP 3.46x 100.0% conv=100 | FVG 27901.3-27917.43 CE=27909.364999999998 | Filter ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(100)+OB_HELD → old Premium is new Discount for DOL 28580.0. Mitigation Block continuation per ICT. LONG only.|MID_OK

#### #4 BEARISH 2023-10-18 13:00→2023-10-18 22:35 PnL +2.823% MFE 2.09R
- **Layer1 BIAS:** BEARISH conf 75 zone PREMIUM reason LH+LL | Zone=PREMIUM | Confidence=75
- **Layer2 Sweep:** BSL lvl 28508.83 wick 28521.82 Q 45.2
- **Layer3 Disp:** BEARISH 2.6x 87.3% conv 87.4 | FVG 28687.3-28744.96 CE 28716.129999999997
- **Layer4 Plan:** entry 28716.13 sl 28990.130079 risk 274.0 atr 51.8 sl_atr 5.29 tp1 {'price': 28277.09, 'kind': 'SWING', 'rr': 1.6, 'dist': 439.03999999999724} tp2 {'price': 27175.94, 'kind': 'HTF_DRAW', 'rr': 5.62} tp3 26377.7
- **Session:** NY_AM_KILLZONE 2023-10-18 09:00 NY (Wed) | Filter 
- **MFE/MAE:** MFE 2.0921897810219052R MAE 0R | Exit A=A_TRAIL B=B_FORTRESS C=C_FORTRESS
- **Events:** 2023-10-18 13:00 OPEN entry=28716.13 sl=28990.130079 tp1=28277.09 filter=ACCUM:PD_PREMIUM|MID_OK; 2023-10-18 13:05 🧠 phase=ACCUMULATION | MFE=0.59R | impr=0 | fuel=0.86; 2023-10-18 13:10 🧠 phase=ACCUMULATION | MFE=0.62R | impr=0 | fuel=0.86; 2023-10-18 13:15 🧠 phase=ACCUMULATION | MFE=0.85R | impr=0 | fuel=0.86; 2023-10-18 13:20 🧠 phase=ACCUMULATION | MFE=0.85R | impr=0 | fuel=0.86; 2023-10-18 13:25 🧠 phase=ACCUMULATION | MFE=0.85R | impr=0 | fuel=0.86; 2023-10-18 13:30 🧠 phase=ACCUMULATION | MFE=0.90R | impr=0 | fuel=0.86; 2023-10-18 13:35 🧠 phase=ACCUMULATION | MFE=0.90R | impr=0 | fuel=0.86; 2023-10-18 13:40 🧠 phase=ACCUMULATION | MFE=0.90R | impr=0 | fuel=0.86; 2023-10-18 13:45 🧠 phase=ACCUMULATION | MFE=0.90R | impr=0 | fuel=0.86; 2023-10-18 13:50 🧠 phase=ACCUMULATION | MFE=0.90R | impr=0 | fuel=0.86; 2023-10-18 13:55 🧠 phase=ACCUMULATION | MFE=0.90R | impr=0 | fuel=0.86; 2023-10-18 14:00 🧠 phase=ACCUMULATION | MFE=0.90R | impr=0 | fuel=0.86; 2023-10-18 14:05 🧠 phase=ACCUMULATION | MFE=0.90R | impr=0 | fuel=0.86; 2023-10-18 14:10 🧠 phase=ACCUMULATION | MFE=0.90R | impr=0 | fuel=0.86
- **Why:** BIAS BEARISH conf75 zone=PREMIUM | SWEEP BSL Q45.2 lvl=28508.83 | DISP 2.6x 87.3% conv=87.4 | FVG 28687.3-28744.96 CE=28716.129999999997 | Filter ACCUM:PD_PREMIUM|MID_OK

#### #5 BEARISH 2023-10-20 18:00→2023-10-21 23:30 PnL -0.805% MFE 1.11R
- **Layer1 BIAS:** BEARISH conf 95 zone PREMIUM reason LH+LL | Zone=PREMIUM | Confidence=95
- **Layer2 Sweep:** BSL lvl 29829.47 wick 29908.86 Q 94.4
- **Layer3 Disp:** BEARISH 3.07x 72.7% conv 85.8 | FVG 29753.37-29835.0 CE 29794.184999999998
- **Layer4 Plan:** entry 29794.185 sl 30221.022968 risk 426.84 atr 89.82 sl_atr 4.75 tp1 {'price': 29111.28, 'kind': 'SWING', 'rr': 1.6, 'dist': 682.9049999999988} tp2 {'price': 27260.0, 'kind': 'HTF_DRAW', 'rr': 5.94} tp3 25990.46
- **Session:** NY_PM_KILLZONE 2023-10-20 14:00 NY (Fri) | Filter 
- **MFE/MAE:** MFE 1.108576984350111R MAE 1.3724229219379636R | Exit A=SL B=B_FORTRESS C=C_FORTRESS
- **Events:** 2023-10-20 18:00 OPEN entry=29794.185 sl=30221.022968 tp1=29111.28 filter=ACCUM:PD_PREMIUM|MID_OK; 2023-10-20 18:05 🧠 phase=ACCUMULATION | MFE=0.58R | impr=0 | fuel=0.91; 2023-10-20 18:10 🧠 phase=ACCUMULATION | MFE=0.58R | impr=0 | fuel=0.91; 2023-10-20 18:15 🧠 phase=ACCUMULATION | MFE=0.83R | impr=0 | fuel=0.91; 2023-10-20 18:20 🧠 phase=ACCUMULATION | MFE=0.97R | impr=0 | fuel=0.91; 2023-10-20 18:25 🧠 phase=ACCUMULATION | MFE=0.97R | impr=0 | fuel=0.91; 2023-10-20 18:30 🧠 phase=ACCUMULATION | MFE=0.97R | impr=0 | fuel=0.91; 2023-10-20 18:35 🧠 phase=ACCUMULATION | MFE=0.97R | impr=0 | fuel=0.91; 2023-10-20 18:40 🧠 phase=ACCUMULATION | MFE=0.97R | impr=0 | fuel=0.91; 2023-10-20 18:45 🧠 phase=ACCUMULATION | MFE=0.97R | impr=0 | fuel=0.91; 2023-10-20 18:50 🧠 phase=ACCUMULATION | MFE=0.97R | impr=0 | fuel=0.91; 2023-10-20 18:55 🧠 phase=ACCUMULATION | MFE=0.97R | impr=0 | fuel=0.91; 2023-10-20 19:00 🧠 phase=ACCUMULATION | MFE=0.97R | impr=0 | fuel=0.91; 2023-10-20 19:05 🧠 phase=ACCUMULATION | MFE=0.97R | impr=0 | fuel=0.91; 2023-10-20 19:10 🧠 phase=ACCUMULATION | MFE=0.97R | impr=0 | fuel=0.91
- **Why:** BIAS BEARISH conf95 zone=PREMIUM | SWEEP BSL Q94.4 lvl=29829.47 | DISP 3.07x 72.7% conv=85.8 | FVG 29753.37-29835.0 CE=29794.184999999998 | Filter ACCUM:PD_PREMIUM|MID_OK

## ETHUSDT — 2023-10 — $100→$125.07 (25.07%) — 7 صفقات W=7 L=0

| # | دخول | خروج | Bias | Entry | SL | TP1 | TP2 | PnL% | $ | Bal | A | B | C | MFE | Session | Sweep Q | Disp Conv | Why |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 2023-10-01 13:00 | 2023-10-01 19:30 | BEARISH | 1689.13 | 1692.27 | 1684.26 | 1615.00 | +5.212 | +5.21 | 105.21 | A_TRAIL | B_FORTRESS | C_FORTRESS | 6.09R | NY_AM_KILLZONE | 58.4 | 90.9 | BIAS BEARISH conf75 zone=PREMIUM | SWEEP BSL Q58.4 lvl=1679.39 | DISP 2.71x 96.6% conv=90.9 | FVG 1689.02-1689.24 CE=168 |
| 2 | 2023-10-05 14:00 | 2023-10-05 15:00 | BULLISH | 1634.78 | 1630.00 | 1642.24 | 1653.91 | +1.073 | +1.13 | 106.34 | A_TRAIL | B_FORTRESS | C_FORTRESS | 2.67R | NY_AM_KILLZONE | 92.6 | 98.7 | BIAS BULLISH conf100 zone=DISCOUNT | SWEEP SSL Q92.6 lvl=1636.0 | DISP 9.97x 91.1% conv=98.7 | FVG 1633.67-1635.89 CE=16 |
| 3 | 2023-10-05 19:00 | 2023-10-06 00:25 | BULLISH | 1614.32 | 1600.85 | 1634.87 | 1668.64 | +0.327 | +0.35 | 106.69 | CE_RISK_CUT | CE_RISK_CUT | CE_RISK_CUT | 0.40R | NY_PM_KILLZONE | 76.2 | 92.0 | BIAS BULLISH conf100 zone=DISCOUNT | SWEEP SSL Q76.2 lvl=1612.95 | DISP 3.27x 75.4% conv=92.0 | FVG 1614.1-1614.54 CE=16 |
| 4 | 2023-10-08 13:00 | 2023-10-08 15:35 | BULLISH | 1620.37 | 1614.95 | 1628.83 | 1644.45 | +3.385 | +3.61 | 110.30 | A_TRAIL | B_FORTRESS | C_FORTRESS | 3.15R | NY_AM_KILLZONE | 91.5 | 99.4 | BIAS BULLISH conf75 zone=DISCOUNT | SWEEP SSL Q91.5 lvl=1621.42 | DISP 3.16x 95.6% conv=99.4 | FVG 1619.51-1621.22 CE=16 |
| 5 | 2023-10-21 06:00 | 2023-10-21 14:25 | BULLISH | 1598.41 | 1591.09 | 1609.43 | 1642.00 | +2.444 | +2.70 | 113.00 | A_TRAIL | B_FORTRESS | C_FORTRESS | 2.26R | LONDON_KILLZONE | 72.6 | 100.0 | BIAS BULLISH conf95 zone=DISCOUNT | SWEEP SSL Q72.6 lvl=1592.38 | DISP 3.54x 100.0% conv=100 | FVG 1598.05-1598.77 CE=15 |
| 6 | 2023-10-22 13:00 | 2023-10-22 23:00 | BULLISH | 1628.81 | 1618.87 | 1643.84 | 1664.60 | +2.417 | +2.73 | 115.73 | A_TRAIL | B_FORTRESS | C_FORTRESS | 3.89R | NY_AM_KILLZONE | 83.6 | 71.7 | BIAS BULLISH conf100 zone=DISCOUNT | SWEEP SSL Q83.6 lvl=1629.05 | DISP 2.24x 76.5% conv=71.7 | FVG 1627.98-1629.63 CE=1 |
| 7 | 2023-10-30 07:00 | 2023-10-30 12:05 | BULLISH | 1782.21 | 1777.69 | 1790.56 | 1854.87 | +8.077 | +9.35 | 125.07 | A_TRAIL | B_FORTRESS | C_FORTRESS | 10.38R | LONDON_KILLZONE | 90.5 | 94.2 | BIAS BULLISH conf90 zone=PREMIUM | SWEEP SSL Q90.5 lvl=1782.12 | DISP 2.93x 78.0% conv=94.2 | FVG 1781.16-1783.26 CE=178 |

### تفصيل كل صفقة — شو شاف وشو عمل ليش


#### #1 BEARISH 2023-10-01 13:00→2023-10-01 19:30 PnL +5.212% MFE 6.09R
- **Layer1 BIAS:** BEARISH conf 75 zone PREMIUM reason LH+LL | Zone=PREMIUM | Confidence=75
- **Layer2 Sweep:** BSL lvl 1679.39 wick 1680.61 Q 58.4
- **Layer3 Disp:** BEARISH 2.71x 96.6% conv 90.9 | FVG 1689.02-1689.24 CE 1689.13
- **Layer4 Plan:** entry 1689.13 sl 1692.265716 risk 3.14 atr 1.77 sl_atr 1.77 tp1 {'price': 1684.26, 'kind': 'SWING', 'rr': 1.55, 'dist': 4.870000000000118} tp2 {'price': 1615.0, 'kind': 'HTF_DRAW', 'rr': 23.64} tp3 1606.74
- **Session:** NY_AM_KILLZONE 2023-10-01 09:00 NY (Sun) | Filter 
- **MFE/MAE:** MFE 6.089171974522331R MAE 0.41719745222928195R | Exit A=A_TRAIL B=B_FORTRESS C=C_FORTRESS
- **Events:** 2023-10-01 13:00 OPEN entry=1689.13 sl=1692.265716 tp1=1684.26 filter=ACCUM:PD_PREMIUM|MID_OK; 2023-10-01 13:05 🧠 phase=ACCUMULATION | MFE=2.46R | impr=0 | fuel=0.97; 2023-10-01 13:05 🎯 A:TP1; 2023-10-01 13:05 📣 PARTIAL_TAKEN→fortresses_active; 2023-10-01 13:10 🧠 phase=ACCUMULATION | MFE=2.46R | impr=0 | fuel=0.97; 2023-10-01 13:15 🧠 phase=ACCUMULATION | MFE=2.46R | impr=0 | fuel=0.97; 2023-10-01 13:20 🧠 phase=ACCUMULATION | MFE=2.46R | impr=0 | fuel=0.97; 2023-10-01 13:25 🧠 phase=ACCUMULATION | MFE=2.46R | impr=0 | fuel=0.97; 2023-10-01 13:30 🧠 phase=ACCUMULATION | MFE=2.46R | impr=0 | fuel=0.97; 2023-10-01 13:35 🧠 phase=ACCUMULATION | MFE=2.46R | impr=0 | fuel=0.97; 2023-10-01 13:40 🧠 phase=ACCUMULATION | MFE=2.46R | impr=0 | fuel=0.97; 2023-10-01 13:45 🧠 phase=ACCUMULATION | MFE=2.46R | impr=0 | fuel=0.97; 2023-10-01 13:50 🧠 phase=ACCUMULATION | MFE=2.46R | impr=0 | fuel=0.97; 2023-10-01 13:55 🧠 phase=ACCUMULATION | MFE=2.46R | impr=0 | fuel=0.97; 2023-10-01 14:00 🧠 phase=ACCUMULATION | MFE=2.46R | impr=0 | fuel=0.97
- **Why:** BIAS BEARISH conf75 zone=PREMIUM | SWEEP BSL Q58.4 lvl=1679.39 | DISP 2.71x 96.6% conv=90.9 | FVG 1689.02-1689.24 CE=1689.13 | Filter ACCUM:PD_PREMIUM|MID_OK

#### #2 BULLISH 2023-10-05 14:00→2023-10-05 15:00 PnL +1.073% MFE 2.67R
- **Layer1 BIAS:** BULLISH conf 100 zone DISCOUNT reason HH+HL | Zone=DISCOUNT | Confidence=100
- **Layer2 Sweep:** SSL lvl 1636.0 wick 1632.07 Q 92.6
- **Layer3 Disp:** BULLISH 9.97x 91.1% conv 98.7 | FVG 1633.67-1635.89 CE 1634.7800000000002
- **Layer4 Plan:** entry 1634.78 sl 1629.999041 risk 4.78 atr 3.34 sl_atr 1.43 tp1 {'price': 1642.24, 'kind': 'SWING', 'rr': 1.56, 'dist': 7.459999999999809} tp2 {'price': 1653.91, 'kind': 'HTF_DRAW', 'rr': 4.0} tp3 1668.64
- **Session:** NY_AM_KILLZONE 2023-10-05 10:00 NY (Thu) | Filter 
- **MFE/MAE:** MFE 2.6715481171548077R MAE 2.882845188284513R | Exit A=A_TRAIL B=B_FORTRESS C=C_FORTRESS
- **Events:** 2023-10-05 14:00 OPEN entry=1634.78 sl=1629.999041 tp1=1642.24 filter=ACCUM:PD_DISCOUNT|MID_OK; 2023-10-05 14:05 🧠 phase=ACCUMULATION | MFE=1.49R | impr=0 | fuel=0.89; 2023-10-05 14:10 🧠 phase=ACCUMULATION | MFE=1.82R | impr=0 | fuel=0.89; 2023-10-05 14:10 🎯 A:TP1; 2023-10-05 14:10 📣 PARTIAL_TAKEN→fortresses_active; 2023-10-05 14:15 🧠 phase=ACCUMULATION | MFE=2.33R | impr=0 | fuel=0.89; 2023-10-05 14:20 🧠 phase=ACCUMULATION | MFE=2.67R | impr=0 | fuel=0.89; 2023-10-05 14:20 🧠 A:Trail; 2023-10-05 14:25 🧠 phase=ACCUMULATION | MFE=2.67R | impr=0 | fuel=0.89; 2023-10-05 14:30 🧠 phase=ACCUMULATION | MFE=2.67R | impr=0 | fuel=0.89; 2023-10-05 14:35 🧠 phase=ACCUMULATION | MFE=2.67R | impr=0 | fuel=0.89; 2023-10-05 14:40 🧠 phase=ACCUMULATION | MFE=2.67R | impr=0 | fuel=0.89; 2023-10-05 14:45 🧠 phase=ACCUMULATION | MFE=2.67R | impr=0 | fuel=0.89; 2023-10-05 14:50 🧠 phase=ACCUMULATION | MFE=2.67R | impr=0 | fuel=0.89; 2023-10-05 14:55 🧠 phase=ACCUMULATION | MFE=2.67R | impr=0 | fuel=0.89
- **Why:** BIAS BULLISH conf100 zone=DISCOUNT | SWEEP SSL Q92.6 lvl=1636.0 | DISP 9.97x 91.1% conv=98.7 | FVG 1633.67-1635.89 CE=1634.7800000000002 | Filter ACCUM:PD_DISCOUNT|MID_OK

#### #3 BULLISH 2023-10-05 19:00→2023-10-06 00:25 PnL +0.327% MFE 0.40R
- **Layer1 BIAS:** BULLISH conf 100 zone DISCOUNT reason HH+HL | Zone=DISCOUNT | Confidence=100
- **Layer2 Sweep:** SSL lvl 1612.95 wick 1611.72 Q 76.2
- **Layer3 Disp:** BULLISH 3.27x 75.4% conv 92.0 | FVG 1614.1-1614.54 CE 1614.32
- **Layer4 Plan:** entry 1614.32 sl 1600.848832 risk 13.47 atr 2.87 sl_atr 4.69 tp1 {'price': 1634.87, 'kind': 'SWING', 'rr': 1.53, 'dist': 20.549999999999955} tp2 {'price': 1668.64, 'kind': 'HTF_DRAW', 'rr': 4.03} tp3 1780.0
- **Session:** NY_PM_KILLZONE 2023-10-05 15:00 NY (Thu) | Filter 
- **MFE/MAE:** MFE 0.4031180400890916R MAE 0.3897550111358574R | Exit A=CE_RISK_CUT B=CE_RISK_CUT C=CE_RISK_CUT
- **Events:** 2023-10-05 19:00 OPEN entry=1614.32 sl=1600.848832 tp1=1634.87 filter=ACCUM:PD_DISCOUNT|MID_OK; 2023-10-05 19:05 🧠 phase=ACCUMULATION | MFE=0.23R | impr=0 | fuel=0.89; 2023-10-05 19:10 🧠 phase=ACCUMULATION | MFE=0.25R | impr=0 | fuel=0.89; 2023-10-05 19:15 🧠 phase=ACCUMULATION | MFE=0.40R | impr=0 | fuel=0.89; 2023-10-05 19:20 🧠 phase=ACCUMULATION | MFE=0.40R | impr=0 | fuel=0.89; 2023-10-05 19:25 🧠 phase=ACCUMULATION | MFE=0.40R | impr=0 | fuel=0.89; 2023-10-05 19:30 🧠 phase=ACCUMULATION | MFE=0.40R | impr=0 | fuel=0.89; 2023-10-05 19:35 🧠 phase=ACCUMULATION | MFE=0.40R | impr=0 | fuel=0.89; 2023-10-05 19:40 🧠 phase=ACCUMULATION | MFE=0.40R | impr=0 | fuel=0.89; 2023-10-05 19:45 🧠 phase=ACCUMULATION | MFE=0.40R | impr=0 | fuel=0.89; 2023-10-05 19:50 🧠 phase=ACCUMULATION | MFE=0.40R | impr=0 | fuel=0.89; 2023-10-05 19:55 🧠 phase=ACCUMULATION | MFE=0.40R | impr=0 | fuel=0.89; 2023-10-05 20:00 🧠 phase=ACCUMULATION | MFE=0.40R | impr=0 | fuel=0.89; 2023-10-05 20:05 🧠 phase=ACCUMULATION | MFE=0.40R | impr=0 | fuel=0.89; 2023-10-05 20:10 🧠 phase=ACCUMULATION | MFE=0.40R | impr=0 | fuel=0.89
- **Why:** BIAS BULLISH conf100 zone=DISCOUNT | SWEEP SSL Q76.2 lvl=1612.95 | DISP 3.27x 75.4% conv=92.0 | FVG 1614.1-1614.54 CE=1614.32 | Filter ACCUM:PD_DISCOUNT|MID_OK

#### #4 BULLISH 2023-10-08 13:00→2023-10-08 15:35 PnL +3.385% MFE 3.15R
- **Layer1 BIAS:** BULLISH conf 75 zone DISCOUNT reason HH+HL | Zone=DISCOUNT | Confidence=75
- **Layer2 Sweep:** SSL lvl 1621.42 wick 1618.95 Q 91.5
- **Layer3 Disp:** BULLISH 3.16x 95.6% conv 99.4 | FVG 1619.51-1621.22 CE 1620.365
- **Layer4 Plan:** entry 1620.365 sl 1614.946026 risk 5.42 atr 1.63 sl_atr 3.33 tp1 {'price': 1628.83, 'kind': 'SWING', 'rr': 1.56, 'dist': 8.464999999999918} tp2 {'price': 1644.45, 'kind': 'HTF_DRAW', 'rr': 4.44} tp3 1653.91
- **Session:** NY_AM_KILLZONE 2023-10-08 09:00 NY (Sun) | Filter 
- **MFE/MAE:** MFE 3.1466789667896795R MAE 0.5046125461254428R | Exit A=A_TRAIL B=B_FORTRESS C=C_FORTRESS
- **Events:** 2023-10-08 13:00 OPEN entry=1620.365 sl=1614.946026 tp1=1628.83 filter=ACCUM:PD_DISCOUNT|MID_OK; 2023-10-08 13:05 🧠 phase=ACCUMULATION | MFE=0.03R | impr=0 | fuel=0.98; 2023-10-08 13:10 🧠 phase=ACCUMULATION | MFE=0.03R | impr=0 | fuel=0.98; 2023-10-08 13:15 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.98; 2023-10-08 13:20 🧠 phase=ACCUMULATION | MFE=1.93R | impr=0 | fuel=0.98; 2023-10-08 13:20 🎯 A:TP1; 2023-10-08 13:20 📣 PARTIAL_TAKEN→fortresses_active; 2023-10-08 13:25 🧠 phase=ACCUMULATION | MFE=1.93R | impr=0 | fuel=0.98; 2023-10-08 13:30 🧠 phase=ACCUMULATION | MFE=1.93R | impr=0 | fuel=0.98; 2023-10-08 13:35 🧠 phase=ACCUMULATION | MFE=1.93R | impr=0 | fuel=0.98; 2023-10-08 13:40 🧠 phase=ACCUMULATION | MFE=2.19R | impr=0 | fuel=0.98; 2023-10-08 13:45 🧠 phase=ACCUMULATION | MFE=2.57R | impr=0 | fuel=0.98; 2023-10-08 13:50 🧠 phase=ACCUMULATION | MFE=2.57R | impr=0 | fuel=0.98; 2023-10-08 13:50 🧠 A:Trail; 2023-10-08 13:55 🧠 phase=ACCUMULATION | MFE=2.57R | impr=0 | fuel=0.98
- **Why:** BIAS BULLISH conf75 zone=DISCOUNT | SWEEP SSL Q91.5 lvl=1621.42 | DISP 3.16x 95.6% conv=99.4 | FVG 1619.51-1621.22 CE=1620.365 | Filter ACCUM:PD_DISCOUNT|MID_OK

#### #5 BULLISH 2023-10-21 06:00→2023-10-21 14:25 PnL +2.444% MFE 2.26R
- **Layer1 BIAS:** BULLISH conf 95 zone DISCOUNT reason HH+HL | Zone=DISCOUNT | Confidence=95
- **Layer2 Sweep:** SSL lvl 1592.38 wick 1591.25 Q 72.6
- **Layer3 Disp:** BULLISH 3.54x 100.0% conv 100.0 | FVG 1598.05-1598.77 CE 1598.4099999999999
- **Layer4 Plan:** entry 1598.41 sl 1591.087022 risk 7.32 atr 1.09 sl_atr 6.74 tp1 {'price': 1609.43, 'kind': 'SWING', 'rr': 1.5, 'dist': 11.02000000000021} tp2 {'price': 1642.0, 'kind': 'HTF_DRAW', 'rr': 5.95} tp3 1687.65
- **Session:** LONDON_KILLZONE 2023-10-21 02:00 NY (Sat) | Filter 
- **MFE/MAE:** MFE 2.2554644808743154R MAE 0.07377049180330478R | Exit A=A_TRAIL B=B_FORTRESS C=C_FORTRESS
- **Events:** 2023-10-21 06:00 OPEN entry=1598.41 sl=1591.087022 tp1=1609.43 filter=ACCUM:PD_DISCOUNT|MID_OK; 2023-10-21 06:05 🧠 phase=ACCUMULATION | MFE=0.07R | impr=0 | fuel=0.95; 2023-10-21 06:10 🧠 phase=ACCUMULATION | MFE=0.07R | impr=0 | fuel=0.95; 2023-10-21 06:15 🧠 phase=ACCUMULATION | MFE=0.16R | impr=0 | fuel=0.95; 2023-10-21 06:20 🧠 phase=ACCUMULATION | MFE=0.33R | impr=0 | fuel=0.93; 2023-10-21 06:25 🧠 phase=ACCUMULATION | MFE=0.62R | impr=0 | fuel=0.89; 2023-10-21 06:30 🧠 phase=ACCUMULATION | MFE=0.89R | impr=0 | fuel=0.86; 2023-10-21 06:35 🧠 phase=ACCUMULATION | MFE=0.89R | impr=0 | fuel=0.86; 2023-10-21 06:40 🧠 phase=ACCUMULATION | MFE=0.89R | impr=0 | fuel=0.86; 2023-10-21 06:45 🧠 phase=ACCUMULATION | MFE=0.89R | impr=0 | CE=1600.31 | CE_HOLDS | fuel=0.86; 2023-10-21 06:50 🧠 phase=ACCUMULATION | MFE=0.89R | impr=0 | CE=1600.31 | CE_HOLDS | fuel=0.86; 2023-10-21 06:55 🧠 phase=ACCUMULATION | MFE=0.89R | impr=0 | CE=1600.31 | CE_HOLDS | fuel=0.86; 2023-10-21 07:00 🧠 phase=ACCUMULATION | MFE=0.89R | impr=0 | CE=1600.31 | CE_HOLDS | fuel=0.86; 2023-10-21 07:05 🧠 phase=ACCUMULATION | MFE=0.89R | impr=0 | CE=1600.31 | CE_HOLDS | fuel=0.86; 2023-10-21 07:10 🧠 phase=ACCUMULATION | MFE=0.89R | impr=0 | CE=1600.31 | CE_HOLDS | fuel=0.86
- **Why:** BIAS BULLISH conf95 zone=DISCOUNT | SWEEP SSL Q72.6 lvl=1592.38 | DISP 3.54x 100.0% conv=100 | FVG 1598.05-1598.77 CE=1598.4099999999999 | Filter ACCUM:PD_DISCOUNT|MID_OK

#### #6 BULLISH 2023-10-22 13:00→2023-10-22 23:00 PnL +2.417% MFE 3.89R
- **Layer1 BIAS:** BULLISH conf 100 zone DISCOUNT reason HH+HL | Zone=DISCOUNT | Confidence=100
- **Layer2 Sweep:** SSL lvl 1629.05 wick 1625.62 Q 83.6
- **Layer3 Disp:** BULLISH 2.24x 76.5% conv 71.7 | FVG 1627.98-1629.63 CE 1628.805
- **Layer4 Plan:** entry 1628.805 sl 1618.866052 risk 9.94 atr 1.89 sl_atr 5.25 tp1 {'price': 1643.84, 'kind': 'SWING', 'rr': 1.51, 'dist': 15.034999999999854} tp2 {'price': 1664.6, 'kind': 'HTF_DRAW', 'rr': 3.6} tp3 1694.11
- **Session:** NY_AM_KILLZONE 2023-10-22 09:00 NY (Sun) | Filter 
- **MFE/MAE:** MFE 3.8928571428571366R MAE 0.8858148893360226R | Exit A=A_TRAIL B=B_FORTRESS C=C_FORTRESS
- **Events:** 2023-10-22 13:00 OPEN entry=1628.805 sl=1618.866052 tp1=1643.84 filter=ACCUM:PD_DISCOUNT|MID_OK; 2023-10-22 13:05 🧠 phase=ACCUMULATION | MFE=0.44R | impr=0 | fuel=0.57; 2023-10-22 13:10 🧠 phase=ACCUMULATION | MFE=0.44R | impr=0 | fuel=0.57; 2023-10-22 13:15 🧠 phase=ACCUMULATION | MFE=0.44R | impr=0 | fuel=0.57; 2023-10-22 13:20 🧠 phase=ACCUMULATION | MFE=0.51R | impr=0 | fuel=0.57; 2023-10-22 13:25 🧠 phase=ACCUMULATION | MFE=0.72R | impr=0 | fuel=0.57; 2023-10-22 13:30 🧠 phase=ACCUMULATION | MFE=0.72R | impr=0 | fuel=0.57; 2023-10-22 13:35 🧠 phase=ACCUMULATION | MFE=0.72R | impr=0 | fuel=0.57; 2023-10-22 13:40 🧠 phase=ACCUMULATION | MFE=0.72R | impr=0 | fuel=0.57; 2023-10-22 13:45 🧠 phase=ACCUMULATION | MFE=0.72R | impr=0 | fuel=0.57; 2023-10-22 13:50 🧠 phase=ACCUMULATION | MFE=0.72R | impr=0 | fuel=0.57; 2023-10-22 13:55 🧠 phase=ACCUMULATION | MFE=0.81R | impr=0 | fuel=0.57; 2023-10-22 14:00 🧠 phase=ACCUMULATION | MFE=0.81R | impr=0 | fuel=0.57; 2023-10-22 14:05 🧠 phase=ACCUMULATION | MFE=0.81R | impr=0 | fuel=0.57; 2023-10-22 14:10 🧠 phase=ACCUMULATION | MFE=0.81R | impr=0 | fuel=0.57
- **Why:** BIAS BULLISH conf100 zone=DISCOUNT | SWEEP SSL Q83.6 lvl=1629.05 | DISP 2.24x 76.5% conv=71.7 | FVG 1627.98-1629.63 CE=1628.805 | Filter ACCUM:PD_DISCOUNT|MID_OK

#### #7 BULLISH 2023-10-30 07:00→2023-10-30 12:05 PnL +8.077% MFE 10.38R
- **Layer1 BIAS:** BULLISH conf 90 zone PREMIUM reason HH+HL | Zone=PREMIUM | Confidence=90
- **Layer2 Sweep:** SSL lvl 1782.12 wick 1778.03 Q 90.5
- **Layer3 Disp:** BULLISH 2.93x 78.0% conv 94.2 | FVG 1781.16-1783.26 CE 1782.21
- **Layer4 Plan:** entry 1782.21 sl 1777.693352 risk 4.52 atr 2.24 sl_atr 2.01 tp1 {'price': 1790.56, 'kind': 'SWING', 'rr': 1.85, 'dist': 8.349999999999909} tp2 {'price': 1854.87, 'kind': 'HTF_DRAW', 'rr': 16.09} tp3 1854.87
- **Session:** LONDON_KILLZONE 2023-10-30 03:00 NY (Mon) | Filter 
- **MFE/MAE:** MFE 10.378318584070765R MAE 0R | Exit A=A_TRAIL B=B_FORTRESS C=C_FORTRESS
- **Events:** 2023-10-30 07:00 OPEN entry=1782.21 sl=1777.693352 tp1=1790.56 filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(94)+OB_HELD → old Premium is new Discount for DOL 1872.64. Mitigation Block continuation per ICT. LONG only.|MID_OK; 2023-10-30 07:05 🧠 phase=ACCUMULATION | MFE=2.00R | impr=0 | fuel=0.87; 2023-10-30 07:05 🎯 A:TP1; 2023-10-30 07:05 📣 PARTIAL_TAKEN→fortresses_active; 2023-10-30 07:10 🧠 phase=ACCUMULATION | MFE=2.35R | impr=0 | fuel=0.85; 2023-10-30 07:15 🧠 phase=ACCUMULATION | MFE=2.35R | impr=0 | fuel=0.85; 2023-10-30 07:20 🧠 phase=ACCUMULATION | MFE=2.35R | impr=0 | fuel=0.85; 2023-10-30 07:25 🧠 phase=ACCUMULATION | MFE=2.35R | impr=0 | fuel=0.85; 2023-10-30 07:30 🧠 phase=ACCUMULATION | MFE=2.35R | impr=0 | fuel=0.85; 2023-10-30 07:35 🧠 phase=ACCUMULATION | MFE=2.35R | impr=0 | fuel=0.85; 2023-10-30 07:40 🧠 phase=ACCUMULATION | MFE=2.35R | impr=0 | fuel=0.85; 2023-10-30 07:45 🧠 phase=ACCUMULATION | MFE=2.35R | impr=0 | fuel=0.85; 2023-10-30 07:50 🧠 phase=ACCUMULATION | MFE=2.35R | impr=0 | fuel=0.85; 2023-10-30 07:55 🧠 phase=ACCUMULATION | MFE=2.35R | impr=0 | fuel=0.85; 2023-10-30 08:00 🧠 phase=ACCUMULATION | MFE=2.35R | impr=0 | fuel=0.85
- **Why:** BIAS BULLISH conf90 zone=PREMIUM | SWEEP SSL Q90.5 lvl=1782.12 | DISP 2.93x 78.0% conv=94.2 | FVG 1781.16-1783.26 CE=1782.21 | Filter ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(94)+OB_HELD → old Premium is new Discount for DOL 1872.64. Mitigation Block continuation per ICT. LONG only.|MID_OK
