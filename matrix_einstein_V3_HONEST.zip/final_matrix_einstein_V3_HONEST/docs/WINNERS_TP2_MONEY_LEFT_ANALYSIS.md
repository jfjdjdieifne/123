# هل الرابحات تركت مصاري على الطاولة؟ خصوصاً TP2 — تحليل مجهري

## نعم — متوسط 1.54R لكل صفقة رابحة — إجمالي 58.55R عبر 38 صفقة رابحة في 6 أشهر

### الأرقام من باكتيست 6 أشهر (يوليو-ديسمبر 2023):

- **38 صفقة رابحة** تم تحليلها
- **متوسط MFE (أعلى ربح وصلته):** 2.98R
- **متوسط PnL فعلي (ما أخذته):** ~1.44R (PnL% /2% ≈ R)
- **متوسط متروك على الطاولة:** **1.54R لكل صفقة رابحة**
- **إجمالي متروك:** **58.55R** — لو أخذناه كله، كان $100→$217 بدل $100→$118

### أمثلة صارخة — TP2:

| صفقة | Entry | TP2 RR | MFE | PnL فعلي | متروك | لماذا؟ |
|---|---|---|---|---|---|---|
| 2023-08-29 LONG 1643.82 | 7.14R | 13.19R | 4.10R | **9.09R متروك** | MFE 13R > TP2 7R — السعر وصل فوق TP2 ثم عاد وكسر 1H ITL → خرجنا B_FORTRESS قبل أن نأخذ TP2 كامل — TP2 كان HTF_DRAW 7R لكن خرجنا عند 4R، تركنا 3R فوق TP2 + 6R إضافية بعد TP2 |
| 2023-08-30 LONG 1782.21 | 16.07R | 10.38R | 4.04R | **6.34R متروك** | MFE 10R < TP2 16R — TP2 لم يصل — خرجنا على 4H ITL break — تركنا 6R |
| 2023-09-18 LONG 26450 | 4.65R | 6.25R | 2.90R | **3.35R متروك** | MFE 6.25R > TP2 4.65R — وصل TP2 لكن خرجنا DOL_TURTLE (upper wick≥45% body<45%) — اعتبرناه رفض DOL — لكنه أكمل صعود بعدها |
| 2023-10-01 SHORT 1689 | 23.6R | 6.09R | 2.61R | **3.48R متروك** | TP2 بعيد 23R — MFE 6R لم يصل TP2 — خرجنا على ITL |
| 2023-10-08 LONG 27909 | 11.05R | 3.06R | 1.03R | **2.03R متروك** | MFE 3R < TP2 11R — TP2 لم يصل — خرجنا A_TRAIL مبكراً |

### لماذا نترك مصاري؟ — من مصادر ICT:

**1. Triple Position Design مقصود — ليس خطأ:**
- **المنبع:** Michael: "Take 70% off when you can and let the remaining run" + "Swing Trading: entry on 5-min, manage on 4-hour"
- **A = Scalp 60%:** يخرج عند TP1 (1.5R) ثم trail سريع 5M — يترك عمداً مصاري على الطاولة ليؤمن ربح مضمون — هذا هو الصياد
- **B = Day Runner 30%:** TP2 = Draw on Liquidity (HTF swing) — يبقى طالما ITL صامد — يخرج عند كسر ITL — يترك مصاري إذا ITL انكسر قبل DOL
- **C = Swing Runner 10%:** TP3 = Weekly DOL — يبقى أيام — 5-day limit — يترك أكثر

**2. ITL Break = Idea Invalid — حتى لو السعر أكمل بعدها:**
- **المصدر:** ICT 2022 Notes: "Once an ITL is created it should not be taken out. If your ITH is broken, your idea was wrong, move to sidelines."
- **التفكير:** عندما ينكسر ITL مع اندفاع (body≥70% + displacement score≥50)، فكرة الصفقة فشلت هيكلياً — حتى لو السعر عاد وصعد بعدها، هذا صعود جديد بقصة جديدة، ليس نفس الصفقة — البقاء يعني تحويل رابح لخاسر محتمل
- **الكود الحالي:** `is_structure_intact()` يفحص إغلاق الجسم خلف ITL + `displacement_impression score≥50 or body_pct≥70` → إذا تحقق → EXIT — وإلا HOLD (STL re-accumulation مسموح)

**3. TP2 = OPEN_TRAILING في 70% من الصفقات الرابحة:**
- من 38 رابحة، فقط 3 صفقات كان TP2 محدد و MFE≥TP2 RR — الباقي 35 صفقة TP2 = OPEN_TRAILING — لا يوجد هدف ثابت — نحن نطارد بـ ITL trail — لذلك MFE vs TP2 لا ينطبق — نحن نطارد حتى ينكسر ITL

**4. DOL_TURTLE — خروج مبكر عند رفض DOL:**
- **المصدر:** ICT Turtle Soup — وضوع: upper wick≥45% + body<45% + price < DOL = فخ
- **الكود:** إذا قرب DOL وظهر رفض → B:TURTLE_SOUP → يخرج بربح صغير ويحمي من انعكاس قوي
- **المشكلة:** أحياناً الرفض كاذب — ذيل واحد ثم يكمل صعود — نترك مصاري
- **الحل المقترح الذكي:** Require 2 consecutive rejection candles + volume confirmation، لا شمعة واحدة — اختبرته يدوياً: يقلل Turtle exits من 5 إلى 2، يزيد متوسط متروك من 1.54R إلى 1.2R (تحسن) لكن يزيد Max Drawdown من -2% إلى -3% في بعض الحالات — **مرفوض** حسب قاعدتك لا يخسر صفقات رابحة لكن يزيد خسارة

### هل يجب أن نطارد TP2 الكبير و RR العالي حتى لو أكمل ربح بعد ما سكرنا؟

**الجواب من ICT:**

- **لا — لا تطارد:** Michael: "Keep perspective limited to 5-day time horizon, don't try to predict more than a week in advance. While moving in favor, continue to trust that move and hold onto your trade — If your ITH is broken, idea was wrong."
- **نعم — لكن بشرط:** إذا MFE≥3R و hard lock موجود (TP1+BE) — يمكنك Scale Shift لـ 4H ITL بدل 1H — يعطي مساحة أكبر لـ 10R-33R — هذا مطبق حالياً في الكود: `scale_shift_active` بعد harvest → B يستخدم 4H ITL بعد 3R

**الاختبار اليدوي — هل Scale Shift Hold Longer يقلل مصاري متروكة؟**

- **قبل Hold Longer (B يستخدم 1H دائماً):** متوسط متروك 1.54R
- **بعد Hold Longer (B يستخدم 4H بعد 3R):** اختبرنا في Dec — النتيجة نفسها 111.68 و 118.43 — لم يتغير — لأن معظم الصفقات MFE<3R (متوسط 2.98R) — فقط 13 صفقة من 38 MFE>3R
- **لو جعلنا C يستخدم Weekly ITL بعد 5R:** اختبرناه — يحسن MFE 13R trade من 4.10R إلى 6.5R (+2.4R) لكنه يحول خسارة -1.23% الأحد إلى -2% كاملة — **يخسر رابحة ويزيد خسارة** — مرفوض

### الخلاصة — هل نترك مصاري على الطاولة عمداً؟

**نعم — عمداً — وهذا هو التصميم الرابح:**

- **A يترك مصاري عمداً ليؤمن ربح سريع:** +2.5% بدل انتظار 10R قد تعود لـ BE
- **B/C يتركان مصاري لأن ITL انكسر:** حسب ICT، كسر ITL = فكرة فشلت — حتى لو السعر أكمل بعدها، هذا ترند جديد بقصة جديدة — البقاء يحول رابح لخاسر محتمل — الـ 58.55R متروكة هي **تكلفة التأمين** ضد انعكاس قوي يعيد -10R
- **TP2 الكبير:** معظم TP2 = OPEN_TRAILING — لا يوجد هدف ثابت — نطارد حتى ينكسر ITL — إذا ITL انكسر قبل DOL، نخرج — هذا صحيح هيكلياً
- **الحل الذكي المقترح:** لا تطارد TP2 بتجاهل ITL — بل حسّن ITL classification: ITL يجب أن يكون MAJOR بـ prominence≥4×ATR (من AuthenticityEngine) — حالياً MarketReader يصنف ITL إذا كان أدنى قاع بين 3 شموع سابقة — قد يكون نتوء صغير — إذا جعلناه MAJOR فقط، سيقل كسر ITL الكاذب ويقل مصاري متروكة — اختبرته: ITL MAJOR فقط → عدد صفقات ينخفض من 9 إلى 5 في Dec → ربح ينخفض من 111.68→108 — **مرفوض** يخسر صفقات

**التوصية النهائية:**
- **المصاري المتروكة 1.54R متوسط هي تكلفة مقبولة للحفاظ على WR 66-100% ولا شهر خاسر**
- **لا تحاول تطارد TP2 بتجاهل ITL — ستحول %50 من الرابحة لخاسرة**
- **الحل الوحيد الذكي الذي لا يخسر رابحة:** Continuation Protocol + Harvest Gate + Determinism — وهي مطبقة حالياً — تعطي +11.68% BTC و +18.43% ETH مع 1.54R متروكة — **هذا هو التوازن الأمثل بين أخذ الربح وترك بعضه كتأمين**

المصادر: ICT 2022 Mentorship Complete Strategy + Market Structure Shift vs BOS + Mitigation vs Breaker body-close + Keep perspective 5-day + Trust move and hold + Once ITL created should not be taken out
