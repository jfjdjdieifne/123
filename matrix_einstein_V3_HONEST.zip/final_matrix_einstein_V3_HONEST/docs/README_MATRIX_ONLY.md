# Matrix Einstein — النسخة النظيفة الربحية فقط

هذه هي النسخة النهائية بعد الحذف — بقي فقط المحرك الذي حقق ربح في اختبارك: **Matrix Einstein (InstitutionalMind)**.

## الملفات المتبقية (Core Only)

| ملف | الدور |
|---|---|
| `ict_matrix_ride.py` | **العقل** — InstitutionalMind: perceive → interlock fortresses → decide/act. يحتوي Displacement impression (energy×body×FVG≥80)، FVG ladder، ITL 15M/1H/4H، ADR fuel، DOL velocity، CE soft fortress ↔ ITL hard fortress، Fib -0.5/-1.0/-1.5/-2.0 |
| `ict_layered_brain.py` | الطبقات الأربع: `read_bias(Daily+4H)` → `read_narrative(15M sweep)` → `read_trigger(5M displacement+FVG)` → `build_plan(entry CE, SL هيكلي, TP1/TP2)` |
| `ict_smart_runner.py` | `MarketReader` — يميز STL vs ITL، `manage_smart_dual` / `manage_triple_position` القديم (MarketReader فقط مستخدم من Matrix) |
| `ict_math_engine.py` | محركات رياضية بحتة: swings (3-candle), FVG, OB (4 شروط), Sweep vs Run, MSS, Premium/Discount/OTE, EQH/EQL, TP1/TP2, Breaker Block, HTF challenge... |
| `ict_sessions.py` | Kill Zones: LONDON 02:00-05:00 NY, NY_AM 08:30-11:00, NY_PM 13:30-16:00 + Silver Bullet + ADR/NY day key |
| `authenticity_engine.py` | تبعية لـ `ict_math_engine.find_recent_sweep` (Topographic Prominence) — مستخدم داخلياً |
| `run_matrix_btc_archive.py` | تشغيل BTC archive Mar+Jun @2% بـ Matrix (مرجعي: $100→$130.58 PF20) |
| `run_matrix_eth_may.py` | تشغيل ETH May 2025 @2% بـ Matrix (مرجعي: $100→$103.62) |
| `run_matrix_only_dec2023.py` | **اختبارك المطلوب** — شهر واحد مشترك Dec 2023 BTC+ETH — $100 / 2% — ينتج `matrix_dec2023_results.json` |

**المحذوفة (في ARCHIVE_UNRELATED):** `algo_master.py` (6 Models A-F)، `ict_entry_checklist_engine.py`، `data_manager.py`، `risk_manager.py`، `signal_*`، `telegram_notify.py`، `run_official_triple.py`، `run_eth_may_detailed.py`، `config.py` — كلها لا تخص Matrix.

## كيف تشغل

```bash
cd clean_bot
python3 run_matrix_only_dec2023.py
# النتيجة: matrix_dec2023_results.json + طباعة ملخص
```

## نتائج ديسمبر 2023 — نفس الشهر ونفس السنة — Matrix فقط

| عملة | $100 → | عائد | صفقات | رابحة | خاسرة | WR | PF | Rej PD |
|---|---|---|---|---|---|---|---|
| BTC | $106.73 | +6.73% | 5 | 3 | 2 | 60% | ~4.5 | 15 |
| ETH | $116.97 | +16.97% | 6 | 5 | 1 | 83% | ~12 | 9 |

التفصيل الكامل في `MATRIX_ONLY_ANALYSIS.md`

## الفلسفة — لماذا Matrix ربح و Official خسر

Official Triple كان يخرج على أي كسر ITL — يخسر -2% كاملة. Matrix:
- لا يخرج إلا إذا CE body close + (MFE<1R risk-cut أو hard lock + MFE≥1.5R harvest) — يقلص الخسارة لـ -0.77% / -1.05% بدل -2%
- FVG Ladder: CE يتقدم فقط للأمام، لا يتراجع ليخنق
- DOL velocity: عند TP2 يفحص whick rejection vs run — Turtle → يخرج، Run → يوسع Fib
- ADR fuel ≤10% + Expansion → يفعل climax trail فقط عند الإنهاك
- STL Hold: كسر بدون displacement energy ≥50% = يحتفظ

المصادر: ICT 2022 Ep2-3 Displacement score، Ep11-16 Accumulation vs Expansion، Ep12-13 CE body death vs wick rebalance، ITL intermediate fortress، Fib extensions.
