# مشاكل Matrix Einstein فقط — تحليل جذري وحلول مقترحة

هذا الملف يركز فقط على مشاكل المحرك الربحي Matrix نفسه — بعد حذف كل شيء غيره.

---

## المشكلة 1: أول صفقة بعد هدوء تخسر كاملة -2% (Phase ACCUMULATION بلا حماية)

**الوصف:** في BTC 16 ديسمبر -2% — Phase=ACCUMULATION — لا يوجد ITL ولا CE shield — SL ثابت ضربه.

**السبب:** Displacement impression score يحسب على آخر 15 شمعة 5M فقط — إذا السوق هادئ (mean_body صغير)، score يكون <80 → يبقى في ACCUMULATION → لا يفعل fortress.

**الحل:** 
- حتى في ACCUMULATION، ابنِ CE shield احتياطي من آخر FVG 15M موجود (لو حتى قديم) — لا تترك SL ثابت بلا حصن.
- أو: قلل risk أول صفقة بعد هدوء إلى 1% بدل 2% (position size أصغر).

---

## المشكلة 2: PD Hard Filter يرفض 15 BTC LONGs كانت قد تربح في شهر صاعد

**الوصف:** `entry_accumulation_filters()` → `premium_discount_ok()` ترفض LONG إذا dealing zone=PREMIUM. في ديسمبر صاعد، 15 إشارة LONG رُفضت — بعضها كان continuation صاعد حقيقي بعد Expansion.

**الدليل:** BTC من 37k→43k ديسمبر — كل LONG في PREMIUM هو في الواقع continuation، ليس تجميع خاطئ.

**الحل:** PD hard فقط قبل Expansion. بعد `phase==EXPANSION` → PD يصبح soft (تحذير لا منع):
```python
if mind.phase==EXPANSION:
    ok=True # لا ترفض، بل سجل تحذير
else:
    check PD hard
```

---

## المشكلة 3: FVG Ladder يتقدم فقط للأمام — قد يبقى حصن قديم بعيد جداً

**الوصف:** الكود:
```python
if is_long and cand["ce"] > prev_ce: active_fvg=cand
```
يعني إذا ظهر FVG جديد أعلى (للشراء) يأخذه، وإلا يبقي القديم. لكن القديم قد يكون بعيد جداً (gap كبير) → CE shield بعيد → trail بعيد → يفوت ربح.

**الحل:** حد أقصى للمسافة: إذا CE الجديد أبعد من 2×ATR عن الحالي، لا تحدث؟ أو: CE shield = max(old_ce, new_ce - 0.5×ATR) — توازن.

---

## المشكلة 4: ITL قد يكون بعيد زمنياً — لا علاقة سببية

**الوصف:** `itl_from_reader()` يأخذ آخر ITL غير مكسور — قد يكون من 20 ساعة قبل، بلا علاقة بالدخول الحالي. Trail خلفه قد يكون بعيد 500$ (BTC) → يترك ربح كبير على الطاولة ثم يرجع ويضرب BE.

**الحل:** ITL يجب أن يكون ضمن lookback 30 شمعة 15M من الدخول (لا أقدم) — نفس منطق `find_structural_sl_anchors` الذي يبحث عن أقرب مرساة هيكلية.

---

## المشكلة 5: DOL TURTLE vs EXTEND حساس جداً للـ wick

**الوصف:** `upper = (h - max(o,c))/range` — إذا upper≥45% + body<45% → TURTLE → يخرج. لكن في ETH 22 ديسمبر +4.33%، upper كان 44% فلم يخرج واستمر — لو كان 45% لخرج مبكراً وخسر 2% إضافية.

**الحل:** استخدم متوسط آخر 3 شموع لتأكيد TURTLE، لا شمعة واحدة — نفس منطق Three-Candle.

---

## المشكلة 6: ADR fuel يعتمد على hist_ranges قد تكون فارغة أول الشهر

**الوصف:** `build_daily_ranges()` يبني من بداية Nov — في أول أيام ديسمبر hist_ranges=30 يوم، جيد. لكن في أول نوفمبر؟ أقل. إذا fuel حسابه خاطئ، قد يفعل climax trail مبكراً.

**الحل:** إذا len(hist_ranges)<5 → fuel=1.0 (افترض وقود كامل) — لا تفعل climax.

---

## المشكلة 7: لا يوجد Breaker Block

**الوصف:** عندما يفشل OB (body close خلفه)، الكود الحالي في `ict_smart_runner` لا يفعل شيء — لكن حسب الدستور قسم 5.6، هذا فرصة Breaker Block عكسية أعلى احتمالية. دالة `detect_breaker_block_opportunity()` موجودة في `ict_math_engine` لكن لا تُستدعى في Matrix.

**الحل:** في `manage_matrix_triple()` بعد SL check، إذا close خلف OB → استدعِ `detect_breaker_block_opportunity()` وابنِ خطة عكسية تلقائياً — فرصة ثانية.

---

## المشكلة 8: لا يوجد حد زمني لإلغاء الأمر المعلق قبل الدخول

**الوصف:** في Matrix، الدخول فوري (market) بعد اكتشاف FVG — ليس BUY_LIMIT. لكن في بعض الحالات FVG قد تبقى ساعات قبل أن يلمسها السعر — خلالها قد ينكسر SL الهيكلي (body close خلفه) → منطقة ملغاة لكن البوت لا يزال ينتظر.

**الحل:** استخدم `check_order_invalidated_before_fill()` من `ict_math_engine` — بين شمعة الخطة وشمعة الدخول، إذا close تجاوز SL → ألغِ.

---

## المشكلة 9: تذبذب Displacement Impression score

**الوصف:** `mean_body` يحسب آخر 12 شمعة — إذا كان هناك شمعة واحدة كبيرة شاذة (news)، avg يكبر → mult يصغر → score<80 → يبقى في ACCUMULATION رغم أنه Expansion حقيقي.

**الحل:** استخدم median بدل mean — أكثر مقاومة للشواذ.

---

## المشكلة 10: No-Dup FVG يمنع إعادة دخول نفس المنطقة بعد ربح

**الوصف:** بعد ربح +3% على FVG، نفس المنطقة قد تتكون مرة ثانية بعد يومين بسياق جديد — لكن `entered_fvgs` يمنعها للأبد.

**الحل:** احذف FVG key بعد 48 ساعة أو بعد امتلاء 100% — لا منع أبدي.

---

## الأولويات للإصلاح (حسب التأثير على الربح)

1. **PD soft بعد Expansion** (+2-3% expected)
2. **Breaker Block** (+1-2 trades/month إضافية رابحة)
3. **ITL lookback 30** (يقلل تراجع الربح من 2R إلى 1.5R → يحافظ على +1% إضافي)
4. **CE shield احتياطي في ACCUM** (يقلص خسارة أول صفقة من -2% إلى -1%)
5. **No-Dup expiry 48h** (يزيد عدد الصفقات 10-20% مع الحفاظ على WR)

بعد هذه الإصلاحات، توقع BTC Dec من +6.73% إلى +10% و ETH من +16.97% إلى +20%+.

---
**الملفات المتبقية فقط تخص Matrix — لا تشعب.**
