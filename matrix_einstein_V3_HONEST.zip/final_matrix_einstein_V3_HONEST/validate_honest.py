#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
validate_honest.py — اختبار متانة النموذج الصادق عبر أشهر متعددة (تجنب overfitting)
يشغل CE_HONEST@72 على عدة أشهر ويطبع جدول مقارنة.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import run_honest as rh

rh.LIMIT_TIMEOUT = 72
rh.MARKET_CONT = False

btc_rows = rh.load_csv(rh.BTC_PATH, ['2023-0', '2023-1'])
eth_rows = rh.load_csv(rh.ETH_PATH, ['2023-11', '2023-12'])

print("\n" + "=" * 90)
print("  التحقق من المتانة — CE_HONEST @ timeout=72 (6h) — BTC أشهر متعددة + ETH")
print("=" * 90)
print(f"{'الشهر':<10}{'الرمز':<10}{'صفقات':<8}{'W':<5}{'L':<5}{'ألغيت':<8}{'العائد%':<10}")
print("-" * 90)

totals = {}
for sym, rows, months in [('BTC', btc_rows, ['2023-07','2023-08','2023-09','2023-10','2023-11','2023-12']),
                           ('ETH', eth_rows, ['2023-11','2023-12'])]:
    t = totals.setdefault(sym, {'trades':0,'w':0,'l':0,'canc':0})
    for m in months:
        res = rh.run_honest(sym+'USDT', rows, m, 'CE_HONEST')
        tr = res['trades']
        w = len([x for x in tr if (x.get('pnl_dollar',0) or 0) > 0.01])
        l = len([x for x in tr if (x.get('pnl_dollar',0) or 0) < -0.01])
        c = len(res['cancelled'])
        t['trades'] += len(tr); t['w'] += w; t['l'] += l; t['canc'] += c
        print(f"{m:<10}{sym:<10}{len(tr):<8}{w:<5}{l:<5}{c:<8}{res['return_pct']:+<10}")

print("-" * 90)
for sym, t in totals.items():
    print(f"  إجمالي {sym}: صفقات={t['trades']} W={t['w']} L={t['l']} ألغيت(صادق)={t['canc']}")
print("=" * 90)
print("  ملاحظة: كل صفقة مسجّلة لمس سعر الدخول فعلاً. أي setup لم يُلمس = مُلغى (لا ربح ولا خسارة).")
