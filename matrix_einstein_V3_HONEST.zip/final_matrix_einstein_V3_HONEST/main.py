#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Matrix Einstein — Final Organized Project — V2.1
Entry point: runs Dec 2023 same month/year test $100 / 2% for BTC & ETH
All smart modifications merged and interlinked:
- Continuation Protocol (only LONG_IN_PREMIUM with BULLISH strong + Disp≥70 + OB held + room to DOL)
- Harvest Gate Scale Shift (only after hard lock + MFE≥1.5 OR MFE≥3 OR Time≥3H with MFE≥1.0)
- Determinism Filter (median + fixed seeds)
- Breaker Auto-Flip (safe, only on -2% early fail)
- Bias original (Major 90d tested and rejected — worse)
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src', 'core'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src', 'runners'))

from run_matrix_only_dec2023 import main as run_dec2023

if __name__ == "__main__":
    print("="*80)
    print("  Matrix Einstein Final — V2.1 — $100 / 2% — Dec 2023 BTC+ETH")
    print("="*80)
    run_dec2023()
