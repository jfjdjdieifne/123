# تقرير مفصل — 2023-09 — BTC & ETH نفس الشهر نفس السنة — Matrix V2.1 — $100 / 2%


## BTCUSDT — 2023-09 — $100→$105.17 (5.17%) — 5 صفقات W=3 L=2

| # | دخول | خروج | Bias | Entry | SL | TP1 | TP2 | PnL% | $ | Bal | A | B | C | MFE | Session | Sweep Q | Disp Conv | Why |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 2023-09-10 19:00 | 2023-09-10 20:15 | BULLISH | 25783.81 | 25748.86 | 25844.26 | 26040.00 | -2.000 | -2.00 | 98.00 | SL | SL | SL | 1.46R | NY_PM_KILLZONE | 62.3 | 100.0 | BIAS BULLISH conf95 zone=DISCOUNT | SWEEP SSL Q62.3 lvl=25797.0 | DISP 3.71x 100.0% conv=100 | FVG 25782.62-25785.0 CE=2 |
| 2 | 2023-09-11 19:00 | 2023-09-11 19:35 | BULLISH | 25653.69 | 25566.36 | 25786.96 | 26040.00 | -2.000 | -1.96 | 96.04 | SL | SL | SL | 1.16R | NY_PM_KILLZONE | 82.7 | 70.5 | BIAS BULLISH conf75 zone=DISCOUNT | SWEEP SSL Q82.7 lvl=25663.81 | DISP 2.07x 89.5% conv=70.5 | FVG 25641.91-25665.47 CE |
| 3 | 2023-09-18 08:00 | 2023-09-18 15:20 | BULLISH | 26450.58 | 26371.34 | 26589.19 | 26819.27 | +5.791 | +5.56 | 101.60 | A_TRAIL | DOL_TURTLE | C_FORTRESS | 6.25R | LONDON_KILLZONE | 80.9 | 99.1 | BIAS BULLISH conf100 zone=DISCOUNT | SWEEP SSL Q80.9 lvl=26438.61 | DISP 3.29x 88.6% conv=99.1 | FVG 26430.0-26471.17 CE |
| 4 | 2023-09-19 08:00 | 2023-09-19 14:15 | BULLISH | 26738.58 | 26619.97 | 26943.83 | 27587.51 | +2.668 | +2.71 | 104.31 | A_TRAIL | B_FORTRESS | C_FORTRESS | 2.18R | LONDON_KILLZONE | 85.2 | 98.4 | BIAS BULLISH conf90 zone=PREMIUM | SWEEP SSL Q85.2 lvl=26728.0 | DISP 4.08x 85.3% conv=98.4 | FVG 26736.08-26741.09 CE=2 |
| 5 | 2023-09-29 07:00 | 2023-09-29 11:00 | BEARISH | 27061.15 | 27313.69 | 26557.98 | 26224.00 | +0.823 | +0.86 | 105.17 | CE_RISK_CUT | CE_RISK_CUT | CE_RISK_CUT | 0.80R | LONDON_KILLZONE | 94.7 | 99.1 | BIAS BEARISH conf75 zone=PREMIUM | SWEEP BSL Q94.7 lvl=27052.35 | DISP 3.63x 94.2% conv=99.1 | FVG 27056.8-27065.5 CE=27 |

### تفصيل كل صفقة — شو شاف وشو عمل ليش


#### #1 BULLISH 2023-09-10 19:00→2023-09-10 20:15 PnL -2.000% MFE 1.46R
- **Layer1 BIAS:** BULLISH conf 95 zone DISCOUNT reason HH+HL | Zone=DISCOUNT | Confidence=95
- **Layer2 Sweep:** SSL lvl 25797.0 wick 25793.4 Q 62.3
- **Layer3 Disp:** BULLISH 3.71x 100.0% conv 100.0 | FVG 25782.62-25785.0 CE 25783.809999999998
- **Layer4 Plan:** entry 25783.81 sl 25748.858872 risk 34.95 atr 9.94 sl_atr 3.52 tp1 {'price': 25844.26, 'kind': 'SWING', 'rr': 1.73, 'dist': 60.45000000000073} tp2 {'price': 26040.0, 'kind': 'HTF_DRAW', 'rr': 7.33} tp3 26299.0
- **Session:** NY_PM_KILLZONE 2023-09-10 15:00 NY (Sun) | Filter 
- **MFE/MAE:** MFE 1.459513590844017R MAE 1.1888412017168213R | Exit A=SL B=SL C=SL
- **Events:** 2023-09-10 19:00 OPEN entry=25783.81 sl=25748.858872 tp1=25844.26 filter=ACCUM:PD_DISCOUNT|MID_OK; 2023-09-10 19:05 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.97; 2023-09-10 19:10 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.97; 2023-09-10 19:15 🧠 phase=ACCUMULATION | MFE=1.26R | impr=0 | fuel=0.97; 2023-09-10 19:20 🧠 phase=ACCUMULATION | MFE=1.46R | impr=0 | fuel=0.97; 2023-09-10 19:25 🧠 phase=ACCUMULATION | MFE=1.46R | impr=0 | fuel=0.97; 2023-09-10 19:30 🧠 phase=ACCUMULATION | MFE=1.46R | impr=0 | fuel=0.97; 2023-09-10 19:35 🧠 phase=ACCUMULATION | MFE=1.46R | impr=0 | fuel=0.97; 2023-09-10 19:40 🧠 phase=ACCUMULATION | MFE=1.46R | impr=0 | fuel=0.97; 2023-09-10 19:45 🧠 phase=ACCUMULATION | MFE=1.46R | impr=0 | fuel=0.97; 2023-09-10 19:50 🧠 phase=ACCUMULATION | MFE=1.46R | impr=0 | fuel=0.97; 2023-09-10 19:55 🧠 phase=ACCUMULATION | MFE=1.46R | impr=0 | fuel=0.97; 2023-09-10 20:00 🧠 phase=ACCUMULATION | MFE=1.46R | impr=0 | fuel=0.97; 2023-09-10 20:05 🧠 phase=ACCUMULATION | MFE=1.46R | impr=0 | fuel=0.97; 2023-09-10 20:10 🧠 phase=ACCUMULATION | MFE=1.46R | impr=0 | fuel=0.97
- **Why:** BIAS BULLISH conf95 zone=DISCOUNT | SWEEP SSL Q62.3 lvl=25797.0 | DISP 3.71x 100.0% conv=100 | FVG 25782.62-25785.0 CE=25783.809999999998 | Filter ACCUM:PD_DISCOUNT|MID_OK

#### #2 BULLISH 2023-09-11 19:00→2023-09-11 19:35 PnL -2.000% MFE 1.16R
- **Layer1 BIAS:** BULLISH conf 75 zone DISCOUNT reason HH+HL | Zone=DISCOUNT | Confidence=75
- **Layer2 Sweep:** SSL lvl 25663.81 wick 25625.29 Q 82.7
- **Layer3 Disp:** BULLISH 2.07x 89.5% conv 70.5 | FVG 25641.91-25665.47 CE 25653.690000000002
- **Layer4 Plan:** entry 25653.69 sl 25566.364224 risk 87.33 atr 28.04 sl_atr 3.11 tp1 {'price': 25786.96, 'kind': 'SWING', 'rr': 1.53, 'dist': 133.2699999999968} tp2 {'price': 26040.0, 'kind': 'HTF_DRAW', 'rr': 4.42} tp3 26299.0
- **Session:** NY_PM_KILLZONE 2023-09-11 15:00 NY (Mon) | Filter 
- **MFE/MAE:** MFE 1.1611130195809167R MAE 2.7888469025535243R | Exit A=SL B=SL C=SL
- **Events:** 2023-09-11 19:00 OPEN entry=25653.69 sl=25566.364224 tp1=25786.96 filter=ACCUM:PD_DISCOUNT|MID_OK; 2023-09-11 19:05 🧠 phase=ACCUMULATION | MFE=1.16R | impr=0 | fuel=0.79; 2023-09-11 19:10 🧠 phase=ACCUMULATION | MFE=1.16R | impr=0 | fuel=0.79; 2023-09-11 19:15 🧠 phase=ACCUMULATION | MFE=1.16R | impr=0 | fuel=0.79; 2023-09-11 19:20 🧠 phase=ACCUMULATION | MFE=1.16R | impr=0 | fuel=0.79; 2023-09-11 19:25 🧠 phase=ACCUMULATION | MFE=1.16R | impr=0 | fuel=0.79; 2023-09-11 19:30 🧠 phase=ACCUMULATION | MFE=1.16R | impr=0 | fuel=0.79; 2023-09-11 19:35 ❌ A:SL; 2023-09-11 19:35 ❌ B:SL; 2023-09-11 19:35 ❌ C:SL
- **Why:** BIAS BULLISH conf75 zone=DISCOUNT | SWEEP SSL Q82.7 lvl=25663.81 | DISP 2.07x 89.5% conv=70.5 | FVG 25641.91-25665.47 CE=25653.690000000002 | Filter ACCUM:PD_DISCOUNT|MID_OK

#### #3 BULLISH 2023-09-18 08:00→2023-09-18 15:20 PnL +5.791% MFE 6.25R
- **Layer1 BIAS:** BULLISH conf 100 zone DISCOUNT reason HH+HL | Zone=DISCOUNT | Confidence=100
- **Layer2 Sweep:** SSL lvl 26438.61 wick 26415.06 Q 80.9
- **Layer3 Disp:** BULLISH 3.29x 88.6% conv 99.1 | FVG 26430.0-26471.17 CE 26450.585
- **Layer4 Plan:** entry 26450.585 sl 26371.341198 risk 79.24 atr 40.06 sl_atr 1.98 tp1 {'price': 26589.19, 'kind': 'SWING', 'rr': 1.75, 'dist': 138.60499999999956} tp2 {'price': 26819.27, 'kind': 'HTF_DRAW', 'rr': 4.65} tp3 28142.85
- **Session:** LONDON_KILLZONE 2023-09-18 04:00 NY (Mon) | Filter 
- **MFE/MAE:** MFE 6.246403331650684R MAE 0R | Exit A=A_TRAIL B=DOL_TURTLE C=C_FORTRESS
- **Events:** 2023-09-18 08:00 OPEN entry=26450.585 sl=26371.341198 tp1=26589.19 filter=ACCUM:PD_DISCOUNT|MID_OK; 2023-09-18 08:05 🧠 phase=ACCUMULATION | MFE=2.83R | impr=0 | fuel=0.47; 2023-09-18 08:05 🎯 A:TP1; 2023-09-18 08:05 📣 PARTIAL_TAKEN→fortresses_active; 2023-09-18 08:10 🧠 phase=ACCUMULATION | MFE=2.83R | impr=0 | fuel=0.47; 2023-09-18 08:15 🧠 phase=ACCUMULATION | MFE=2.97R | impr=0 | fuel=0.47; 2023-09-18 08:20 🧠 phase=ACCUMULATION | MFE=3.41R | impr=0 | fuel=0.47; 2023-09-18 08:25 🧠 phase=ACCUMULATION | MFE=3.41R | impr=0 | fuel=0.47; 2023-09-18 08:30 🧠 phase=ACCUMULATION | MFE=3.41R | impr=0 | fuel=0.47; 2023-09-18 08:30 🧠 A:Trail; 2023-09-18 08:35 🧠 phase=ACCUMULATION | MFE=3.41R | impr=0 | fuel=0.47; 2023-09-18 08:40 🧠 phase=ACCUMULATION | MFE=3.41R | impr=0 | fuel=0.47; 2023-09-18 08:45 🧠 phase=ACCUMULATION | MFE=3.41R | impr=0 | fuel=0.47; 2023-09-18 08:50 🧠 phase=ACCUMULATION | MFE=3.41R | impr=0 | fuel=0.47; 2023-09-18 08:55 🧠 phase=ACCUMULATION | MFE=3.41R | impr=0 | fuel=0.47
- **Why:** BIAS BULLISH conf100 zone=DISCOUNT | SWEEP SSL Q80.9 lvl=26438.61 | DISP 3.29x 88.6% conv=99.1 | FVG 26430.0-26471.17 CE=26450.585 | Filter ACCUM:PD_DISCOUNT|MID_OK

#### #4 BULLISH 2023-09-19 08:00→2023-09-19 14:15 PnL +2.668% MFE 2.18R
- **Layer1 BIAS:** BULLISH conf 90 zone PREMIUM reason HH+HL | Zone=PREMIUM | Confidence=90
- **Layer2 Sweep:** SSL lvl 26728.0 wick 26694.38 Q 85.2
- **Layer3 Disp:** BULLISH 4.08x 85.3% conv 98.4 | FVG 26736.08-26741.09 CE 26738.585
- **Layer4 Plan:** entry 26738.585 sl 26619.970322 risk 118.61 atr 18.66 sl_atr 6.36 tp1 {'price': 26943.83, 'kind': 'SWING', 'rr': 1.73, 'dist': 205.24500000000262} tp2 {'price': 27587.51, 'kind': 'HTF_DRAW', 'rr': 7.16} tp3 28142.85
- **Session:** LONDON_KILLZONE 2023-09-19 04:00 NY (Tue) | Filter 
- **MFE/MAE:** MFE 2.1845965770171283R MAE 0R | Exit A=A_TRAIL B=B_FORTRESS C=C_FORTRESS
- **Events:** 2023-09-19 08:00 OPEN entry=26738.585 sl=26619.970322 tp1=26943.83 filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(98)+OB_HELD → old Premium is new Discount for DOL 28142.85. Mitigation Block continuation per ICT. LONG only.|MID_OK; 2023-09-19 08:05 🧠 phase=ACCUMULATION | MFE=0.26R | impr=0 | fuel=0.91; 2023-09-19 08:10 🧠 phase=ACCUMULATION | MFE=0.37R | impr=0 | fuel=0.91; 2023-09-19 08:15 🧠 phase=ACCUMULATION | MFE=0.55R | impr=0 | fuel=0.91; 2023-09-19 08:20 🧠 phase=ACCUMULATION | MFE=0.56R | impr=0 | fuel=0.91; 2023-09-19 08:25 🧠 phase=ACCUMULATION | MFE=0.70R | impr=0 | fuel=0.91; 2023-09-19 08:30 🧠 phase=ACCUMULATION | MFE=0.75R | impr=0 | fuel=0.91; 2023-09-19 08:35 🧠 phase=ACCUMULATION | MFE=0.86R | impr=0 | fuel=0.91; 2023-09-19 08:40 🧠 phase=ACCUMULATION | MFE=0.86R | impr=0 | fuel=0.91; 2023-09-19 08:45 🧠 phase=ACCUMULATION | MFE=0.86R | impr=0 | fuel=0.91; 2023-09-19 08:50 🧠 phase=ACCUMULATION | MFE=0.86R | impr=0 | fuel=0.91; 2023-09-19 08:55 🧠 phase=ACCUMULATION | MFE=0.86R | impr=0 | fuel=0.91; 2023-09-19 09:00 🧠 phase=ACCUMULATION | MFE=0.86R | impr=0 | fuel=0.91; 2023-09-19 09:05 🧠 phase=ACCUMULATION | MFE=0.86R | impr=0 | fuel=0.91; 2023-09-19 09:10 🧠 phase=ACCUMULATION | MFE=0.86R | impr=0 | fuel=0.91
- **Why:** BIAS BULLISH conf90 zone=PREMIUM | SWEEP SSL Q85.2 lvl=26728.0 | DISP 4.08x 85.3% conv=98.4 | FVG 26736.08-26741.09 CE=26738.585 | Filter ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(98)+OB_HELD → old Premium is new Discount for DOL 28142.85. Mitigation Block continuation per ICT. LONG only.|MID_OK

#### #5 BEARISH 2023-09-29 07:00→2023-09-29 11:00 PnL +0.823% MFE 0.80R
- **Layer1 BIAS:** BEARISH conf 75 zone PREMIUM reason LH+LL | Zone=PREMIUM | Confidence=75
- **Layer2 Sweep:** BSL lvl 27052.35 wick 27134.16 Q 94.7
- **Layer3 Disp:** BEARISH 3.63x 94.2% conv 99.1 | FVG 27056.8-27065.5 CE 27061.15
- **Layer4 Plan:** entry 27061.15 sl 27313.687496 risk 252.54 atr 34.72 sl_atr 7.27 tp1 {'price': 26557.98, 'kind': 'SWING', 'rr': 1.99, 'dist': 503.1700000000019} tp2 {'price': 26224.0, 'kind': 'HTF_DRAW', 'rr': 3.31} tp3 25562.62
- **Session:** LONDON_KILLZONE 2023-09-29 03:00 NY (Fri) | Filter 
- **MFE/MAE:** MFE 0.797695414587791R MAE 0.13403817217073946R | Exit A=CE_RISK_CUT B=CE_RISK_CUT C=CE_RISK_CUT
- **Events:** 2023-09-29 07:00 OPEN entry=27061.15 sl=27313.687496 tp1=26557.98 filter=ACCUM:PD_PREMIUM|MID_OK; 2023-09-29 07:05 🧠 phase=ACCUMULATION | MFE=0.07R | impr=0 | fuel=0.91; 2023-09-29 07:10 🧠 phase=ACCUMULATION | MFE=0.15R | impr=0 | fuel=0.91; 2023-09-29 07:15 🧠 phase=ACCUMULATION | MFE=0.15R | impr=0 | fuel=0.91; 2023-09-29 07:20 🧠 phase=ACCUMULATION | MFE=0.16R | impr=0 | fuel=0.91; 2023-09-29 07:25 🧠 phase=ACCUMULATION | MFE=0.16R | impr=0 | fuel=0.91; 2023-09-29 07:30 🧠 phase=ACCUMULATION | MFE=0.16R | impr=0 | fuel=0.91; 2023-09-29 07:35 🧠 phase=ACCUMULATION | MFE=0.19R | impr=0 | fuel=0.91; 2023-09-29 07:40 🧠 phase=ACCUMULATION | MFE=0.19R | impr=0 | fuel=0.91; 2023-09-29 07:45 🧠 phase=ACCUMULATION | MFE=0.19R | impr=0 | fuel=0.91; 2023-09-29 07:50 🧠 phase=ACCUMULATION | MFE=0.23R | impr=0 | fuel=0.91; 2023-09-29 07:55 🧠 phase=ACCUMULATION | MFE=0.39R | impr=0 | fuel=0.90; 2023-09-29 08:00 🧠 phase=ACCUMULATION | MFE=0.44R | impr=0 | fuel=0.88; 2023-09-29 08:05 🧠 phase=ACCUMULATION | MFE=0.56R | impr=0 | fuel=0.83; 2023-09-29 08:10 🧠 phase=ACCUMULATION | MFE=0.80R | impr=0 | fuel=0.72
- **Why:** BIAS BEARISH conf75 zone=PREMIUM | SWEEP BSL Q94.7 lvl=27052.35 | DISP 3.63x 94.2% conv=99.1 | FVG 27056.8-27065.5 CE=27061.15 | Filter ACCUM:PD_PREMIUM|MID_OK

## ETHUSDT — 2023-09 — $100→$100.9 (0.9%) — 5 صفقات W=3 L=2

| # | دخول | خروج | Bias | Entry | SL | TP1 | TP2 | PnL% | $ | Bal | A | B | C | MFE | Session | Sweep Q | Disp Conv | Why |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 2023-09-01 14:00 | 2023-09-01 14:45 | BULLISH | 1640.04 | 1627.85 | 1658.32 | 1694.36 | -2.000 | -2.00 | 98.00 | SL | SL | SL | 0.41R | NY_AM_KILLZONE | 86.1 | 91.4 | BIAS BULLISH conf95 zone=DISCOUNT | SWEEP SSL Q86.1 lvl=1643.01 | DISP 3.38x 76.4% conv=91.4 | FVG 1638.29-1641.78 CE=16 |
| 2 | 2023-09-01 19:00 | 2023-09-01 21:30 | BULLISH | 1609.41 | 1600.46 | 1628.44 | 1703.85 | +3.925 | +3.85 | 101.85 | A_TRAIL | B_FORTRESS | C_FORTRESS | 3.19R | NY_PM_KILLZONE | 69.6 | 99.7 | BIAS BULLISH conf75 zone=DISCOUNT | SWEEP SSL Q69.6 lvl=1621.0 | DISP 5.31x 84.0% conv=99.7 | FVG 1608.43-1610.39 CE=160 |
| 3 | 2023-09-08 14:00 | 2023-09-09 00:15 | BULLISH | 1630.42 | 1614.69 | 1658.77 | 1680.00 | +0.678 | +0.69 | 102.54 | CE_RISK_CUT | B_FORTRESS | C_FORTRESS | 0.49R | NY_AM_KILLZONE | 71.3 | 98.6 | BIAS BULLISH conf100 zone=DISCOUNT | SWEEP SSL Q71.3 lvl=1642.21 | DISP 10.06x 85.6% conv=98.6 | FVG 1629.05-1631.8 CE=1 |
| 4 | 2023-09-29 18:00 | 2023-09-29 21:10 | BEARISH | 1670.13 | 1688.01 | 1642.03 | 1615.00 | +0.414 | +0.42 | 102.96 | CE_RISK_CUT | CE_RISK_CUT | CE_RISK_CUT | 0.79R | NY_PM_KILLZONE | 76.1 | 100.0 | BIAS BEARISH conf75 zone=PREMIUM | SWEEP BSL Q76.1 lvl=1673.8 | DISP 4.24x 81.8% conv=100.0 | FVG 1669.44-1670.83 CE=167 |
| 5 | 2023-09-30 13:00 | 2023-09-30 13:55 | BEARISH | 1674.98 | 1679.05 | 1668.27 | 1615.00 | -2.001 | -2.06 | 100.90 | SL | SL | SL | 0.73R | NY_AM_KILLZONE | 93.1 | 75.8 | BIAS BEARISH conf95 zone=PREMIUM | SWEEP BSL Q93.1 lvl=1675.25 | DISP 2.67x 72.4% conv=75.8 | FVG 1674.73-1675.23 CE=167 |

### تفصيل كل صفقة — شو شاف وشو عمل ليش


#### #1 BULLISH 2023-09-01 14:00→2023-09-01 14:45 PnL -2.000% MFE 0.41R
- **Layer1 BIAS:** BULLISH conf 95 zone DISCOUNT reason HH+HL | Zone=DISCOUNT | Confidence=95
- **Layer2 Sweep:** SSL lvl 1643.01 wick 1641.33 Q 86.1
- **Layer3 Disp:** BULLISH 3.38x 76.4% conv 91.4 | FVG 1638.29-1641.78 CE 1640.0349999999999
- **Layer4 Plan:** entry 1640.035 sl 1627.846223 risk 12.19 atr 3.03 sl_atr 4.03 tp1 {'price': 1658.32, 'kind': 'SWING', 'rr': 1.5, 'dist': 18.285000000000082} tp2 {'price': 1694.36, 'kind': 'HTF_DRAW', 'rr': 4.46} tp3 1878.0
- **Session:** NY_AM_KILLZONE 2023-09-01 10:00 NY (Fri) | Filter 
- **MFE/MAE:** MFE 0.4064807219031934R MAE 1.5615258408531651R | Exit A=SL B=SL C=SL
- **Events:** 2023-09-01 14:00 OPEN entry=1640.035 sl=1627.846223 tp1=1658.32 filter=ACCUM:PD_DISCOUNT|MID_OK; 2023-09-01 14:05 🧠 phase=ACCUMULATION | MFE=0.41R | impr=0 | fuel=0.98; 2023-09-01 14:10 🧠 phase=ACCUMULATION | MFE=0.41R | impr=0 | fuel=0.98; 2023-09-01 14:15 🧠 phase=ACCUMULATION | MFE=0.41R | impr=0 | fuel=0.98; 2023-09-01 14:20 🧠 phase=ACCUMULATION | MFE=0.41R | impr=0 | fuel=0.98; 2023-09-01 14:25 🧠 phase=ACCUMULATION | MFE=0.41R | impr=0 | fuel=0.98; 2023-09-01 14:30 🧠 phase=ACCUMULATION | MFE=0.41R | impr=0 | fuel=0.98; 2023-09-01 14:35 🧠 phase=ACCUMULATION | MFE=0.41R | impr=0 | fuel=0.98; 2023-09-01 14:40 🧠 phase=ACCUMULATION | MFE=0.41R | impr=0 | fuel=0.98; 2023-09-01 14:45 ❌ A:SL; 2023-09-01 14:45 ❌ B:SL; 2023-09-01 14:45 ❌ C:SL
- **Why:** BIAS BULLISH conf95 zone=DISCOUNT | SWEEP SSL Q86.1 lvl=1643.01 | DISP 3.38x 76.4% conv=91.4 | FVG 1638.29-1641.78 CE=1640.0349999999999 | Filter ACCUM:PD_DISCOUNT|MID_OK

#### #2 BULLISH 2023-09-01 19:00→2023-09-01 21:30 PnL +3.925% MFE 3.19R
- **Layer1 BIAS:** BULLISH conf 75 zone DISCOUNT reason HH+HL | Zone=DISCOUNT | Confidence=75
- **Layer2 Sweep:** SSL lvl 1621.0 wick 1617.44 Q 69.6
- **Layer3 Disp:** BULLISH 5.31x 84.0% conv 99.7 | FVG 1608.43-1610.39 CE 1609.41
- **Layer4 Plan:** entry 1609.41 sl 1600.463353 risk 8.95 atr 5.04 sl_atr 1.77 tp1 {'price': 1628.44, 'kind': 'SWING', 'rr': 2.13, 'dist': 19.029999999999973} tp2 {'price': 1703.85, 'kind': 'HTF_DRAW', 'rr': 10.56} tp3 1878.0
- **Session:** NY_PM_KILLZONE 2023-09-01 15:00 NY (Fri) | Filter 
- **MFE/MAE:** MFE 3.1899441340782073R MAE 0R | Exit A=A_TRAIL B=B_FORTRESS C=C_FORTRESS
- **Events:** 2023-09-01 19:00 OPEN entry=1609.41 sl=1600.463353 tp1=1628.44 filter=ACCUM:PD_DISCOUNT|MID_OK; 2023-09-01 19:05 🧠 phase=ACCUMULATION | MFE=0.91R | impr=0 | fuel=0.98; 2023-09-01 19:10 🧠 phase=ACCUMULATION | MFE=0.91R | impr=0 | fuel=0.98; 2023-09-01 19:15 🧠 phase=ACCUMULATION | MFE=0.91R | impr=0 | fuel=0.98; 2023-09-01 19:20 🧠 phase=ACCUMULATION | MFE=0.91R | impr=0 | fuel=0.98; 2023-09-01 19:25 🧠 phase=ACCUMULATION | MFE=0.91R | impr=0 | fuel=0.98; 2023-09-01 19:30 🧠 phase=ACCUMULATION | MFE=1.02R | impr=0 | fuel=0.98; 2023-09-01 19:35 🧠 phase=ACCUMULATION | MFE=1.02R | impr=0 | fuel=0.98; 2023-09-01 19:40 🧠 phase=ACCUMULATION | MFE=1.02R | impr=0 | fuel=0.98; 2023-09-01 19:45 🧠 phase=ACCUMULATION | MFE=1.02R | impr=0 | fuel=0.98; 2023-09-01 19:50 🧠 phase=ACCUMULATION | MFE=1.02R | impr=0 | fuel=0.98; 2023-09-01 19:55 🧠 phase=ACCUMULATION | MFE=1.09R | impr=0 | fuel=0.98; 2023-09-01 20:00 🧠 phase=ACCUMULATION | MFE=1.15R | impr=0 | fuel=0.98; 2023-09-01 20:05 🧠 phase=ACCUMULATION | MFE=1.15R | impr=0 | fuel=0.98; 2023-09-01 20:10 🧠 phase=ACCUMULATION | MFE=1.18R | impr=0 | fuel=0.98
- **Why:** BIAS BULLISH conf75 zone=DISCOUNT | SWEEP SSL Q69.6 lvl=1621.0 | DISP 5.31x 84.0% conv=99.7 | FVG 1608.43-1610.39 CE=1609.41 | Filter ACCUM:PD_DISCOUNT|MID_OK

#### #3 BULLISH 2023-09-08 14:00→2023-09-09 00:15 PnL +0.678% MFE 0.49R
- **Layer1 BIAS:** BULLISH conf 100 zone DISCOUNT reason HH+HL | Zone=DISCOUNT | Confidence=100
- **Layer2 Sweep:** SSL lvl 1642.21 wick 1637.69 Q 71.3
- **Layer3 Disp:** BULLISH 10.06x 85.6% conv 98.6 | FVG 1629.05-1631.8 CE 1630.425
- **Layer4 Plan:** entry 1630.425 sl 1614.69364 risk 15.73 atr 2.04 sl_atr 7.7 tp1 {'price': 1658.77, 'kind': 'SWING', 'rr': 1.8, 'dist': 28.345000000000027} tp2 {'price': 1680.0, 'kind': 'HTF_DRAW', 'rr': 3.15} tp3 1861.93
- **Session:** NY_AM_KILLZONE 2023-09-08 10:00 NY (Fri) | Filter 
- **MFE/MAE:** MFE 0.49237126509854534R MAE 0.4192625556261937R | Exit A=CE_RISK_CUT B=B_FORTRESS C=C_FORTRESS
- **Events:** 2023-09-08 14:00 OPEN entry=1630.425 sl=1614.69364 tp1=1658.77 filter=ACCUM:PD_DISCOUNT|MID_OK; 2023-09-08 14:05 🧠 phase=ACCUMULATION | MFE=0.13R | impr=0 | fuel=0.81; 2023-09-08 14:10 🧠 phase=ACCUMULATION | MFE=0.13R | impr=0 | fuel=0.81; 2023-09-08 14:15 🧠 phase=ACCUMULATION | MFE=0.13R | impr=0 | fuel=0.81; 2023-09-08 14:20 🧠 phase=ACCUMULATION | MFE=0.13R | impr=0 | fuel=0.81; 2023-09-08 14:25 🧠 phase=ACCUMULATION | MFE=0.18R | impr=0 | fuel=0.81; 2023-09-08 14:30 🧠 phase=ACCUMULATION | MFE=0.18R | impr=0 | fuel=0.81; 2023-09-08 14:35 🧠 phase=ACCUMULATION | MFE=0.18R | impr=0 | fuel=0.81; 2023-09-08 14:40 🧠 phase=ACCUMULATION | MFE=0.18R | impr=0 | fuel=0.81; 2023-09-08 14:45 🧠 phase=ACCUMULATION | MFE=0.18R | impr=0 | fuel=0.81; 2023-09-08 14:50 🧠 phase=ACCUMULATION | MFE=0.18R | impr=0 | fuel=0.81; 2023-09-08 14:55 🧠 phase=ACCUMULATION | MFE=0.18R | impr=0 | fuel=0.81; 2023-09-08 15:00 🧠 phase=ACCUMULATION | MFE=0.18R | impr=0 | fuel=0.81; 2023-09-08 15:05 🧠 phase=ACCUMULATION | MFE=0.18R | impr=0 | fuel=0.81; 2023-09-08 15:10 🧠 phase=ACCUMULATION | MFE=0.18R | impr=0 | fuel=0.81
- **Why:** BIAS BULLISH conf100 zone=DISCOUNT | SWEEP SSL Q71.3 lvl=1642.21 | DISP 10.06x 85.6% conv=98.6 | FVG 1629.05-1631.8 CE=1630.425 | Filter ACCUM:PD_DISCOUNT|MID_OK

#### #4 BEARISH 2023-09-29 18:00→2023-09-29 21:10 PnL +0.414% MFE 0.79R
- **Layer1 BIAS:** BEARISH conf 75 zone PREMIUM reason LH+LL | Zone=PREMIUM | Confidence=75
- **Layer2 Sweep:** BSL lvl 1673.8 wick 1681.64 Q 76.1
- **Layer3 Disp:** BEARISH 4.24x 81.8% conv 100.0 | FVG 1669.44-1670.83 CE 1670.135
- **Layer4 Plan:** entry 1670.135 sl 1688.007958 risk 17.87 atr 2.39 sl_atr 7.49 tp1 {'price': 1642.03, 'kind': 'SWING', 'rr': 1.57, 'dist': 28.105000000000018} tp2 {'price': 1615.0, 'kind': 'HTF_DRAW', 'rr': 3.08} tp3 1528.61
- **Session:** NY_PM_KILLZONE 2023-09-29 14:00 NY (Fri) | Filter 
- **MFE/MAE:** MFE 0.7909904868494678R MAE 0.03553441522104034R | Exit A=CE_RISK_CUT B=CE_RISK_CUT C=CE_RISK_CUT
- **Events:** 2023-09-29 18:00 OPEN entry=1670.135 sl=1688.007958 tp1=1642.03 filter=ACCUM:PD_PREMIUM|MID_OK; 2023-09-29 18:05 🧠 phase=ACCUMULATION | MFE=0.70R | impr=0 | fuel=0.93; 2023-09-29 18:10 🧠 phase=ACCUMULATION | MFE=0.78R | impr=0 | fuel=0.93; 2023-09-29 18:15 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | fuel=0.93; 2023-09-29 18:20 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | fuel=0.93; 2023-09-29 18:25 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | fuel=0.93; 2023-09-29 18:30 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | fuel=0.93; 2023-09-29 18:35 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | fuel=0.93; 2023-09-29 18:40 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | fuel=0.93; 2023-09-29 18:45 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | fuel=0.93; 2023-09-29 18:50 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | fuel=0.93; 2023-09-29 18:55 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | fuel=0.93; 2023-09-29 19:00 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | fuel=0.93; 2023-09-29 19:05 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | fuel=0.93; 2023-09-29 19:10 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | fuel=0.93
- **Why:** BIAS BEARISH conf75 zone=PREMIUM | SWEEP BSL Q76.1 lvl=1673.8 | DISP 4.24x 81.8% conv=100.0 | FVG 1669.44-1670.83 CE=1670.135 | Filter ACCUM:PD_PREMIUM|MID_OK

#### #5 BEARISH 2023-09-30 13:00→2023-09-30 13:55 PnL -2.001% MFE 0.73R
- **Layer1 BIAS:** BEARISH conf 95 zone PREMIUM reason LH+LL | Zone=PREMIUM | Confidence=95
- **Layer2 Sweep:** BSL lvl 1675.25 wick 1676.78 Q 93.1
- **Layer3 Disp:** BEARISH 2.67x 72.4% conv 75.8 | FVG 1674.73-1675.23 CE 1674.98
- **Layer4 Plan:** entry 1674.98 sl 1679.052932 risk 4.07 atr 1.29 sl_atr 3.17 tp1 {'price': 1668.27, 'kind': 'SWING', 'rr': 1.65, 'dist': 6.710000000000036} tp2 {'price': 1615.0, 'kind': 'HTF_DRAW', 'rr': 14.73} tp3 1606.74
- **Session:** NY_AM_KILLZONE 2023-09-30 09:00 NY (Sat) | Filter 
- **MFE/MAE:** MFE 0.7272727272727362R MAE 1.6339066339066561R | Exit A=SL B=SL C=SL
- **Events:** 2023-09-30 13:00 OPEN entry=1674.98 sl=1679.052932 tp1=1668.27 filter=ACCUM:PD_PREMIUM|MID_OK; 2023-09-30 13:05 🧠 phase=ACCUMULATION | MFE=0.69R | impr=0 | fuel=0.98; 2023-09-30 13:10 🧠 phase=ACCUMULATION | MFE=0.73R | impr=0 | fuel=0.98; 2023-09-30 13:15 🧠 phase=ACCUMULATION | MFE=0.73R | impr=0 | fuel=0.98; 2023-09-30 13:20 🧠 phase=ACCUMULATION | MFE=0.73R | impr=0 | fuel=0.98; 2023-09-30 13:25 🧠 phase=ACCUMULATION | MFE=0.73R | impr=0 | fuel=0.98; 2023-09-30 13:30 🧠 phase=ACCUMULATION | MFE=0.73R | impr=0 | fuel=0.98; 2023-09-30 13:35 🧠 phase=ACCUMULATION | MFE=0.73R | impr=0 | fuel=0.98; 2023-09-30 13:40 🧠 phase=ACCUMULATION | MFE=0.73R | impr=0 | fuel=0.98; 2023-09-30 13:45 🧠 phase=ACCUMULATION | MFE=0.73R | impr=0 | fuel=0.98; 2023-09-30 13:50 🧠 phase=ACCUMULATION | MFE=0.73R | impr=0 | fuel=0.98; 2023-09-30 13:55 ❌ A:SL; 2023-09-30 13:55 ❌ B:SL; 2023-09-30 13:55 ❌ C:SL
- **Why:** BIAS BEARISH conf95 zone=PREMIUM | SWEEP BSL Q93.1 lvl=1675.25 | DISP 2.67x 72.4% conv=75.8 | FVG 1674.73-1675.23 CE=1674.98 | Filter ACCUM:PD_PREMIUM|MID_OK
