#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
مدقق الدخولات — VERIFIES whether each recorded entry was actually reachable.
لكل صفقة: بعد شمعة الإشارة، هل السعر لمس entry المسجّل قبل أن يلمس TP1 أو SL؟
هذا يكشف الصفقات "الوهمية" التي دخلت بسعر لم يصل إليه السوق فعلاً.
"""
import csv, datetime, json, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src', 'core'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src', 'runners'))


def load_csv(path, months_prefixes):
    rows = []
    with open(path) as f:
        r = csv.DictReader(f)
        for row in r:
            dt_str = row.get('datetime')
            if not dt_str:
                vals = list(row.values()); dt_str = vals[1]
            if not dt_str:
                continue
            if not any(dt_str.startswith(p) for p in months_prefixes):
                continue
            dt_str = dt_str[:16]
            try:
                dt = datetime.datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
            except:
                continue
            rows.append({
                'ts': int(dt.replace(tzinfo=datetime.timezone.utc).timestamp() * 1000),
                'dt': dt_str,
                'o': float(row['open']), 'h': float(row['high']),
                'l': float(row['low']), 'c': float(row['close']),
                'v': float(row['volume']),
            })
    return rows


def find_idx(rows, dt_str):
    for i, r in enumerate(rows):
        if r['dt'] == dt_str:
            return i
    # fallback prefix
    for i, r in enumerate(rows):
        if r['dt'] >= dt_str:
            return i
    return None


def verify_trade(rows, t, lookforward=600):
    """بعد شمعة الإشارة، نتحقق هل entry المسجل وصل فعلاً قبل أي نتيجة."""
    sig_idx = find_idx(rows, t['entry_time'])
    if sig_idx is None:
        return {'status': 'SIGNAL_NOT_FOUND'}
    is_long = t['bias'] == 'BULLISH'
    entry = float(t['entry'])
    signal_price = float(t['signal_price'])
    sl = float(t['sl'])
    tp1 = float(t['tp1']['price']) if isinstance(t.get('tp1'), dict) else None

    # شمعة الإشارة نفسها: السعر يكون عند signal_price (الإغلاق)
    # للحصول على entry المسجل (fvg_bot)، السعر يجب أن يتحرك نحوه.
    # نسير للأمام من الشمعة التالية ونرى أي حدث يحدث أولاً.
    results = {
        'signal_dt': t['entry_time'],
        'bias': t['bias'],
        'signal_price': signal_price,
        'entry_recorded': entry,
        'entry_offset': entry - signal_price,  # سلبي للـlong = entry أقل من السوق
        'sl': sl, 'tp1': tp1,
        'is_limit': t.get('is_limit_order'),
        'entry_type': t.get('entry_type'),
        'recorded_pnl': t.get('pnl_pct'),
    }

    # الحالة 1: لو entry_price داخل أو متجاوز شمعة الإشارة نفسها (لمسه فعلاً)
    sig_row = rows[sig_idx]
    touched_at_signal = sig_row['l'] <= entry <= sig_row['h']
    results['entry_in_signal_candle_range'] = touched_at_signal

    # نسير للأمام من sig_idx+1 ونرى التسلسل الزمني الحقيقي للأحداث
    first_event = None  # 'ENTRY_TOUCH', 'SL_HIT', 'TP1_HIT', 'NONE'
    entry_touch_idx = None
    entry_actually_reachable = False
    for j in range(sig_idx + 1, min(sig_idx + lookforward, len(rows))):
        row = rows[j]
        # هل السعر وصل للـentry؟
        entry_touched = row['l'] <= entry <= row['h']
        # في نفس الوقت، هل ضرب SL أو TP1 أولاً؟
        if is_long:
            sl_hit = row['l'] <= sl
            tp1_hit = row['h'] >= tp1 if tp1 else False
        else:
            sl_hit = row['h'] >= sl
            tp1_hit = row['l'] <= tp1 if tp1 else False

        # ترتيب الأسبقية: نشيك اللمس أولاً (لأن entry أقرب من sl عادةً)
        if entry_touched and first_event is None:
            first_event = 'ENTRY_TOUCH'
            entry_touch_idx = j
            entry_actually_reachable = True
            break
        # لكن لو sl أو tp1 حصلوا في نفس الشمعة وentry ما لمس → المشكلة
        if sl_hit and first_event is None:
            first_event = 'SL_HIT_BEFORE_ENTRY'
            break
        if tp1_hit and first_event is None:
            first_event = 'TP1_HIT_BEFORE_ENTRY'
            break

    results['first_forward_event'] = first_event
    results['entry_actually_reachable_after_signal'] = entry_actually_reachable
    if entry_touch_idx:
        results['entry_touch_dt'] = rows[entry_touch_idx]['dt']
        results['bars_to_entry'] = entry_touch_idx - sig_idx

    # الخلاصة: هل الدخول صادق؟
    # صادق = السعر لمس entry فعلاً (سواء بشمعة الإشارة أو بعدها) قبل أن يهرب للـtarget
    # أو لو entry قريب جداً من signal_price (دخول ماركت حقيقي تقريباً)
    market_like = abs(entry - signal_price) / signal_price < 0.0005  # <0.05%
    honest = entry_actually_reachable or touched_at_signal or market_like
    results['honest_entry'] = honest
    results['market_like_fill'] = market_like
    return results


def main():
    base = os.path.dirname(__file__)
    btc_rows = load_csv('/home/user/raw_data/BTCUSDT_5m_2017-09-01_to_2025-09-23.csv',
                        ['2023-0', '2023-1'])
    eth_rows = load_csv('/home/user/raw_data/ETHUSDT_5m.csv', ['2023-11', '2023-12'])
    d = json.load(open(os.path.join(base, 'matrix_dec2023_results.json')))

    grand_honest = 0
    grand_total = 0
    for sym, rows in [('BTC', btc_rows), ('ETH', eth_rows)]:
        print('=' * 78)
        print(f'  {sym}  —  التحقق من صحة الدخولات (هل السعر لمس الدخول فعلاً؟)')
        print('=' * 78)
        for i, t in enumerate(d[sym]['trades'], 1):
            r = verify_trade(rows, t)
            grand_total += 1
            honest = r.get('honest_entry', False)
            if honest:
                grand_honest += 1
            off = r.get('entry_offset', 0)
            mark = '✅ صادق' if honest else '❌ دخول وهمي'
            print(f"  #{i} {r['signal_dt']} {r['bias']}")
            print(f"     signal_price={r['signal_price']:.2f}  entry_recorded={r['entry_recorded']:.2f}  (offset={off:+.2f})")
            print(f"     النوع: {r['entry_type']}  is_limit={r['is_limit']}")
            print(f"     أول حدث بعد الإشارة: {r.get('first_forward_event')}")
            print(f"     لمس الإشارة نفسها؟ {r.get('entry_in_signal_candle_range')}")
            if r.get('entry_touch_dt'):
                print(f"     entry لمس بعد {r.get('bars_to_entry')} شمعة @ {r['entry_touch_dt']}")
            print(f"     PnL المسجل={r['recorded_pnl']:+.3f}%  =>  {mark}")
            print()
    print('=' * 78)
    print(f'  الخلاصة: {grand_honest}/{grand_total} دخول صادق، {grand_total - grand_honest} دخول وهمي/مشكوك به')
    print('=' * 78)


if __name__ == '__main__':
    main()
