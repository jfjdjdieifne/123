# تقرير مفصل — 2023-08 — BTC & ETH نفس الشهر نفس السنة — Matrix V2.1 — $100 / 2%


## BTCUSDT — 2023-08 — $100→$103.93 (3.93%) — 1 صفقات W=1 L=0

| # | دخول | خروج | Bias | Entry | SL | TP1 | TP2 | PnL% | $ | Bal | A | B | C | MFE | Session | Sweep Q | Disp Conv | Why |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 2023-08-29 18:00 | 2023-08-29 19:25 | BULLISH | 25953.03 | 25915.41 | 26010.68 | 26299.00 | +3.928 | +3.93 | 103.93 | A_TRAIL | B_FORTRESS | C_FORTRESS | 4.00R | NY_PM_KILLZONE | 89.8 | 100.0 | BIAS BULLISH conf95 zone=DISCOUNT | SWEEP SSL Q89.8 lvl=25963.24 | DISP 4.63x 100.0% conv=100 | FVG 25943.0-25963.07 CE= |

### تفصيل كل صفقة — شو شاف وشو عمل ليش


#### #1 BULLISH 2023-08-29 18:00→2023-08-29 19:25 PnL +3.928% MFE 4.00R
- **Layer1 BIAS:** BULLISH conf 95 zone DISCOUNT reason HH+HL | Zone=DISCOUNT | Confidence=95
- **Layer2 Sweep:** SSL lvl 25963.24 wick 25922.97 Q 89.8
- **Layer3 Disp:** BULLISH 4.63x 100.0% conv 100.0 | FVG 25943.0-25963.07 CE 25953.035
- **Layer4 Plan:** entry 25953.035 sl 25915.410237 risk 37.62 atr 17.27 sl_atr 2.18 tp1 {'price': 26010.68, 'kind': 'SWING', 'rr': 1.53, 'dist': 57.64500000000044} tp2 {'price': 26299.0, 'kind': 'HTF_DRAW', 'rr': 9.2} tp3 30244.0
- **Session:** NY_PM_KILLZONE 2023-08-29 14:00 NY (Tue) | Filter 
- **MFE/MAE:** MFE 3.997740563530049R MAE 0R | Exit A=A_TRAIL B=B_FORTRESS C=C_FORTRESS
- **Events:** 2023-08-29 18:00 OPEN entry=25953.035 sl=25915.410237 tp1=26010.68 filter=ACCUM:PD_DISCOUNT|MID_OK; 2023-08-29 18:05 🧠 phase=ACCUMULATION | MFE=1.47R | impr=0 | fuel=0.55; 2023-08-29 18:10 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.55; 2023-08-29 18:10 🎯 A:TP1; 2023-08-29 18:10 📣 PARTIAL_TAKEN→fortresses_active; 2023-08-29 18:15 🧠 phase=ACCUMULATION | MFE=2.06R | impr=0 | fuel=0.55; 2023-08-29 18:20 🧠 phase=ACCUMULATION | MFE=2.06R | impr=0 | fuel=0.55; 2023-08-29 18:25 🧠 phase=ACCUMULATION | MFE=2.43R | impr=0 | fuel=0.55; 2023-08-29 18:30 🧠 phase=ACCUMULATION | MFE=2.74R | impr=0 | fuel=0.55; 2023-08-29 18:35 🧠 phase=ACCUMULATION | MFE=2.74R | impr=0 | fuel=0.55; 2023-08-29 18:40 🧠 phase=ACCUMULATION | MFE=2.74R | impr=0 | fuel=0.55; 2023-08-29 18:45 🧠 phase=ACCUMULATION | MFE=2.74R | impr=0 | fuel=0.55; 2023-08-29 18:50 🧠 phase=ACCUMULATION | MFE=2.74R | impr=0 | fuel=0.55; 2023-08-29 18:55 🧠 phase=ACCUMULATION | MFE=2.74R | impr=0 | fuel=0.55; 2023-08-29 18:55 🧠 A:Trail
- **Why:** BIAS BULLISH conf95 zone=DISCOUNT | SWEEP SSL Q89.8 lvl=25963.24 | DISP 4.63x 100.0% conv=100 | FVG 25943.0-25963.07 CE=25953.035 | Filter ACCUM:PD_DISCOUNT|MID_OK

## ETHUSDT — 2023-08 — $100→$103.92 (3.92%) — 3 صفقات W=1 L=2

| # | دخول | خروج | Bias | Entry | SL | TP1 | TP2 | PnL% | $ | Bal | A | B | C | MFE | Session | Sweep Q | Disp Conv | Why |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 2023-08-15 07:00 | 2023-08-15 11:30 | BULLISH | 1841.45 | 1838.71 | 1845.56 | 1858.90 | -1.999 | -2.00 | 98.00 | SL | SL | SL | 1.14R | LONDON_KILLZONE | 94.5 | 79.9 | BIAS BULLISH conf100 zone=DISCOUNT | SWEEP SSL Q94.5 lvl=1842.62 | DISP 3.03x 69.3% conv=79.9 | FVG 1841.14-1841.76 CE=1 |
| 2 | 2023-08-29 13:00 | 2023-08-29 14:45 | BULLISH | 1643.82 | 1636.75 | 1654.83 | 1694.36 | +8.205 | +8.04 | 106.04 | A_TRAIL | TP2 | C_FORTRESS | 13.19R | NY_AM_KILLZONE | 83.0 | 99.9 | BIAS BULLISH conf95 zone=DISCOUNT | SWEEP SSL Q83.0 lvl=1644.19 | DISP 3.02x 85.6% conv=99.9 | FVG 1643.16-1644.47 CE=16 |
| 3 | 2023-08-30 13:00 | 2023-08-30 13:35 | BULLISH | 1715.47 | 1709.65 | 1727.21 | 1861.93 | -2.001 | -2.12 | 103.92 | SL | SL | SL | 1.07R | NY_AM_KILLZONE | 74.6 | 98.0 | BIAS BULLISH conf90 zone=PREMIUM | SWEEP SSL Q74.6 lvl=1715.26 | DISP 4.28x 86.0% conv=98.0 | FVG 1715.34-1715.61 CE=171 |

### تفصيل كل صفقة — شو شاف وشو عمل ليش


#### #1 BULLISH 2023-08-15 07:00→2023-08-15 11:30 PnL -1.999% MFE 1.14R
- **Layer1 BIAS:** BULLISH conf 100 zone DISCOUNT reason HH+HL | Zone=DISCOUNT | Confidence=100
- **Layer2 Sweep:** SSL lvl 1842.62 wick 1841.08 Q 94.5
- **Layer3 Disp:** BULLISH 3.03x 69.3% conv 79.9 | FVG 1841.14-1841.76 CE 1841.45
- **Layer4 Plan:** entry 1841.45 sl 1838.711969 risk 2.74 atr 0.45 sl_atr 6.04 tp1 {'price': 1845.56, 'kind': 'SWING', 'rr': 1.5, 'dist': 4.1099999999999} tp2 {'price': 1858.9, 'kind': 'HTF_DRAW', 'rr': 6.37} tp3 1928.81
- **Session:** LONDON_KILLZONE 2023-08-15 03:00 NY (Tue) | Filter 
- **MFE/MAE:** MFE 1.1423357664233145R MAE 1.0510948905109887R | Exit A=SL B=SL C=SL
- **Events:** 2023-08-15 07:00 OPEN entry=1841.45 sl=1838.711969 tp1=1845.56 filter=ACCUM:PD_DISCOUNT|MID_OK; 2023-08-15 07:05 🧠 phase=ACCUMULATION | MFE=0.00R | impr=0 | fuel=1.00; 2023-08-15 07:10 🧠 phase=ACCUMULATION | MFE=0.00R | impr=0 | fuel=1.00; 2023-08-15 07:15 🧠 phase=ACCUMULATION | MFE=0.00R | impr=0 | fuel=1.00; 2023-08-15 07:20 🧠 phase=ACCUMULATION | MFE=0.02R | impr=0 | fuel=1.00; 2023-08-15 07:25 🧠 phase=ACCUMULATION | MFE=0.02R | impr=0 | fuel=1.00; 2023-08-15 07:30 🧠 phase=ACCUMULATION | MFE=0.02R | impr=0 | fuel=1.00; 2023-08-15 07:35 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=1.00; 2023-08-15 07:40 🧠 phase=ACCUMULATION | MFE=0.50R | impr=0 | fuel=1.00; 2023-08-15 07:45 🧠 phase=ACCUMULATION | MFE=0.74R | impr=0 | fuel=1.00; 2023-08-15 07:50 🧠 phase=ACCUMULATION | MFE=0.76R | impr=0 | fuel=1.00; 2023-08-15 07:55 🧠 phase=ACCUMULATION | MFE=0.76R | impr=0 | fuel=1.00; 2023-08-15 08:00 🧠 phase=ACCUMULATION | MFE=0.76R | impr=0 | CE=1841.90 | CE_HOLDS | fuel=1.00; 2023-08-15 08:05 🧠 phase=ACCUMULATION | MFE=0.76R | impr=0 | CE=1841.90 | CE_HOLDS | fuel=1.00; 2023-08-15 08:10 🧠 phase=ACCUMULATION | MFE=0.76R | impr=0 | CE=1841.90 | CE_HOLDS | fuel=1.00
- **Why:** BIAS BULLISH conf100 zone=DISCOUNT | SWEEP SSL Q94.5 lvl=1842.62 | DISP 3.03x 69.3% conv=79.9 | FVG 1841.14-1841.76 CE=1841.45 | Filter ACCUM:PD_DISCOUNT|MID_OK

#### #2 BULLISH 2023-08-29 13:00→2023-08-29 14:45 PnL +8.205% MFE 13.19R
- **Layer1 BIAS:** BULLISH conf 95 zone DISCOUNT reason HH+HL | Zone=DISCOUNT | Confidence=95
- **Layer2 Sweep:** SSL lvl 1644.19 wick 1641.87 Q 83.0
- **Layer3 Disp:** BULLISH 3.02x 85.6% conv 99.9 | FVG 1643.16-1644.47 CE 1643.815
- **Layer4 Plan:** entry 1643.815 sl 1636.752199 risk 7.06 atr 1.65 sl_atr 4.28 tp1 {'price': 1654.83, 'kind': 'SWING', 'rr': 1.56, 'dist': 11.014999999999873} tp2 {'price': 1694.36, 'kind': 'HTF_DRAW', 'rr': 7.16} tp3 1878.0
- **Session:** NY_AM_KILLZONE 2023-08-29 09:00 NY (Tue) | Filter 
- **MFE/MAE:** MFE 13.187677053824366R MAE 0.2953257790368324R | Exit A=A_TRAIL B=TP2 C=C_FORTRESS
- **Events:** 2023-08-29 13:00 OPEN entry=1643.815 sl=1636.752199 tp1=1654.83 filter=ACCUM:PD_DISCOUNT|MID_OK; 2023-08-29 13:05 🧠 phase=ACCUMULATION | MFE=0.14R | impr=0 | fuel=0.96; 2023-08-29 13:10 🧠 phase=ACCUMULATION | MFE=0.14R | impr=0 | fuel=0.96; 2023-08-29 13:15 🧠 phase=ACCUMULATION | MFE=0.14R | impr=0 | fuel=0.96; 2023-08-29 13:20 🧠 phase=ACCUMULATION | MFE=0.14R | impr=0 | fuel=0.96; 2023-08-29 13:25 🧠 phase=ACCUMULATION | MFE=0.14R | impr=0 | fuel=0.96; 2023-08-29 13:30 🧠 phase=ACCUMULATION | MFE=0.14R | impr=0 | fuel=0.96; 2023-08-29 13:35 🧠 phase=ACCUMULATION | MFE=0.14R | impr=0 | fuel=0.96; 2023-08-29 13:40 🧠 phase=ACCUMULATION | MFE=0.26R | impr=0 | fuel=0.96; 2023-08-29 13:45 🧠 phase=ACCUMULATION | MFE=0.66R | impr=0 | fuel=0.96; 2023-08-29 13:50 🧠 phase=ACCUMULATION | MFE=0.66R | impr=0 | fuel=0.96; 2023-08-29 13:55 🧠 phase=ACCUMULATION | MFE=0.66R | impr=0 | fuel=0.96; 2023-08-29 14:00 🧠 phase=ACCUMULATION | MFE=1.16R | impr=0 | CE=1643.52 | CE_HOLDS | fuel=0.96; 2023-08-29 14:05 🧠 phase=ACCUMULATION | MFE=1.77R | impr=0 | CE=1643.52 | CE_HOLDS | fuel=0.85; 2023-08-29 14:05 🎯 A:TP1
- **Why:** BIAS BULLISH conf95 zone=DISCOUNT | SWEEP SSL Q83.0 lvl=1644.19 | DISP 3.02x 85.6% conv=99.9 | FVG 1643.16-1644.47 CE=1643.815 | Filter ACCUM:PD_DISCOUNT|MID_OK

#### #3 BULLISH 2023-08-30 13:00→2023-08-30 13:35 PnL -2.001% MFE 1.07R
- **Layer1 BIAS:** BULLISH conf 90 zone PREMIUM reason HH+HL | Zone=PREMIUM | Confidence=90
- **Layer2 Sweep:** SSL lvl 1715.26 wick 1710.38 Q 74.6
- **Layer3 Disp:** BULLISH 4.28x 86.0% conv 98.0 | FVG 1715.34-1715.61 CE 1715.475
- **Layer4 Plan:** entry 1715.475 sl 1709.652091 risk 5.82 atr 2.32 sl_atr 2.51 tp1 {'price': 1727.21, 'kind': 'SWING', 'rr': 2.02, 'dist': 11.735000000000127} tp2 {'price': 1861.93, 'kind': 'HTF_DRAW', 'rr': 25.15} tp3 1878.0
- **Session:** NY_AM_KILLZONE 2023-08-30 09:00 NY (Wed) | Filter 
- **MFE/MAE:** MFE 1.067869415807585R MAE 3.1743986254295375R | Exit A=SL B=SL C=SL
- **Events:** 2023-08-30 13:00 OPEN entry=1715.475 sl=1709.652091 tp1=1727.21 filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(98)+OB_HELD → old Premium is new Discount for DOL 1878.0. Mitigation Block continuation per ICT. LONG only.|MID_OK; 2023-08-30 13:05 🧠 phase=ACCUMULATION | MFE=0.60R | impr=0 | fuel=0.91; 2023-08-30 13:10 🧠 phase=ACCUMULATION | MFE=0.78R | impr=0 | fuel=0.91; 2023-08-30 13:15 🧠 phase=ACCUMULATION | MFE=1.07R | impr=0 | fuel=0.91; 2023-08-30 13:20 🧠 phase=ACCUMULATION | MFE=1.07R | impr=0 | fuel=0.91; 2023-08-30 13:25 🧠 phase=ACCUMULATION | MFE=1.07R | impr=0 | fuel=0.91; 2023-08-30 13:30 🧠 phase=ACCUMULATION | MFE=1.07R | impr=0 | fuel=0.91; 2023-08-30 13:35 ❌ A:SL; 2023-08-30 13:35 ❌ B:SL; 2023-08-30 13:35 ❌ C:SL
- **Why:** BIAS BULLISH conf90 zone=PREMIUM | SWEEP SSL Q74.6 lvl=1715.26 | DISP 4.28x 86.0% conv=98.0 | FVG 1715.34-1715.61 CE=1715.475 | Filter ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(98)+OB_HELD → old Premium is new Discount for DOL 1878.0. Mitigation Block continuation per ICT. LONG only.|MID_OK
