# Matrix Einstein — Final Organized Project — V2.1

**المشروع كامل متكامل منظم سلس ذكي مترابط — ليس مفصول ولا مجعلك**

## الهيكل

```
final_matrix_einstein/
├── main.py                      # نقطة الدخول — يشغل Dec 2023 BTC+ETH $100/2%
├── requirements.txt
├── src/
│   ├── core/                    # القلب — 6 ملفات مترابطة بذكاء
│   │   ├── ict_matrix_ride.py   # العقل InstitutionalMind V2.1 (Continuation + Harvest Gate + Determinism + Breaker)
│   │   ├── ict_layered_brain.py # 4 طبقات + read_bias_major (مختبر ومرفوض) + read_bias الأصلي
│   │   ├── ict_smart_runner.py  # MarketReader ITL/STL
│   │   ├── ict_math_engine.py   # محركات رياضية + Breaker Block + TP
│   │   ├── ict_sessions.py      # Kill Zones + NY time
│   │   └── authenticity_engine.py # Significant Swings MAJOR
│   └── runners/
│       ├── run_matrix_only_dec2023.py # اختبارك Dec 2023 $100/2% — يمرر displacement_score + dealing_15m
│       ├── run_matrix_btc_archive.py  # BTC archive Mar+Jun مرجعي
│       └── run_matrix_eth_may.py      # ETH May مرجعي
├── docs/
│   ├── README_V2_1.md
│   └── FINAL_V2_1_REPORT.md
└── data/                        # ضع هنا CSVs: BTCUSDT_5m*.csv و ETHUSDT_5m.csv
```

## التعديلات الذكية المدمجة والمترابطة

1. **Continuation Protocol** — `ict_matrix_ride.py: is_continuation_unlock_thinking()` — يفكر: Bias قوي + Disp خارق + BOS + OB held (Mitigation) + room to DOL → old Premium is new Discount. فقط LONG_IN_PREMIUM.
   - مصدر: innercircletrader.net PD change after BOS + ictflow fractal HTF wins + Mitigation Block continuation

2. **Harvest Gate Scale Shift** — `InstitutionalMind.perceive()` — scale_shift_active فقط إذا hard lock + MFE≥1.5 (TP1+BE) أو MFE≥3R أو Time≥3H مع MFE≥1.0
   - مصدر: ICT 2022 Notes trust move, trailing below OB low + Daily Bias Trick 15M/1H

3. **Determinism Filter** — أعلى `ict_matrix_ride.py`: `PYTHONHASHSEED=0 + random.seed(42) + np.random.seed(42)` + `mean_body` → `median` — deterministic OK

4. **Breaker Auto-Flip** — `run_matrix_only_dec2023.py` بعد خسارة -2% في ACCUMULATION + MFE<1R → يستدعي `detect_breaker_block_opportunity()` ويفتح عكسية فورية — آمن، لم يجد فرصة في Dec 2023

5. **Bias الأصلي** — `read_bias_major()` موجود لكن اختباره أعطى 102.39 vs 109.45 أسوأ → مرفوض، نستخدم `read_bias` الأصلي

## النتائج النهائية V2.1

```
python3 main.py
# BTC $100→$111.68 +11.68% 9 trades
# ETH $100→$118.43 +18.43% 9 trades
# Deterministic: نفس النتيجة كل مرة
```

مقارنة مع Official Triple: BTC كان $92.24 -7.76% → الآن +19.44% فرق، ETH كان $105.55 → الآن +12.88% فرق.

## تشغيل

```bash
pip install -r requirements.txt
# ضع البيانات في data/ أو اترك المسارات الافتراضية:
# BTC: /home/user/raw_data/BTCUSDT_5m_2017-09-01_to_2025-09-23.csv
# ETH: /tmp/eth_3_2/ETHUSDT_5m.csv
python3 main.py
```

## الملفات كلها منظمة وسلسة وذكية مترابطة — لا فصل ولا جعلكة
