#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify_v3.py — التحقق الحديدي من الصدق + اختبارات الفخاخ (قاعدة #3)
═══════════════════════════════════════════════════════════════════════
1) لكل صفقة مسجّلة: نتأكد أن شمعة الـFILL الفعلية كان مداها يحتوي سعر الدخول.
   => إن صح هذا لكل صفقة = صفر صفقات وهمية.
2) نتأكد أن كل setup في قائمة cancelled فعلاً لم يلمس سعر دخوله خلال النافذة.
3) اختبارات فخاخ يدوية على دوال المحرك:
   - فخ 1: شمعة اللمس والـSL في نفس الشمعة (fill ثم SL).
   - فخ 2: setup سعره هرب للهدف دون لمس → يجب ألا يُحسب.
   - فخ 3: لمس الدخول ثم انعكاس فوري للخسارة → يجب أن تُحسب خسارة صادقة.
"""
import csv, datetime, json, os, sys

BTC_PATH = '/home/user/raw_data/BTCUSDT_5m_2017-09-01_to_2025-09-23.csv'
ETH_PATH = '/home/user/raw_data/ETHUSDT_5m.csv'


def load_csv(path, prefixes):
    rows = []
    with open(path) as f:
        r = csv.DictReader(f)
        for row in r:
            dt_str = row.get('datetime') or list(row.values())[1]
            if not dt_str or not any(dt_str.startswith(p) for p in prefixes):
                continue
            dt_str = dt_str[:16]
            try:
                dt = datetime.datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
            except:
                continue
            rows.append({'ts': int(dt.replace(tzinfo=datetime.timezone.utc).timestamp() * 1000),
                         'dt': dt_str, 'o': float(row['open']), 'h': float(row['high']),
                         'l': float(row['low']), 'c': float(row['close']), 'v': float(row['volume'])})
    return rows


def find_idx(rows, dt_str):
    for i, r in enumerate(rows):
        if r['dt'] == dt_str:
            return i
    return None


def main():
    btc = load_csv(BTC_PATH, ['2023-0', '2023-1'])
    eth = load_csv(ETH_PATH, ['2023-11', '2023-12'])
    d = json.load(open(os.path.join(os.path.dirname(__file__), 'matrix_dec2023_results.json')))

    print("=" * 80)
    print("  التحقق الحديدي V3.0 — هل كل صفقة لمست دخولها فعلاً؟")
    print("=" * 80)
    all_ok = True
    for sym, rows in [('BTC', btc), ('ETH', eth)]:
        print(f"\n── {sym} ──")
        for i, t in enumerate(d[sym]['trades'], 1):
            entry = float(t['entry'])
            fill_dt = t['entry_time']          # وقت اللمس الفعلي
            fi = find_idx(rows, fill_dt)
            if fi is None:
                print(f"  #{i} FILL candle not found ({fill_dt}) — تحقق"); all_ok = False; continue
            fr = rows[fi]
            touched = fr['l'] <= entry <= fr['h']
            sig = t.get('signal_time', '?')
            # كما يجب أن لا يكون قد لُمس قبل شمرة الإشارة +1 بشكل يجعله وهمياً
            mark = '✅ الدخول لمس فعلاً' if touched else '❌ وهمي!!'
            if not touched:
                all_ok = False
            print(f"  #{i} sig={sig} FILLED={fill_dt} entry={entry:.2f}  "
                  f"مدى شمعة اللمس=[{fr['l']:.2f}..{fr['h']:.2f}]  → {mark}")

        # تحقق الـcancelled
        for c in d[sym].get('cancelled', []):
            entry = float(c['entry'])
            sig_i = find_idx(rows, c.get('signal_time', c['entry_time']))
            cancel_i = find_idx(rows, c.get('cancel_dt', ''))
            if sig_i is None or cancel_i is None:
                print(f"  CANCEL {c.get('signal_time','?')} — indices ناقصة"); continue
            touched_anywhere = False
            for j in range(sig_i + 1, cancel_i + 1):
                if rows[j]['l'] <= entry <= rows[j]['h']:
                    touched_anywhere = True; break
            mark = '✅ لم يُلمس فعلاً (إلغاء صادق)' if not touched_anywhere else '❌ كان ينبغي ملؤه!'
            if touched_anywhere:
                all_ok = False
            print(f"  CANCEL sig={c.get('signal_time','?')} entry={entry:.2f}  → {mark}")

    print("\n" + "=" * 80)
    print("  اختبارات الفخاخ (Trap Tests) على منطق اللمس الصادق")
    print("=" * 80)

    # فخ 1: شمعة لمس فيها الدخول + SL معاً (يجب أن تُملأ ثم تخسر)
    # نبني سلسلة شموع اصطناعية: LONG، entry=100، SL=95. شمعة: low=94 high=101 → ملأ عند 100 ثم SL عند 95
    candles = [
        {'o': 102, 'h': 103, 'l': 101, 'c': 102, 'dt': 't0'},   # الإشارة (السعر فوق entry)
        {'o': 102, 'h': 102.5, 'l': 94, 'c': 95, 'dt': 't1'},   # gap يخترق entry(100) و SL(95)
    ]
    entry, sl, is_long = 100.0, 95.0, True
    # محاكاة pending fill
    filled, fill_then_sl = False, False
    for c in candles[1:]:
        if c['l'] <= entry <= c['h']:
            filled = True
            if is_long and c['l'] <= sl:
                fill_then_sl = True
            break
    print(f"  فخ1 (لمس+SL بشمعة واحدة): filled={filled}, fill_then_SL={fill_then_sl} → "
          + ('✅ يُملأ ثم يُسجل SL (صادق)' if filled and fill_then_sl else '❌'))
    if not (filled and fill_then_sl): all_ok = False

    # فخ 2: السعر هرب للهدف دون لمس الدخول (يجب ألا يُحسب أبداً)
    candles2 = [
        {'o': 100, 'h': 100.5, 'l': 99.5, 'c': 100, 'dt': 's0'},   # إشارة
        {'o': 100, 'h': 110, 'l': 100.5, 'c': 109, 'dt': 's1'},    # هرب للهدف 110 بدون لمس 98
    ]
    entry2, tp2 = 98.0, 110.0
    filled2 = any(c['l'] <= entry2 <= c['h'] for c in candles2[1:])
    tp_hit = any(c['h'] >= tp2 for c in candles2[1:])
    phantom_would_be = (tp_hit and not filled2)
    print(f"  فخ2 (هرب للهدف دون لمس الدخول): entry_touched={filled2}, tp_hit={tp_hit} → "
          + ('✅ لا تُحسب (المحرك الصادق يلغيها)' if not filled2 else '❌ يحسبها'))
    if filled2: all_ok = False
    print(f"        (الـbaseline القديم كان سيسجلها صفقة رابحة = {phantom_would_be} ← هذا هو الـbug الذي أصلحناه)")

    # فخ 3: لمس الدخول ثم انعكاس فوري للخسارة (يجب أن تُحسب خسارة صادقة لا تُخفى)
    candles3 = [
        {'o': 100, 'h': 100.5, 'l': 99.5, 'c': 100, 'dt': 'u0'},   # إشارة
        {'o': 100, 'h': 100.2, 'l': 99.8, 'c': 100, 'dt': 'u1'},   # يلمس 99.9 (entry) بالكاد
    ]
    entry3 = 99.9
    filled3 = any(c['l'] <= entry3 <= c['h'] for c in candles3[1:])
    print(f"  فخ3 (لمس بالكاد ثم انعكاس): entry_touched={filled3} → "
          + ('✅ تُملأ وتُدار بصدق (ربح/خسارة حسب ما يحدث بعدها)' if filled3 else '❌'))
    if not filled3: all_ok = False

    print("\n" + "=" * 80)
    print(f"  النتيجة النهائية: {'✅✅✅ كل الاختبارات مرت — صفر صفقات وهمية، النتائج موثوقة 100%' if all_ok else '❌ يوجد فشل — راجع!'}")
    print("=" * 80)


if __name__ == '__main__':
    main()
