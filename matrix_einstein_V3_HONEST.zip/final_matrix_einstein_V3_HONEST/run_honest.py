#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_honest.py — نموذج التنفيذ الصادق + اختبار استراتيجيات الدخول
═══════════════════════════════════════════════════════════════════════
القاعدة الذهبية: صفقة لا تُحسب إلا إذا لمس السعر سعر الدخول فعلاً.
لا FILL وهمي، لا MARKET_FALLBACK، لا عدّ لأرباح لم تحدث.

الحالات:
  PHANTOM     = ي reproduces السلوك الحالي (fill فوري عند الحافة العميقة + fallback) للتحقق
  DEEP_HONEST = limit عند الحافة العميقة، fill صادق فقط عند اللمس
  CE_HONEST   = limit عند CE (منتصف FVG)، fill صادق
  NEAR_HONEST = limit عند الحافة القريبة الصحيحة (LONG=fvg_top, SHORT=fvg_bot)

المرجعية (ICT):
- innercircletrader.net FVG: Consequent Encroachment (CE=50%) هو مستوى إعادة التوازن
- IOFED "just inside the edge": الحافة التي يعود إليها السعر أولاً (LONG=fvg_top, SHORT=fvg_bot)
- "wait for price to return to the FVG before entering" — إن لم يعد، لا دخول (انضباط ICT)
"""
import csv, datetime, sys, os, json
from collections import defaultdict

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE, 'src', 'core'))
sys.path.insert(0, os.path.join(BASE, 'src', 'runners'))

from ict_sessions import classify_session
from ict_layered_brain import read_bias, read_narrative, read_trigger, build_plan
from ict_math_engine import detect_ict_three_candle_swings as detect_sw2
from ict_matrix_ride import (
    manage_matrix_triple, entry_accumulation_filters, get_ny_day_key,
    compute_hybrid_entry, process_limit_order_state
)

BTC_PATH = '/home/user/raw_data/BTCUSDT_5m_2017-09-01_to_2025-09-23.csv'
ETH_PATH = '/home/user/raw_data/ETHUSDT_5m.csv'
RISK = 0.02
LIMIT_TIMEOUT = 36
MARKET_CONT = False


def load_csv(path, prefixes):
    rows = []
    with open(path) as f:
        r = csv.DictReader(f)
        for row in r:
            dt_str = row.get('datetime')
            if not dt_str:
                vals = list(row.values()); dt_str = vals[1]
            if not dt_str or not any(dt_str.startswith(p) for p in prefixes):
                continue
            dt_str = dt_str[:16]
            try:
                dt = datetime.datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
            except:
                continue
            rows.append({
                'ts': int(dt.replace(tzinfo=datetime.timezone.utc).timestamp() * 1000),
                'dt': dt_str, 'o': float(row['open']), 'h': float(row['high']),
                'l': float(row['low']), 'c': float(row['close']), 'v': float(row['volume']),
            })
    return rows


_CACHE = {'last_idx': -1, 'data': None, 'full': None, 'd5': None, 'd15': None, 'd4h': None, 'd1d': None}


def _build_cache(rows, idx, lookback=8000):
    if _CACHE['last_idx'] >= idx - 12 and _CACHE['data'] is not None:
        return
    s = max(0, idx - lookback + 1)
    ch = rows[s:idx + 1]
    full = {k: [r[k[0]] for r in ch] for k in [('o',), ('h',), ('l',), ('c',), ('v',), ('ts',)]}
    full = {
        'timestamps': [r['ts'] for r in ch], 'opens': [r['o'] for r in ch],
        'highs': [r['h'] for r in ch], 'lows': [r['l'] for r in ch],
        'closes': [r['c'] for r in ch], 'volumes': [r['v'] for r in ch],
    }
    s5 = max(0, idx - 249); ch5 = rows[s5:idx + 1]
    d5 = {
        'timestamps': [r['ts'] for r in ch5], 'opens': [r['o'] for r in ch5],
        'highs': [r['h'] for r in ch5], 'lows': [r['l'] for r in ch5],
        'closes': [r['c'] for r in ch5], 'volumes': [r['v'] for r in ch5],
    }
    _CACHE.update({'last_idx': idx, 'data': True, 'full': full,
                   'd5': d5, 'd15': _aggregate(full, 15), 'd4h': _aggregate(full, 240),
                   'd1d': _aggregate(full, 1440)})


def _aggregate(data, tf):
    n = len(data['closes']); ratio = tf // 5
    if n < ratio:
        return None
    out = {'timestamps': [], 'opens': [], 'highs': [], 'lows': [], 'closes': [], 'volumes': []}
    for i in range(n // ratio):
        a, b = i * ratio, (i + 1) * ratio
        out['timestamps'].append(data['timestamps'][a]); out['opens'].append(data['opens'][a])
        out['highs'].append(max(data['highs'][a:b])); out['lows'].append(min(data['lows'][a:b]))
        out['closes'].append(data['closes'][b - 1]); out['volumes'].append(sum(data['volumes'][a:b]))
    return out


def daily_ctx(rows, idx):
    by = defaultdict(lambda: {"h": -1e18, "l": 1e18, "o": None})
    for r in rows[:idx + 1]:
        k = get_ny_day_key(r['ts'])
        if by[k]['o'] is None:
            by[k]['o'] = r['o']
        by[k]['h'] = max(by[k]['h'], r['h']); by[k]['l'] = min(by[k]['l'], r['l'])
    cur = get_ny_day_key(rows[idx]['ts'])
    completed = sorted(d for d in by if d < cur)
    ranges = [by[d]['h'] - by[d]['l'] for d in completed[-10:]]
    return ranges, by[cur]['o'], by[cur]['h'], by[cur]['l'], cur


def midnight_open(rows, idx):
    cur = get_ny_day_key(rows[idx]['ts'])
    for i in range(idx, -1, -1):
        if get_ny_day_key(rows[i]['ts']) != cur:
            return rows[i + 1]['o'] if i + 1 <= idx else rows[idx]['o']
    return rows[0]['o']


def choose_entry(mode, is_long, fvg_top, fvg_bot, ce):
    """اختيار سعر الدخول حسب الاستراتيجية."""
    if mode == 'CE_HONEST':
        return ce
    if mode == 'NEAR_HONEST':
        return fvg_top if is_long else fvg_bot     # الحافة القريبة الصحيحة
    if mode == 'DEEP_HONEST':
        return fvg_bot if is_long else fvg_top      # الحافة العميقة (السلوك الحالي)
    return ce


def detect_setup(rows, idx, mode):
    """يعيد pending-order dict أو None. نسخة صادقة من منطق المسح."""
    sess = classify_session(rows[idx]['ts'])
    if sess['session'] not in {"LONDON_KILLZONE", "NY_AM_KILLZONE", "NY_PM_KILLZONE"}:
        return None
    _build_cache(rows, idx, lookback=8000)
    d5, d15, d4h, d1d = _CACHE['d5'], _CACHE['d15'], _CACHE['d4h'], _CACHE['d1d']
    if not d1d or len(d1d['closes']) < 10 or not d15:
        return None
    bias = read_bias(d1d, d4h)
    if bias['direction'] not in ('BULLISH', 'BEARISH') or bias['confidence'] < 50:
        return None
    narr = read_narrative(d15, bias['direction'])
    sweep_obj = narr.get('sweep') or {}
    if narr['state'] != 'SWEEP_FOUND' or sweep_obj.get('quality', 0) < 25:
        return None
    trig = read_trigger(d5, narr, bias['direction'])
    if not trig['ready']:
        return None
    plan = build_plan(d5, d1d, trig, narr, bias)
    if not plan:
        return None
    is_long = bias['direction'] == 'BULLISH'
    mid = midnight_open(rows, idx)
    disp_score = float(trig['displacement']['conviction'])
    dealing_15m = narr.get('dealing_range')
    ok, reason = entry_accumulation_filters(
        is_long, plan['entry'], bias, mid,
        displacement_score=disp_score, dealing_15m=dealing_15m,
        last_ob_held=True, current_price=plan['entry'])
    if not ok:
        return None
    # SL filter base
    if plan.get('sl_atr', 0) > 0 and plan['sl_atr'] < 2.8:
        return None
    # Confluence
    confluence = 0
    if bias.get('confidence', 0) >= 70: confluence += 1
    if narr.get('sweep') and narr['sweep'].get('quality', 0) >= 50: confluence += 1
    if trig.get('displacement') and trig['displacement'].get('conviction', 0) >= 80: confluence += 1
    if trig.get('fvg') and trig['fvg'].get('ce') is not None: confluence += 1
    if trig.get('displacement', {}).get('index') is not None: confluence += 1
    if 'CONT_UNLOCKED' in reason:
        confluence += 1
        if confluence < 4:
            return None

    fvg = trig['fvg']
    fvg_top, fvg_bot, ce = float(fvg['top']), float(fvg['bottom']), float(fvg['ce'])
    entry_raw = choose_entry(mode, is_long, fvg_top, fvg_bot, ce)
    sl = plan['sl']
    atr = plan['atr']
    risk = abs(entry_raw - sl)
    if risk <= 0 or atr <= 0:
        return None
    if risk / atr < 2.8:                       # SL_ATR filter على الدخول المختار
        return None
    tp1_price = plan['tp1']['price']
    tp1_rr = abs(tp1_price - entry_raw) / risk
    if tp1_rr < 1.5:
        return None

    # tp3 من d1d
    sw = detect_sw2(d1d)
    targs = sw['swing_highs'] if is_long else sw['swing_lows']
    tp3 = None
    for s in targs:
        if (is_long and s['price'] > entry_raw + risk * 5) or (not is_long and s['price'] < entry_raw - risk * 5):
            tp3 = s['price']; break
    ss, se = ((min(narr['sweep']['wick_extreme'], sl), max(fvg_top, entry_raw)) if is_long else
              (max(narr['sweep']['wick_extreme'], sl), min(fvg_bot, entry_raw)))

    return {
        'entry': entry_raw, 'sl': sl, 'risk': risk, 'atr': atr,
        'tp1': tp1_price, 'tp2': plan['tp2'].get('price') if isinstance(plan['tp2'], dict) else None,
        'tp3': tp3, 'is_short': not is_long, 'signal_price': rows[idx]['c'],
        'signal_dt': rows[idx]['dt'], 'signal_idx': idx,
        'bias': bias['direction'], 'bias_conf': bias['confidence'],
        'setup_start': ss, 'setup_end': se, 'mode': mode,
        'fvg_top': fvg_top, 'fvg_bot': fvg_bot, 'fvg_ce': ce,
        'limit_candles_left': LIMIT_TIMEOUT,   # timeout صادق
        'session': sess['session'], 'why': reason,
    }


def make_active(p, fill_row):
    """يبني حالة الصفقة المفعّلة عند اللمس الفعلي (entry_filled=True حقيقة)."""
    is_long = not p['is_short']
    return {
        'symbol': '?', 'entry_time': fill_row['dt'], 'session': p['session'],
        'signal_price': p['signal_price'], 'bias': p['bias'], 'bias_conf': p['bias_conf'],
        'entry': p['entry'], 'sl': p['sl'], 'risk': p['risk'], 'atr': p['atr'],
        'tp1': p['tp1'], 'tp2': p['tp2'], 'tp3': p['tp3'], 'is_short': p['is_short'],
        'risk_pct_a': RISK * 100 * 0.6, 'risk_pct_b': RISK * 100 * 0.3, 'risk_pct_c': RISK * 100 * 0.1,
        'pos_a': {'active': True, 'entry': p['entry'], 'sl': p['sl'], 'tp1': p['tp1'],
                  'tp1_hit': False, 'pnl': 0, 'entry_filled': True},
        'pos_b': {'active': True, 'entry': p['entry'], 'sl': p['sl'], 'tp2_price': p['tp2'],
                  'be_set': False, 'pnl': 0, 'entry_filled': True},
        'pos_c': {'active': True, 'entry': p['entry'], 'sl': p['sl'], 'tp3_price': p['tp3'],
                  'be_set': False, 'pnl': 0, 'entry_filled': True},
        'setup_start': p['setup_start'], 'setup_end': p['setup_end'],
        'mfe_r': 0, 'mae_r': 0, 'candle_count': 0, 'entry_type': p.get('entry_type', 'LIMIT_FILLED_HONEST'),
        'events': [f"{fill_row['dt']} ✅ HONEST_LIMIT_FILLED @ {p['entry']:.2f} (signal was {p['signal_dt']})"],
        'signal_dt': p['signal_dt'], 'mode': p['mode'],
        'fvg_top': p['fvg_top'], 'fvg_bot': p['fvg_bot'],
    }


def run_honest(symbol, rows, month, mode='NEAR_HONEST'):
    global _CACHE
    _CACHE = {'last_idx': -1, 'data': None, 'full': None, 'd5': None, 'd15': None, 'd4h': None, 'd1d': None}
    start_idx = next((i for i, r in enumerate(rows) if r['dt'].startswith(month)), 0)
    balance = 100.0
    trades, cancelled = [], []
    active = None
    pending = None
    entered = set()
    c1 = c4 = 0

    for idx in range(start_idx, len(rows)):
        row = rows[idx]
        if not row['dt'].startswith(month):
            break
        c1 += 1; c4 += 1

        # ── إدارة صفقة مفعّلة ──
        if active:
            c5 = {'o': row['o'], 'h': row['h'], 'l': row['l'], 'c': row['c']}
            c1h = c4h = None
            if c1 >= 12 and idx >= 12:
                ch = rows[idx - 11:idx + 1]
                c1h = {'o': ch[0]['o'], 'h': max(x['h'] for x in ch), 'l': min(x['l'] for x in ch), 'c': row['c']}
                c1 = 0
            if c4 >= 48 and idx >= 48:
                ch = rows[idx - 47:idx + 1]
                c4h = {'o': ch[0]['o'], 'h': max(x['h'] for x in ch), 'l': min(x['l'] for x in ch), 'c': row['c']}
                c4 = 0
            hist, d_o, d_h, d_l, dk = daily_ctx(rows, idx)
            ctx = {"hist_ranges": hist, "day_open": d_o, "day_high": d_h, "day_low": d_l, "day_key": dk,
                   "setup_start": active.get("setup_start"), "setup_end": active.get("setup_end")}
            entry = active['pos_a']['entry']
            if active['is_short']:
                fav = entry - row['l']; adv = row['h'] - entry
            else:
                fav = row['h'] - entry; adv = entry - row['l']
            if active['risk'] > 0:
                active['mfe_r'] = max(active.get('mfe_r', 0), fav / active['risk'])
                active['mae_r'] = max(active.get('mae_r', 0), adv / active['risk'])
            events, closed = manage_matrix_triple(c5, c1h, c4h, active, day_ctx=ctx)
            if events:
                for e in events[-5:]:
                    active.setdefault("events", []).append(f"{row['dt']} {e}")
            if closed:
                pnl = active.get('pnl_pct') or 0
                usd = balance * pnl / 100; balance += usd
                active['exit_time'] = row['dt']; active['pnl_pct'] = pnl
                active['pnl_dollar'] = usd; active['balance_after'] = balance
                trades.append(active); active = None
            continue

        # ── pending: فحص اللمس الصادق + timeout زمني ثابت (أثبت الاختبار أنه الأفضل) ──
        # ملاحظة (قاعدة #3): جربنا إلغاء الأمر عند بلوغ الهدف (TP1_REACHED) كفكرة "ذكية"،
        # لكنها أخسرت صفقات رابحة حقيقية (BTC#1/#5: لمس الهدف ثم ارتد للـCE فملأهما ثم ربحا).
        # لذا نلتزم بالـtimeout الزمني الصادق: يملأ عند اللمس، وإلا يُلغي بعد نافذة الجلسة.
        if pending:
            entry = pending['entry']; is_long = not pending['is_short']
            touched = row['l'] <= entry <= row['h']
            if touched:
                active = make_active(pending, row); pending = None
                c1 = c4 = 0
                continue   # نبدأ الإدارة من الشمعة التالية (اللمس حدث بهذه الشمعة)
            pending['limit_candles_left'] -= 1
            if pending['limit_candles_left'] <= 0:
                pending['cancel_dt'] = row['dt']
                pending['cancel_reason'] = 'LIMIT_TIMEOUT_NO_TOUCH'
                cancelled.append(pending); pending = None
            continue

        # ── مسح جديد ──
        if idx % 1 != 0:
            continue
        p = detect_setup(rows, idx, mode)
        if p is None:
            continue
        fk = (round(p['fvg_top'], 2), round(p['fvg_bot'], 2), p['bias'])
        if fk in entered:
            continue
        entered.add(fk)
        pending = p

    return {'trades': trades, 'cancelled': cancelled, 'end': round(balance, 2),
            'return_pct': round((balance / 100 - 1) * 100, 2)}


def report(symbol, res):
    tr = res['trades']
    wins = [t for t in tr if (t.get('pnl_dollar', 0) or 0) > 0.01]
    losses = [t for t in tr if (t.get('pnl_dollar', 0) or 0) < -0.01]
    canc = res['cancelled']
    print(f"\n  {symbol}: ${res['end']} ({res['return_pct']:+}%)  |  صفقات صادقة={len(tr)}  (W={len(wins)} L={len(losses)})  |  setups أُلغيت (لم تُلمس)={len(canc)}")
    for i, t in enumerate(tr, 1):
        print(f"    #{i} {t['entry_time']} {t['bias']:7} entry={t['entry']:.2f} PnL={t.get('pnl_pct',0):+.3f}% MFE={t.get('mfe_r',0):.2f}R sig={t.get('signal_dt')}")
    if canc:
        print(f"    ── أُلغيت صادقاً (السعر لم يلمس الدخول):")
        for c in canc:
            print(f"       {c['signal_dt']} {c['bias']:7} entry={c['entry']:.2f} ← {c['cancel_reason']} @ {c.get('cancel_dt')}")
    return res


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--mode', default='CE_HONEST')
    ap.add_argument('--timeout', type=int, default=36)
    ap.add_argument('--market_cont', action='store_true', help='دخول ماركت صادق عند تأكيد الاستمرار')
    args = ap.parse_args()
    global LIMIT_TIMEOUT, MARKET_CONT
    LIMIT_TIMEOUT = args.timeout
    MARKET_CONT = args.market_cont

    btc_rows = load_csv(BTC_PATH, ['2023-0', '2023-1'])
    eth_rows = load_csv(ETH_PATH, ['2023-11', '2023-12'])
    print("\n" + "█" * 78)
    print(f"█  MODE = {args.mode}  timeout={args.timeout} شمعة  market_cont={args.market_cont}")
    print("█" * 78)
    for sym, rows in [('BTCUSDT', btc_rows), ('ETHUSDT', eth_rows)]:
        res = run_honest(sym, rows, '2023-12', args.mode)
        report(sym, res)


if __name__ == '__main__':
    main()
