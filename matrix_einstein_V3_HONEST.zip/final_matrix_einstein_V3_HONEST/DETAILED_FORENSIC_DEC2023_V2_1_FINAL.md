# تقرير مفصّل جداً — ديسمبر 2023 — BTC & ETH — نفس الشهر ونفس السنة — Matrix V2.1 Final

**رأس المال $100 / مخاطرة 2% (A=1.2% B=0.6% C=0.2%) — المحرك Matrix Einstein V2.1 (Continuation + Harvest Gate + Determinism + Breaker)**

## الملخص السريع

| عملة | $100→ | عائد | صفقات | W | L | WR | PF | سكانات | مرفوضة PD |
|---|---|---|---|---|---|---|---|---|
| BTCUSDT | $111.68 | 11.68% | 9 | 6 | 3 | 66.7% | - | 719 | 10 |
| ETHUSDT | $118.35 | 18.35% | 9 | 6 | 3 | 66.7% | - | 700 | 5 |

---


# BTCUSDT — MATRIX_EINSTEIN V2.1 FINAL — 2023-12 — $100→$111.68 (11.68%)

صفقات 9 رابحة 6 خاسرة 3 | سكانات 719 مرفوضة PD 10

## جدول سريع لكل الصفقات

| # | دخول | خروج | Bias | Entry | SL | TP1 | TP2 | TP3 | PnL% | $ | Bal | A | B | C | MFE | MAE | مدة | Session |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 2023-12-09 19:00 | 2023-12-09 22:50 | BULLISH | 43827.74 | 43632.28 | 44126.00 | 44488.00 | 0.00 | +2.506 | +2.51 | 102.51 | A_TRAIL | B_FORTRESS | C_FORTRESS | 1.58R | 0.37R | 3.8h | NY_PM_KILLZONE |
| 2 | 2023-12-10 07:00 | 2023-12-10 09:55 | BULLISH | 43787.11 | 43577.92 | 44114.78 | 44488.00 | 0.00 | +0.947 | +0.97 | 103.48 | CE_RISK_CUT | CE_RISK_CUT | CE_RISK_CUT | 0.49R | 0.34R | 2.9h | LONDON_KILLZONE |
| 3 | 2023-12-16 20:00 | 2023-12-16 21:25 | BEARISH | 42401.71 | 42556.01 | 42169.48 | 40222.00 | 35632.01 | -2.000 | -2.07 | 101.41 | SL | SL | SL | 0.60R | 1.36R | 1.4h | NY_PM_KILLZONE |
| 4 | 2023-12-18 08:00 | 2023-12-18 11:35 | BEARISH | 41899.21 | 42438.13 | 41057.17 | 40222.00 | 35632.01 | +3.130 | +3.17 | 104.58 | A_TRAIL | B_FORTRESS | C_FORTRESS | 2.04R | 0.00R | 3.6h | LONDON_KILLZONE |
| 5 | 2023-12-19 20:00 | 2023-12-19 23:55 | BEARISH | 43049.25 | 43509.64 | 42313.14 | 40222.00 | 36707.00 | +3.484 | +3.64 | 108.23 | A_TRAIL | B_FORTRESS | C_FORTRESS | 2.69R | 0.00R | 3.9h | NY_PM_KILLZONE |
| 6 | 2023-12-20 14:00 | 2023-12-20 18:30 | BEARISH | 42902.00 | 43050.81 | 42634.08 | 41605.00 | 36707.00 | -0.775 | -0.84 | 107.39 | SL | B_FORTRESS | C_FORTRESS | 1.53R | 1.33R | 4.5h | NY_AM_KILLZONE |
| 7 | 2023-12-22 14:00 | 2023-12-22 19:05 | BEARISH | 44103.74 | 44412.11 | 43624.81 | 41605.00 | 36707.00 | +2.944 | +3.16 | 110.55 | A_TRAIL | B_FORTRESS | C_FORTRESS | 2.08R | 0.00R | 5.1h | NY_AM_KILLZONE |
| 8 | 2023-12-23 09:00 | 2023-12-23 09:35 | BULLISH | 43543.90 | 43404.71 | 43759.97 | 44488.00 | 44488.00 | -2.000 | -2.21 | 108.34 | SL | SL | SL | 0.46R | 1.64R | 0.6h | LONDON_KILLZONE |
| 9 | 2023-12-24 15:00 | 2023-12-24 19:10 | BULLISH | 43509.22 | 43396.91 | 43682.67 | 44398.26 | 44488.00 | +3.084 | +3.34 | 111.68 | A_TRAIL | B_FORTRESS | C_FORTRESS | 2.00R | 0.93R | 4.2h | NY_AM_KILLZONE |

## تفصيل كل صفقة — شو شاف وشو عمل ليش قرر وليش شاف


### صفقة #1 — BULLISH — 2023-12-09 19:00 → 2023-12-09 22:50 — PnL +2.506% ($+2.51)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=NY_PM_KILLZONE NY=2023-12-09 14:00 NY (Sat) | سعر السوق لحظة الإشارة=43985.18 | Filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(98)+OB_HELD → old Premium is new Discount for DOL 44488.0. Mitigation Block continuation per ICT. LONG only.|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BULLISH Confidence=90 | Reason=HH+HL | Zone=PREMIUM | Confidence=90 | Structure={'hh': True, 'hl': True, 'lh': False, 'll': False}
  - Dealing Daily: zone=PREMIUM eq=39644.0 high=44488.0 low=34800.0 pct_in_range=93.2 current=43828.85
- **Layer2 NARRATIVE (15M Sweep):** Side=SSL Level=43810.0 Wick=43753.37 Quality=86.7 (min 25) | تعني: سيولة بيع مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=39750.0 ERL_H=44700.0 ERL_L=34800.0
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BULLISH BodyMult=4.65x Body%=83.7% Conviction=97.6 | تعني: اندفاع مؤسساتي — جسم 4.65x متوسط 5 شموع + جسم 83.7% من المدى = نية مؤسساتية
  - FVG: bottom=43797.78 top=43857.7 **CE(entry)=43827.74** dir=BULLISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=43827.74 SL=43632.280612 Risk=195.46 ATR=42.66 SL/ATR=4.58 | TP1={'price': 44126.0, 'kind': 'SWING', 'rr': 1.53, 'dist': 298.26000000000204} TP2={'price': 44488.0, 'kind': 'HTF_DRAW', 'rr': 3.38} TP3=None
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BULLISH conf90 zone=PREMIUM | SWEEP SSL Q86.7 lvl=43810.0 wick=43753.37 | DISP 4.65x 83.7% conv=97.6 | FVG 43797.78-43857.7 CE=43827.74 RR1=1.53 SL_ATR=4.58 | KZ=NY_PM_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 1.58R سعر متطرف لصالحنا 44136.52 | MAE 0.37R سعر ضدنا 43755.0 | مدة 3.8 ساعة | Phase EXPANSION
- أسباب خروج: A=A_TRAIL B=B_FORTRESS C=C_FORTRESS — تفسير: A=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. B=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. C=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. 
- Balance 100.0 → 102.50619952931548
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-09 19:00 OPEN entry=43827.74 sl=43632.280612 tp1=44126.0 filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(98)+OB_HELD → old Premium is new Discount for DOL 44488.0. Mitigation Block continuation per ICT. LONG only.|MID_OK | | | |
| | 2023-12-09 19:05 | 🧠 phase=ACCUMULATION | MFE=0.84R | impr=0 | fuel=0.92 | c=43985.91 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 19:10 | 🧠 phase=ACCUMULATION | MFE=0.84R | impr=0 | fuel=0.92 | c=43965.74 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 19:15 | 🧠 phase=ACCUMULATION | MFE=1.11R | impr=0 | fuel=0.92 | c=44036.31 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 19:20 | 🧠 phase=ACCUMULATION | MFE=1.11R | impr=0 | fuel=0.92 | c=43993.38 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 19:25 | 🧠 phase=ACCUMULATION | MFE=1.11R | impr=0 | fuel=0.92 | c=43996.33 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 19:30 | 🧠 phase=ACCUMULATION | MFE=1.16R | impr=0 | fuel=0.92 | c=44052.69 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 19:35 | 🧠 phase=ACCUMULATION | MFE=1.47R | impr=0 | fuel=0.92 | c=44080.36 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 19:40 | 🧠 phase=ACCUMULATION | MFE=1.47R | impr=0 | fuel=0.92 | c=44093.69 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 19:45 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | fuel=0.92 | c=44114.39 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 19:45 | 🎯 A:TP1 | c=44114.39 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 19:45 | 📣 PARTIAL_TAKEN→fortresses_active | c=44114.39 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 19:50 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | fuel=0.92 | c=44056.47 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 19:55 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | fuel=0.92 | c=44044.02 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 20:00 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | fuel=0.92 | c=44000.0 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 20:05 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | fuel=0.92 | c=43967.37 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 20:10 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | fuel=0.92 | c=43878.01 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 20:10 | 🧠 A:Trail | c=43878.01 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 20:15 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | fuel=0.92 | c=43770.52 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 20:20 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | fuel=0.92 | c=43857.37 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 20:25 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=42 | fuel=0.92 | c=43935.58 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 20:30 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=42 | fuel=0.92 | c=43936.01 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 20:35 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | fuel=0.92 | c=43881.72 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 20:40 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | fuel=0.92 | c=43899.74 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 20:45 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | fuel=0.92 | c=43934.81 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 20:50 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=60 | fuel=0.92 | c=43941.73 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 20:55 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | fuel=0.92 | c=43919.52 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 21:00 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | fuel=0.92 | c=43961.41 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 21:05 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=30 | fuel=0.92 | c=43939.22 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 21:10 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | fuel=0.92 | c=43963.51 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 21:15 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | fuel=0.92 | c=44030.68 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 21:20 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=71 | fuel=0.92 | c=44061.65 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 21:25 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=30 | fuel=0.92 | c=44045.1 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 21:30 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | CE=43996.09 | CE_HOLDS | fuel=0.92 | c=44075.0 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 21:35 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | CE=43996.09 | CE_HOLDS | fuel=0.92 | c=44066.83 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 21:40 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | CE=43996.09 | CE_HOLDS | fuel=0.92 | c=44047.82 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 21:45 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | CE=43996.09 | CE_HOLDS | fuel=0.92 | c=44022.89 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 21:50 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | CE=43996.09 | CE_HOLDS | fuel=0.92 | c=44019.94 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 21:55 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | CE=43996.09 | CE_HOLDS | fuel=0.92 | c=43999.99 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 22:00 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | CE=43996.09 | CE_WICK_REBALANCE | fuel=0.92 | c=44058.78 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 22:05 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=75 | CE=43996.09 | CE_WICK_REBALANCE | fuel=0.92 | c=44054.14 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 22:10 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | CE=43996.09 | CE_WICK_REBALANCE | fuel=0.92 | c=44058.72 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 22:15 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | CE=43996.09 | CE_HOLDS | fuel=0.92 | c=44038.54 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 22:20 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | CE=43996.09 | CE_HOLDS | fuel=0.92 | c=43986.93 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 22:25 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | CE=43996.09 | CE_HOLDS | fuel=0.92 | c=44008.58 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 22:30 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=30 | CE=43996.09 | CE_BODY_DEAD | fuel=0.92 | c=43989.72 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 22:35 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | CE=43996.09 | CE_BODY_DEAD | fuel=0.92 | c=43911.59 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 22:40 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | CE=43996.09 | CE_BODY_DEAD | fuel=0.92 | c=43893.52 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 22:45 | 🧠 phase=ACCUMULATION | MFE=1.58R | impr=0 | CE=43996.09 | CE_WICK_REBALANCE | fuel=0.92 | c=43966.24 sl_B=43632.280612 sl_C=43632.280612 | | | |
| | 2023-12-09 22:50 | 🧠 phase=EXPANSION | MFE=1.58R | impr=83 | CE=43996.09 | CE_WICK_REBALANCE | fuel=0.92 | c=43963.32 sl_B=43992.6772 sl_C=43992.6772 | | | |
| | 2023-12-09 22:50 | 🛡️ B:CE_SOFT→43992.68 | c=43963.32 sl_B=43992.6772 sl_C=43992.6772 | | | |
| | 2023-12-09 22:50 | 🛡️ C:CE_SOFT→43992.68 | c=43963.32 sl_B=43992.6772 sl_C=43992.6772 | | | |
| | 2023-12-09 22:50 | 🛡️ B:FORTRESS_HIT | c=43963.32 sl_B=43992.6772 sl_C=43992.6772 | | | |
| | 2023-12-09 22:50 | 🛡️ C:FORTRESS_HIT | c=43963.32 sl_B=43992.6772 sl_C=43992.6772 | | | |


### صفقة #2 — BULLISH — 2023-12-10 07:00 → 2023-12-10 09:55 — PnL +0.947% ($+0.97)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=LONDON_KILLZONE NY=2023-12-10 02:00 NY (Sun) | سعر السوق لحظة الإشارة=43823.62 | Filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(99)+OB_HELD → old Premium is new Discount for DOL 44488.0. Mitigation Block continuation per ICT. LONG only.|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BULLISH Confidence=90 | Reason=HH+HL | Zone=PREMIUM | Confidence=90 | Structure={'hh': True, 'hl': True, 'lh': False, 'll': False}
  - Dealing Daily: zone=PREMIUM eq=39644.0 high=44488.0 low=34800.0 pct_in_range=97.1 current=44202.25
- **Layer2 NARRATIVE (15M Sweep):** Side=SSL Level=43893.25 Wick=43864.86 Quality=56.9 (min 25) | تعني: سيولة بيع مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=39750.0 ERL_H=44700.0 ERL_L=34800.0
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BULLISH BodyMult=4.02x Body%=90.9% Conviction=98.6 | تعني: اندفاع مؤسساتي — جسم 4.02x متوسط 5 شموع + جسم 90.9% من المدى = نية مؤسساتية
  - FVG: bottom=43753.58 top=43820.64 **CE(entry)=43787.11** dir=BULLISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=43787.11 SL=43577.915571 Risk=209.19 ATR=43.96 SL/ATR=4.76 | TP1={'price': 44114.78, 'kind': 'SWING', 'rr': 1.57, 'dist': 327.66999999999825} TP2={'price': 44488.0, 'kind': 'HTF_DRAW', 'rr': 3.35} TP3=None
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BULLISH conf90 zone=PREMIUM | SWEEP SSL Q56.9 lvl=43893.25 wick=43864.86 | DISP 4.02x 90.9% conv=98.6 | FVG 43753.58-43820.64 CE=43787.11 RR1=1.57 SL_ATR=4.76 | KZ=LONDON_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 0.49R سعر متطرف لصالحنا 43890.29 | MAE 0.34R سعر ضدنا 43716.7 | مدة 2.9 ساعة | Phase EXPANSION
- أسباب خروج: A=CE_RISK_CUT B=CE_RISK_CUT C=CE_RISK_CUT — تفسير: A=CE_RISK_CUT MFE<1R — قطع مخاطرة مبكراً بدل -2% كاملة. B=CE_RISK_CUT MFE<1R — قطع مخاطرة مبكراً بدل -2% كاملة. C=CE_RISK_CUT MFE<1R — قطع مخاطرة مبكراً بدل -2% كاملة. 
- Balance 102.50619952931548 → 103.47721289031408
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-10 07:00 OPEN entry=43787.11 sl=43577.915571 tp1=44114.78 filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(99)+OB_HELD → old Premium is new Discount for DOL 44488.0. Mitigation Block continuation per ICT. LONG only.|MID_OK | | | |
| | 2023-12-10 07:05 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43798.01 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 07:10 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43802.52 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 07:15 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43798.1 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 07:20 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43807.98 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 07:25 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43793.86 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 07:30 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43802.23 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 07:35 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43772.92 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 07:40 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43748.9 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 07:45 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43741.84 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 07:50 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43749.84 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 07:55 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43729.38 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 08:00 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43724.03 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 08:05 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43756.0 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 08:10 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43778.06 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 08:15 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=47 | fuel=0.96 | c=43760.01 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 08:20 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43784.16 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 08:25 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=2 | fuel=0.96 | c=43744.71 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 08:30 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43744.73 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 08:35 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43744.73 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 08:40 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43765.99 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 08:45 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=30 | fuel=0.96 | c=43731.47 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 08:50 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=0 | fuel=0.96 | c=43776.0 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 08:55 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=54 | fuel=0.96 | c=43778.02 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 09:00 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=30 | fuel=0.96 | c=43811.99 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 09:05 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=60 | fuel=0.96 | c=43814.01 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 09:10 | 🧠 phase=ACCUMULATION | MFE=0.17R | impr=21 | fuel=0.96 | c=43819.77 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 09:15 | 🧠 phase=ACCUMULATION | MFE=0.20R | impr=30 | CE=43784.99 | CE_HOLDS | fuel=0.96 | c=43803.99 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 09:20 | 🧠 phase=ACCUMULATION | MFE=0.20R | impr=0 | CE=43784.99 | CE_HOLDS | fuel=0.96 | c=43815.01 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 09:25 | 🧠 phase=ACCUMULATION | MFE=0.28R | impr=30 | CE=43784.99 | CE_HOLDS | fuel=0.96 | c=43845.32 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 09:30 | 🧠 phase=ACCUMULATION | MFE=0.28R | impr=71 | CE=43784.99 | CE_HOLDS | fuel=0.96 | c=43834.38 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 09:35 | 🧠 phase=ACCUMULATION | MFE=0.28R | impr=0 | CE=43784.99 | CE_HOLDS | fuel=0.96 | c=43830.01 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 09:40 | 🧠 phase=ACCUMULATION | MFE=0.28R | impr=0 | CE=43784.99 | CE_HOLDS | fuel=0.96 | c=43826.98 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 09:45 | 🧠 phase=ACCUMULATION | MFE=0.28R | impr=0 | CE=43784.99 | CE_HOLDS | fuel=0.96 | c=43839.63 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 09:50 | 🧠 phase=ACCUMULATION | MFE=0.45R | impr=60 | CE=43784.99 | CE_HOLDS | fuel=0.95 | c=43873.24 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 09:55 | 🧠 phase=EXPANSION | MFE=0.49R | impr=100 | CE=43856.43 | CE_BODY_DEAD | fuel=0.94 | c=43886.19 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 09:55 | ☠️ A:CE_RISK_CUT @ 43886.19 | c=43886.19 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 09:55 | ☠️ B:CE_RISK_CUT @ 43886.19 | c=43886.19 sl_B=43577.915571 sl_C=43577.915571 | | | |
| | 2023-12-10 09:55 | ☠️ C:CE_RISK_CUT @ 43886.19 | c=43886.19 sl_B=43577.915571 sl_C=43577.915571 | | | |


### صفقة #3 — BEARISH — 2023-12-16 20:00 → 2023-12-16 21:25 — PnL -2.000% ($-2.07)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=NY_PM_KILLZONE NY=2023-12-16 15:00 NY (Sat) | سعر السوق لحظة الإشارة=42324.02 | Filter=ACCUM:PD_PREMIUM|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BEARISH Confidence=100 | Reason=LH+LL | Zone=PREMIUM | Confidence=100 | Structure={'hh': False, 'hl': False, 'lh': True, 'll': True}
  - Dealing Daily: zone=PREMIUM eq=40166.005 high=44700.0 low=35632.01 pct_in_range=70.7 current=42045.1
- **Layer2 NARRATIVE (15M Sweep):** Side=BSL Level=42180.0 Wick=42223.93 Quality=54.6 (min 25) | تعني: سيولة شراء مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=40166.005 ERL_H=44700.0 ERL_L=35632.01
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BEARISH BodyMult=4.93x Body%=92.5% Conviction=100.0 | تعني: اندفاع مؤسساتي — جسم 4.93x متوسط 5 شموع + جسم 92.5% من المدى = نية مؤسساتية
  - FVG: bottom=42381.43 top=42421.99 **CE(entry)=42401.71** dir=BEARISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=42401.71 SL=42556.010579 Risk=154.3 ATR=53.4 SL/ATR=2.89 | TP1={'price': 42169.48, 'kind': 'SWING', 'rr': 1.51, 'dist': 232.22999999999593} TP2={'price': 40222.0, 'kind': 'HTF_DRAW', 'rr': 14.13} TP3=35632.01
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BEARISH conf100 zone=PREMIUM | SWEEP BSL Q54.6 lvl=42180.0 wick=42223.93 | DISP 4.93x 92.5% conv=100.0 | FVG 42381.43-42421.99 CE=42401.71 RR1=1.51 SL_ATR=2.89 | KZ=NY_PM_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 0.60R سعر متطرف لصالحنا 42309.87 | MAE 1.36R سعر ضدنا 42611.08 | مدة 1.4 ساعة | Phase ACCUMULATION
- أسباب خروج: A=SL B=SL C=SL — تفسير: A=SL ضرب الستوب الابتدائي قبل TP1 — الفكرة فشلت مبكراً. B=SL ضرب الستوب الابتدائي قبل TP1 — الفكرة فشلت مبكراً. C=SL ضرب الستوب الابتدائي قبل TP1 — الفكرة فشلت مبكراً. 
- Balance 103.47721289031408 → 101.40766086668712
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-16 20:00 OPEN entry=42401.71 sl=42556.010579 tp1=42169.48 filter=ACCUM:PD_PREMIUM|MID_OK | | | |
| | 2023-12-16 20:05 | 🧠 phase=ACCUMULATION | MFE=0.53R | impr=0 | fuel=0.84 | c=42332.96 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 20:10 | 🧠 phase=ACCUMULATION | MFE=0.53R | impr=0 | fuel=0.84 | c=42353.8 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 20:15 | 🧠 phase=ACCUMULATION | MFE=0.53R | impr=0 | fuel=0.84 | c=42329.49 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 20:20 | 🧠 phase=ACCUMULATION | MFE=0.53R | impr=0 | fuel=0.84 | c=42363.26 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 20:25 | 🧠 phase=ACCUMULATION | MFE=0.53R | impr=0 | fuel=0.84 | c=42361.63 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 20:30 | 🧠 phase=ACCUMULATION | MFE=0.53R | impr=0 | fuel=0.84 | c=42438.01 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 20:35 | 🧠 phase=ACCUMULATION | MFE=0.53R | impr=0 | fuel=0.84 | c=42396.0 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 20:40 | 🧠 phase=ACCUMULATION | MFE=0.53R | impr=0 | fuel=0.84 | c=42371.99 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 20:45 | 🧠 phase=ACCUMULATION | MFE=0.60R | impr=0 | fuel=0.84 | c=42328.0 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 20:50 | 🧠 phase=ACCUMULATION | MFE=0.60R | impr=0 | fuel=0.84 | c=42337.52 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 20:55 | 🧠 phase=ACCUMULATION | MFE=0.60R | impr=0 | fuel=0.84 | c=42366.25 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 21:00 | 🧠 phase=ACCUMULATION | MFE=0.60R | impr=0 | fuel=0.84 | c=42470.57 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 21:05 | 🧠 phase=ACCUMULATION | MFE=0.60R | impr=0 | fuel=0.84 | c=42444.87 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 21:10 | 🧠 phase=ACCUMULATION | MFE=0.60R | impr=0 | fuel=0.84 | c=42439.96 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 21:15 | 🧠 phase=ACCUMULATION | MFE=0.60R | impr=0 | fuel=0.84 | c=42464.44 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 21:20 | 🧠 phase=ACCUMULATION | MFE=0.60R | impr=0 | fuel=0.84 | c=42496.31 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 21:25 | 🧠 phase=ACCUMULATION | MFE=0.60R | impr=0 | fuel=0.84 | c=42604.0 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 21:25 | ❌ A:SL | c=42604.0 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 21:25 | ❌ B:SL | c=42604.0 sl_B=42556.010579 sl_C=42556.010579 | | | |
| | 2023-12-16 21:25 | ❌ C:SL | c=42604.0 sl_B=42556.010579 sl_C=42556.010579 | | | |


### صفقة #4 — BEARISH — 2023-12-18 08:00 → 2023-12-18 11:35 — PnL +3.130% ($+3.17)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=LONDON_KILLZONE NY=2023-12-18 03:00 NY (Mon) | سعر السوق لحظة الإشارة=40949.5 | Filter=ACCUM:PD_PREMIUM|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BEARISH Confidence=100 | Reason=LH+LL | Zone=PREMIUM | Confidence=100 | Structure={'hh': False, 'hl': False, 'lh': True, 'll': True}
  - Dealing Daily: zone=PREMIUM eq=40166.005 high=44700.0 low=35632.01 pct_in_range=69.0 current=41886.25
- **Layer2 NARRATIVE (15M Sweep):** Side=BSL Level=42176.31 Wick=42190.87 Quality=25.2 (min 25) | تعني: سيولة شراء مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=40166.005 ERL_H=44700.0 ERL_L=35632.01
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BEARISH BodyMult=3.65x Body%=98.3% Conviction=99.7 | تعني: اندفاع مؤسساتي — جسم 3.65x متوسط 5 شموع + جسم 98.3% من المدى = نية مؤسساتية
  - FVG: bottom=41884.82 top=41913.61 **CE(entry)=41899.215** dir=BEARISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=41899.215 SL=42438.128771 Risk=538.91 ATR=93.73 SL/ATR=5.75 | TP1={'price': 41057.17, 'kind': 'SWING', 'rr': 1.56, 'dist': 842.0449999999983} TP2={'price': 40222.0, 'kind': 'HTF_DRAW', 'rr': 3.11} TP3=35632.01
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BEARISH conf100 zone=PREMIUM | SWEEP BSL Q25.2 lvl=42176.31 wick=42190.87 | DISP 3.65x 98.3% conv=99.7 | FVG 41884.82-41913.61 CE=41899.215 RR1=1.56 SL_ATR=5.75 | KZ=LONDON_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 2.04R سعر متطرف لصالحنا 40801.0 | MAE 0.00R سعر ضدنا 41899.215 | مدة 3.6 ساعة | Phase EXPANSION
- أسباب خروج: A=A_TRAIL B=B_FORTRESS C=C_FORTRESS — تفسير: A=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. B=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. C=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. 
- Balance 101.40766086668712 → 104.5818767967681
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-18 08:00 OPEN entry=41899.215 sl=42438.128771 tp1=41057.17 filter=ACCUM:PD_PREMIUM|MID_OK | | | |
| | 2023-12-18 08:05 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=40852.0 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 08:05 | 🎯 A:TP1 | c=40852.0 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 08:05 | 📣 PARTIAL_TAKEN→fortresses_active | c=40852.0 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 08:10 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=40877.99 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 08:15 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=40920.0 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 08:20 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=40902.0 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 08:25 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=40900.57 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 08:30 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41026.01 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 08:35 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41017.76 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 08:40 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=40992.79 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 08:45 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41038.0 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 08:50 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41048.03 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 08:55 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41045.99 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 09:00 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41054.0 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 09:05 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41037.99 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 09:10 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41107.55 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 09:15 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41065.99 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 09:20 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=48 | fuel=0.54 | c=41108.01 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 09:25 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41090.92 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 09:30 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=30 | fuel=0.54 | c=41081.08 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 09:35 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=30 | fuel=0.54 | c=41048.27 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 09:40 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=30 | fuel=0.54 | c=41089.83 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 09:45 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41092.01 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 09:45 | 🧠 A:Trail | c=41092.01 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 09:50 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41158.0 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 09:55 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41181.09 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 10:00 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41132.05 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 10:05 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=37 | fuel=0.54 | c=41119.99 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 10:10 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41151.09 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 10:15 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41140.0 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 10:20 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41199.99 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 10:25 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41187.53 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 10:30 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41159.26 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 10:35 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=60 | fuel=0.54 | c=41106.01 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 10:40 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=60 | fuel=0.54 | c=41119.98 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 10:45 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41111.03 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 10:50 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41154.92 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 10:55 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41179.19 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 11:00 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41166.9 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 11:05 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41143.77 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 11:10 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=30 | fuel=0.54 | c=41086.38 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 11:15 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=49 | fuel=0.54 | c=41103.46 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 11:20 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=0 | fuel=0.54 | c=41070.18 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 11:25 | 🧠 phase=ACCUMULATION | MFE=2.04R | impr=48 | fuel=0.54 | c=41004.18 sl_B=42438.128771 sl_C=42438.128771 | | | |
| | 2023-12-18 11:30 | 🧠 phase=EXPANSION | MFE=2.04R | impr=82 | CE=41046.19 | CE_WICK_REBALANCE | fuel=0.54 | c=41013.09 sl_B=41053.6934 sl_C=41053.6934 | | | |
| | 2023-12-18 11:30 | 🛡️ B:CE_SOFT→41053.69 | c=41013.09 sl_B=41053.6934 sl_C=41053.6934 | | | |
| | 2023-12-18 11:30 | 🛡️ C:CE_SOFT→41053.69 | c=41013.09 sl_B=41053.6934 sl_C=41053.6934 | | | |
| | 2023-12-18 11:35 | 🧠 phase=EXPANSION | MFE=2.04R | impr=0 | CE=41046.19 | CE_WICK_REBALANCE | fuel=0.54 | c=41064.01 sl_B=41053.6934 sl_C=41053.6934 | | | |
| | 2023-12-18 11:35 | 🛡️ B:FORTRESS_HIT | c=41064.01 sl_B=41053.6934 sl_C=41053.6934 | | | |
| | 2023-12-18 11:35 | 🛡️ C:FORTRESS_HIT | c=41064.01 sl_B=41053.6934 sl_C=41053.6934 | | | |


### صفقة #5 — BEARISH — 2023-12-19 20:00 → 2023-12-19 23:55 — PnL +3.484% ($+3.64)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=NY_PM_KILLZONE NY=2023-12-19 15:00 NY (Tue) | سعر السوق لحظة الإشارة=42691.09 | Filter=ACCUM:PD_PREMIUM|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BEARISH Confidence=95 | Reason=LH+LL | Zone=PREMIUM | Confidence=95 | Structure={'hh': False, 'hl': False, 'lh': True, 'll': True}
  - Dealing Daily: zone=PREMIUM eq=40703.5 high=44700.0 low=36707.0 pct_in_range=62.3 current=41688.02
- **Layer2 NARRATIVE (15M Sweep):** Side=BSL Level=43024.27 Wick=43100.0 Quality=76.0 (min 25) | تعني: سيولة شراء مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=40166.005 ERL_H=44700.0 ERL_L=35632.01
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BEARISH BodyMult=2.54x Body%=97.4% Conviction=86.2 | تعني: اندفاع مؤسساتي — جسم 2.54x متوسط 5 شموع + جسم 97.4% من المدى = نية مؤسساتية
  - FVG: bottom=43024.31 top=43074.2 **CE(entry)=43049.255** dir=BEARISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=43049.255 SL=43509.640967 Risk=460.39 ATR=84.27 SL/ATR=5.46 | TP1={'price': 42313.14, 'kind': 'SWING', 'rr': 1.6, 'dist': 736.114999999998} TP2={'price': 40222.0, 'kind': 'HTF_DRAW', 'rr': 6.14} TP3=36707.0
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BEARISH conf95 zone=PREMIUM | SWEEP BSL Q76.0 lvl=43024.27 wick=43100.0 | DISP 2.54x 97.4% conv=86.2 | FVG 43024.31-43074.2 CE=43049.255 RR1=1.6 SL_ATR=5.46 | KZ=NY_PM_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 2.69R سعر متطرف لصالحنا 41811.1 | MAE 0.00R سعر ضدنا 43049.255 | مدة 3.9 ساعة | Phase EXPANSION
- أسباب خروج: A=A_TRAIL B=B_FORTRESS C=C_FORTRESS — تفسير: A=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. B=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. C=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. 
- Balance 104.5818767967681 → 108.22532320459332
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-19 20:00 OPEN entry=43049.255 sl=43509.640967 tp1=42313.14 filter=ACCUM:PD_PREMIUM|MID_OK | | | |
| | 2023-12-19 20:05 | 🧠 phase=ACCUMULATION | MFE=0.86R | impr=0 | fuel=0.96 | c=42652.29 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 20:10 | 🧠 phase=ACCUMULATION | MFE=0.92R | impr=0 | fuel=0.96 | c=42635.56 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 20:15 | 🧠 phase=ACCUMULATION | MFE=1.30R | impr=0 | fuel=0.90 | c=42475.39 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 20:20 | 🧠 phase=ACCUMULATION | MFE=1.77R | impr=0 | fuel=0.76 | c=42301.24 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 20:20 | 🎯 A:TP1 | c=42301.24 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 20:20 | 📣 PARTIAL_TAKEN→fortresses_active | c=42301.24 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 20:25 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42367.03 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 20:30 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42458.01 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 20:35 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42502.24 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 20:40 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42562.06 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 20:45 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42631.09 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 20:50 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42593.58 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 20:55 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42729.98 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 21:00 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42629.61 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 21:05 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42591.96 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 21:10 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42617.13 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 21:15 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42522.79 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 21:20 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=25 | fuel=0.76 | c=42484.5 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 21:25 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42486.86 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 21:30 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42610.71 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 21:35 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42574.96 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 21:40 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=22 | fuel=0.76 | c=42639.99 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 21:40 | 🧠 A:Trail | c=42639.99 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 21:45 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42584.8 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 21:50 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=30 | fuel=0.76 | c=42548.02 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 21:55 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=30 | fuel=0.76 | c=42464.94 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 22:00 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=56 | fuel=0.76 | c=42451.1 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 22:05 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42469.99 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 22:10 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | fuel=0.76 | c=42460.28 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 22:15 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | CE=42518.67 | CE_HOLDS | fuel=0.76 | c=42390.44 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 22:20 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=6 | CE=42518.67 | CE_HOLDS | fuel=0.76 | c=42417.22 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 22:25 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=0 | CE=42518.67 | CE_HOLDS | fuel=0.76 | c=42337.8 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 22:30 | 🧠 phase=ACCUMULATION | MFE=1.78R | impr=29 | CE=42518.67 | CE_HOLDS | fuel=0.76 | c=42282.5 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 22:35 | 🧠 phase=ACCUMULATION | MFE=2.17R | impr=30 | CE=42518.67 | CE_HOLDS | fuel=0.64 | c=42106.11 sl_B=43509.640967 sl_C=43509.640967 | | | |
| | 2023-12-19 22:40 | 🧠 phase=EXPANSION | MFE=2.39R | impr=100 | CE=42186.79 | CE_WICK_REBALANCE | fuel=0.58 | c=42015.27 sl_B=42193.5945 sl_C=42193.5945 | | | |
| | 2023-12-19 22:40 | 🛡️ B:CE_SOFT→42193.59 | c=42015.27 sl_B=42193.5945 sl_C=42193.5945 | | | |
| | 2023-12-19 22:40 | 🛡️ C:CE_SOFT→42193.59 | c=42015.27 sl_B=42193.5945 sl_C=42193.5945 | | | |
| | 2023-12-19 22:45 | 🧠 phase=EXPANSION | MFE=2.50R | impr=14 | CE=42186.79 | CE_WICK_REBALANCE | fuel=0.54 | c=41963.13 sl_B=42193.5945 sl_C=42193.5945 | | | |
| | 2023-12-19 22:50 | 🧠 phase=EXPANSION | MFE=2.50R | impr=0 | CE=42186.79 | CE_WICK_REBALANCE | fuel=0.54 | c=41901.1 sl_B=42193.5945 sl_C=42193.5945 | | | |
| | 2023-12-19 22:55 | 🧠 phase=EXPANSION | MFE=2.55R | impr=11 | CE=42186.79 | CE_WICK_REBALANCE | fuel=0.53 | c=41967.96 sl_B=42193.5945 sl_C=42193.5945 | | | |
| | 2023-12-19 23:00 | 🧠 phase=EXPANSION | MFE=2.59R | impr=0 | CE=42136.73 | CE_HOLDS | fuel=0.52 | c=41988.0 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |
| | 2023-12-19 23:00 | 🛡️ B:CE_SOFT→42148.53 | c=41988.0 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |
| | 2023-12-19 23:00 | 🛡️ C:CE_SOFT→42148.53 | c=41988.0 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |
| | 2023-12-19 23:05 | 🧠 phase=EXPANSION | MFE=2.59R | impr=0 | CE=42136.73 | CE_HOLDS | fuel=0.52 | c=42081.1 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |
| | 2023-12-19 23:10 | 🧠 phase=EXPANSION | MFE=2.59R | impr=0 | CE=42136.73 | CE_HOLDS | fuel=0.52 | c=42043.98 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |
| | 2023-12-19 23:15 | 🧠 phase=EXPANSION | MFE=2.59R | impr=0 | CE=42136.73 | CE_HOLDS | fuel=0.52 | c=42100.02 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |
| | 2023-12-19 23:20 | 🧠 phase=EXPANSION | MFE=2.59R | impr=0 | CE=42136.73 | CE_HOLDS | fuel=0.52 | c=41928.69 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |
| | 2023-12-19 23:25 | 🧠 phase=EXPANSION | MFE=2.64R | impr=96 | CE=42136.73 | CE_HOLDS | fuel=0.50 | c=41854.06 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |
| | 2023-12-19 23:30 | 🧠 phase=EXPANSION | MFE=2.69R | impr=30 | CE=42136.73 | CE_HOLDS | fuel=0.49 | c=41934.94 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |
| | 2023-12-19 23:35 | 🧠 phase=EXPANSION | MFE=2.69R | impr=0 | CE=42136.73 | CE_HOLDS | fuel=0.49 | c=41920.0 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |
| | 2023-12-19 23:40 | 🧠 phase=EXPANSION | MFE=2.69R | impr=0 | CE=42136.73 | CE_HOLDS | fuel=0.49 | c=42050.0 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |
| | 2023-12-19 23:45 | 🧠 phase=EXPANSION | MFE=2.69R | impr=0 | CE=42136.73 | CE_HOLDS | fuel=0.49 | c=42067.76 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |
| | 2023-12-19 23:50 | 🧠 phase=EXPANSION | MFE=2.69R | impr=0 | CE=42136.73 | CE_HOLDS | fuel=0.49 | c=42093.89 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |
| | 2023-12-19 23:55 | 🧠 phase=EXPANSION | MFE=2.69R | impr=0 | CE=42136.73 | CE_HOLDS | fuel=0.49 | c=42154.47 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |
| | 2023-12-19 23:55 | 🛡️ B:FORTRESS_HIT | c=42154.47 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |
| | 2023-12-19 23:55 | 🛡️ C:FORTRESS_HIT | c=42154.47 sl_B=42148.531500000005 sl_C=42148.531500000005 | | | |


### صفقة #6 — BEARISH — 2023-12-20 14:00 → 2023-12-20 18:30 — PnL -0.775% ($-0.84)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=NY_AM_KILLZONE NY=2023-12-20 09:00 NY (Wed) | سعر السوق لحظة الإشارة=42869.07 | Filter=ACCUM:PD_PREMIUM|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BEARISH Confidence=100 | Reason=LH+LL | Zone=PREMIUM | Confidence=100 | Structure={'hh': False, 'hl': False, 'lh': True, 'll': True}
  - Dealing Daily: zone=PREMIUM eq=40703.5 high=44700.0 low=36707.0 pct_in_range=78.0 current=42939.0
- **Layer2 NARRATIVE (15M Sweep):** Side=BSL Level=42880.08 Wick=42998.08 Quality=97.3 (min 25) | تعني: سيولة شراء مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=40469.6 ERL_H=44700.0 ERL_L=36239.2
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BEARISH BodyMult=2.94x Body%=84.5% Conviction=98.2 | تعني: اندفاع مؤسساتي — جسم 2.94x متوسط 5 شموع + جسم 84.5% من المدى = نية مؤسساتية
  - FVG: bottom=42880.0 top=42924.0 **CE(entry)=42902.0** dir=BEARISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=42902.0 SL=43050.805438 Risk=148.81 ATR=64.7 SL/ATR=2.3 | TP1={'price': 42634.08, 'kind': 'SWING', 'rr': 1.8, 'dist': 267.91999999999825} TP2={'price': 41605.0, 'kind': 'HTF_DRAW', 'rr': 8.72} TP3=36707.0
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BEARISH conf100 zone=PREMIUM | SWEEP BSL Q97.3 lvl=42880.08 wick=42998.08 | DISP 2.94x 84.5% conv=98.2 | FVG 42880.0-42924.0 CE=42902.0 RR1=1.8 SL_ATR=2.3 | KZ=NY_AM_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 1.53R سعر متطرف لصالحنا 42675.0 | MAE 1.33R سعر ضدنا 43100.0 | مدة 4.5 ساعة | Phase EXPANSION
- أسباب خروج: A=SL B=B_FORTRESS C=C_FORTRESS — تفسير: A=SL ضرب الستوب الابتدائي قبل TP1 — الفكرة فشلت مبكراً. B=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. C=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. 
- Balance 108.22532320459332 → 107.38690003591105
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-20 14:00 OPEN entry=42902.0 sl=43050.805438 tp1=42634.08 filter=ACCUM:PD_PREMIUM|MID_OK | | | |
| | 2023-12-20 14:05 | 🧠 phase=ACCUMULATION | MFE=0.46R | impr=0 | fuel=0.95 | c=42834.08 sl_B=43050.805438 sl_C=43050.805438 | | | |
| | 2023-12-20 14:10 | 🧠 phase=ACCUMULATION | MFE=0.47R | impr=0 | fuel=0.95 | c=42832.24 sl_B=43050.805438 sl_C=43050.805438 | | | |
| | 2023-12-20 14:15 | 🧠 phase=ACCUMULATION | MFE=0.98R | impr=0 | fuel=0.95 | c=42767.39 sl_B=43050.805438 sl_C=43050.805438 | | | |
| | 2023-12-20 14:20 | 🧠 phase=ACCUMULATION | MFE=0.98R | impr=0 | fuel=0.95 | c=42791.11 sl_B=43050.805438 sl_C=43050.805438 | | | |
| | 2023-12-20 14:25 | 🧠 phase=ACCUMULATION | MFE=0.98R | impr=0 | fuel=0.95 | c=42776.99 sl_B=43050.805438 sl_C=43050.805438 | | | |
| | 2023-12-20 14:30 | 🧠 phase=ACCUMULATION | MFE=0.98R | impr=0 | fuel=0.95 | c=42853.52 sl_B=43050.805438 sl_C=43050.805438 | | | |
| | 2023-12-20 14:35 | 🧠 phase=ACCUMULATION | MFE=0.98R | impr=0 | fuel=0.95 | c=42821.88 sl_B=43050.805438 sl_C=43050.805438 | | | |
| | 2023-12-20 14:40 | 🧠 phase=ACCUMULATION | MFE=0.98R | impr=0 | fuel=0.95 | c=42848.92 sl_B=43050.805438 sl_C=43050.805438 | | | |
| | 2023-12-20 14:45 | 🧠 phase=ACCUMULATION | MFE=0.98R | impr=0 | fuel=0.95 | c=42864.79 sl_B=43050.805438 sl_C=43050.805438 | | | |
| | 2023-12-20 14:50 | 🧠 phase=ACCUMULATION | MFE=0.98R | impr=0 | fuel=0.95 | c=42885.46 sl_B=43050.805438 sl_C=43050.805438 | | | |
| | 2023-12-20 14:55 | 🧠 phase=ACCUMULATION | MFE=0.98R | impr=0 | fuel=0.95 | c=42949.72 sl_B=43050.805438 sl_C=43050.805438 | | | |
| | 2023-12-20 15:00 | 🧠 phase=ACCUMULATION | MFE=0.98R | impr=0 | fuel=0.95 | c=42894.01 sl_B=43050.805438 sl_C=43050.805438 | | | |
| | 2023-12-20 15:05 | 🧠 phase=ACCUMULATION | MFE=0.98R | impr=0 | fuel=0.95 | c=42853.99 sl_B=43050.805438 sl_C=43050.805438 | | | |
| | 2023-12-20 15:10 | 🧠 phase=ACCUMULATION | MFE=0.98R | impr=0 | fuel=0.95 | c=42844.16 sl_B=43050.805438 sl_C=43050.805438 | | | |
| | 2023-12-20 15:15 | 🧠 phase=ACCUMULATION | MFE=1.22R | impr=0 | fuel=0.95 | c=42742.31 sl_B=43050.805438 sl_C=43050.805438 | | | |
| | 2023-12-20 15:20 | 🧠 phase=EXPANSION | MFE=1.22R | impr=99 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42764.67 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 15:20 | 🛡️ B:CE_SOFT→42822.90 | c=42764.67 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 15:20 | 🛡️ C:CE_SOFT→42822.90 | c=42764.67 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 15:25 | 🧠 phase=EXPANSION | MFE=1.22R | impr=0 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42788.36 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 15:30 | 🧠 phase=EXPANSION | MFE=1.22R | impr=0 | CE=42817.72 | CE_HOLDS | fuel=0.95 | c=42775.59 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 15:35 | 🧠 phase=EXPANSION | MFE=1.22R | impr=0 | CE=42817.72 | CE_HOLDS | fuel=0.95 | c=42746.0 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 15:40 | 🧠 phase=EXPANSION | MFE=1.22R | impr=30 | CE=42817.72 | CE_HOLDS | fuel=0.95 | c=42852.62 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 15:40 | 🛡️ B:FORTRESS_HIT | c=42852.62 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 15:40 | 🛡️ C:FORTRESS_HIT | c=42852.62 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 15:45 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42726.2 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 15:50 | 🧠 phase=EXPANSION | MFE=1.53R | impr=56 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42772.0 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 15:55 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42748.44 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 16:00 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_HOLDS | fuel=0.95 | c=42788.17 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 16:05 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_HOLDS | fuel=0.95 | c=42804.99 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 16:10 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_HOLDS | fuel=0.95 | c=42832.21 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 16:15 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_BODY_DEAD | fuel=0.95 | c=42844.47 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 16:15 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=42844.47 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 16:20 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_BODY_DEAD | fuel=0.95 | c=42792.59 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 16:20 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=42792.59 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 16:25 | 🧠 phase=EXPANSION | MFE=1.53R | impr=15 | CE=42817.72 | CE_BODY_DEAD | fuel=0.95 | c=42870.67 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 16:25 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=42870.67 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 16:30 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42826.25 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 16:35 | 🧠 phase=EXPANSION | MFE=1.53R | impr=30 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42894.46 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 16:40 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42818.15 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 16:45 | 🧠 phase=EXPANSION | MFE=1.53R | impr=20 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42860.39 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 16:50 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42836.89 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 16:55 | 🧠 phase=EXPANSION | MFE=1.53R | impr=30 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42788.0 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 17:00 | 🧠 phase=EXPANSION | MFE=1.53R | impr=60 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42779.87 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 17:05 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42806.98 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 17:10 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42842.94 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 17:15 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_BODY_DEAD | fuel=0.95 | c=42984.0 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 17:15 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=42984.0 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 17:20 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_BODY_DEAD | fuel=0.95 | c=42925.57 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 17:20 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=42925.57 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 17:25 | 🧠 phase=EXPANSION | MFE=1.53R | impr=30 | CE=42817.72 | CE_BODY_DEAD | fuel=0.95 | c=42864.44 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 17:25 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=42864.44 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 17:30 | 🧠 phase=EXPANSION | MFE=1.53R | impr=57 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42868.96 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 17:35 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42777.19 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 17:40 | 🧠 phase=EXPANSION | MFE=1.53R | impr=61 | CE=42817.72 | CE_WICK_REBALANCE | fuel=0.95 | c=42787.45 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 17:45 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_WICK_REBALANCE | ITL_HARD=42993.20 | fuel=0.95 | c=42857.82 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 17:50 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_WICK_REBALANCE | ITL_HARD=42993.20 | fuel=0.95 | c=42897.66 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 17:55 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_WICK_REBALANCE | ITL_HARD=42993.20 | fuel=0.95 | c=42935.15 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 18:00 | 🧠 phase=EXPANSION | MFE=1.53R | impr=0 | CE=42817.72 | CE_BODY_DEAD | ITL_HARD=42993.20 | fuel=0.95 | c=42939.51 sl_B=42822.896 sl_C=42822.896 | | | |
| | 2023-12-20 18:00 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=42939.51 sl_B=42822.896 sl_C=42822.896 | | | |


### صفقة #7 — BEARISH — 2023-12-22 14:00 → 2023-12-22 19:05 — PnL +2.944% ($+3.16)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=NY_AM_KILLZONE NY=2023-12-22 09:00 NY (Fri) | سعر السوق لحظة الإشارة=43762.76 | Filter=ACCUM:PD_PREMIUM|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BEARISH Confidence=75 | Reason=LH+LL | Zone=PREMIUM | Confidence=75 | Structure={'hh': False, 'hl': False, 'lh': True, 'll': True}
  - Dealing Daily: zone=PREMIUM eq=40703.5 high=44700.0 low=36707.0 pct_in_range=93.7 current=44199.99
- **Layer2 NARRATIVE (15M Sweep):** Side=BSL Level=44230.22 Wick=44398.26 Quality=63.9 (min 25) | تعني: سيولة شراء مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=40703.5 ERL_H=44700.0 ERL_L=36707.0
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BEARISH BodyMult=2.12x Body%=80.8% Conviction=73.3 | تعني: اندفاع مؤسساتي — جسم 2.12x متوسط 5 شموع + جسم 80.8% من المدى = نية مؤسساتية
  - FVG: bottom=44070.0 top=44137.48 **CE(entry)=44103.740000000005** dir=BEARISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=44103.74 SL=44412.113389 Risk=308.37 ATR=92.36 SL/ATR=3.34 | TP1={'price': 43624.81, 'kind': 'SWING', 'rr': 1.55, 'dist': 478.93000000000757} TP2={'price': 41605.0, 'kind': 'HTF_DRAW', 'rr': 8.1} TP3=36707.0
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BEARISH conf75 zone=PREMIUM | SWEEP BSL Q63.9 lvl=44230.22 wick=44398.26 | DISP 2.12x 80.8% conv=73.3 | FVG 44070.0-44137.48 CE=44103.740000000005 RR1=1.55 SL_ATR=3.34 | KZ=NY_AM_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 2.08R سعر متطرف لصالحنا 43463.0 | MAE 0.00R سعر ضدنا 44103.74 | مدة 5.1 ساعة | Phase EXPANSION
- أسباب خروج: A=A_TRAIL B=B_FORTRESS C=C_FORTRESS — تفسير: A=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. B=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. C=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. 
- Balance 107.38690003591105 → 110.54863392132235
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-22 14:00 OPEN entry=44103.74 sl=44412.113389 tp1=43624.81 filter=ACCUM:PD_PREMIUM|MID_OK | | | |
| | 2023-12-22 14:05 | 🧠 phase=ACCUMULATION | MFE=1.43R | impr=0 | fuel=0.77 | c=43689.16 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 14:10 | 🧠 phase=ACCUMULATION | MFE=1.53R | impr=0 | fuel=0.77 | c=43632.0 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 14:15 | 🧠 phase=ACCUMULATION | MFE=1.53R | impr=0 | fuel=0.77 | c=43699.29 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 14:20 | 🧠 phase=ACCUMULATION | MFE=1.53R | impr=0 | fuel=0.77 | c=43655.33 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 14:25 | 🧠 phase=ACCUMULATION | MFE=1.62R | impr=0 | fuel=0.77 | c=43610.01 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 14:25 | 🎯 A:TP1 | c=43610.01 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 14:25 | 📣 PARTIAL_TAKEN→fortresses_active | c=43610.01 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 14:30 | 🧠 phase=ACCUMULATION | MFE=1.62R | impr=0 | fuel=0.77 | c=43630.33 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 14:35 | 🧠 phase=ACCUMULATION | MFE=1.63R | impr=0 | fuel=0.77 | c=43684.66 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 14:40 | 🧠 phase=ACCUMULATION | MFE=1.63R | impr=0 | fuel=0.77 | c=43600.01 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 14:45 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43506.57 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 14:50 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43526.64 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 14:50 | 🧠 A:Trail | c=43526.64 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 14:55 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43597.34 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 15:00 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43641.63 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 15:05 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43606.0 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 15:10 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43701.67 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 15:15 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43743.86 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 15:20 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43746.27 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 15:25 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43741.96 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 15:30 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43691.25 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 15:35 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=30 | fuel=0.72 | c=43748.02 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 15:40 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43735.7 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 15:45 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43675.21 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 15:50 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=16 | fuel=0.72 | c=43722.66 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 15:55 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43721.42 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 16:00 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43687.68 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 16:05 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43721.59 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 16:10 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43740.99 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 16:15 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43744.79 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 16:20 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43708.16 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 16:25 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=30 | fuel=0.72 | c=43701.01 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 16:30 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=30 | fuel=0.72 | c=43661.95 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 16:35 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=32 | fuel=0.72 | c=43647.9 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 16:40 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=14 | fuel=0.72 | c=43674.6 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 16:45 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43768.3 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 16:50 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43747.92 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 16:55 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=15 | fuel=0.72 | c=43754.19 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 17:00 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43729.96 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 17:05 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43746.01 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 17:10 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43806.17 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 17:15 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43795.22 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 17:20 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43783.51 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 17:25 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43753.94 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 17:30 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=19 | fuel=0.72 | c=43750.0 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 17:35 | 🧠 phase=ACCUMULATION | MFE=2.08R | impr=0 | fuel=0.72 | c=43648.0 sl_B=44412.113389 sl_C=44412.113389 | | | |
| | 2023-12-22 17:40 | 🧠 phase=EXPANSION | MFE=2.08R | impr=100 | CE=43702.75 | CE_WICK_REBALANCE | fuel=0.72 | c=43577.44 sl_B=43710.1388 sl_C=43710.1388 | | | |
| | 2023-12-22 17:40 | 🛡️ B:CE_SOFT→43710.14 | c=43577.44 sl_B=43710.1388 sl_C=43710.1388 | | | |
| | 2023-12-22 17:40 | 🛡️ C:CE_SOFT→43710.14 | c=43577.44 sl_B=43710.1388 sl_C=43710.1388 | | | |
| | 2023-12-22 17:45 | 🧠 phase=EXPANSION | MFE=2.08R | impr=70 | CE=43702.75 | CE_WICK_REBALANCE | ITL_HARD=43839.22 | fuel=0.72 | SCALE_SHIFT:HARVEST_GATE MFE=2.08R hard=43839→1H/4H (TP1+BE locked, safe to scale) | c=43584.23 sl_B=43710.1388 sl_C=43710.1388 | | | |
| | 2023-12-22 17:50 | 🧠 phase=EXPANSION | MFE=2.08R | impr=0 | CE=43702.75 | CE_WICK_REBALANCE | ITL_HARD=43839.22 | fuel=0.72 | SCALE_SHIFT:HARVEST_GATE MFE=2.08R hard=43839→1H/4H (TP1+BE locked, safe to scale) | c=43564.55 sl_B=43710.1388 sl_C=43710.1388 | | | |
| | 2023-12-22 17:55 | 🧠 phase=EXPANSION | MFE=2.08R | impr=0 | CE=43702.75 | CE_WICK_REBALANCE | ITL_HARD=43839.22 | fuel=0.72 | SCALE_SHIFT:HARVEST_GATE MFE=2.08R hard=43839→1H/4H (TP1+BE locked, safe to scale) | c=43571.91 sl_B=43710.1388 sl_C=43710.1388 | | | |
| | 2023-12-22 18:00 | 🧠 phase=EXPANSION | MFE=2.08R | impr=0 | CE=43679.85 | CE_HOLDS | ITL_HARD=43839.22 | fuel=0.72 | SCALE_SHIFT:HARVEST_GATE MFE=2.08R hard=43839→1H/4H (TP1+BE locked, safe to scale) | c=43614.0 sl_B=43687.2388 sl_C=43687.2388 | | | |
| | 2023-12-22 18:00 | 🛡️ B:CE_SOFT→43687.24 | c=43614.0 sl_B=43687.2388 sl_C=43687.2388 | | | |
| | 2023-12-22 18:00 | 🛡️ C:CE_SOFT→43687.24 | c=43614.0 sl_B=43687.2388 sl_C=43687.2388 | | | |
| | 2023-12-22 18:05 | 🧠 phase=EXPANSION | MFE=2.08R | impr=0 | CE=43679.85 | CE_HOLDS | ITL_HARD=43839.22 | fuel=0.72 | SCALE_SHIFT:HARVEST_GATE MFE=2.08R hard=43839→1H/4H (TP1+BE locked, safe to scale) | c=43629.21 sl_B=43687.2388 sl_C=43687.2388 | | | |
| | 2023-12-22 18:10 | 🧠 phase=EXPANSION | MFE=2.08R | impr=0 | CE=43679.85 | CE_HOLDS | ITL_HARD=43839.22 | fuel=0.72 | SCALE_SHIFT:HARVEST_GATE MFE=2.08R hard=43839→1H/4H (TP1+BE locked, safe to scale) | c=43647.29 sl_B=43687.2388 sl_C=43687.2388 | | | |
| | 2023-12-22 18:15 | 🧠 phase=EXPANSION | MFE=2.08R | impr=0 | CE=43679.85 | CE_HOLDS | ITL_HARD=43839.22 | fuel=0.72 | SCALE_SHIFT:HARVEST_GATE MFE=2.08R hard=43839→1H/4H (TP1+BE locked, safe to scale) | c=43627.7 sl_B=43687.2388 sl_C=43687.2388 | | | |
| | 2023-12-22 18:20 | 🧠 phase=EXPANSION | MFE=2.08R | impr=22 | CE=43679.85 | CE_HOLDS | ITL_HARD=43839.22 | fuel=0.72 | SCALE_SHIFT:HARVEST_GATE MFE=2.08R hard=43839→1H/4H (TP1+BE locked, safe to scale) | c=43549.21 sl_B=43687.2388 sl_C=43687.2388 | | | |


### صفقة #8 — BULLISH — 2023-12-23 09:00 → 2023-12-23 09:35 — PnL -2.000% ($-2.21)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=LONDON_KILLZONE NY=2023-12-23 04:00 NY (Sat) | سعر السوق لحظة الإشارة=43574.91 | Filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(74)+OB_HELD → old Premium is new Discount for DOL 44700.0. Mitigation Block continuation per ICT. LONG only.|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BULLISH Confidence=90 | Reason=HH+HL | Zone=PREMIUM | Confidence=90 | Structure={'hh': True, 'hl': True, 'lh': False, 'll': False}
  - Dealing Daily: zone=PREMIUM eq=40703.5 high=44700.0 low=36707.0 pct_in_range=86.9 current=43655.33
- **Layer2 NARRATIVE (15M Sweep):** Side=SSL Level=43559.69 Wick=43456.0 Quality=79.5 (min 25) | تعني: سيولة بيع مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=40703.5 ERL_H=44700.0 ERL_L=36707.0
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BULLISH BodyMult=2.6x Body%=71.0% Conviction=74.5 | تعني: اندفاع مؤسساتي — جسم 2.6x متوسط 5 شموع + جسم 71.0% من المدى = نية مؤسساتية
  - FVG: bottom=43541.1 top=43546.7 **CE(entry)=43543.899999999994** dir=BULLISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=43543.9 SL=43404.714483 Risk=139.19 ATR=52.17 SL/ATR=2.67 | TP1={'price': 43759.97, 'kind': 'SWING', 'rr': 1.55, 'dist': 216.07000000000698} TP2={'price': 44488.0, 'kind': 'HTF_DRAW', 'rr': 6.78} TP3=44488.0
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BULLISH conf90 zone=PREMIUM | SWEEP SSL Q79.5 lvl=43559.69 wick=43456.0 | DISP 2.6x 71.0% conv=74.5 | FVG 43541.1-43546.7 CE=43543.899999999994 RR1=1.55 SL_ATR=2.67 | KZ=LONDON_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 0.46R سعر متطرف لصالحنا 43608.13 | MAE 1.64R سعر ضدنا 43316.0 | مدة 0.6 ساعة | Phase ACCUMULATION
- أسباب خروج: A=SL B=SL C=SL — تفسير: A=SL ضرب الستوب الابتدائي قبل TP1 — الفكرة فشلت مبكراً. B=SL ضرب الستوب الابتدائي قبل TP1 — الفكرة فشلت مبكراً. C=SL ضرب الستوب الابتدائي قبل TP1 — الفكرة فشلت مبكراً. 
- Balance 110.54863392132235 → 108.33773245340328
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-23 09:00 OPEN entry=43543.9 sl=43404.714483 tp1=43759.97 filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(74)+OB_HELD → old Premium is new Discount for DOL 44700.0. Mitigation Block continuation per ICT. LONG only.|MID_OK | | | |
| | 2023-12-23 09:05 | 🧠 phase=ACCUMULATION | MFE=0.32R | impr=0 | fuel=0.95 | c=43586.91 sl_B=43404.714483 sl_C=43404.714483 | | | |
| | 2023-12-23 09:10 | 🧠 phase=ACCUMULATION | MFE=0.32R | impr=0 | fuel=0.95 | c=43556.62 sl_B=43404.714483 sl_C=43404.714483 | | | |
| | 2023-12-23 09:15 | 🧠 phase=ACCUMULATION | MFE=0.46R | impr=0 | fuel=0.95 | c=43572.74 sl_B=43404.714483 sl_C=43404.714483 | | | |
| | 2023-12-23 09:20 | 🧠 phase=ACCUMULATION | MFE=0.46R | impr=0 | fuel=0.95 | c=43493.38 sl_B=43404.714483 sl_C=43404.714483 | | | |
| | 2023-12-23 09:25 | 🧠 phase=ACCUMULATION | MFE=0.46R | impr=0 | fuel=0.95 | c=43526.43 sl_B=43404.714483 sl_C=43404.714483 | | | |
| | 2023-12-23 09:30 | 🧠 phase=ACCUMULATION | MFE=0.46R | impr=0 | fuel=0.95 | c=43441.65 sl_B=43404.714483 sl_C=43404.714483 | | | |
| | 2023-12-23 09:35 | 🧠 phase=ACCUMULATION | MFE=0.46R | impr=0 | fuel=0.95 | c=43356.75 sl_B=43404.714483 sl_C=43404.714483 | | | |
| | 2023-12-23 09:35 | ❌ A:SL | c=43356.75 sl_B=43404.714483 sl_C=43404.714483 | | | |
| | 2023-12-23 09:35 | ❌ B:SL | c=43356.75 sl_B=43404.714483 sl_C=43404.714483 | | | |
| | 2023-12-23 09:35 | ❌ C:SL | c=43356.75 sl_B=43404.714483 sl_C=43404.714483 | | | |


### صفقة #9 — BULLISH — 2023-12-24 15:00 → 2023-12-24 19:10 — PnL +3.084% ($+3.34)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=NY_AM_KILLZONE NY=2023-12-24 10:00 NY (Sun) | سعر السوق لحظة الإشارة=43610.09 | Filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(100)+OB_HELD → old Premium is new Discount for DOL 44700.0. Mitigation Block continuation per ICT. LONG only.|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BULLISH Confidence=80 | Reason=HH+HL | Zone=PREMIUM | Confidence=80 | Structure={'hh': True, 'hl': True, 'lh': False, 'll': False}
  - Dealing Daily: zone=PREMIUM eq=40703.5 high=44700.0 low=36707.0 pct_in_range=87.6 current=43708.97
- **Layer2 NARRATIVE (15M Sweep):** Side=SSL Level=43754.09 Wick=43701.73 Quality=49.7 (min 25) | تعني: سيولة بيع مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=40703.5 ERL_H=44700.0 ERL_L=36707.0
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BULLISH BodyMult=3.3x Body%=99.9% Conviction=100 | تعني: اندفاع مؤسساتي — جسم 3.3x متوسط 5 شموع + جسم 99.9% من المدى = نية مؤسساتية
  - FVG: bottom=43508.0 top=43510.44 **CE(entry)=43509.22** dir=BULLISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=43509.22 SL=43396.908136 Risk=112.31 ATR=27.28 SL/ATR=4.12 | TP1={'price': 43682.67, 'kind': 'SWING', 'rr': 1.54, 'dist': 173.4499999999971} TP2={'price': 44398.26, 'kind': 'HTF_DRAW', 'rr': 7.92} TP3=44488.0
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BULLISH conf80 zone=PREMIUM | SWEEP SSL Q49.7 lvl=43754.09 wick=43701.73 | DISP 3.3x 99.9% conv=100 | FVG 43508.0-43510.44 CE=43509.22 RR1=1.54 SL_ATR=4.12 | KZ=NY_AM_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 2.00R سعر متطرف لصالحنا 43734.08 | MAE 0.93R سعر ضدنا 43405.0 | مدة 4.2 ساعة | Phase EXPANSION
- أسباب خروج: A=A_TRAIL B=B_FORTRESS C=C_FORTRESS — تفسير: A=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. B=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. C=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. 
- Balance 108.33773245340328 → 111.67911931223618
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-24 15:00 OPEN entry=43509.22 sl=43396.908136 tp1=43682.67 filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(100)+OB_HELD → old Premium is new Discount for DOL 44700.0. Mitigation Block continuation per ICT. LONG only.|MID_OK | | | |
| | 2023-12-24 15:05 | 🧠 phase=ACCUMULATION | MFE=1.33R | impr=0 | fuel=0.87 | c=43644.41 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 15:10 | 🧠 phase=ACCUMULATION | MFE=1.57R | impr=0 | fuel=0.87 | c=43684.99 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 15:10 | 🎯 A:TP1 | c=43684.99 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 15:10 | 📣 PARTIAL_TAKEN→fortresses_active | c=43684.99 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 15:15 | 🧠 phase=ACCUMULATION | MFE=1.64R | impr=0 | fuel=0.87 | c=43693.62 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 15:20 | 🧠 phase=ACCUMULATION | MFE=1.64R | impr=0 | fuel=0.87 | c=43685.93 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 15:25 | 🧠 phase=ACCUMULATION | MFE=1.64R | impr=0 | fuel=0.87 | c=43685.26 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 15:30 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43670.22 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 15:30 | 🧠 A:Trail | c=43670.22 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 15:35 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43655.98 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 15:40 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43630.16 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 15:45 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43537.42 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 15:50 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43581.33 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 15:55 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43553.3 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 16:00 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43524.75 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 16:05 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43467.31 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 16:10 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43508.0 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 16:15 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43544.72 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 16:20 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=30 | fuel=0.87 | c=43600.03 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 16:25 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=30 | fuel=0.87 | c=43594.57 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 16:30 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43610.12 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 16:35 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=30 | fuel=0.87 | c=43618.01 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 16:40 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=21 | fuel=0.87 | c=43557.19 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 16:45 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43587.99 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 16:50 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=30 | fuel=0.87 | c=43607.04 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 16:55 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=60 | fuel=0.87 | c=43632.93 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 17:00 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=30 | fuel=0.87 | c=43612.35 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 17:05 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43591.89 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 17:10 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43591.99 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 17:15 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43594.07 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 17:20 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43619.18 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 17:25 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=60 | fuel=0.87 | c=43634.2 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 17:30 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=30 | fuel=0.87 | c=43644.31 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 17:35 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=30 | fuel=0.87 | c=43647.82 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 17:40 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=1 | fuel=0.87 | c=43627.27 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 17:45 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43582.03 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 17:50 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43579.99 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 17:55 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43566.01 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 18:00 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43601.7 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 18:05 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=72 | fuel=0.87 | c=43616.81 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 18:10 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=60 | fuel=0.87 | c=43648.57 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 18:15 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=43 | fuel=0.87 | c=43629.87 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 18:20 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | fuel=0.87 | c=43646.17 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 18:25 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=6 | fuel=0.87 | c=43646.45 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 18:30 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | CE=43620.44 | CE_HOLDS | fuel=0.87 | c=43630.01 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 18:35 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=0 | CE=43620.44 | CE_HOLDS | fuel=0.87 | c=43650.68 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 18:40 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=26 | CE=43620.44 | CE_HOLDS | fuel=0.87 | c=43675.58 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 18:45 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=60 | CE=43620.44 | CE_HOLDS | fuel=0.87 | c=43677.33 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 18:50 | 🧠 phase=ACCUMULATION | MFE=1.65R | impr=30 | CE=43620.44 | CE_HOLDS | fuel=0.87 | c=43672.74 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 18:55 | 🧠 phase=ACCUMULATION | MFE=2.00R | impr=0 | CE=43620.44 | CE_HOLDS | fuel=0.87 | c=43721.93 sl_B=43396.908136 sl_C=43396.908136 | | | |
| | 2023-12-24 19:00 | 🧠 phase=EXPANSION | MFE=2.00R | impr=85 | CE=43684.21 | CE_WICK_REBALANCE | fuel=0.87 | c=43712.28 sl_B=43682.0326 sl_C=43682.0326 | | | |
| | 2023-12-24 19:00 | 🛡️ B:CE_SOFT→43682.03 | c=43712.28 sl_B=43682.0326 sl_C=43682.0326 | | | |
| | 2023-12-24 19:00 | 🛡️ C:CE_SOFT→43682.03 | c=43712.28 sl_B=43682.0326 sl_C=43682.0326 | | | |
| | 2023-12-24 19:05 | 🧠 phase=EXPANSION | MFE=2.00R | impr=0 | CE=43684.21 | CE_WICK_REBALANCE | fuel=0.87 | c=43698.52 sl_B=43682.0326 sl_C=43682.0326 | | | |
| | 2023-12-24 19:10 | 🧠 phase=EXPANSION | MFE=2.00R | impr=0 | CE=43684.21 | CE_WICK_REBALANCE | fuel=0.87 | c=43674.83 sl_B=43682.0326 sl_C=43682.0326 | | | |
| | 2023-12-24 19:10 | 🛡️ B:FORTRESS_HIT | c=43674.83 sl_B=43682.0326 sl_C=43682.0326 | | | |
| | 2023-12-24 19:10 | 🛡️ C:FORTRESS_HIT | c=43674.83 sl_B=43682.0326 sl_C=43682.0326 | | | |


## كل قرارات الفحص — شو شاف وقرر HOLD ولماذا (Top 100)

| وقت | Session | سعر | قرار | السبب | Bias | Conf | Sweep Q | Disp Conv | FVG CE | Filter |
|------|---------|------|-------|-------|------|------|---------|-----------|--------|--------|
| 2023-12-01 00:00 | ASIAN_RANGE | 37781.04 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 01:00 | ASIAN_RANGE | 37795.99 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 02:00 | ASIAN_RANGE | 37748.79 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 03:00 | ASIAN_RANGE | 37752.05 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 04:00 | ASIAN_RANGE | 37784.62 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 05:00 | ASIAN_MANIPULATION | 37712.32 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 06:00 | ASIAN_MANIPULATION | 37650.26 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 07:00 | LONDON_KILLZONE | 37896.42 | HOLD | PLAN invalid: risk 0.5-8 ATR filter or TP1 RR<1.5 — risk not logical | BULLISH | 60 | 97.5 | 85.2 | 37714.34 | None |
| 2023-12-01 08:00 | LONDON_KILLZONE | 37904.53 | HOLD | PLAN invalid: risk 0.5-8 ATR filter or TP1 RR<1.5 — risk not logical | BULLISH | 60 | 92.2 | 85.2 | 37714.34 | None |
| 2023-12-01 09:00 | LONDON_KILLZONE | 37990.51 | HOLD | TRIGGER not ready: FVG_ALREADY_FILLED — no institutional displacement+FVG | BULLISH | 60 | 86.8 | None | None | None |
| 2023-12-01 10:00 | PRE_NY | 38151.48 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 11:00 | PRE_NY | 38120.84 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 12:00 | PRE_NY | 38111.97 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 13:00 | PRE_NY | 38264.65 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 14:00 | NY_AM_KILLZONE | 38215.01 | HOLD | TRIGGER not ready: FVG_ALREADY_FILLED — no institutional displacement+FVG | BULLISH | 80 | 60.2 | None | None | None |
| 2023-12-01 15:00 | NY_AM_KILLZONE | 38623.44 | HOLD | TRIGGER not ready: FVG_ALREADY_FILLED — no institutional displacement+FVG | BULLISH | 80 | 54.8 | None | None | None |
| 2023-12-01 16:00 | NY_LUNCH_DEAD_ZONE | 38643.44 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 17:00 | NY_LUNCH_DEAD_ZONE | 38626.34 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 18:00 | NY_LUNCH_DEAD_ZONE | 38502.6 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 19:00 | NY_PM_KILLZONE | 38398.91 | HOLD | TRIGGER not ready: FVG_ALREADY_FILLED — no institutional displacement+FVG | BULLISH | 80 | 33.5 | None | None | None |
| 2023-12-01 20:00 | NY_PM_KILLZONE | 38343.57 | HOLD | PLAN invalid: risk 0.5-8 ATR filter or TP1 RR<1.5 — risk not logical | BULLISH | 60 | 90.0 | 74.1 | 38291.69500000001 | None |
| 2023-12-01 21:00 | AFTER_HOURS | 38400.0 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 22:00 | AFTER_HOURS | 38959.99 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 23:00 | ASIAN_RANGE | 38717.39 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 00:00 | ASIAN_RANGE | 38800.99 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 01:00 | ASIAN_RANGE | 38657.98 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 02:00 | ASIAN_RANGE | 38815.57 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 03:00 | ASIAN_RANGE | 38831.01 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 04:00 | ASIAN_RANGE | 38729.54 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 05:00 | ASIAN_MANIPULATION | 38672.89 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 06:00 | ASIAN_MANIPULATION | 38661.8 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 07:00 | LONDON_KILLZONE | 38787.99 | HOLD | PLAN invalid: risk 0.5-8 ATR filter or TP1 RR<1.5 — risk not logical | BULLISH | 90 | 95.5 | 100 | 38722.725 | None |
| 2023-12-02 08:00 | LONDON_KILLZONE | 38678.85 | HOLD | TRIGGER not ready: FVG_ALREADY_FILLED — no institutional displacement+FVG | BULLISH | 80 | 90.1 | None | None | None |
| 2023-12-02 09:00 | LONDON_KILLZONE | 38750.3 | HOLD | TRIGGER not ready: FVG_ALREADY_FILLED — no institutional displacement+FVG | BULLISH | 90 | 84.8 | None | None | None |
| 2023-12-02 10:00 | PRE_NY | 38798.2 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 11:00 | PRE_NY | 38793.89 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 12:00 | PRE_NY | 38760.43 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 13:00 | PRE_NY | 38720.08 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 14:00 | NY_AM_KILLZONE | 38712.01 | HOLD | TRIGGER not ready: NO_DISPLACEMENT_WITH_FVG — no institutional displacement+FVG | BULLISH | 90 | 90.1 | None | None | None |
| 2023-12-02 15:00 | NY_AM_KILLZONE | 38753.99 | HOLD | PLAN invalid: risk 0.5-8 ATR filter or TP1 RR<1.5 — risk not logical | BULLISH | 90 | 97.3 | 100 | 38741.89 | None |
| 2023-12-02 16:00 | NY_LUNCH_DEAD_ZONE | 38765.22 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 17:00 | NY_LUNCH_DEAD_ZONE | 38718.0 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 18:00 | NY_LUNCH_DEAD_ZONE | 38775.62 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 19:00 | NY_PM_KILLZONE | 38794.49 | HOLD | TRIGGER not ready: FVG_ALREADY_FILLED — no institutional displacement+FVG | BULLISH | 90 | 76.0 | None | None | None |
| 2023-12-02 20:00 | NY_PM_KILLZONE | 38817.46 | HOLD | TRIGGER not ready: FVG_ALREADY_FILLED — no institutional displacement+FVG | BULLISH | 80 | 70.7 | None | None | None |
| 2023-12-02 21:00 | AFTER_HOURS | 38804.0 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 22:00 | AFTER_HOURS | 38745.74 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 23:00 | ASIAN_RANGE | 38769.89 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 00:00 | ASIAN_RANGE | 38866.91 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 01:00 | ASIAN_RANGE | 39247.76 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 02:00 | ASIAN_RANGE | 39345.89 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 03:00 | ASIAN_RANGE | 39541.08 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 04:00 | ASIAN_RANGE | 39440.3 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 05:00 | ASIAN_MANIPULATION | 39462.58 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 06:00 | ASIAN_MANIPULATION | 39424.38 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 07:00 | LONDON_KILLZONE | 39513.81 | HOLD | PLAN invalid: risk 0.5-8 ATR filter or TP1 RR<1.5 — risk not logical | BULLISH | 90 | 80.4 | 91.5 | 39464.84 | None |
| 2023-12-03 08:00 | LONDON_KILLZONE | 39431.78 | HOLD | TRIGGER not ready: FVG_ALREADY_FILLED — no institutional displacement+FVG | BULLISH | 80 | 78.7 | None | None | None |
| 2023-12-03 09:00 | LONDON_KILLZONE | 39324.83 | HOLD | TRIGGER not ready: FVG_ALREADY_FILLED — no institutional displacement+FVG | BULLISH | 80 | 73.3 | None | None | None |
| 2023-12-03 10:00 | PRE_NY | 39386.01 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 11:00 | PRE_NY | 39431.65 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 12:00 | PRE_NY | 39404.5 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 13:00 | PRE_NY | 39474.49 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 14:00 | NY_AM_KILLZONE | 39441.86 | HOLD | TRIGGER not ready: NO_DISPLACEMENT_WITH_FVG — no institutional displacement+FVG | BULLISH | 90 | 66.2 | None | None | None |
| 2023-12-03 15:00 | NY_AM_KILLZONE | 39423.17 | HOLD | TRIGGER not ready: NO_DISPLACEMENT_WITH_FVG — no institutional displacement+FVG | BULLISH | 90 | 60.9 | None | None | None |
| 2023-12-03 16:00 | NY_LUNCH_DEAD_ZONE | 39471.69 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 17:00 | NY_LUNCH_DEAD_ZONE | 39490.42 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 18:00 | NY_LUNCH_DEAD_ZONE | 39500.0 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 19:00 | NY_PM_KILLZONE | 39680.69 | HOLD | PLAN invalid: risk 0.5-8 ATR filter or TP1 RR<1.5 — risk not logical | BULLISH | 90 | 97.3 | 100.0 | 39456.07000000001 | None |
| 2023-12-03 20:00 | NY_PM_KILLZONE | 39693.83 | HOLD | PLAN invalid: risk 0.5-8 ATR filter or TP1 RR<1.5 — risk not logical | BULLISH | 90 | 91.7 | 100.0 | 39456.07000000001 | None |
| 2023-12-03 21:00 | AFTER_HOURS | 39629.58 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 22:00 | AFTER_HOURS | 39728.47 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 23:00 | ASIAN_RANGE | 39550.01 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 00:00 | ASIAN_RANGE | 39552.37 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 01:00 | ASIAN_RANGE | 39563.05 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 02:00 | ASIAN_RANGE | 39588.38 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 03:00 | ASIAN_RANGE | 39671.46 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 04:00 | ASIAN_RANGE | 40038.0 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 05:00 | ASIAN_MANIPULATION | 39926.21 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 06:00 | ASIAN_MANIPULATION | 40152.77 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 07:00 | LONDON_KILLZONE | 40723.72 | HOLD PD_FILTER | PD_FILTER blocked: ACCUM:LONG_IN_PREMIUM — Premium/Discount law | BULLISH | 90 | 46.8 | 100 | 39521.21 | ACCUM:LONG_IN_PREMIUM |
| 2023-12-04 08:00 | LONDON_KILLZONE | 40571.94 | HOLD PD_FILTER | PD_FILTER blocked: ACCUM:LONG_IN_PREMIUM — Premium/Discount law | BULLISH | 90 | 40.1 | 100 | 39521.21 | ACCUM:LONG_IN_PREMIUM |
| 2023-12-04 09:00 | LONDON_KILLZONE | 40774.33 | HOLD PD_FILTER | PD_FILTER blocked: ACCUM:LONG_IN_PREMIUM — Premium/Discount law | BULLISH | 90 | 36.9 | 100 | 39521.21 | ACCUM:LONG_IN_PREMIUM |
| 2023-12-04 10:00 | PRE_NY | 40711.93 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 11:00 | PRE_NY | 41273.55 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 12:00 | PRE_NY | 41543.91 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 13:00 | PRE_NY | 41462.48 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 14:00 | NY_AM_KILLZONE | 41601.1 | HOLD | TRIGGER not ready: NO_DISPLACEMENT_WITH_FVG — no institutional displacement+FVG | BULLISH | 90 | 58.5 | None | None | None |
| 2023-12-04 15:00 | NY_AM_KILLZONE | 41724.07 | HOLD | TRIGGER not ready: NO_DISPLACEMENT_WITH_FVG — no institutional displacement+FVG | BULLISH | 90 | 53.2 | None | None | None |
| 2023-12-04 16:00 | NY_LUNCH_DEAD_ZONE | 41835.62 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 17:00 | NY_LUNCH_DEAD_ZONE | 41558.43 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 18:00 | NY_LUNCH_DEAD_ZONE | 41610.0 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 19:00 | NY_PM_KILLZONE | 41849.48 | HOLD | TRIGGER not ready: FVG_ALREADY_FILLED — no institutional displacement+FVG | BULLISH | 90 | 69.7 | None | None | None |
| 2023-12-04 20:00 | NY_PM_KILLZONE | 41496.86 | HOLD | TRIGGER not ready: FVG_ALREADY_FILLED — no institutional displacement+FVG | BULLISH | 90 | 64.9 | None | None | None |
| 2023-12-04 21:00 | AFTER_HOURS | 41208.03 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 22:00 | AFTER_HOURS | 41431.03 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 23:00 | ASIAN_RANGE | 41711.89 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-05 00:00 | ASIAN_RANGE | 41703.36 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-05 01:00 | ASIAN_RANGE | 41935.21 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-05 02:00 | ASIAN_RANGE | 41859.86 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-05 03:00 | ASIAN_RANGE | 41842.97 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |

---


# ETHUSDT — MATRIX_EINSTEIN V2.1 FINAL — 2023-12 — $100→$118.35 (18.35%)

صفقات 9 رابحة 6 خاسرة 3 | سكانات 700 مرفوضة PD 5

## جدول سريع لكل الصفقات

| # | دخول | خروج | Bias | Entry | SL | TP1 | TP2 | TP3 | PnL% | $ | Bal | A | B | C | MFE | MAE | مدة | Session |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 2023-12-14 14:00 | 2023-12-14 23:00 | BEARISH | 2295.85 | 2320.86 | 2257.05 | 2218.49 | 1928.74 | -1.054 | -1.05 | 98.95 | SL | B_FORTRESS | C_FORTRESS | 1.12R | 1.06R | 9.0h | NY_AM_KILLZONE |
| 2 | 2023-12-20 09:00 | 2023-12-20 12:10 | BEARISH | 2214.39 | 2239.78 | 2175.00 | 2116.56 | 1985.00 | +0.549 | +0.54 | 99.49 | CE_RISK_CUT | CE_RISK_CUT | CE_RISK_CUT | 0.38R | 0.46R | 3.2h | LONDON_KILLZONE |
| 3 | 2023-12-21 14:00 | 2023-12-21 22:00 | BEARISH | 2258.92 | 2283.28 | 2216.62 | 2145.33 | 1985.00 | +2.343 | +2.33 | 101.82 | A_TRAIL | B_FORTRESS | C_FORTRESS | 2.42R | 0.29R | 8.0h | NY_AM_KILLZONE |
| 4 | 2023-12-22 19:00 | 2023-12-22 22:30 | BEARISH | 2338.49 | 2346.81 | 2325.00 | 2195.28 | 1985.00 | +4.356 | +4.43 | 106.26 | A_TRAIL | B_FORTRESS | C_FORTRESS | 4.15R | 0.00R | 3.5h | NY_PM_KILLZONE |
| 5 | 2023-12-24 07:00 | 2023-12-24 08:20 | BEARISH | 2319.03 | 2329.58 | 2303.15 | 2195.28 | 1985.00 | +3.784 | +4.02 | 110.28 | A_TRAIL | B_FORTRESS | C_FORTRESS | 2.98R | 0.00R | 1.3h | LONDON_KILLZONE |
| 6 | 2023-12-24 14:00 | 2023-12-24 20:40 | BULLISH | 2290.99 | 2274.55 | 2316.30 | 2345.95 | 2407.63 | -1.238 | -1.37 | 108.91 | SL | B_FORTRESS | C_FORTRESS | 1.10R | 1.22R | 6.7h | NY_AM_KILLZONE |
| 7 | 2023-12-29 09:00 | 2023-12-29 16:15 | BULLISH | 2342.60 | 2310.23 | 2394.60 | 0.00 | 0.00 | -0.455 | -0.50 | 108.42 | SL | B_FORTRESS | C_FORTRESS | 1.43R | 1.17R | 7.2h | LONDON_KILLZONE |
| 8 | 2023-12-29 19:00 | 2023-12-29 23:15 | BEARISH | 2373.93 | 2389.71 | 2350.09 | 2241.20 | 2186.00 | +6.021 | +6.53 | 114.94 | A_TRAIL | B_FORTRESS | C_FORTRESS | 7.55R | 0.00R | 4.2h | NY_PM_KILLZONE |
| 9 | 2023-12-31 08:00 | 2023-12-31 11:55 | BULLISH | 2288.82 | 2273.34 | 2312.93 | 2345.95 | 2407.63 | +2.966 | +3.41 | 118.35 | A_TRAIL | B_FORTRESS | C_FORTRESS | 1.89R | 0.00R | 3.9h | LONDON_KILLZONE |

## تفصيل كل صفقة — شو شاف وشو عمل ليش قرر وليش شاف


### صفقة #1 — BEARISH — 2023-12-14 14:00 → 2023-12-14 23:00 — PnL -1.054% ($-1.05)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=NY_AM_KILLZONE NY=2023-12-14 09:00 NY (Thu) | سعر السوق لحظة الإشارة=2271.24 | Filter=ACCUM:PD_PREMIUM|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BEARISH Confidence=95 | Reason=LH+LL | Zone=PREMIUM | Confidence=95 | Structure={'hh': False, 'hl': False, 'lh': True, 'll': True}
  - Dealing Daily: zone=PREMIUM eq=2168.185 high=2407.63 low=1928.74 pct_in_range=63.8 current=2234.39
- **Layer2 NARRATIVE (15M Sweep):** Side=BSL Level=2292.05 Wick=2304.46 Quality=90.6 (min 25) | تعني: سيولة شراء مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=2155.72 ERL_H=2407.63 ERL_L=1903.81
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BEARISH BodyMult=2.98x Body%=99.9% Conviction=99.3 | تعني: اندفاع مؤسساتي — جسم 2.98x متوسط 5 شموع + جسم 99.9% من المدى = نية مؤسساتية
  - FVG: bottom=2292.58 top=2299.12 **CE(entry)=2295.85** dir=BEARISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=2295.85 SL=2320.856057 Risk=25.01 ATR=12.37 SL/ATR=2.02 | TP1={'price': 2257.05, 'kind': 'SWING', 'rr': 1.55, 'dist': 38.79999999999973} TP2={'price': 2218.49, 'kind': 'HTF_DRAW', 'rr': 3.09} TP3=1928.74
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BEARISH conf95 zone=PREMIUM | SWEEP BSL Q90.6 lvl=2292.05 wick=2304.46 | DISP 2.98x 99.9% conv=99.3 | FVG 2292.58-2299.12 CE=2295.85 RR1=1.55 SL_ATR=2.02 | KZ=NY_AM_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 1.12R سعر متطرف لصالحنا 2267.8 | MAE 1.06R سعر ضدنا 2322.36 | مدة 9.0 ساعة | Phase EXPANSION
- أسباب خروج: A=SL B=B_FORTRESS C=C_FORTRESS — تفسير: A=SL ضرب الستوب الابتدائي قبل TP1 — الفكرة فشلت مبكراً. B=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. C=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. 
- Balance 100.0 → 98.94590370251898
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-14 14:00 OPEN entry=2295.85 sl=2320.856057 tp1=2257.05 filter=ACCUM:PD_PREMIUM|MID_OK | | | |
| | 2023-12-14 14:05 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.73 | c=2269.72 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 14:10 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2272.51 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 14:15 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2281.16 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 14:20 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2281.52 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 14:25 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2289.2 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 14:30 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2295.04 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 14:35 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2285.67 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 14:40 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2282.65 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 14:45 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2280.91 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 14:50 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2287.55 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 14:55 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2288.73 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 15:00 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2288.22 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 15:05 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2286.68 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 15:10 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2281.59 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 15:15 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=29 | fuel=0.73 | c=2276.84 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 15:20 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=7 | fuel=0.73 | c=2276.63 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 15:25 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2274.34 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 15:30 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2276.29 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 15:35 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2269.99 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 15:40 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=69 | fuel=0.73 | c=2277.11 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 15:45 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2276.33 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 15:50 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2276.31 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 15:55 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2275.95 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 16:00 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2277.49 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 16:05 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2281.8 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 16:10 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2281.76 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 16:15 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2278.62 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 16:20 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=1 | fuel=0.73 | c=2276.79 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 16:25 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2278.03 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 16:30 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2278.82 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 16:35 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2288.84 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 16:40 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2284.1 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 16:45 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=52 | fuel=0.73 | c=2283.04 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 16:50 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2283.05 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 16:55 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2283.0 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 17:00 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2288.29 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 17:05 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2291.09 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 17:10 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2294.77 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 17:15 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2294.63 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 17:20 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2291.13 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 17:25 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=11 | fuel=0.73 | c=2295.96 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 17:30 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2307.07 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 17:35 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2314.33 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 17:40 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2309.04 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 17:45 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=5 | fuel=0.73 | c=2309.41 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 17:50 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2308.9 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 17:55 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | fuel=0.73 | c=2305.33 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 18:00 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=55 | fuel=0.73 | c=2300.85 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 18:05 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=60 | fuel=0.73 | c=2294.21 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 18:10 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=60 | fuel=0.73 | c=2293.14 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 18:15 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | CE=2302.32 | CE_HOLDS | fuel=0.73 | c=2294.71 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 18:20 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | CE=2302.32 | CE_HOLDS | fuel=0.73 | c=2294.07 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 18:25 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | CE=2302.32 | CE_HOLDS | fuel=0.73 | c=2292.17 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 18:30 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | CE=2298.89 | CE_HOLDS | fuel=0.73 | c=2292.19 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 18:35 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | CE=2298.89 | CE_HOLDS | fuel=0.73 | c=2296.77 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 18:40 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | CE=2298.89 | CE_HOLDS | fuel=0.73 | c=2294.41 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 18:45 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=0 | CE=2298.89 | CE_WICK_REBALANCE | fuel=0.73 | c=2291.63 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 18:50 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=30 | CE=2298.89 | CE_WICK_REBALANCE | fuel=0.73 | c=2288.28 sl_B=2320.856057 sl_C=2320.856057 | | | |
| | 2023-12-14 18:55 | 🧠 phase=ACCUMULATION | MFE=1.12R | impr=25 | CE=2298.89 | CE_WICK_REBALANCE | fuel=0.73 | c=2287.89 sl_B=2320.856057 sl_C=2320.856057 | | | |


### صفقة #2 — BEARISH — 2023-12-20 09:00 → 2023-12-20 12:10 — PnL +0.549% ($+0.54)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=LONDON_KILLZONE NY=2023-12-20 04:00 NY (Wed) | سعر السوق لحظة الإشارة=2212.15 | Filter=ACCUM:PD_PREMIUM|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BEARISH Confidence=75 | Reason=LH+LL | Zone=PREMIUM | Confidence=75 | Structure={'hh': False, 'hl': False, 'lh': True, 'll': True}
  - Dealing Daily: zone=PREMIUM eq=2196.315 high=2407.63 low=1985.0 pct_in_range=53.3 current=2210.4
- **Layer2 NARRATIVE (15M Sweep):** Side=BSL Level=2212.0 Wick=2219.63 Quality=92.6 (min 25) | تعني: سيولة شراء مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=2196.315 ERL_H=2407.63 ERL_L=1985.0
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BEARISH BodyMult=5.62x Body%=87.0% Conviction=100.0 | تعني: اندفاع مؤسساتي — جسم 5.62x متوسط 5 شموع + جسم 87.0% من المدى = نية مؤسساتية
  - FVG: bottom=2211.4 top=2217.39 **CE(entry)=2214.395** dir=BEARISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=2214.395 SL=2239.775707 Risk=25.38 ATR=3.84 SL/ATR=6.61 | TP1={'price': 2175.0, 'kind': 'SWING', 'rr': 1.55, 'dist': 39.39499999999998} TP2={'price': 2116.56, 'kind': 'HTF_DRAW', 'rr': 3.85} TP3=1985.0
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BEARISH conf75 zone=PREMIUM | SWEEP BSL Q92.6 lvl=2212.0 wick=2219.63 | DISP 5.62x 87.0% conv=100.0 | FVG 2211.4-2217.39 CE=2214.395 RR1=1.55 SL_ATR=6.61 | KZ=LONDON_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 0.38R سعر متطرف لصالحنا 2204.85 | MAE 0.46R سعر ضدنا 2226.0 | مدة 3.2 ساعة | Phase EXPANSION
- أسباب خروج: A=CE_RISK_CUT B=CE_RISK_CUT C=CE_RISK_CUT — تفسير: A=CE_RISK_CUT MFE<1R — قطع مخاطرة مبكراً بدل -2% كاملة. B=CE_RISK_CUT MFE<1R — قطع مخاطرة مبكراً بدل -2% كاملة. C=CE_RISK_CUT MFE<1R — قطع مخاطرة مبكراً بدل -2% كاملة. 
- Balance 98.94590370251898 → 99.48897558533068
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-20 09:00 OPEN entry=2214.395 sl=2239.775707 tp1=2175.0 filter=ACCUM:PD_PREMIUM|MID_OK | | | |
| | 2023-12-20 09:05 | 🧠 phase=ACCUMULATION | MFE=0.19R | impr=0 | fuel=0.89 | c=2209.8 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 09:10 | 🧠 phase=ACCUMULATION | MFE=0.19R | impr=0 | fuel=0.89 | c=2216.51 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 09:15 | 🧠 phase=ACCUMULATION | MFE=0.19R | impr=0 | fuel=0.89 | c=2216.7 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 09:20 | 🧠 phase=ACCUMULATION | MFE=0.19R | impr=0 | fuel=0.89 | c=2218.42 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 09:25 | 🧠 phase=ACCUMULATION | MFE=0.19R | impr=0 | fuel=0.89 | c=2222.92 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 09:30 | 🧠 phase=ACCUMULATION | MFE=0.19R | impr=0 | fuel=0.89 | c=2219.41 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 09:35 | 🧠 phase=ACCUMULATION | MFE=0.19R | impr=0 | fuel=0.89 | c=2218.88 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 09:40 | 🧠 phase=ACCUMULATION | MFE=0.19R | impr=0 | fuel=0.89 | c=2217.42 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 09:45 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2208.9 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 09:50 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2212.89 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 09:55 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2216.04 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 10:00 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2214.34 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 10:05 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2217.5 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 10:10 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2224.3 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 10:15 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2217.41 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 10:20 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=10 | fuel=0.89 | c=2216.0 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 10:25 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2214.82 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 10:30 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2215.7 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 10:35 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2215.68 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 10:40 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2217.43 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 10:45 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2218.43 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 10:50 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2217.03 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 10:55 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2221.53 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 11:00 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2217.92 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 11:05 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=43 | fuel=0.89 | c=2217.32 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 11:10 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2214.02 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 11:15 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=39 | fuel=0.89 | c=2215.38 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 11:20 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=0 | fuel=0.89 | c=2212.51 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 11:25 | 🧠 phase=ACCUMULATION | MFE=0.27R | impr=33 | fuel=0.89 | c=2209.41 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 11:30 | 🧠 phase=ACCUMULATION | MFE=0.28R | impr=70 | fuel=0.89 | c=2208.53 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 11:35 | 🧠 phase=ACCUMULATION | MFE=0.36R | impr=0 | fuel=0.89 | c=2209.2 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 11:40 | 🧠 phase=ACCUMULATION | MFE=0.36R | impr=0 | fuel=0.89 | c=2210.91 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 11:45 | 🧠 phase=ACCUMULATION | MFE=0.36R | impr=0 | fuel=0.89 | c=2216.87 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 11:50 | 🧠 phase=ACCUMULATION | MFE=0.36R | impr=0 | fuel=0.89 | c=2215.25 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 11:55 | 🧠 phase=ACCUMULATION | MFE=0.36R | impr=30 | fuel=0.89 | c=2212.7 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 12:00 | 🧠 phase=ACCUMULATION | MFE=0.36R | impr=30 | fuel=0.89 | c=2213.48 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 12:05 | 🧠 phase=ACCUMULATION | MFE=0.36R | impr=0 | fuel=0.89 | c=2207.7 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 12:10 | 🧠 phase=EXPANSION | MFE=0.38R | impr=100 | CE=2209.43 | CE_BODY_DEAD | fuel=0.89 | c=2207.43 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 12:10 | ☠️ A:CE_RISK_CUT @ 2207.43 | c=2207.43 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 12:10 | ☠️ B:CE_RISK_CUT @ 2207.43 | c=2207.43 sl_B=2239.775707 sl_C=2239.775707 | | | |
| | 2023-12-20 12:10 | ☠️ C:CE_RISK_CUT @ 2207.43 | c=2207.43 sl_B=2239.775707 sl_C=2239.775707 | | | |


### صفقة #3 — BEARISH — 2023-12-21 14:00 → 2023-12-21 22:00 — PnL +2.343% ($+2.33)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=NY_AM_KILLZONE NY=2023-12-21 09:00 NY (Thu) | سعر السوق لحظة الإشارة=2248.98 | Filter=ACCUM:PD_PREMIUM|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BEARISH Confidence=95 | Reason=LH+LL | Zone=PREMIUM | Confidence=95 | Structure={'hh': False, 'hl': False, 'lh': True, 'll': True}
  - Dealing Daily: zone=PREMIUM eq=2196.315 high=2407.63 low=1985.0 pct_in_range=55.5 current=2219.43
- **Layer2 NARRATIVE (15M Sweep):** Side=BSL Level=2251.87 Wick=2260.17 Quality=68.5 (min 25) | تعني: سيولة شراء مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=2196.315 ERL_H=2407.63 ERL_L=1985.0
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BEARISH BodyMult=3.42x Body%=75.8% Conviction=92.6 | تعني: اندفاع مؤسساتي — جسم 3.42x متوسط 5 شموع + جسم 75.8% من المدى = نية مؤسساتية
  - FVG: bottom=2257.4 top=2260.44 **CE(entry)=2258.92** dir=BEARISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=2258.92 SL=2283.276516 Risk=24.36 ATR=5.78 SL/ATR=4.22 | TP1={'price': 2216.62, 'kind': 'SWING', 'rr': 1.74, 'dist': 42.30000000000018} TP2={'price': 2145.33, 'kind': 'HTF_DRAW', 'rr': 4.66} TP3=1985.0
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BEARISH conf95 zone=PREMIUM | SWEEP BSL Q68.5 lvl=2251.87 wick=2260.17 | DISP 3.42x 75.8% conv=92.6 | FVG 2257.4-2260.44 CE=2258.92 RR1=1.74 SL_ATR=4.22 | KZ=NY_AM_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 2.42R سعر متطرف لصالحنا 2200.0 | MAE 0.29R سعر ضدنا 2266.0 | مدة 8.0 ساعة | Phase EXPANSION
- أسباب خروج: A=A_TRAIL B=B_FORTRESS C=C_FORTRESS — تفسير: A=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. B=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. C=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. 
- Balance 99.48897558533068 → 101.82031661106298
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-21 14:00 OPEN entry=2258.92 sl=2283.276516 tp1=2216.62 filter=ACCUM:PD_PREMIUM|MID_OK | | | |
| | 2023-12-21 14:05 | 🧠 phase=ACCUMULATION | MFE=0.63R | impr=0 | fuel=0.93 | c=2243.95 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 14:10 | 🧠 phase=ACCUMULATION | MFE=1.05R | impr=0 | fuel=0.93 | c=2237.68 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 14:15 | 🧠 phase=ACCUMULATION | MFE=1.36R | impr=0 | fuel=0.93 | c=2238.51 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 14:20 | 🧠 phase=ACCUMULATION | MFE=1.36R | impr=0 | fuel=0.93 | c=2239.37 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 14:25 | 🧠 phase=ACCUMULATION | MFE=1.36R | impr=0 | fuel=0.93 | c=2235.45 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 14:30 | 🧠 phase=ACCUMULATION | MFE=1.36R | impr=0 | fuel=0.93 | c=2236.64 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 14:35 | 🧠 phase=ACCUMULATION | MFE=1.36R | impr=0 | fuel=0.93 | c=2236.17 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 14:40 | 🧠 phase=ACCUMULATION | MFE=1.44R | impr=0 | fuel=0.93 | c=2226.8 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 14:45 | 🧠 phase=ACCUMULATION | MFE=1.44R | impr=0 | fuel=0.93 | c=2229.82 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 14:50 | 🧠 phase=ACCUMULATION | MFE=1.44R | impr=0 | fuel=0.93 | c=2229.72 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 14:55 | 🧠 phase=ACCUMULATION | MFE=1.81R | impr=0 | fuel=0.93 | c=2217.55 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 14:55 | 🎯 A:TP1 | c=2217.55 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 14:55 | 📣 PARTIAL_TAKEN→fortresses_active | c=2217.55 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 15:00 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2215.79 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 15:05 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2220.84 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 15:10 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2226.18 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 15:15 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2226.05 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 15:20 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2230.56 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 15:25 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2230.48 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 15:30 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2231.33 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 15:35 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2228.03 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 15:40 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2232.83 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 15:40 | 🧠 A:Trail | c=2232.83 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 15:45 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2227.2 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 15:50 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=13 | fuel=0.93 | c=2229.72 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 15:55 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2234.5 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 16:00 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2237.39 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 16:05 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2235.38 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 16:10 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2232.89 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 16:15 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=9 | fuel=0.93 | c=2230.23 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 16:20 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=30 | fuel=0.93 | c=2228.97 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 16:25 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2229.16 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 16:30 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2229.9 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 16:35 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2225.21 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 16:40 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=30 | fuel=0.93 | c=2228.21 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 16:45 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2224.01 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 16:50 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2228.01 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 16:55 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2238.55 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 17:00 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2233.5 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 17:05 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=30 | fuel=0.93 | c=2230.29 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 17:10 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=60 | fuel=0.93 | c=2228.56 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 17:15 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2232.22 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 17:20 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2236.46 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 17:25 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2237.51 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 17:30 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2243.0 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 17:35 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2235.94 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 17:40 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=30 | fuel=0.93 | c=2230.79 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 17:45 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=30 | fuel=0.93 | c=2228.49 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 17:50 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2238.23 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 17:55 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | fuel=0.93 | c=2234.92 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 18:00 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | ITL_HARD=2248.63 | fuel=0.93 | c=2239.44 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 18:05 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | ITL_HARD=2248.63 | fuel=0.93 | c=2239.32 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 18:10 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | ITL_HARD=2248.63 | fuel=0.93 | c=2237.8 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 18:15 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | ITL_HARD=2248.63 | fuel=0.93 | c=2237.14 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 18:20 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | ITL_HARD=2248.63 | fuel=0.93 | c=2238.82 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 18:25 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | ITL_HARD=2248.63 | fuel=0.93 | c=2237.97 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 18:30 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | ITL_HARD=2248.63 | fuel=0.93 | c=2233.77 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 18:35 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=12 | ITL_HARD=2248.63 | fuel=0.93 | c=2233.38 sl_B=2283.276516 sl_C=2283.276516 | | | |
| | 2023-12-21 18:40 | 🧠 phase=ACCUMULATION | MFE=2.42R | impr=0 | ITL_HARD=2248.63 | fuel=0.93 | c=2236.01 sl_B=2283.276516 sl_C=2283.276516 | | | |


### صفقة #4 — BEARISH — 2023-12-22 19:00 → 2023-12-22 22:30 — PnL +4.356% ($+4.43)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=NY_PM_KILLZONE NY=2023-12-22 14:00 NY (Fri) | سعر السوق لحظة الإشارة=2325.74 | Filter=ACCUM:PD_PREMIUM|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BEARISH Confidence=95 | Reason=LH+LL | Zone=PREMIUM | Confidence=95 | Structure={'hh': False, 'hl': False, 'lh': True, 'll': True}
  - Dealing Daily: zone=PREMIUM eq=2196.315 high=2407.63 low=1985.0 pct_in_range=60.7 current=2241.38
- **Layer2 NARRATIVE (15M Sweep):** Side=BSL Level=2326.52 Wick=2338.64 Quality=85.4 (min 25) | تعني: سيولة شراء مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=2196.315 ERL_H=2407.63 ERL_L=1985.0
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BEARISH BodyMult=2.1x Body%=83.9% Conviction=71.8 | تعني: اندفاع مؤسساتي — جسم 2.1x متوسط 5 شموع + جسم 83.9% من المدى = نية مؤسساتية
  - FVG: bottom=2337.45 top=2339.54 **CE(entry)=2338.495** dir=BEARISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=2338.495 SL=2346.807371 Risk=8.31 ATR=5.72 SL/ATR=1.45 | TP1={'price': 2325.0, 'kind': 'SWING', 'rr': 1.62, 'dist': 13.49499999999989} TP2={'price': 2195.28, 'kind': 'HTF_DRAW', 'rr': 17.23} TP3=1985.0
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BEARISH conf95 zone=PREMIUM | SWEEP BSL Q85.4 lvl=2326.52 wick=2338.64 | DISP 2.1x 83.9% conv=71.8 | FVG 2337.45-2339.54 CE=2338.495 RR1=1.62 SL_ATR=1.45 | KZ=NY_PM_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 4.15R سعر متطرف لصالحنا 2303.98 | MAE 0.00R سعر ضدنا 2338.495 | مدة 3.5 ساعة | Phase EXPANSION
- أسباب خروج: A=A_TRAIL B=B_FORTRESS C=C_FORTRESS — تفسير: A=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. B=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. C=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. 
- Balance 101.82031661106298 → 106.25531063564623
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-22 19:00 OPEN entry=2338.495 sl=2346.807371 tp1=2325.0 filter=ACCUM:PD_PREMIUM|MID_OK | | | |
| | 2023-12-22 19:05 | 🧠 phase=ACCUMULATION | MFE=2.21R | impr=0 | fuel=0.86 | c=2321.32 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 19:05 | 🎯 A:TP1 | c=2321.32 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 19:05 | 📣 PARTIAL_TAKEN→fortresses_active | c=2321.32 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 19:10 | 🧠 phase=ACCUMULATION | MFE=2.32R | impr=0 | fuel=0.86 | c=2321.3 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 19:15 | 🧠 phase=ACCUMULATION | MFE=3.03R | impr=0 | fuel=0.86 | c=2319.05 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 19:20 | 🧠 phase=ACCUMULATION | MFE=3.17R | impr=0 | fuel=0.86 | c=2314.4 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 19:25 | 🧠 phase=ACCUMULATION | MFE=3.17R | impr=0 | fuel=0.86 | c=2316.3 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 19:30 | 🧠 phase=ACCUMULATION | MFE=3.17R | impr=0 | fuel=0.86 | c=2318.55 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 19:35 | 🧠 phase=ACCUMULATION | MFE=3.17R | impr=0 | fuel=0.86 | c=2317.48 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 19:40 | 🧠 phase=ACCUMULATION | MFE=3.17R | impr=0 | fuel=0.86 | c=2314.43 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 19:45 | 🧠 phase=ACCUMULATION | MFE=3.52R | impr=0 | fuel=0.86 | c=2312.17 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 19:50 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2310.35 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 19:55 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2311.4 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 20:00 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2312.69 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 20:05 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2316.1 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 20:10 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2316.23 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 20:15 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2317.1 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 20:20 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2317.91 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 20:25 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2316.92 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 20:30 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2311.15 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 20:35 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=75 | fuel=0.86 | c=2310.59 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 20:40 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2313.81 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 20:45 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2318.08 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 20:45 | 🧠 A:Trail | c=2318.08 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 20:50 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2316.7 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 20:55 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2314.23 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 21:00 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=29 | fuel=0.86 | c=2313.68 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 21:05 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2317.92 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 21:10 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2317.73 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 21:15 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2316.02 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 21:20 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=13 | fuel=0.86 | c=2319.4 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 21:25 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2318.67 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 21:30 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2319.21 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 21:35 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2319.52 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 21:40 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2318.59 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 21:45 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2316.93 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 21:50 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2318.31 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 21:55 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2314.65 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 22:00 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=70 | fuel=0.86 | c=2318.19 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 22:05 | 🧠 phase=ACCUMULATION | MFE=3.77R | impr=0 | fuel=0.86 | c=2311.21 sl_B=2346.807371 sl_C=2346.807371 | | | |
| | 2023-12-22 22:10 | 🧠 phase=EXPANSION | MFE=4.15R | impr=97 | CE=2313.03 | CE_WICK_REBALANCE | fuel=0.86 | c=2306.7 sl_B=2313.4926 sl_C=2313.4926 | | | |
| | 2023-12-22 22:10 | 🛡️ B:CE_SOFT→2313.49 | c=2306.7 sl_B=2313.4926 sl_C=2313.4926 | | | |
| | 2023-12-22 22:10 | 🛡️ C:CE_SOFT→2313.49 | c=2306.7 sl_B=2313.4926 sl_C=2313.4926 | | | |
| | 2023-12-22 22:15 | 🧠 phase=EXPANSION | MFE=4.15R | impr=46 | CE=2313.03 | CE_WICK_REBALANCE | ITL_HARD=2319.76 | fuel=0.86 | SCALE_SHIFT:HARVEST_GATE MFE=4.15R hard=2320→1H/4H (TP1+BE locked, safe to scale) | c=2310.08 sl_B=2313.4926 sl_C=2313.4926 | | | |
| | 2023-12-22 22:20 | 🧠 phase=EXPANSION | MFE=4.15R | impr=0 | CE=2313.03 | CE_WICK_REBALANCE | ITL_HARD=2319.76 | fuel=0.86 | SCALE_SHIFT:HARVEST_GATE MFE=4.15R hard=2320→1H/4H (TP1+BE locked, safe to scale) | c=2310.98 sl_B=2313.4926 sl_C=2313.4926 | | | |
| | 2023-12-22 22:25 | 🧠 phase=EXPANSION | MFE=4.15R | impr=0 | CE=2313.03 | CE_WICK_REBALANCE | ITL_HARD=2319.76 | fuel=0.86 | SCALE_SHIFT:HARVEST_GATE MFE=4.15R hard=2320→1H/4H (TP1+BE locked, safe to scale) | c=2310.66 sl_B=2313.4926 sl_C=2313.4926 | | | |
| | 2023-12-22 22:30 | 🧠 phase=EXPANSION | MFE=4.15R | impr=0 | CE=2313.03 | CE_BODY_DEAD | ITL_HARD=2319.76 | fuel=0.86 | SCALE_SHIFT:HARVEST_GATE MFE=4.15R hard=2320→1H/4H (TP1+BE locked, safe to scale) | c=2313.72 sl_B=2313.4926 sl_C=2313.4926 | | | |
| | 2023-12-22 22:30 | 🔄 SCALE_SHIFT_HOLD: ignoring 15M CE death MFE=4.15R → watching 1H ITL None / 4H None | c=2313.72 sl_B=2313.4926 sl_C=2313.4926 | | | |
| | 2023-12-22 22:30 | 🛡️ B:FORTRESS_HIT | c=2313.72 sl_B=2313.4926 sl_C=2313.4926 | | | |
| | 2023-12-22 22:30 | 🛡️ C:FORTRESS_HIT | c=2313.72 sl_B=2313.4926 sl_C=2313.4926 | | | |


### صفقة #5 — BEARISH — 2023-12-24 07:00 → 2023-12-24 08:20 — PnL +3.784% ($+4.02)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=LONDON_KILLZONE NY=2023-12-24 02:00 NY (Sun) | سعر السوق لحظة الإشارة=2292.12 | Filter=ACCUM:PD_PREMIUM|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BEARISH Confidence=75 | Reason=LH+LL | Zone=PREMIUM | Confidence=75 | Structure={'hh': False, 'hl': False, 'lh': True, 'll': True}
  - Dealing Daily: zone=PREMIUM eq=2196.315 high=2407.63 low=1985.0 pct_in_range=73.1 current=2293.89
- **Layer2 NARRATIVE (15M Sweep):** Side=BSL Level=2317.95 Wick=2322.46 Quality=73.9 (min 25) | تعني: سيولة شراء مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=2196.315 ERL_H=2407.63 ERL_L=1985.0
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BEARISH BodyMult=6.5x Body%=96.3% Conviction=100.0 | تعني: اندفاع مؤسساتي — جسم 6.5x متوسط 5 شموع + جسم 96.3% من المدى = نية مؤسساتية
  - FVG: bottom=2317.86 top=2320.19 **CE(entry)=2319.025** dir=BEARISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=2319.025 SL=2329.584454 Risk=10.56 ATR=5.3 SL/ATR=1.99 | TP1={'price': 2303.15, 'kind': 'SWING', 'rr': 1.5, 'dist': 15.875} TP2={'price': 2195.28, 'kind': 'HTF_DRAW', 'rr': 11.72} TP3=1985.0
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BEARISH conf75 zone=PREMIUM | SWEEP BSL Q73.9 lvl=2317.95 wick=2322.46 | DISP 6.5x 96.3% conv=100.0 | FVG 2317.86-2320.19 CE=2319.025 RR1=1.5 SL_ATR=1.99 | KZ=LONDON_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 2.98R سعر متطرف لصالحنا 2287.55 | MAE 0.00R سعر ضدنا 2319.025 | مدة 1.3 ساعة | Phase EXPANSION
- أسباب خروج: A=A_TRAIL B=B_FORTRESS C=C_FORTRESS — تفسير: A=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. B=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. C=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. 
- Balance 106.25531063564623 → 110.2763899234021
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-24 07:00 OPEN entry=2319.025 sl=2329.584454 tp1=2303.15 filter=ACCUM:PD_PREMIUM|MID_OK | | | |
| | 2023-12-24 07:05 | 🧠 phase=ACCUMULATION | MFE=2.63R | impr=0 | fuel=0.63 | c=2293.24 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 07:05 | 🎯 A:TP1 | c=2293.24 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 07:05 | 📣 PARTIAL_TAKEN→fortresses_active | c=2293.24 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 07:10 | 🧠 phase=ACCUMULATION | MFE=2.63R | impr=0 | fuel=0.63 | c=2295.2 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 07:15 | 🧠 phase=ACCUMULATION | MFE=2.63R | impr=0 | fuel=0.63 | c=2295.26 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 07:20 | 🧠 phase=ACCUMULATION | MFE=2.63R | impr=0 | fuel=0.63 | c=2296.62 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 07:25 | 🧠 phase=ACCUMULATION | MFE=2.63R | impr=0 | fuel=0.63 | c=2296.16 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 07:30 | 🧠 phase=ACCUMULATION | MFE=2.63R | impr=0 | fuel=0.63 | c=2292.88 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 07:35 | 🧠 phase=ACCUMULATION | MFE=2.73R | impr=0 | fuel=0.63 | c=2290.37 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 07:40 | 🧠 phase=ACCUMULATION | MFE=2.77R | impr=0 | fuel=0.63 | c=2292.35 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 07:45 | 🧠 phase=ACCUMULATION | MFE=2.77R | impr=0 | fuel=0.63 | c=2296.6 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 07:45 | 🧠 A:Trail | c=2296.6 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 07:50 | 🧠 phase=ACCUMULATION | MFE=2.77R | impr=0 | fuel=0.63 | c=2296.95 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 07:55 | 🧠 phase=ACCUMULATION | MFE=2.77R | impr=0 | fuel=0.63 | c=2296.11 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 08:00 | 🧠 phase=ACCUMULATION | MFE=2.77R | impr=0 | fuel=0.63 | c=2294.15 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 08:05 | 🧠 phase=ACCUMULATION | MFE=2.77R | impr=0 | fuel=0.63 | c=2294.63 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 08:10 | 🧠 phase=ACCUMULATION | MFE=2.87R | impr=0 | fuel=0.63 | c=2288.85 sl_B=2329.584454 sl_C=2329.584454 | | | |
| | 2023-12-24 08:15 | 🧠 phase=EXPANSION | MFE=2.98R | impr=83 | CE=2292.46 | CE_WICK_REBALANCE | fuel=0.63 | c=2291.17 sl_B=2292.884 sl_C=2292.884 | | | |
| | 2023-12-24 08:15 | 🛡️ B:CE_SOFT→2292.88 | c=2291.17 sl_B=2292.884 sl_C=2292.884 | | | |
| | 2023-12-24 08:15 | 🛡️ C:CE_SOFT→2292.88 | c=2291.17 sl_B=2292.884 sl_C=2292.884 | | | |
| | 2023-12-24 08:20 | 🧠 phase=EXPANSION | MFE=2.98R | impr=0 | CE=2292.46 | CE_WICK_REBALANCE | fuel=0.63 | c=2291.56 sl_B=2292.884 sl_C=2292.884 | | | |
| | 2023-12-24 08:20 | 🛡️ B:FORTRESS_HIT | c=2291.56 sl_B=2292.884 sl_C=2292.884 | | | |
| | 2023-12-24 08:20 | 🛡️ C:FORTRESS_HIT | c=2291.56 sl_B=2292.884 sl_C=2292.884 | | | |


### صفقة #6 — BULLISH — 2023-12-24 14:00 → 2023-12-24 20:40 — PnL -1.238% ($-1.37)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=NY_AM_KILLZONE NY=2023-12-24 09:00 NY (Sun) | سعر السوق لحظة الإشارة=2299.16 | Filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(73)+OB_HELD → old Premium is new Discount for DOL 2407.63. Mitigation Block continuation per ICT. LONG only.|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BULLISH Confidence=90 | Reason=HH+HL | Zone=PREMIUM | Confidence=90 | Structure={'hh': True, 'hl': True, 'lh': False, 'll': False}
  - Dealing Daily: zone=PREMIUM eq=2196.315 high=2407.63 low=1985.0 pct_in_range=74.2 current=2298.59
- **Layer2 NARRATIVE (15M Sweep):** Side=SSL Level=2291.07 Wick=2287.87 Quality=89.3 (min 25) | تعني: سيولة بيع مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=2196.315 ERL_H=2407.63 ERL_L=1985.0
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BULLISH BodyMult=2.11x Body%=93.3% Conviction=73.4 | تعني: اندفاع مؤسساتي — جسم 2.11x متوسط 5 شموع + جسم 93.3% من المدى = نية مؤسساتية
  - FVG: bottom=2290.34 top=2291.65 **CE(entry)=2290.995** dir=BULLISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=2290.995 SL=2274.554218 Risk=16.44 ATR=2.97 SL/ATR=5.53 | TP1={'price': 2316.3, 'kind': 'SWING', 'rr': 1.54, 'dist': 25.30500000000029} TP2={'price': 2345.95, 'kind': 'HTF_DRAW', 'rr': 3.34} TP3=2407.63
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BULLISH conf90 zone=PREMIUM | SWEEP SSL Q89.3 lvl=2291.07 wick=2287.87 | DISP 2.11x 93.3% conv=73.4 | FVG 2290.34-2291.65 CE=2290.995 RR1=1.54 SL_ATR=5.53 | KZ=NY_AM_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 1.10R سعر متطرف لصالحنا 2309.13 | MAE 1.22R سعر ضدنا 2270.97 | مدة 6.7 ساعة | Phase EXPANSION
- أسباب خروج: A=SL B=B_FORTRESS C=C_FORTRESS — تفسير: A=SL ضرب الستوب الابتدائي قبل TP1 — الفكرة فشلت مبكراً. B=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. C=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. 
- Balance 110.2763899234021 → 108.91128235623867
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-24 14:00 OPEN entry=2290.995 sl=2274.554218 tp1=2316.3 filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(73)+OB_HELD → old Premium is new Discount for DOL 2407.63. Mitigation Block continuation per ICT. LONG only.|MID_OK | | | |
| | 2023-12-24 14:05 | 🧠 phase=ACCUMULATION | MFE=0.60R | impr=0 | fuel=0.97 | c=2300.52 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 14:10 | 🧠 phase=ACCUMULATION | MFE=0.96R | impr=0 | fuel=0.97 | c=2306.69 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 14:15 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2308.0 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 14:20 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2305.01 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 14:25 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2304.11 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 14:30 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2301.57 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 14:35 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2303.07 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 14:40 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2298.0 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 14:45 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2289.84 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 14:50 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2287.15 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 14:55 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2290.85 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 15:00 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2295.23 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 15:05 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2293.75 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 15:10 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2297.99 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 15:15 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=45 | fuel=0.97 | c=2297.99 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 15:20 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2298.32 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 15:25 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2296.34 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 15:30 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2294.55 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 15:35 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2295.59 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 15:40 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2298.1 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 15:45 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=30 | fuel=0.97 | c=2297.76 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 15:50 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2296.65 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 15:55 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2294.6 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 16:00 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2293.03 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 16:05 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2288.83 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 16:10 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2293.2 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 16:15 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=53 | fuel=0.97 | c=2289.04 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 16:20 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2292.97 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 16:25 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=33 | fuel=0.97 | c=2296.06 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 16:30 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=43 | fuel=0.97 | c=2294.54 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 16:35 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2295.78 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 16:40 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2295.1 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 16:45 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2298.25 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 16:50 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=30 | fuel=0.97 | c=2297.44 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 16:55 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2295.43 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 17:00 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2297.13 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 17:05 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2294.92 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 17:10 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2297.91 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 17:15 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=30 | fuel=0.97 | c=2294.04 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 17:20 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2291.4 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 17:25 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2293.21 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 17:30 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2292.04 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 17:35 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2291.76 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 17:40 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2293.1 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 17:45 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=17 | fuel=0.97 | c=2290.93 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 17:50 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2290.68 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 17:55 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2291.4 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 18:00 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2290.87 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 18:05 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2290.53 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 18:10 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2291.13 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 18:15 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2293.39 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 18:20 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=16 | fuel=0.97 | c=2291.66 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 18:25 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2290.0 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 18:30 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2285.31 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 18:35 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2287.46 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 18:40 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=4 | fuel=0.97 | c=2287.93 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 18:45 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2287.49 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 18:50 | 🧠 phase=ACCUMULATION | MFE=1.10R | impr=0 | fuel=0.97 | c=2291.04 sl_B=2274.554218 sl_C=2274.554218 | | | |
| | 2023-12-24 18:55 | 🧠 phase=EXPANSION | MFE=1.10R | impr=100 | CE=2289.49 | CE_WICK_REBALANCE | fuel=0.97 | c=2293.0 sl_B=2289.2524 sl_C=2289.2524 | | | |


### صفقة #7 — BULLISH — 2023-12-29 09:00 → 2023-12-29 16:15 — PnL -0.455% ($-0.50)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=LONDON_KILLZONE NY=2023-12-29 04:00 NY (Fri) | سعر السوق لحظة الإشارة=2343.5 | Filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(94)+OB_HELD → old Premium is new Discount for DOL 2407.63. Mitigation Block continuation per ICT. LONG only.|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BULLISH Confidence=80 | Reason=HH+HL | Zone=PREMIUM | Confidence=80 | Structure={'hh': True, 'hl': True, 'lh': False, 'll': False}
  - Dealing Daily: zone=PREMIUM eq=2261.13 high=2407.63 low=2114.63 pct_in_range=87.1 current=2369.81
- **Layer2 NARRATIVE (15M Sweep):** Side=SSL Level=2343.95 Wick=2335.56 Quality=97.3 (min 25) | تعني: سيولة بيع مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=2262.91 ERL_H=2455.52 ERL_L=2070.3
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BULLISH BodyMult=2.8x Body%=88.8% Conviction=94.0 | تعني: اندفاع مؤسساتي — جسم 2.8x متوسط 5 شموع + جسم 88.8% من المدى = نية مؤسساتية
  - FVG: bottom=2340.76 top=2344.44 **CE(entry)=2342.6000000000004** dir=BULLISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=2342.6 SL=2310.228313 Risk=32.37 ATR=5.61 SL/ATR=5.77 | TP1={'price': 2394.6, 'kind': 'SWING', 'rr': 1.61, 'dist': 51.999999999999545} TP2={'mode': 'OPEN_TRAILING', 'kind': 'TRAIL'} TP3=None
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BULLISH conf80 zone=PREMIUM | SWEEP SSL Q97.3 lvl=2343.95 wick=2335.56 | DISP 2.8x 88.8% conv=94.0 | FVG 2340.76-2344.44 CE=2342.6000000000004 RR1=1.61 SL_ATR=5.77 | KZ=LONDON_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 1.43R سعر متطرف لصالحنا 2388.74 | MAE 1.17R سعر ضدنا 2304.64 | مدة 7.2 ساعة | Phase EXPANSION
- أسباب خروج: A=SL B=B_FORTRESS C=C_FORTRESS — تفسير: A=SL ضرب الستوب الابتدائي قبل TP1 — الفكرة فشلت مبكراً. B=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. C=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. 
- Balance 108.91128235623867 → 108.41625031694491
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-29 09:00 OPEN entry=2342.6 sl=2310.228313 tp1=2394.6 filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(94)+OB_HELD → old Premium is new Discount for DOL 2407.63. Mitigation Block continuation per ICT. LONG only.|MID_OK | | | |
| | 2023-12-29 09:05 | 🧠 phase=ACCUMULATION | MFE=0.19R | impr=0 | fuel=0.92 | c=2348.83 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 09:10 | 🧠 phase=ACCUMULATION | MFE=0.28R | impr=0 | fuel=0.92 | c=2351.23 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 09:15 | 🧠 phase=ACCUMULATION | MFE=0.30R | impr=0 | fuel=0.92 | c=2351.47 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 09:20 | 🧠 phase=ACCUMULATION | MFE=0.54R | impr=0 | fuel=0.92 | c=2357.91 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 09:25 | 🧠 phase=ACCUMULATION | MFE=0.57R | impr=0 | fuel=0.92 | c=2360.51 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 09:30 | 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | fuel=0.87 | c=2364.05 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 09:35 | 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | fuel=0.87 | c=2362.58 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 09:40 | 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | fuel=0.87 | c=2360.59 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 09:45 | 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | CE=2354.64 | CE_HOLDS | fuel=0.87 | c=2358.68 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 09:50 | 🧠 phase=ACCUMULATION | MFE=0.79R | impr=0 | CE=2354.64 | CE_HOLDS | fuel=0.87 | c=2361.48 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 09:55 | 🧠 phase=ACCUMULATION | MFE=1.03R | impr=0 | CE=2354.64 | CE_HOLDS | fuel=0.80 | c=2369.95 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 10:00 | 🧠 phase=ACCUMULATION | MFE=1.03R | impr=0 | CE=2354.64 | CE_HOLDS | fuel=0.80 | c=2367.01 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 10:05 | 🧠 phase=ACCUMULATION | MFE=1.03R | impr=0 | CE=2354.64 | CE_HOLDS | fuel=0.80 | c=2368.2 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 10:10 | 🧠 phase=ACCUMULATION | MFE=1.03R | impr=0 | CE=2354.64 | CE_HOLDS | fuel=0.80 | c=2367.62 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 10:15 | 🧠 phase=ACCUMULATION | MFE=1.03R | impr=0 | CE=2354.64 | CE_HOLDS | fuel=0.80 | c=2367.49 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 10:20 | 🧠 phase=ACCUMULATION | MFE=1.03R | impr=0 | CE=2354.64 | CE_HOLDS | fuel=0.80 | c=2367.63 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 10:25 | 🧠 phase=ACCUMULATION | MFE=1.03R | impr=0 | CE=2354.64 | CE_HOLDS | fuel=0.80 | c=2368.34 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 10:30 | 🧠 phase=ACCUMULATION | MFE=1.03R | impr=0 | CE=2354.64 | CE_HOLDS | fuel=0.80 | c=2367.6 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 10:35 | 🧠 phase=ACCUMULATION | MFE=1.03R | impr=0 | CE=2354.64 | CE_HOLDS | fuel=0.80 | c=2368.82 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 10:40 | 🧠 phase=ACCUMULATION | MFE=1.03R | impr=0 | CE=2354.64 | CE_HOLDS | fuel=0.80 | c=2370.59 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 10:45 | 🧠 phase=ACCUMULATION | MFE=1.03R | impr=1 | CE=2354.64 | CE_HOLDS | fuel=0.80 | c=2372.23 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 10:50 | 🧠 phase=ACCUMULATION | MFE=1.03R | impr=2 | CE=2354.64 | CE_HOLDS | fuel=0.80 | c=2368.89 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 10:55 | 🧠 phase=ACCUMULATION | MFE=1.03R | impr=0 | CE=2354.64 | CE_HOLDS | fuel=0.80 | c=2367.79 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 11:00 | 🧠 phase=ACCUMULATION | MFE=1.03R | impr=0 | CE=2354.64 | CE_HOLDS | fuel=0.80 | c=2368.73 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 11:05 | 🧠 phase=ACCUMULATION | MFE=1.03R | impr=0 | CE=2354.64 | CE_HOLDS | fuel=0.80 | c=2371.73 sl_B=2310.228313 sl_C=2310.228313 | | | |
| | 2023-12-29 11:10 | 🧠 phase=EXPANSION | MFE=1.06R | impr=96 | CE=2370.36 | CE_BODY_DEAD | fuel=0.79 | c=2374.4 sl_B=2369.9111999999996 sl_C=2369.9111999999996 | | | |
| | 2023-12-29 11:10 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=2374.4 sl_B=2369.9111999999996 sl_C=2369.9111999999996 | | | |
| | 2023-12-29 11:10 | 🛡️ B:CE_SOFT→2369.91 | c=2374.4 sl_B=2369.9111999999996 sl_C=2369.9111999999996 | | | |
| | 2023-12-29 11:10 | 🛡️ C:CE_SOFT→2369.91 | c=2374.4 sl_B=2369.9111999999996 sl_C=2369.9111999999996 | | | |
| | 2023-12-29 11:15 | 🧠 phase=EXPANSION | MFE=1.16R | impr=54 | CE=2370.36 | CE_WICK_REBALANCE | fuel=0.77 | c=2376.29 sl_B=2369.9111999999996 sl_C=2369.9111999999996 | | | |
| | 2023-12-29 11:20 | 🧠 phase=EXPANSION | MFE=1.19R | impr=0 | CE=2370.36 | CE_WICK_REBALANCE | fuel=0.76 | c=2377.36 sl_B=2369.9111999999996 sl_C=2369.9111999999996 | | | |
| | 2023-12-29 11:25 | 🧠 phase=EXPANSION | MFE=1.19R | impr=0 | CE=2370.36 | CE_WICK_REBALANCE | fuel=0.76 | c=2374.82 sl_B=2369.9111999999996 sl_C=2369.9111999999996 | | | |
| | 2023-12-29 11:30 | 🧠 phase=EXPANSION | MFE=1.19R | impr=0 | CE=2373.22 | CE_HOLDS | fuel=0.76 | c=2374.47 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 11:30 | 🛡️ B:CE_SOFT→2372.77 | c=2374.47 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 11:30 | 🛡️ C:CE_SOFT→2372.77 | c=2374.47 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 11:35 | 🧠 phase=EXPANSION | MFE=1.19R | impr=0 | CE=2373.22 | CE_HOLDS | fuel=0.76 | c=2372.75 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 11:35 | 🛡️ B:FORTRESS_HIT | c=2372.75 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 11:35 | 🛡️ C:FORTRESS_HIT | c=2372.75 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 11:40 | 🧠 phase=EXPANSION | MFE=1.19R | impr=0 | CE=2373.22 | CE_HOLDS | fuel=0.76 | c=2372.15 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 11:45 | 🧠 phase=EXPANSION | MFE=1.19R | impr=0 | CE=2373.22 | CE_BODY_DEAD | fuel=0.76 | c=2371.45 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 11:45 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=2371.45 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 11:50 | 🧠 phase=EXPANSION | MFE=1.19R | impr=0 | CE=2373.22 | CE_BODY_DEAD | fuel=0.76 | c=2373.0 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 11:50 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=2373.0 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 11:55 | 🧠 phase=EXPANSION | MFE=1.19R | impr=0 | CE=2373.22 | CE_BODY_DEAD | fuel=0.76 | c=2374.65 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 11:55 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=2374.65 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 12:00 | 🧠 phase=EXPANSION | MFE=1.19R | impr=30 | CE=2373.22 | CE_WICK_REBALANCE | fuel=0.76 | c=2375.9 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 12:05 | 🧠 phase=EXPANSION | MFE=1.19R | impr=12 | CE=2373.22 | CE_WICK_REBALANCE | fuel=0.76 | c=2373.05 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 12:10 | 🧠 phase=EXPANSION | MFE=1.19R | impr=0 | CE=2373.22 | CE_WICK_REBALANCE | fuel=0.76 | c=2369.32 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 12:15 | 🧠 phase=EXPANSION | MFE=1.19R | impr=0 | CE=2373.22 | CE_BODY_DEAD | fuel=0.76 | c=2370.31 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 12:15 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=2370.31 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 12:20 | 🧠 phase=EXPANSION | MFE=1.19R | impr=0 | CE=2373.22 | CE_BODY_DEAD | fuel=0.76 | c=2370.17 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 12:20 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=2370.17 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 12:25 | 🧠 phase=EXPANSION | MFE=1.19R | impr=0 | CE=2373.22 | CE_BODY_DEAD | fuel=0.76 | c=2368.83 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 12:25 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=2368.83 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 12:30 | 🧠 phase=EXPANSION | MFE=1.19R | impr=0 | CE=2373.22 | CE_BODY_DEAD | fuel=0.76 | c=2366.4 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 12:30 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=2366.4 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 12:35 | 🧠 phase=EXPANSION | MFE=1.19R | impr=0 | CE=2373.22 | CE_BODY_DEAD | fuel=0.76 | c=2365.35 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 12:35 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=2365.35 sl_B=2372.7662 sl_C=2372.7662 | | | |
| | 2023-12-29 12:40 | 🧠 phase=EXPANSION | MFE=1.19R | impr=0 | CE=2373.22 | CE_BODY_DEAD | fuel=0.76 | c=2362.25 sl_B=2372.7662 sl_C=2372.7662 | | | |


### صفقة #8 — BEARISH — 2023-12-29 19:00 → 2023-12-29 23:15 — PnL +6.021% ($+6.53)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=NY_PM_KILLZONE NY=2023-12-29 14:00 NY (Fri) | سعر السوق لحظة الإشارة=2316.11 | Filter=ACCUM:PD_PREMIUM|MID_OK
- **Layer1 BIAS (Daily+4H):** Direction=BEARISH Confidence=100 | Reason=LH+LL | Zone=PREMIUM | Confidence=100 | Structure={'hh': False, 'hl': False, 'lh': True, 'll': True}
  - Dealing Daily: zone=PREMIUM eq=2261.13 high=2407.63 low=2114.63 pct_in_range=81.1 current=2352.18
- **Layer2 NARRATIVE (15M Sweep):** Side=BSL Level=2377.72 Wick=2385.83 Quality=77.1 (min 25) | تعني: سيولة شراء مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=2271.525 ERL_H=2455.52 ERL_L=2087.53
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BEARISH BodyMult=2.19x Body%=91.6% Conviction=74.5 | تعني: اندفاع مؤسساتي — جسم 2.19x متوسط 5 شموع + جسم 91.6% من المدى = نية مؤسساتية
  - FVG: bottom=2372.28 top=2375.57 **CE(entry)=2373.925** dir=BEARISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=2373.925 SL=2389.705692 Risk=15.78 ATR=6.44 SL/ATR=2.45 | TP1={'price': 2350.09, 'kind': 'SWING', 'rr': 1.51, 'dist': 23.835000000000036} TP2={'price': 2241.2, 'kind': 'HTF_DRAW', 'rr': 8.41} TP3=2186.0
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BEARISH conf100 zone=PREMIUM | SWEEP BSL Q77.1 lvl=2377.72 wick=2385.83 | DISP 2.19x 91.6% conv=74.5 | FVG 2372.28-2375.57 CE=2373.925 RR1=1.51 SL_ATR=2.45 | KZ=NY_PM_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 7.55R سعر متطرف لصالحنا 2254.72 | MAE 0.00R سعر ضدنا 2373.925 | مدة 4.2 ساعة | Phase EXPANSION
- أسباب خروج: A=A_TRAIL B=B_FORTRESS C=C_FORTRESS — تفسير: A=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. B=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. C=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. 
- Balance 108.41625031694491 → 114.94361212366967
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-29 19:00 OPEN entry=2373.925 sl=2389.705692 tp1=2350.09 filter=ACCUM:PD_PREMIUM|MID_OK | | | |
| | 2023-12-29 19:05 | 🧠 phase=ACCUMULATION | MFE=3.90R | impr=0 | fuel=0.39 | c=2313.25 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 19:05 | 🎯 A:TP1 | c=2313.25 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 19:05 | 📣 PARTIAL_TAKEN→fortresses_active | c=2313.25 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 19:10 | 🧠 phase=ACCUMULATION | MFE=4.09R | impr=0 | fuel=0.39 | c=2314.84 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 19:15 | 🧠 phase=ACCUMULATION | MFE=4.09R | impr=0 | fuel=0.39 | c=2313.75 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 19:20 | 🧠 phase=ACCUMULATION | MFE=4.09R | impr=0 | fuel=0.39 | c=2317.39 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 19:25 | 🧠 phase=ACCUMULATION | MFE=4.09R | impr=0 | fuel=0.39 | c=2317.57 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 19:30 | 🧠 phase=ACCUMULATION | MFE=4.09R | impr=0 | fuel=0.39 | c=2320.14 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 19:35 | 🧠 phase=ACCUMULATION | MFE=4.09R | impr=0 | fuel=0.39 | c=2318.02 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 19:40 | 🧠 phase=ACCUMULATION | MFE=4.09R | impr=0 | fuel=0.39 | c=2317.88 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 19:45 | 🧠 phase=ACCUMULATION | MFE=4.09R | impr=0 | fuel=0.39 | c=2318.25 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 19:50 | 🧠 phase=ACCUMULATION | MFE=4.09R | impr=0 | fuel=0.39 | c=2320.37 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 19:55 | 🧠 phase=ACCUMULATION | MFE=4.09R | impr=0 | fuel=0.39 | c=2318.84 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 20:00 | 🧠 phase=ACCUMULATION | MFE=4.09R | impr=0 | fuel=0.39 | c=2315.48 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 20:05 | 🧠 phase=ACCUMULATION | MFE=4.09R | impr=0 | fuel=0.39 | c=2315.2 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 20:10 | 🧠 phase=ACCUMULATION | MFE=4.09R | impr=0 | fuel=0.39 | c=2313.76 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 20:15 | 🧠 phase=ACCUMULATION | MFE=4.09R | impr=0 | fuel=0.39 | c=2310.87 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 20:20 | 🧠 phase=ACCUMULATION | MFE=4.28R | impr=19 | fuel=0.39 | c=2310.45 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 20:25 | 🧠 phase=ACCUMULATION | MFE=4.37R | impr=0 | fuel=0.39 | c=2308.27 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 20:30 | 🧠 phase=ACCUMULATION | MFE=4.37R | impr=0 | CE=2313.09 | CE_HOLDS | fuel=0.39 | c=2306.19 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 20:35 | 🧠 phase=ACCUMULATION | MFE=4.51R | impr=3 | CE=2313.09 | CE_HOLDS | fuel=0.39 | c=2303.11 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 20:40 | 🧠 phase=ACCUMULATION | MFE=4.61R | impr=15 | CE=2313.09 | CE_HOLDS | fuel=0.39 | c=2301.82 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 20:45 | 🧠 phase=ACCUMULATION | MFE=4.61R | impr=0 | CE=2308.47 | CE_HOLDS | fuel=0.39 | c=2305.41 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 20:50 | 🧠 phase=ACCUMULATION | MFE=4.61R | impr=0 | CE=2308.47 | CE_HOLDS | fuel=0.39 | c=2306.17 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 20:50 | 🧠 A:Trail | c=2306.17 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 20:55 | 🧠 phase=ACCUMULATION | MFE=4.61R | impr=0 | CE=2308.47 | CE_HOLDS | fuel=0.39 | c=2307.53 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 21:00 | 🧠 phase=ACCUMULATION | MFE=4.61R | impr=0 | CE=2308.47 | CE_WICK_REBALANCE | fuel=0.39 | c=2307.76 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 21:05 | 🧠 phase=ACCUMULATION | MFE=4.61R | impr=0 | CE=2308.47 | CE_WICK_REBALANCE | fuel=0.39 | c=2306.42 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 21:10 | 🧠 phase=ACCUMULATION | MFE=4.61R | impr=0 | CE=2308.47 | CE_WICK_REBALANCE | fuel=0.39 | c=2312.24 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 21:15 | 🧠 phase=ACCUMULATION | MFE=4.61R | impr=0 | CE=2308.47 | CE_WICK_REBALANCE | fuel=0.39 | c=2303.93 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 21:20 | 🧠 phase=ACCUMULATION | MFE=4.61R | impr=70 | CE=2308.47 | CE_WICK_REBALANCE | fuel=0.39 | c=2303.51 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 21:25 | 🧠 phase=ACCUMULATION | MFE=4.84R | impr=0 | CE=2308.47 | CE_WICK_REBALANCE | fuel=0.39 | c=2301.09 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 21:30 | 🧠 phase=ACCUMULATION | MFE=4.85R | impr=30 | CE=2308.47 | CE_HOLDS | fuel=0.39 | c=2299.01 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 21:35 | 🧠 phase=ACCUMULATION | MFE=4.85R | impr=0 | CE=2308.47 | CE_HOLDS | fuel=0.39 | c=2298.02 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 21:40 | 🧠 phase=ACCUMULATION | MFE=4.90R | impr=0 | CE=2308.47 | CE_HOLDS | fuel=0.39 | c=2302.99 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 21:45 | 🧠 phase=ACCUMULATION | MFE=5.05R | impr=0 | CE=2308.47 | CE_HOLDS | fuel=0.39 | c=2297.24 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 21:50 | 🧠 phase=ACCUMULATION | MFE=6.01R | impr=53 | CE=2308.47 | CE_HOLDS | fuel=0.33 | c=2285.34 sl_B=2389.705692 sl_C=2389.705692 | | | |
| | 2023-12-29 21:55 | 🧠 phase=EXPANSION | MFE=6.27R | impr=80 | CE=2291.51 | CE_WICK_REBALANCE | fuel=0.29 | c=2287.52 sl_B=2292.0202 sl_C=2292.0202 | | | |
| | 2023-12-29 21:55 | 🛡️ B:CE_SOFT→2292.02 | c=2287.52 sl_B=2292.0202 sl_C=2292.0202 | | | |
| | 2023-12-29 21:55 | 🛡️ C:CE_SOFT→2292.02 | c=2287.52 sl_B=2292.0202 sl_C=2292.0202 | | | |
| | 2023-12-29 22:00 | 🧠 phase=EXPANSION | MFE=6.27R | impr=0 | CE=2291.51 | CE_WICK_REBALANCE | fuel=0.29 | c=2286.56 sl_B=2292.0202 sl_C=2292.0202 | | | |
| | 2023-12-29 22:05 | 🧠 phase=EXPANSION | MFE=6.27R | impr=0 | CE=2291.51 | CE_WICK_REBALANCE | fuel=0.29 | c=2283.4 sl_B=2292.0202 sl_C=2292.0202 | | | |
| | 2023-12-29 22:10 | 🧠 phase=EXPANSION | MFE=6.27R | impr=0 | CE=2291.51 | CE_WICK_REBALANCE | fuel=0.29 | c=2278.18 sl_B=2292.0202 sl_C=2292.0202 | | | |
| | 2023-12-29 22:15 | 🧠 phase=EXPANSION | MFE=6.40R | impr=19 | CE=2290.40 | CE_HOLDS | fuel=0.27 | c=2273.84 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |
| | 2023-12-29 22:15 | 🛡️ B:CE_SOFT→2290.92 | c=2273.84 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |
| | 2023-12-29 22:15 | 🛡️ C:CE_SOFT→2290.92 | c=2273.84 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |
| | 2023-12-29 22:20 | 🧠 phase=EXPANSION | MFE=7.55R | impr=30 | CE=2290.40 | CE_HOLDS | fuel=0.11 | c=2271.84 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |
| | 2023-12-29 22:25 | 🧠 phase=EXPANSION | MFE=7.55R | impr=0 | CE=2290.40 | CE_HOLDS | fuel=0.11 | c=2280.06 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |
| | 2023-12-29 22:30 | 🧠 phase=EXPANSION | MFE=7.55R | impr=0 | CE=2290.40 | CE_HOLDS | fuel=0.11 | c=2277.38 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |
| | 2023-12-29 22:35 | 🧠 phase=EXPANSION | MFE=7.55R | impr=0 | CE=2290.40 | CE_HOLDS | fuel=0.11 | c=2281.8 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |
| | 2023-12-29 22:40 | 🧠 phase=EXPANSION | MFE=7.55R | impr=0 | CE=2290.40 | CE_HOLDS | fuel=0.11 | c=2285.61 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |
| | 2023-12-29 22:45 | 🧠 phase=EXPANSION | MFE=7.55R | impr=0 | CE=2290.40 | CE_HOLDS | fuel=0.11 | c=2281.83 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |
| | 2023-12-29 22:50 | 🧠 phase=EXPANSION | MFE=7.55R | impr=30 | CE=2290.40 | CE_HOLDS | fuel=0.11 | c=2278.0 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |
| | 2023-12-29 22:55 | 🧠 phase=EXPANSION | MFE=7.55R | impr=30 | CE=2290.40 | CE_HOLDS | fuel=0.11 | c=2283.0 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |
| | 2023-12-29 23:00 | 🧠 phase=EXPANSION | MFE=7.55R | impr=0 | CE=2290.40 | CE_HOLDS | fuel=0.11 | c=2285.63 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |
| | 2023-12-29 23:05 | 🧠 phase=EXPANSION | MFE=7.55R | impr=0 | CE=2290.40 | CE_HOLDS | fuel=0.11 | c=2286.98 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |
| | 2023-12-29 23:10 | 🧠 phase=EXPANSION | MFE=7.55R | impr=0 | CE=2290.40 | CE_HOLDS | fuel=0.11 | c=2288.65 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |
| | 2023-12-29 23:15 | 🧠 phase=EXPANSION | MFE=7.55R | impr=0 | CE=2290.40 | CE_BODY_DEAD | fuel=0.11 | c=2292.96 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |
| | 2023-12-29 23:15 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=2292.96 sl_B=2290.9201999999996 sl_C=2290.9201999999996 | | | |


### صفقة #9 — BULLISH — 2023-12-31 08:00 → 2023-12-31 11:55 — PnL +2.966% ($+3.41)

**لماذا دخل؟ (4 طبقات)**

- **السياق والجلسة:** Session=LONDON_KILLZONE NY=2023-12-31 03:00 NY (Sun) | سعر السوق لحظة الإشارة=2297.61 | Filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(99)+OB_HELD → old Premium is new Discount for DOL 2455.52. Mitigation Block continuation per ICT. LONG only.|SOFT_ABOVE_MIDNIGHT
- **Layer1 BIAS (Daily+4H):** Direction=BULLISH Confidence=90 | Reason=HH+HL | Zone=PREMIUM | Confidence=90 | Structure={'hh': True, 'hl': True, 'lh': False, 'll': False}
  - Dealing Daily: zone=PREMIUM eq=2285.075 high=2455.52 low=2114.63 pct_in_range=50.9 current=2288.27
- **Layer2 NARRATIVE (15M Sweep):** Side=SSL Level=2282.58 Wick=2280.91 Quality=56.5 (min 25) | تعني: سيولة بيع مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine
  - Dealing 15M: zone=PREMIUM eq=2285.075 ERL_H=2455.52 ERL_L=2114.63
- **Layer3 TRIGGER (5M Displacement+FVG):** Dir=BULLISH BodyMult=6.41x Body%=89.2% Conviction=99.1 | تعني: اندفاع مؤسساتي — جسم 6.41x متوسط 5 شموع + جسم 89.2% من المدى = نية مؤسساتية
  - FVG: bottom=2287.85 top=2289.79 **CE(entry)=2288.8199999999997** dir=BULLISH | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات
- **Layer4 PLAN:** Entry=2288.82 SL=2273.337347 Risk=15.48 ATR=3.48 SL/ATR=4.44 | TP1={'price': 2312.93, 'kind': 'SWING', 'rr': 1.56, 'dist': 24.110000000000127} TP2={'price': 2345.95, 'kind': 'HTF_DRAW', 'rr': 3.69} TP3=2407.63
  - توزيع مخاطرة: A=1.2% B=0.6% C=0.2% = إجمالي 2%
  - جملة الدخول: BIAS BULLISH conf90 zone=PREMIUM | SWEEP SSL Q56.5 lvl=2282.58 wick=2280.91 | DISP 6.41x 89.2% conv=99.1 | FVG 2287.85-2289.79 CE=2288.8199999999997 RR1=1.56 SL_ATR=4.44 | KZ=LONDON_KILLZONE

**كيف أدار الصفقة ولماذا خرج؟**

- MFE 1.89R سعر متطرف لصالحنا 2318.0 | MAE 0.00R سعر ضدنا 2288.82 | مدة 3.9 ساعة | Phase EXPANSION
- أسباب خروج: A=A_TRAIL B=B_FORTRESS C=C_FORTRESS — تفسير: A=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. B=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. C=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. 
- Balance 114.94361212366967 → 118.35280995806589
- Timeline الأحداث (شو عمل):

| وقت | حدث | سعر | SL_B | SL_C |
|------|------|------|------|------|
| | 2023-12-31 08:00 OPEN entry=2288.82 sl=2273.337347 tp1=2312.93 filter=ACCUM:LONG_IN_PREMIUM|CONT_UNLOCKED:CONTINUATION_UNLOCK_LONG: 15M PREMIUM but Daily PREMIUM with BOS+Disp(99)+OB_HELD → old Premium is new Discount for DOL 2455.52. Mitigation Block continuation per ICT. LONG only.|SOFT_ABOVE_MIDNIGHT | | | |
| | 2023-12-31 08:05 | 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.82 | c=2297.65 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 08:10 | 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.82 | c=2296.82 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 08:15 | 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.82 | c=2297.78 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 08:20 | 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.82 | c=2294.55 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 08:25 | 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.82 | c=2294.81 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 08:30 | 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.82 | c=2294.0 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 08:35 | 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.82 | c=2293.66 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 08:40 | 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.82 | c=2293.44 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 08:45 | 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.82 | c=2292.9 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 08:50 | 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.82 | c=2295.42 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 08:55 | 🧠 phase=ACCUMULATION | MFE=0.68R | impr=0 | fuel=0.82 | c=2296.96 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 09:00 | 🧠 phase=ACCUMULATION | MFE=0.95R | impr=0 | fuel=0.82 | c=2303.18 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 09:05 | 🧠 phase=ACCUMULATION | MFE=0.95R | impr=0 | fuel=0.82 | c=2300.65 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 09:10 | 🧠 phase=ACCUMULATION | MFE=1.06R | impr=0 | fuel=0.82 | c=2305.17 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 09:15 | 🧠 phase=ACCUMULATION | MFE=1.16R | impr=70 | CE=2297.48 | CE_HOLDS | fuel=0.82 | c=2306.75 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 09:20 | 🧠 phase=ACCUMULATION | MFE=1.49R | impr=0 | CE=2297.48 | CE_HOLDS | fuel=0.78 | c=2310.9 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 09:25 | 🧠 phase=ACCUMULATION | MFE=1.49R | impr=34 | CE=2297.48 | CE_HOLDS | fuel=0.78 | c=2309.39 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 09:30 | 🧠 phase=ACCUMULATION | MFE=1.49R | impr=0 | CE=2304.22 | CE_HOLDS | fuel=0.78 | c=2310.76 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 09:35 | 🧠 phase=ACCUMULATION | MFE=1.49R | impr=0 | CE=2304.22 | CE_HOLDS | fuel=0.78 | c=2310.38 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 09:40 | 🧠 phase=ACCUMULATION | MFE=1.49R | impr=0 | CE=2304.22 | CE_HOLDS | fuel=0.78 | c=2307.7 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 09:45 | 🧠 phase=ACCUMULATION | MFE=1.49R | impr=0 | CE=2304.22 | CE_HOLDS | fuel=0.78 | c=2306.08 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 09:50 | 🧠 phase=ACCUMULATION | MFE=1.49R | impr=0 | CE=2304.22 | CE_HOLDS | fuel=0.78 | c=2307.19 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 09:55 | 🧠 phase=ACCUMULATION | MFE=1.68R | impr=0 | CE=2304.22 | CE_HOLDS | fuel=0.76 | c=2312.42 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 09:55 | 🎯 A:TP1 | c=2312.42 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 09:55 | 📣 PARTIAL_TAKEN→fortresses_active | c=2312.42 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 10:00 | 🧠 phase=ACCUMULATION | MFE=1.68R | impr=77 | CE=2304.22 | CE_WICK_REBALANCE | fuel=0.76 | c=2311.13 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 10:05 | 🧠 phase=ACCUMULATION | MFE=1.68R | impr=0 | CE=2304.22 | CE_WICK_REBALANCE | fuel=0.76 | c=2312.77 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 10:10 | 🧠 phase=ACCUMULATION | MFE=1.68R | impr=0 | CE=2304.22 | CE_WICK_REBALANCE | fuel=0.76 | c=2311.37 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 10:15 | 🧠 phase=ACCUMULATION | MFE=1.68R | impr=0 | CE=2304.22 | CE_HOLDS | fuel=0.76 | c=2309.44 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 10:20 | 🧠 phase=ACCUMULATION | MFE=1.68R | impr=0 | CE=2304.22 | CE_HOLDS | fuel=0.76 | c=2307.1 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 10:25 | 🧠 phase=ACCUMULATION | MFE=1.68R | impr=0 | CE=2304.22 | CE_HOLDS | fuel=0.76 | c=2305.67 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 10:30 | 🧠 phase=ACCUMULATION | MFE=1.68R | impr=0 | CE=2304.22 | CE_WICK_REBALANCE | fuel=0.76 | c=2305.88 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 10:35 | 🧠 phase=ACCUMULATION | MFE=1.68R | impr=0 | CE=2304.22 | CE_WICK_REBALANCE | fuel=0.76 | c=2310.97 sl_B=2273.337347 sl_C=2273.337347 | | | |
| | 2023-12-31 10:40 | 🧠 phase=EXPANSION | MFE=1.76R | impr=100 | CE=2307.97 | CE_BODY_DEAD | fuel=0.75 | c=2313.15 sl_B=2307.6916 sl_C=2307.6916 | | | |
| | 2023-12-31 10:40 | 🔄 CE_BODY_BUT_HOLD (fortress synthesis) | c=2313.15 sl_B=2307.6916 sl_C=2307.6916 | | | |
| | 2023-12-31 10:40 | 🛡️ B:CE_SOFT→2307.69 | c=2313.15 sl_B=2307.6916 sl_C=2307.6916 | | | |
| | 2023-12-31 10:40 | 🛡️ C:CE_SOFT→2307.69 | c=2313.15 sl_B=2307.6916 sl_C=2307.6916 | | | |
| | 2023-12-31 10:45 | 🧠 phase=EXPANSION | MFE=1.76R | impr=16 | CE=2307.97 | CE_WICK_REBALANCE | fuel=0.75 | c=2313.89 sl_B=2307.6916 sl_C=2307.6916 | | | |
| | 2023-12-31 10:50 | 🧠 phase=EXPANSION | MFE=1.76R | impr=0 | CE=2307.97 | CE_WICK_REBALANCE | fuel=0.75 | c=2312.75 sl_B=2307.6916 sl_C=2307.6916 | | | |
| | 2023-12-31 10:55 | 🧠 phase=EXPANSION | MFE=1.76R | impr=0 | CE=2307.97 | CE_WICK_REBALANCE | fuel=0.75 | c=2312.13 sl_B=2307.6916 sl_C=2307.6916 | | | |
| | 2023-12-31 11:00 | 🧠 phase=EXPANSION | MFE=1.80R | impr=0 | CE=2310.32 | CE_HOLDS | fuel=0.74 | c=2315.24 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:00 | 🛡️ B:CE_SOFT→2310.05 | c=2315.24 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:00 | 🛡️ C:CE_SOFT→2310.05 | c=2315.24 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:05 | 🧠 phase=EXPANSION | MFE=1.89R | impr=15 | CE=2310.32 | CE_HOLDS | fuel=0.73 | c=2311.34 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:05 | 🧠 A:Trail | c=2311.34 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:10 | 🧠 phase=EXPANSION | MFE=1.89R | impr=0 | CE=2310.32 | CE_HOLDS | fuel=0.73 | c=2316.31 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:15 | 🧠 phase=EXPANSION | MFE=1.89R | impr=68 | CE=2310.32 | CE_HOLDS | fuel=0.73 | c=2315.84 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:20 | 🧠 phase=EXPANSION | MFE=1.89R | impr=0 | CE=2310.32 | CE_HOLDS | fuel=0.73 | c=2314.87 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:25 | 🧠 phase=EXPANSION | MFE=1.89R | impr=0 | CE=2310.32 | CE_HOLDS | fuel=0.73 | c=2314.93 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:30 | 🧠 phase=EXPANSION | MFE=1.89R | impr=0 | CE=2310.32 | CE_HOLDS | fuel=0.73 | c=2314.91 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:35 | 🧠 phase=EXPANSION | MFE=1.89R | impr=0 | CE=2310.32 | CE_HOLDS | fuel=0.73 | c=2314.42 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:40 | 🧠 phase=EXPANSION | MFE=1.89R | impr=0 | CE=2310.32 | CE_HOLDS | fuel=0.73 | c=2313.61 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:45 | 🧠 phase=EXPANSION | MFE=1.89R | impr=0 | CE=2310.32 | CE_HOLDS | fuel=0.73 | c=2312.15 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:50 | 🧠 phase=EXPANSION | MFE=1.89R | impr=0 | CE=2310.32 | CE_HOLDS | fuel=0.73 | c=2311.44 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:55 | 🧠 phase=EXPANSION | MFE=1.89R | impr=0 | CE=2310.32 | CE_HOLDS | fuel=0.73 | c=2310.66 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:55 | 🛡️ B:FORTRESS_HIT | c=2310.66 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |
| | 2023-12-31 11:55 | 🛡️ C:FORTRESS_HIT | c=2310.66 sl_B=2310.0465999999997 sl_C=2310.0465999999997 | | | |


## كل قرارات الفحص — شو شاف وقرر HOLD ولماذا (Top 100)

| وقت | Session | سعر | قرار | السبب | Bias | Conf | Sweep Q | Disp Conv | FVG CE | Filter |
|------|---------|------|-------|-------|------|------|---------|-----------|--------|--------|
| 2023-12-01 00:00 | ASIAN_RANGE | 2050.18 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 01:00 | ASIAN_RANGE | 2046.97 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 02:00 | ASIAN_RANGE | 2084.44 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 03:00 | ASIAN_RANGE | 2085.83 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 04:00 | ASIAN_RANGE | 2093.59 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 05:00 | ASIAN_MANIPULATION | 2093.18 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 06:00 | ASIAN_MANIPULATION | 2089.44 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 07:00 | LONDON_KILLZONE | 2092.76 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-01 08:00 | LONDON_KILLZONE | 2094.97 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-01 09:00 | LONDON_KILLZONE | 2095.99 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-01 10:00 | PRE_NY | 2104.77 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 11:00 | PRE_NY | 2090.59 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 12:00 | PRE_NY | 2093.78 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 13:00 | PRE_NY | 2088.31 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 14:00 | NY_AM_KILLZONE | 2080.54 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-01 15:00 | NY_AM_KILLZONE | 2080.41 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-01 16:00 | NY_LUNCH_DEAD_ZONE | 2081.05 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 17:00 | NY_LUNCH_DEAD_ZONE | 2103.93 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 18:00 | NY_LUNCH_DEAD_ZONE | 2095.52 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 19:00 | NY_PM_KILLZONE | 2088.9 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-01 20:00 | NY_PM_KILLZONE | 2088.34 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-01 21:00 | AFTER_HOURS | 2092.46 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 22:00 | AFTER_HOURS | 2088.96 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-01 23:00 | ASIAN_RANGE | 2085.07 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 00:00 | ASIAN_RANGE | 2087.33 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 01:00 | ASIAN_RANGE | 2090.42 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 02:00 | ASIAN_RANGE | 2093.82 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 03:00 | ASIAN_RANGE | 2090.74 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 04:00 | ASIAN_RANGE | 2091.51 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 05:00 | ASIAN_MANIPULATION | 2091.76 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 06:00 | ASIAN_MANIPULATION | 2094.7 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 07:00 | LONDON_KILLZONE | 2104.82 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-02 08:00 | LONDON_KILLZONE | 2099.01 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-02 09:00 | LONDON_KILLZONE | 2099.29 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-02 10:00 | PRE_NY | 2104.39 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 11:00 | PRE_NY | 2100.42 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 12:00 | PRE_NY | 2098.29 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 13:00 | PRE_NY | 2104.95 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 14:00 | NY_AM_KILLZONE | 2105.45 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-02 15:00 | NY_AM_KILLZONE | 2095.37 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-02 16:00 | NY_LUNCH_DEAD_ZONE | 2101.64 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 17:00 | NY_LUNCH_DEAD_ZONE | 2099.5 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 18:00 | NY_LUNCH_DEAD_ZONE | 2119.6 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 19:00 | NY_PM_KILLZONE | 2155.27 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-02 20:00 | NY_PM_KILLZONE | 2157.94 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-02 21:00 | AFTER_HOURS | 2160.25 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 22:00 | AFTER_HOURS | 2165.92 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-02 23:00 | ASIAN_RANGE | 2161.29 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 00:00 | ASIAN_RANGE | 2164.53 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 01:00 | ASIAN_RANGE | 2165.09 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 02:00 | ASIAN_RANGE | 2171.14 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 03:00 | ASIAN_RANGE | 2162.9 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 04:00 | ASIAN_RANGE | 2162.2 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 05:00 | ASIAN_MANIPULATION | 2155.92 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 06:00 | ASIAN_MANIPULATION | 2159.4 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 07:00 | LONDON_KILLZONE | 2158.19 | HOLD | TRIGGER not ready: NO_DISPLACEMENT_WITH_FVG — no institutional displacement+FVG | BULLISH | 90 | 97.1 | None | None | None |
| 2023-12-03 08:00 | LONDON_KILLZONE | 2163.6 | HOLD | PLAN invalid: risk 0.5-8 ATR filter or TP1 RR<1.5 — risk not logical | BULLISH | 90 | 91.7 | 91.5 | 2160.715 | None |
| 2023-12-03 09:00 | LONDON_KILLZONE | 2162.36 | HOLD | PLAN invalid: risk 0.5-8 ATR filter or TP1 RR<1.5 — risk not logical | BULLISH | 90 | 86.4 | 91.5 | 2160.715 | None |
| 2023-12-03 10:00 | PRE_NY | 2164.44 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 11:00 | PRE_NY | 2166.1 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 12:00 | PRE_NY | 2154.99 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 13:00 | PRE_NY | 2154.23 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 14:00 | NY_AM_KILLZONE | 2160.4 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-03 15:00 | NY_AM_KILLZONE | 2156.18 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-03 16:00 | NY_LUNCH_DEAD_ZONE | 2159.13 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 17:00 | NY_LUNCH_DEAD_ZONE | 2157.96 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 18:00 | NY_LUNCH_DEAD_ZONE | 2154.51 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 19:00 | NY_PM_KILLZONE | 2161.33 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-03 20:00 | NY_PM_KILLZONE | 2170.32 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-03 21:00 | AFTER_HOURS | 2170.48 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 22:00 | AFTER_HOURS | 2186.78 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-03 23:00 | ASIAN_RANGE | 2206.81 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 00:00 | ASIAN_RANGE | 2192.79 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 01:00 | ASIAN_RANGE | 2208.29 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 02:00 | ASIAN_RANGE | 2212.86 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 03:00 | ASIAN_RANGE | 2213.94 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 04:00 | ASIAN_RANGE | 2215.38 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 05:00 | ASIAN_MANIPULATION | 2223.93 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 06:00 | ASIAN_MANIPULATION | 2245.19 | HOLD | Session ASIAN_MANIPULATION not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 07:00 | LONDON_KILLZONE | 2253.16 | HOLD | PLAN invalid: risk 0.5-8 ATR filter or TP1 RR<1.5 — risk not logical | BULLISH | 60 | 51.2 | 99.9 | 2214.14 | None |
| 2023-12-04 08:00 | LONDON_KILLZONE | 2249.53 | HOLD | PLAN invalid: risk 0.5-8 ATR filter or TP1 RR<1.5 — risk not logical | BULLISH | 80 | 45.9 | 99.9 | 2214.14 | None |
| 2023-12-04 09:00 | LONDON_KILLZONE | 2256.27 | HOLD | TRIGGER not ready: NO_DISPLACEMENT_WITH_FVG — no institutional displacement+FVG | BULLISH | 80 | 84.0 | None | None | None |
| 2023-12-04 10:00 | PRE_NY | 2250.03 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 11:00 | PRE_NY | 2267.55 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 12:00 | PRE_NY | 2236.24 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 13:00 | PRE_NY | 2250.85 | HOLD | Session PRE_NY not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 14:00 | NY_AM_KILLZONE | 2236.11 | HOLD | TRIGGER not ready: FVG_ALREADY_FILLED — no institutional displacement+FVG | BULLISH | 60 | 91.2 | None | None | None |
| 2023-12-04 15:00 | NY_AM_KILLZONE | 2225.0 | HOLD | TRIGGER not ready: NO_DISPLACEMENT_WITH_FVG — no institutional displacement+FVG | BULLISH | 60 | 86.2 | None | None | None |
| 2023-12-04 16:00 | NY_LUNCH_DEAD_ZONE | 2215.03 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 17:00 | NY_LUNCH_DEAD_ZONE | 2225.05 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 18:00 | NY_LUNCH_DEAD_ZONE | 2217.98 | HOLD | Session NY_LUNCH_DEAD_ZONE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 19:00 | NY_PM_KILLZONE | 2225.6 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-04 20:00 | NY_PM_KILLZONE | 2230.9 | HOLD | BIAS weak: MIXED conf 30<50 — no clear HH/HL | MIXED | 30 | None | None | None | None |
| 2023-12-04 21:00 | AFTER_HOURS | 2228.59 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 22:00 | AFTER_HOURS | 2231.8 | HOLD | Session AFTER_HOURS not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-04 23:00 | ASIAN_RANGE | 2230.01 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-05 00:00 | ASIAN_RANGE | 2238.41 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-05 01:00 | ASIAN_RANGE | 2249.37 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-05 02:00 | ASIAN_RANGE | 2236.89 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |
| 2023-12-05 03:00 | ASIAN_RANGE | 2230.0 | HOLD | Session ASIAN_RANGE not executable — ICT time filter | None | None | None | None | None | None |

---

