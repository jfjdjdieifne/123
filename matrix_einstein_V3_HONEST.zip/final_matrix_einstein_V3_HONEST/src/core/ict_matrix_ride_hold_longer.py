# Quick patch to hold B longer using 4H ITL after 3R
import sys
sys.path.insert(0, 'src/core')
# We'll monkey patch the file in place for testing
with open('src/core/ict_matrix_ride.py','r') as f:
    txt=f.read()

# Replace B intact check to use 4H when MFE>=3R
# Find the block for B when scale_shift_active
old="""
                if view.scale_shift_active:
                    intact, reason = mind.reader_1h.is_structure_intact(is_long, c)
                    if not intact:
                        # 1H opposing energy?
                        if c1h:
                            bp_1h = abs(c1h['c']-c1h['o'])/max(1e-12, c1h['h']-c1h['l'])
                            is_opp = (is_long and c1h['c']<c1h['o'] and bp_1h>=0.5) or ((not is_long) and c1h['c']>c1h['o'] and bp_1h>=0.5)
                            if is_opp:
                                _close_leg(pb, state, "risk_pct_b", c, is_long, "B_1H_STRUCT_SCALE", risk)
                                events.append(f"🧱 B:1H {reason[:30]} SCALE_SHIFT")
                            else:
                                events.append("🔄 B:1H STL_HOLD SCALE_SHIFT")
"""

new="""
                if view.scale_shift_active:
                    # Hold longer: after 3R, B uses 4H ITL (more room) not 1H, to leave less money on table for TP2 runner
                    # Source: ICT - manage on 4-hour for swing, Keep perspective 5-day horizon
                    use_reader = mind.reader_4h if view.mfe_r >= 3.0 else mind.reader_1h
                    intact, reason = use_reader.is_structure_intact(is_long, c)
                    if not intact:
                        # 1H/4H opposing energy?
                        check_candle = c4h if view.mfe_r >= 3.0 else c1h
                        if check_candle:
                            bp = abs(check_candle['c']-check_candle['o'])/max(1e-12, check_candle['h']-check_candle['l'])
                            is_opp = (is_long and check_candle['c']<check_candle['o'] and bp>=0.6) or ((not is_long) and check_candle['c']>check_candle['o'] and bp>=0.6)
                            if is_opp:
                                _close_leg(pb, state, "risk_pct_b", c, is_long, f"B_{'4H' if view.mfe_r>=3.0 else '1H'}_STRUCT_SCALE", risk)
                                events.append(f"🧱 B:{'4H' if view.mfe_r>=3.0 else '1H'} {reason[:30]} SCALE_SHIFT_HOLD_LONGER")
                            else:
                                events.append(f"🔄 B:{'4H' if view.mfe_r>=3.0 else '1H'} STL_HOLD SCALE_SHIFT_HOLD_LONGER")
"""

if old in txt:
    print("Found old, replacing")
    txt=txt.replace(old,new)
    with open('src/core/ict_matrix_ride.py','w') as f:
        f.write(txt)
    print("Patched to hold B longer using 4H after 3R")
else:
    print("Old pattern not found, trying manual edit")
