# Backup and patch for large RR capture
import os
with open('src/core/ict_matrix_ride.py','r') as f:
    content=f.read()

# Patch 1: Increase buffer for large MFE - dynamic buffer
# Find buffer calculation for ITL_HARD
old1 = "                if hard is not None:\n                    if is_long:\n                        if hard > p[\"sl\"] and hard < view.price_c:\n                            if soft is None or hard >= soft or hard > entry:\n                                new_sl = hard - atr * 0.05\n                                reason = f\"ITL_HARD→{new_sl:.2f}\""
new1 = """                if hard is not None:
                    # Large RR wisdom: more room for big winners - dynamic buffer grows with MFE
                    # Source: ICT - trailing below previous bullish OB's low - but for large RR, give more room
                    # Thinking: If MFE is 13R, a tight 0.05 ATR buffer will be hit by noise - need 0.5 ATR or more
                    dynamic_buffer = atr * (0.05 + min(1.0, view.mfe_r * 0.15))  # 0.05 at 0R, 0.5 at 3R, 1.05 at 10R
                    if is_long:
                        if hard > p["sl"] and hard < view.price_c:
                            if soft is None or hard >= soft or hard > entry:
                                new_sl = hard - dynamic_buffer
                                reason = f\"ITL_HARD→{new_sl:.2f} buf={dynamic_buffer:.2f} MFE={view.mfe_r:.1f}R\""""

if old1 in content:
    content=content.replace(old1,new1)
    print("Patched buffer 1")

old2 = "                    else:\n                        if hard < p[\"sl\"] and hard > view.price_c:\n                            if soft is None or hard <= soft or hard < entry:\n                                new_sl = hard + atr * 0.05\n                                reason = f\"ITL_HARD→{new_sl:.2f}\""
new2 = """                    else:
                        dynamic_buffer = atr * (0.05 + min(1.0, view.mfe_r * 0.15))
                        if hard < p["sl"] and hard > view.price_c:
                            if soft is None or hard <= soft or hard < entry:
                                new_sl = hard + dynamic_buffer
                                reason = f\"ITL_HARD→{new_sl:.2f} buf={dynamic_buffer:.2f} MFE={view.mfe_r:.1f}R\""""

if old2 in content:
    content=content.replace(old2,new2)
    print("Patched buffer 2")

# Patch 2: For large MFE >=3R, extend TP2 to next Fib even if not near DOL - capture big RR
# Find DOL velocity block
old3 = "        # DOL velocity synthesis\n        dol_verdict = \"NONE\"\n        ext_b = ext_c = None\n        if self.phase == PHASE_EXPAN and near_b and dol_b is not None:"
new3 = """        # DOL velocity synthesis + Large RR capture
        # For big RR (16, 30), price may go far beyond DOL - need Fib extensions even if not near DOL yet
        # Source: ICT Fib extensions -0.5/-1.0/-1.5/-2.0 at DOL expansion - but also for continuation beyond DOL
        dol_verdict = "NONE"
        ext_b = ext_c = None
        # Large RR wisdom: If MFE>=3R and not near DOL, still project next Fib as target - don't wait for DOL
        # This captures 16R and 30R moves
        large_rr_no_dol = (self.phase == PHASE_EXPAN and dol_b is None and mfe >= 3.0 and day_ctx and day_ctx.get("setup_start") is not None)
        if large_rr_no_dol:
            ss, se = day_ctx.get("setup_start"), day_ctx.get("setup_end")
            if ss is not None and se is not None:
                # Find next fib beyond current wave_best
                for i, lvl in enumerate(ICT_FIB_EXT):
                    if i < self.expansion_tier:
                        continue
                    proj = ict_fib_extension(ss, se, lvl)
                    if is_long and proj > self.wave_best:
                        ext_b = proj
                        self.expansion_tier = i+1
                        dol_verdict = "EXTEND_LARGE_RR"
                        break
                    if (not is_long) and proj < self.wave_best:
                        ext_b = proj
                        self.expansion_tier = i+1
                        dol_verdict = "EXTEND_LARGE_RR"
                        break
        if self.phase == PHASE_EXPAN and near_b and dol_b is not None:"""

if old3 in content:
    content=content.replace(old3,new3)
    print("Patched DOL for large RR")
else:
    print("Old3 not found")

with open('src/core/ict_matrix_ride.py','w') as f:
    f.write(content)

print("Patched file for large RR capture")
