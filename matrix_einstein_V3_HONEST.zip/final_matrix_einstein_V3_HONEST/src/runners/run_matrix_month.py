#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Matrix Einstein — Test any common month — BTC & ETH same month/year
Usage: python3 run_matrix_month.py 2023-11
"""
import csv, datetime, sys, os
from collections import defaultdict
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'core'))

from ict_sessions import classify_session
from ict_layered_brain import read_bias, read_narrative, read_trigger, build_plan
from ict_math_engine import detect_ict_three_candle_swings
from ict_matrix_ride import manage_matrix_triple, entry_accumulation_filters, get_ny_day_key

POSSIBLE_BTC = [
    "/home/user/raw_data/BTCUSDT_5m_2017-09-01_to_2025-09-23.csv",
    "data/BTCUSDT_5m_2017-09-01_to_2025-09-23.csv",
]
POSSIBLE_ETH = [
    "/tmp/eth_3_2/ETHUSDT_5m.csv",
    "data/ETHUSDT_5m.csv",
]
def pick_path(cands):
    for p in cands:
        if os.path.exists(p):
            return p
    return cands[0]

BTC_PATH = pick_path(POSSIBLE_BTC)
ETH_PATH = pick_path(POSSIBLE_ETH)
RISK=0.02

def load_btc(month):
    # month like 2023-11
    year_month = month[:7]
    prev_month = ""
    # compute prev month for warmup (need Nov + Oct for warmup)
    # for simplicity load Oct+Nov if Nov, etc.
    # We'll load 2 months: previous and target
    y,m = map(int, year_month.split('-'))
    # prev month
    if m==1:
        py=y-1; pm=12
    else:
        py=y; pm=m-1
    prev = f"{py:04d}-{pm:02d}"
    rows=[]
    with open(BTC_PATH) as f:
        r=csv.DictReader(f)
        for row in r:
            dt=row['datetime'][:7]
            if dt==year_month or dt==prev:
                dt_str=row['datetime'][:16]
                dt_obj=datetime.datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
                rows.append({'ts':int(dt_obj.replace(tzinfo=datetime.timezone.utc).timestamp()*1000),'dt':dt_str,'o':float(row['open']),'h':float(row['high']),'l':float(row['low']),'c':float(row['close']),'v':float(row['volume'])})
    return rows

def load_eth(month):
    year_month = month[:7]
    y,m = map(int, year_month.split('-'))
    if m==1:
        py=y-1; pm=12
    else:
        py=y; pm=m-1
    prev = f"{py:04d}-{pm:02d}"
    rows=[]
    with open(ETH_PATH) as f:
        r=csv.DictReader(f)
        for row in r:
            dt_str=row.get('datetime')
            if not dt_str:
                vals=list(row.values())
                dt_str=vals[1]
            if not dt_str:
                continue
            if not (dt_str.startswith(year_month) or dt_str.startswith(prev)):
                continue
            dt_str=dt_str[:16]
            try:
                dt_obj=datetime.datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
            except:
                continue
            rows.append({'ts':int(dt_obj.replace(tzinfo=datetime.timezone.utc).timestamp()*1000),'dt':dt_str,'o':float(row['open']),'h':float(row['high']),'l':float(row['low']),'c':float(row['close']),'v':float(row['volume'])})
    return rows

def slice_data(rows,end_idx,lookback):
    s=max(0,end_idx-lookback+1)
    ch=rows[s:end_idx+1]
    return {'timestamps':[r['ts'] for r in ch],'opens':[r['o'] for r in ch],'highs':[r['h'] for r in ch],'lows':[r['l'] for r in ch],'closes':[r['c'] for r in ch],'volumes':[r['v'] for r in ch]}

def aggregate(data,tf):
    n=len(data['closes'])
    ratio=tf//5
    if n<ratio:
        return None
    out={'timestamps':[],'opens':[],'highs':[],'lows':[],'closes':[],'volumes':[]}
    for i in range(n//ratio):
        a,b=i*ratio,(i+1)*ratio
        out['timestamps'].append(data['timestamps'][a])
        out['opens'].append(data['opens'][a])
        out['highs'].append(max(data['highs'][a:b]))
        out['lows'].append(min(data['lows'][a:b]))
        out['closes'].append(data['closes'][b-1])
        out['volumes'].append(sum(data['volumes'][a:b]))
    return out

def daily_ctx(rows, idx):
    by=defaultdict(lambda:{"h":-1e18,"l":1e18,"o":None})
    for r in rows[:idx+1]:
        k=get_ny_day_key(r['ts'])
        if by[k]['o'] is None:
            by[k]['o']=r['o']
        by[k]['h']=max(by[k]['h'],r['h'])
        by[k]['l']=min(by[k]['l'],r['l'])
    cur=get_ny_day_key(rows[idx]['ts'])
    completed=sorted(d for d in by if d<cur)
    ranges=[by[d]['h']-by[d]['l'] for d in completed[-10:]]
    return ranges, by[cur]['o'], by[cur]['h'], by[cur]['l'], cur

def midnight_open(rows, idx):
    cur=get_ny_day_key(rows[idx]['ts'])
    for i in range(idx,-1,-1):
        if get_ny_day_key(rows[i]['ts'])!=cur:
            return rows[i+1]['o'] if i+1<=idx else rows[idx]['o']
    return rows[0]['o']

def run_for_month(symbol, rows, month):
    start_idx=next((i for i,r in enumerate(rows) if r['dt'].startswith(month)), None)
    if start_idx is None:
        print(f"No data for {month}")
        return None
    EXEC={"LONDON_KILLZONE","NY_AM_KILLZONE","NY_PM_KILLZONE"}
    balance=100.0
    trades=[]
    active=None
    entered=set()
    c1=c4=0
    rejected=0
    scans=0
    for idx in range(start_idx, len(rows)):
        row=rows[idx]
        if not row['dt'].startswith(month):
            break
        c1+=1; c4+=1
        if active:
            c5={'o':row['o'],'h':row['h'],'l':row['l'],'c':row['c']}
            c1h=c4h=None
            if c1>=12 and idx>=12:
                ch=rows[idx-11:idx+1]
                c1h={'o':ch[0]['o'],'h':max(x['h'] for x in ch),'l':min(x['l'] for x in ch),'c':row['c']}
                c1=0
            if c4>=48 and idx>=48:
                ch=rows[idx-47:idx+1]
                c4h={'o':ch[0]['o'],'h':max(x['h'] for x in ch),'l':min(x['l'] for x in ch),'c':row['c']}
                c4=0
            hist,d_o,d_h,d_l,dk=daily_ctx(rows,idx)
            ctx={"hist_ranges":hist,"day_open":d_o,"day_high":d_h,"day_low":d_l,"day_key":dk,"setup_start":active.get("setup_start"),"setup_end":active.get("setup_end")}
            is_short=active['is_short']
            entry=active['pos_a']['entry']
            if is_short:
                fav=entry-row['l']
                adv=row['h']-entry
            else:
                fav=row['h']-entry
                adv=entry-row['l']
            if active['risk']>0:
                active['mfe_r']=max(active.get('mfe_r',0), fav/active['risk'])
                active['mae_r']=max(active.get('mae_r',0), adv/active['risk'])
            events, closed = manage_matrix_triple(c5,c1h,c4h,active,day_ctx=ctx)
            if events:
                for e in events[-3:]:
                    active.setdefault("events", []).append(f"{row['dt']} {e}")
            if closed:
                pnl=active.get('pnl_pct') or 0
                usd=balance*pnl/100
                balance+=usd
                active['exit_time']=row['dt']
                active['pnl_pct']=pnl
                active['pnl_dollar']=usd
                active['balance_after']=balance
                trades.append(active)
                active=None
            continue
        if idx%12!=0:
            continue
        sess=classify_session(row['ts'])
        if sess['session'] not in EXEC:
            continue
        scans+=1
        full=slice_data(rows, idx, 8000)
        d5=slice_data(rows, idx, 250)
        d15=aggregate(full,15)
        d4h=aggregate(full,240)
        d1d=aggregate(full,1440)
        if not d1d or len(d1d['closes'])<10 or not d15:
            continue
        bias=read_bias(d1d,d4h)
        if bias['direction'] not in ('BULLISH','BEARISH') or bias['confidence']<50:
            continue
        narr=read_narrative(d15,bias['direction'])
        sweep_obj = narr.get('sweep') or {}
        if narr['state']!='SWEEP_FOUND' or sweep_obj.get('quality',0)<25:
            continue
        trig=read_trigger(d5,narr,bias['direction'])
        if not trig['ready']:
            continue
        plan=build_plan(d5,d1d,trig,narr,bias)
        if not plan:
            continue
        fk=(round(trig['fvg']['top'],2), round(trig['fvg']['bottom'],2))
        if fk in entered:
            continue
        is_long=bias['direction']=='BULLISH'
        mid=midnight_open(rows, idx)
        disp_score=float(trig['displacement']['conviction'])
        dealing_15m=narr.get('dealing_range')
        ok, reason = entry_accumulation_filters(is_long, plan['entry'], bias, mid, displacement_score=disp_score, dealing_15m=dealing_15m, last_ob_held=True, current_price=plan['entry'])
        if not ok:
            rejected+=1
            continue
        entered.add(fk)
        sw=detect_ict_three_candle_swings(d1d)
        targs=sw['swing_highs'] if is_long else sw['swing_lows']
        tp3=None
        for s in targs:
            if (is_long and s['price']>plan['entry']+plan['risk']*5) or (not is_long and s['price']<plan['entry']-plan['risk']*5):
                tp3=s['price']; break
        ss,se = (min(narr['sweep']['wick_extreme'], plan['sl']), max(trig['fvg']['top'], plan['entry'])) if is_long else (max(narr['sweep']['wick_extreme'], plan['sl']), min(trig['fvg']['bottom'], plan['entry']))
        active={
            'entry_time':row['dt'],'session':sess['session'],'ny_time':sess['ny_time'],'signal_price':row['c'],
            'bias':bias['direction'],'bias_conf':bias['confidence'],'bias_reason':bias['reason'],'bias_zone':(bias.get('dealing_range') or {}).get('zone'),
            'sweep_side':narr['sweep']['side'],'sweep_level':narr['sweep']['level'],'sweep_wick':narr['sweep']['wick_extreme'],'sweep_quality':narr['sweep']['quality'],
            'disp_dir':trig['displacement']['direction'],'disp_body_mult':float(trig['displacement']['body_multiple']),'disp_body_pct':float(trig['displacement']['body_pct']),'disp_conv':float(trig['displacement']['conviction']),
            'fvg_bottom':trig['fvg']['bottom'],'fvg_top':trig['fvg']['top'],'fvg_ce':trig['fvg']['ce'],
            'entry':plan['entry'],'sl':plan['sl'],'risk':plan['risk'],'atr':plan['atr'],'sl_atr':plan['sl_atr'],'tp1':plan['tp1'],'tp2':plan['tp2'],'tp3':tp3,
            'is_short': not is_long,'risk_pct_a':RISK*100*0.6,'risk_pct_b':RISK*100*0.3,'risk_pct_c':RISK*100*0.1,
            'pos_a':{'active':True,'entry':plan['entry'],'sl':plan['sl'],'tp1':plan['tp1']['price'],'tp1_hit':False,'pnl':0},
            'pos_b':{'active':True,'entry':plan['entry'],'sl':plan['sl'],'tp2_price':plan['tp2'].get('price') if isinstance(plan['tp2'], dict) else None,'be_set':False,'pnl':0},
            'pos_c':{'active':True,'entry':plan['entry'],'sl':plan['sl'],'tp3_price':tp3,'be_set':False,'pnl':0},
            'setup_start':ss,'setup_end':se,'mfe_r':0,'mae_r':0,'candle_count':0,
            'events':[f"{row['dt']} OPEN entry={plan['entry']} sl={plan['sl']} tp1={plan['tp1']['price']} filter={reason}"],
            'why':f"BIAS {bias['direction']} conf{bias['confidence']} zone={(bias.get('dealing_range') or {}).get('zone')} | SWEEP {narr['sweep']['side']} Q{narr['sweep']['quality']} lvl={narr['sweep']['level']} | DISP {trig['displacement']['body_multiple']}x {trig['displacement']['body_pct']}% conv={trig['displacement']['conviction']} | FVG {trig['fvg']['bottom']}-{trig['fvg']['top']} CE={trig['fvg']['ce']} | Filter {reason}",
        }
        c1=c4=0
    summary={'symbol':symbol,'month':month,'engine':'MATRIX V2.1','start':100,'end':round(balance,2),'return_pct':round((balance/100-1)*100,2),'trades':len(trades),'wins':len([t for t in trades if t.get('pnl_dollar',0)>0.01]),'losses':len([t for t in trades if t.get('pnl_dollar',0)<-0.01]),'scans':scans,'rejected_pd':rejected}
    return {'summary':summary,'trades':trades}

def main():
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('--month', default='2023-11', help='YYYY-MM e.g. 2023-11')
    args=ap.parse_args()
    month=args.month
    print(f"Testing month {month} — BTC & ETH same month/year — Matrix V2.1 — $100 / 2%")
    btc_rows=load_btc(month)
    eth_rows=load_eth(month)
    print(f"BTC rows {len(btc_rows)} {btc_rows[0]['dt'] if btc_rows else 'none'}->{btc_rows[-1]['dt'] if btc_rows else 'none'}")
    print(f"ETH rows {len(eth_rows)} {eth_rows[0]['dt'] if eth_rows else 'none'}->{eth_rows[-1]['dt'] if eth_rows else 'none'}")
    btc_res=run_for_month("BTCUSDT", btc_rows, month)
    eth_res=run_for_month("ETHUSDT", eth_rows, month)
    for res in [btc_res, eth_res]:
        if not res:
            continue
        s=res['summary']
        print(f"\n{s['symbol']} {s['month']} ${s['start']}->{s['end']} {s['return_pct']}% Trades={s['trades']} W={s['wins']} L={s['losses']} Scans={s['scans']} Rej={s['rejected_pd']}")
        for t in res['trades']:
            print(f"  {t['entry_time']}->{t.get('exit_time')} {t['bias']} entry={t['entry']} sl={t['sl']} Q={t['sweep_quality']} conv={t['disp_conv']} PnL {t.get('pnl_pct'):+.3f}% MFE {t.get('mfe_r',0):.2f}R A={t.get('pos_a',{}).get('exit_reason') or t.get('exit_reason_a')} B={t.get('pos_b',{}).get('exit_reason') or t.get('exit_reason_b')} C={t.get('pos_c',{}).get('exit_reason') or t.get('exit_reason_c')}")
    # save markdown detailed
    out_md=f"DETAILED_{month}_BTC_ETH_V2_1.md"
    with open(out_md,'w',encoding='utf-8') as f:
        f.write(f"# تقرير مفصل — {month} — BTC & ETH نفس الشهر نفس السنة — Matrix V2.1 — $100 / 2%\n\n")
        for res in [btc_res, eth_res]:
            if not res:
                continue
            s=res['summary']
            f.write(f"\n## {s['symbol']} — {s['month']} — ${s['start']}→${s['end']} ({s['return_pct']}%) — {s['trades']} صفقات W={s['wins']} L={s['losses']}\n\n")
            f.write("| # | دخول | خروج | Bias | Entry | SL | TP1 | TP2 | PnL% | $ | Bal | A | B | C | MFE | Session | Sweep Q | Disp Conv | Why |\n|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|\n")
            for i,t in enumerate(res['trades'],1):
                f.write(f"| {i} | {t['entry_time']} | {t.get('exit_time')} | {t['bias']} | {t['entry']:.2f} | {t['sl']:.2f} | {t['pos_a'].get('tp1',0):.2f} | {t['pos_b'].get('tp2_price') or 0:.2f} | {t.get('pnl_pct',0):+.3f} | {t.get('pnl_dollar',0):+.2f} | {t.get('balance_after',0):.2f} | {t.get('exit_reason_a') or t.get('pos_a',{}).get('exit_reason')} | {t.get('exit_reason_b') or t.get('pos_b',{}).get('exit_reason')} | {t.get('exit_reason_c') or t.get('pos_c',{}).get('exit_reason')} | {t.get('mfe_r',0):.2f}R | {t['session']} | {t['sweep_quality']} | {t['disp_conv']} | {t['why'][:120]} |\n")
            f.write("\n### تفصيل كل صفقة — شو شاف وشو عمل ليش\n\n")
            for i,t in enumerate(res['trades'],1):
                f.write(f"\n#### #{i} {t['bias']} {t['entry_time']}→{t.get('exit_time')} PnL {t.get('pnl_pct'):+.3f}% MFE {t.get('mfe_r',0):.2f}R\n")
                f.write(f"- **Layer1 BIAS:** {t['bias']} conf {t['bias_conf']} zone {t['bias_zone']} reason {t['bias_reason']}\n")
                f.write(f"- **Layer2 Sweep:** {t['sweep_side']} lvl {t['sweep_level']} wick {t['sweep_wick']} Q {t['sweep_quality']}\n")
                f.write(f"- **Layer3 Disp:** {t['disp_dir']} {t['disp_body_mult']}x {t['disp_body_pct']}% conv {t['disp_conv']} | FVG {t['fvg_bottom']}-{t['fvg_top']} CE {t['fvg_ce']}\n")
                f.write(f"- **Layer4 Plan:** entry {t['entry']} sl {t['sl']} risk {t['risk']} atr {t['atr']} sl_atr {t['sl_atr']} tp1 {t['tp1']} tp2 {t['tp2']} tp3 {t['tp3']}\n")
                f.write(f"- **Session:** {t['session']} {t['ny_time']} | Filter {t.get('filter_reason','')}\n")
                f.write(f"- **MFE/MAE:** MFE {t.get('mfe_r')}R MAE {t.get('mae_r')}R | Exit A={t.get('exit_reason_a')} B={t.get('exit_reason_b')} C={t.get('exit_reason_c')}\n")
                f.write(f"- **Events:** {'; '.join(t.get('events',[])[:15])}\n")
                f.write(f"- **Why:** {t.get('why')}\n")
    print(f"\nSaved {out_md}")

if __name__=="__main__":
    main()
