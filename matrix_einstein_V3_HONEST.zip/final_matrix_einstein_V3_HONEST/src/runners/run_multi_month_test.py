#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Test BTC across multiple months in 2023 to verify V2.2 robustness."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'core'))
import csv, datetime
from run_matrix_only_dec2023 import run, load_btc

# Load BTC
rows = load_btc()
print(f"BTC total: {len(rows)} rows from {rows[0]['dt']} to {rows[-1]['dt']}")
print()

total_return = 0
total_trades = 0
total_w = 0
total_l = 0
for month in ['2023-08', '2023-09', '2023-10', '2023-11', '2023-12']:
    import run_matrix_only_dec2023 as rmod
    rmod.MONTH = month
    res = rmod.run("BTCUSDT", rows)
    s = res['summary']
    print(f"{month}: ${s['start']}->{s['end']} {s['return_pct']:+.2f}% Trades={s['trades']} W={s['wins']} L={s['losses']}")
    for t in res['trades']:
        print(f"  {t['entry_time']} {t['bias']} PnL {t.get('pnl_pct'):+.3f}% MFE {t.get('mfe_r',0):.2f}R ExitA={t.get('exit_reason_a','?')}")
    total_return += s['return_pct']
    total_trades += s['trades']
    total_w += s['wins']
    total_l += s['losses']

print(f"\n=== 5-Month Summary BTC ===")
print(f"Total return: {total_return:+.2f}%")
print(f"Total trades: {total_trades} (W={total_w} L={total_l})")
print(f"WR: {total_w/max(1,total_trades)*100:.1f}%")
