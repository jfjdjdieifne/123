#!/usr/bin/env python3
"""BTC archive Mar+Jun 2025 @2% — Official discovery + Dual-State Matrix management."""
from __future__ import annotations
import csv, datetime, json, os, sys
from collections import defaultdict
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ict_sessions import classify_session
from ict_layered_brain import read_bias, read_narrative, read_trigger, build_plan
from ict_math_engine import detect_ict_three_candle_swings
from ict_matrix_ride import (
    manage_matrix_triple, entry_accumulation_filters, get_ny_day_key, compute_adr_5,
)

DATA = "/home/user/historical_data"  # archive files
RISK = 0.02


def load_csv(path):
    rows = []
    with open(path) as f:
        for row in csv.DictReader(f):
            dt = datetime.datetime.strptime(row["datetime"][:16], "%Y-%m-%d %H:%M")
            rows.append({
                "ts": int(dt.replace(tzinfo=datetime.timezone.utc).timestamp() * 1000),
                "dt": row["datetime"][:16],
                "o": float(row["open"]), "h": float(row["high"]),
                "l": float(row["low"]), "c": float(row["close"]), "v": float(row["volume"]),
            })
    return rows


def slice_data(rows, end_idx, lookback):
    s = max(0, end_idx - lookback + 1)
    ch = rows[s: end_idx + 1]
    return {k: [r[k if k != "timestamps" else "ts"] if k != "timestamps" else r["ts"] for r in ch]
            for k in ()}  # placeholder


def slc(rows, end_idx, lookback):
    s = max(0, end_idx - lookback + 1)
    ch = rows[s: end_idx + 1]
    return {
        "timestamps": [r["ts"] for r in ch], "opens": [r["o"] for r in ch],
        "highs": [r["h"] for r in ch], "lows": [r["l"] for r in ch],
        "closes": [r["c"] for r in ch], "volumes": [r["v"] for r in ch],
    }


def agg(d, tf):
    n, r = len(d["closes"]), tf // 5
    if n < r: return None
    out = {k: [] for k in d}
    for i in range(n // r):
        a, b = i * r, (i + 1) * r
        out["timestamps"].append(d["timestamps"][a])
        out["opens"].append(d["opens"][a])
        out["highs"].append(max(d["highs"][a:b]))
        out["lows"].append(min(d["lows"][a:b]))
        out["closes"].append(d["closes"][b - 1])
        out["volumes"].append(sum(d["volumes"][a:b]))
    return out


def daily_ctx(rows, idx):
    by = defaultdict(lambda: {"h": -1e18, "l": 1e18, "o": None})
    for r in rows[: idx + 1]:
        k = get_ny_day_key(r["ts"])
        if by[k]["o"] is None: by[k]["o"] = r["o"]
        by[k]["h"] = max(by[k]["h"], r["h"]); by[k]["l"] = min(by[k]["l"], r["l"])
    cur = get_ny_day_key(rows[idx]["ts"])
    completed = sorted(d for d in by if d < cur)
    ranges = [by[d]["h"] - by[d]["l"] for d in completed[-10:]]
    return ranges, by[cur]["o"], by[cur]["h"], by[cur]["l"], cur


def midnight_open(rows, idx):
    cur = get_ny_day_key(rows[idx]["ts"])
    for i in range(idx, -1, -1):
        if get_ny_day_key(rows[i]["ts"]) != cur:
            return rows[i + 1]["o"] if i + 1 <= idx else rows[idx]["o"]
    return rows[0]["o"]


def run_month(path, month_prefix, label, bal0, use_matrix=True):
    rows = load_csv(path)
    start = next(i for i, r in enumerate(rows) if r["dt"].startswith(month_prefix))
    EXEC = {"LONDON_KILLZONE", "NY_AM_KILLZONE", "NY_PM_KILLZONE"}
    bal, trades, active, seen = bal0, [], None, set()
    c1 = c4 = 0
    rejected = 0

    for idx in range(start, len(rows)):
        # stop after month for June file ends at jun; for mar file continue to end of mar data only
        if not rows[idx]["dt"].startswith(month_prefix[:7]) and idx > start:
            # still in file warmup months after? for jan-mar file after mar ends
            if label == "MAR" and not rows[idx]["dt"].startswith("2025-03"):
                break
            if label == "JUN" and not rows[idx]["dt"].startswith("2025-06"):
                if rows[idx]["dt"][:7] > "2025-06":
                    break
        row = rows[idx]
        if label == "MAR" and not row["dt"].startswith("2025-03"):
            continue
        if label == "JUN" and not row["dt"].startswith("2025-06"):
            continue

        c1 += 1; c4 += 1
        if active is not None:
            c5 = {"o": row["o"], "h": row["h"], "l": row["l"], "c": row["c"]}
            c1h = c4h = None
            if c1 >= 12 and idx >= 12:
                ch = rows[idx - 11: idx + 1]
                c1h = {"o": ch[0]["o"], "h": max(x["h"] for x in ch), "l": min(x["l"] for x in ch), "c": row["c"]}
                c1 = 0
            if c4 >= 48 and idx >= 48:
                ch = rows[idx - 47: idx + 1]
                c4h = {"o": ch[0]["o"], "h": max(x["h"] for x in ch), "l": min(x["l"] for x in ch), "c": row["c"]}
                c4 = 0
            hist, d_o, d_h, d_l, dk = daily_ctx(rows, idx)
            ctx = {"hist_ranges": hist, "day_open": d_o, "day_high": d_h, "day_low": d_l, "day_key": dk,
                   "setup_start": active.get("setup_start"), "setup_end": active.get("setup_end")}
            if use_matrix:
                ev, done = manage_matrix_triple(c5, c1h, c4h, active, day_ctx=ctx)
            else:
                from ict_smart_runner import manage_triple_position
                ev, done = manage_triple_position(c5, c1h, c4h, active)
            if ev:
                active.setdefault("events", []).extend(f"{row['dt']}:{e}" for e in ev[-5:])
            if done:
                pnl = active.get("pnl_pct") or 0
                usd = bal * pnl / 100
                bal += usd
                trades.append({
                    "entry_time": active["entry_time"], "exit_time": row["dt"], "bias": active["bias"],
                    "entry": active["pos_a"]["entry"], "pnl_pct": pnl, "pnl_usd": usd, "bal": bal,
                    "ea": active.get("exit_reason_a") or active["pos_a"].get("exit_reason"),
                    "eb": active.get("exit_reason_b") or active["pos_b"].get("exit_reason"),
                    "ec": active.get("exit_reason_c") or active["pos_c"].get("exit_reason"),
                    "phase": active.get("market_phase"), "tier": active.get("mx_expansion_tier", 0),
                    "events": (active.get("events") or [])[-12:],
                })
                flag = "✅" if usd > 0 else "❌"
                print(f"  {flag} {active['entry_time']}→{row['dt']} {active['bias']} {pnl:+.2f}% ${usd:+.2f} bal=${bal:.2f} "
                      f"A={trades[-1]['ea']} B={trades[-1]['eb']} C={trades[-1]['ec']} phase={active.get('market_phase')}")
                active = None
            continue

        if idx % 12 != 0:
            continue
        sess = classify_session(row["ts"])
        if sess["session"] not in EXEC:
            continue
        full, d5 = slc(rows, idx, 12000), slc(rows, idx, 250)
        d15, d4h, d1d = agg(full, 15), agg(full, 240), agg(full, 1440)
        if not d1d or len(d1d["closes"]) < 10 or not d15:
            continue
        bias = read_bias(d1d, d4h)
        if bias["direction"] not in ("BULLISH", "BEARISH") or bias["confidence"] < 50:
            continue
        narr = read_narrative(d15, bias["direction"])
        if narr["state"] != "SWEEP_FOUND" or narr["sweep"]["quality"] < 25:
            continue
        trig = read_trigger(d5, narr, bias["direction"])
        if not trig["ready"]:
            continue
        plan = build_plan(d5, d1d, trig, narr, bias)
        if not plan:
            continue
        fk = (round(trig["fvg"]["top"], 2), round(trig["fvg"]["bottom"], 2))
        if fk in seen:
            continue
        is_long = bias["direction"] == "BULLISH"
        mid = midnight_open(rows, idx)
        ok, reason = entry_accumulation_filters(is_long, plan["entry"], bias, mid)
        if use_matrix and not ok:
            rejected += 1
            continue
        seen.add(fk)
        sw = detect_ict_three_candle_swings(d1d)
        targs = sw["swing_highs"] if is_long else sw["swing_lows"]
        tp3 = None
        for s in targs:
            if (is_long and s["price"] > plan["entry"] + plan["risk"] * 5) or (
                not is_long and s["price"] < plan["entry"] - plan["risk"] * 5
            ):
                tp3 = s["price"]; break
        if is_long:
            ss, se = min(narr["sweep"]["wick_extreme"], plan["sl"]), max(trig["fvg"]["top"], plan["entry"])
        else:
            ss, se = max(narr["sweep"]["wick_extreme"], plan["sl"]), min(trig["fvg"]["bottom"], plan["entry"])
        active = {
            "entry_time": row["dt"], "bias": bias["direction"], "is_short": not is_long,
            "atr": plan["atr"], "risk": plan["risk"], "market_phase": "ACCUMULATION",
            "risk_pct_a": RISK * 100 * 0.6, "risk_pct_b": RISK * 100 * 0.3, "risk_pct_c": RISK * 100 * 0.1,
            "pos_a": {"active": True, "entry": plan["entry"], "sl": plan["sl"], "tp1": plan["tp1"]["price"], "tp1_hit": False, "pnl": 0},
            "pos_b": {"active": True, "entry": plan["entry"], "sl": plan["sl"],
                      "tp2_price": plan["tp2"].get("price") if isinstance(plan["tp2"], dict) else None,
                      "be_set": False, "pnl": 0},
            "pos_c": {"active": True, "entry": plan["entry"], "sl": plan["sl"], "tp3_price": tp3, "be_set": False, "pnl": 0},
            "setup_start": ss, "setup_end": se, "candle_count": 0, "events": [],
        }
        c1 = c4 = 0

    if active:
        last = rows[-1]
        for k, rk in (("pos_a", "risk_pct_a"), ("pos_b", "risk_pct_b"), ("pos_c", "risk_pct_c")):
            p = active[k]
            if p.get("active"):
                p["active"] = False; p["exit_reason"] = "EOD"
                is_long = not active["is_short"]
                move = (last["c"] - p["entry"]) if is_long else (p["entry"] - last["c"])
                p["pnl"] = (move / active["risk"]) * active[rk] if active["risk"] else 0
        active["pnl_pct"] = sum(active[k].get("pnl") or 0 for k in ("pos_a", "pos_b", "pos_c"))
        usd = bal * active["pnl_pct"] / 100; bal += usd
        trades.append({"entry_time": active["entry_time"], "exit_time": last["dt"], "pnl_pct": active["pnl_pct"],
                       "pnl_usd": usd, "bal": bal, "bias": active["bias"], "ea": "EOD", "eb": "EOD", "ec": "EOD",
                       "phase": active.get("market_phase")})
    return trades, bal, rejected


def main():
    mar = os.path.join(DATA, "btc_jan_mar_2025.csv")
    jun = os.path.join(DATA, "btc_apr_jun_2025.csv")
    print("=" * 70)
    print("  BTC ARCHIVE Dual-State Matrix @ 2%")
    print("=" * 70)
    print("\n📅 March…")
    t1, b1, r1 = run_month(mar, "2025-03-01", "MAR", 100.0, use_matrix=True)
    print(f"  March end ${b1:.2f} trades={len(t1)} rejected={r1}")
    print("\n📅 June…")
    t2, b2, r2 = run_month(jun, "2025-06-01", "JUN", b1, use_matrix=True)
    print(f"  June end ${b2:.2f} trades={len(t2)} rejected={r2}")
    all_t = t1 + t2
    wins = [t for t in all_t if t.get("pnl_usd", 0) > 0]
    losses = [t for t in all_t if t.get("pnl_usd", 0) < 0]
    gw = sum(t["pnl_usd"] for t in wins) if wins else 0
    gl = abs(sum(t["pnl_usd"] for t in losses)) if losses else 0
    pf = gw / gl if gl else float("inf")
    print(f"\n{'='*70}")
    print(f"  MATRIX BTC: $100 → ${b2:.2f} ({(b2/100-1)*100:+.2f}%)")
    print(f"  n={len(all_t)} W={len(wins)} L={len(losses)} WR={len(wins)/len(all_t)*100 if all_t else 0:.0f}% PF={pf:.2f}")
    print(f"  BASELINE official triple @2%: $140.36")
    print(f"  Δ vs baseline: ${b2-140.36:+.2f}")
    print(f"{'='*70}")
    out = {"final": b2, "trades": all_t, "rejected_mar": r1, "rejected_jun": r2}
    os.makedirs("eth_may_results", exist_ok=True)
    with open("eth_may_results/btc_archive_matrix_2pct.json", "w") as f:
        json.dump(out, f, indent=2, default=str)


if __name__ == "__main__":
    main()
