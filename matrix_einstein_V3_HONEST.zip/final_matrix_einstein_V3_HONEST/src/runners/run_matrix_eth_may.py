#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ETHUSDT May 2025 — Official Triple + Matrix Ride @ 2% risk
Same discovery as clean official triple + ICT entry filters + manage_matrix_triple
"""
from __future__ import annotations

import csv
import datetime
import json
import os
import sys
from collections import defaultdict
from copy import deepcopy

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ict_sessions import classify_session, ts_to_ny
from ict_layered_brain import read_bias, read_narrative, read_trigger, build_plan
from ict_math_engine import detect_ict_three_candle_swings
from ict_matrix_ride import (
    manage_matrix_triple,
    entry_accumulation_filters,
    get_ny_day_key,
    compute_adr_5,
)

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "eth_may_results")
os.makedirs(OUT, exist_ok=True)
ETH_5M = "/home/user/ohlc_2025/ETHUSDT_5m_2025.csv"
RISK = 0.02
START = 100.0


def load_csv(path):
    rows = []
    with open(path) as f:
        for row in csv.DictReader(f):
            dt_s = row["datetime"][:16]
            dt = datetime.datetime.strptime(dt_s, "%Y-%m-%d %H:%M")
            rows.append({
                "ts": int(dt.replace(tzinfo=datetime.timezone.utc).timestamp() * 1000),
                "dt": dt_s,
                "o": float(row["open"]), "h": float(row["high"]),
                "l": float(row["low"]), "c": float(row["close"]),
                "v": float(row["volume"]),
            })
    return rows


def slice_data(rows, end_idx, lookback):
    s = max(0, end_idx - lookback + 1)
    chunk = rows[s: end_idx + 1]
    return {
        "timestamps": [r["ts"] for r in chunk],
        "opens": [r["o"] for r in chunk],
        "highs": [r["h"] for r in chunk],
        "lows": [r["l"] for r in chunk],
        "closes": [r["c"] for r in chunk],
        "volumes": [r["v"] for r in chunk],
    }


def aggregate(data, tf_m):
    n = len(data["closes"])
    ratio = tf_m // 5
    if n < ratio:
        return None
    out = {k: [] for k in ("timestamps", "opens", "highs", "lows", "closes", "volumes")}
    for i in range(n // ratio):
        a, b = i * ratio, (i + 1) * ratio
        out["timestamps"].append(data["timestamps"][a])
        out["opens"].append(data["opens"][a])
        out["highs"].append(max(data["highs"][a:b]))
        out["lows"].append(min(data["lows"][a:b]))
        out["closes"].append(data["closes"][b - 1])
        out["volumes"].append(sum(data["volumes"][a:b]))
    return out


def build_daily_ranges(rows, upto_idx):
    """Completed NY-day ranges before current bar (for ADR)."""
    by_day = defaultdict(lambda: {"h": -1e18, "l": 1e18, "o": None})
    for r in rows[: upto_idx + 1]:
        dk = get_ny_day_key(r["ts"])
        if by_day[dk]["o"] is None:
            by_day[dk]["o"] = r["o"]
        by_day[dk]["h"] = max(by_day[dk]["h"], r["h"])
        by_day[dk]["l"] = min(by_day[dk]["l"], r["l"])
    days = sorted(by_day.keys())
    # exclude current incomplete day
    if not days:
        return [], None, None, None, None
    cur = get_ny_day_key(rows[upto_idx]["ts"])
    completed = [d for d in days if d < cur]
    ranges = [by_day[d]["h"] - by_day[d]["l"] for d in completed[-10:]]
    cur_d = by_day[cur]
    return ranges, cur_d["o"], cur_d["h"], cur_d["l"], cur


def midnight_open_for_bar(rows, idx):
    """First 5m open of current NY day at or before idx."""
    cur = get_ny_day_key(rows[idx]["ts"])
    for i in range(idx, -1, -1):
        if get_ny_day_key(rows[i]["ts"]) != cur:
            # next bar is start of cur day
            if i + 1 <= idx:
                return rows[i + 1]["o"]
            return rows[idx]["o"]
    return rows[0]["o"]


def run():
    print("Loading ETH…")
    rows = load_csv(ETH_5M)
    may0 = next(i for i, r in enumerate(rows) if r["dt"].startswith("2025-05-01"))
    may1 = next(i for i, r in enumerate(rows) if r["dt"].startswith("2025-06-01"))
    print(f"May {rows[may0]['dt']}→{rows[may1-1]['dt']} risk=2% Matrix")

    EXEC = {"LONDON_KILLZONE", "NY_AM_KILLZONE", "NY_PM_KILLZONE"}
    bal = START
    trades = []
    active = None
    seen = set()
    c1 = c4 = 0
    rejected = []

    for idx in range(may0, may1):
        row = rows[idx]
        c1 += 1
        c4 += 1

        if active is not None:
            c5 = {"o": row["o"], "h": row["h"], "l": row["l"], "c": row["c"]}
            c1h = c4h = None
            if c1 >= 12 and idx >= 12:
                ch = rows[idx - 11: idx + 1]
                c1h = {"o": ch[0]["o"], "h": max(x["h"] for x in ch),
                       "l": min(x["l"] for x in ch), "c": row["c"]}
                c1 = 0
            if c4 >= 48 and idx >= 48:
                ch = rows[idx - 47: idx + 1]
                c4h = {"o": ch[0]["o"], "h": max(x["h"] for x in ch),
                       "l": min(x["l"] for x in ch), "c": row["c"]}
                c4 = 0

            # MFE track
            is_short = active["is_short"]
            entry = active["pos_a"]["entry"]
            risk = active["risk"]
            if is_short:
                fav = (entry - row["l"]) / risk if risk else 0
            else:
                fav = (row["h"] - entry) / risk if risk else 0
            active["mfe_r"] = max(active.get("mfe_r", 0), fav)

            hist_r, d_o, d_h, d_l, d_key = build_daily_ranges(rows, idx)
            day_ctx = {
                "day_key": d_key,
                "day_open": d_o,
                "day_high": d_h,
                "day_low": d_l,
                "hist_ranges": hist_r,
                "setup_start": active.get("setup_start"),
                "setup_end": active.get("setup_end"),
            }
            ev, done = manage_matrix_triple(c5, c1h, c4h, active, day_ctx=day_ctx)
            if ev:
                active.setdefault("events", []).extend(f"{row['dt']}:{e}" for e in ev)
            if done:
                pnl = active.get("pnl_pct", 0) or 0
                usd = bal * pnl / 100
                before = bal
                bal += usd
                t = {
                    "n": len(trades) + 1,
                    "entry_time": active["entry_time"],
                    "exit_time": row["dt"],
                    "bias": active["bias"],
                    "entry": active["pos_a"]["entry"],
                    "sl0": active["plan_sl"],
                    "tp1": active["pos_a"].get("tp1"),
                    "tp2": active["pos_b"].get("tp2_price"),
                    "tp3": active["pos_c"].get("tp3_price"),
                    "pnl_pct": pnl,
                    "pnl_usd": usd,
                    "bal_before": before,
                    "bal_after": bal,
                    "exit_a": active.get("exit_reason_a") or active["pos_a"].get("exit_reason"),
                    "exit_b": active.get("exit_reason_b") or active["pos_b"].get("exit_reason"),
                    "exit_c": active.get("exit_reason_c") or active["pos_c"].get("exit_reason"),
                    "pa_pnl": active["pos_a"].get("pnl"),
                    "pb_pnl": active["pos_b"].get("pnl"),
                    "pc_pnl": active["pos_c"].get("pnl"),
                    "mfe_r": active.get("mfe_r"),
                    "phase": active.get("market_phase"),
                    "expanded": active.get("mx_expansion_tier", 0) > 0,
                    "impression": (active.get("mx_last_impression") or {}).get("score"),
                    "why": active.get("why"),
                    "filter": active.get("entry_filter"),
                    "events": (active.get("events") or [])[-25:],
                    "session": active.get("session"),
                    "conf": active.get("bias_conf"),
                    "sweep_q": active.get("sweep_q"),
                    "conviction": active.get("conviction"),
                }
                trades.append(t)
                flag = "✅" if usd > 0 else "❌"
                print(
                    f"  {flag} #{t['n']:02d} {t['entry_time']}→{t['exit_time']} {t['bias']} "
                    f"| {pnl:+.3f}% (${usd:+.2f}) bal=${bal:.2f} | "
                    f"A={t['exit_a']} B={t['exit_b']} C={t['exit_c']}"
                    f"{' 🚀EXP' if t.get('phase')=='EXPANSION' else ''}{' 🚀EXT' if t['expanded'] else ''}"
                )
                active = None
            continue

        if idx % 12 != 0:
            continue
        sess = classify_session(row["ts"])
        if sess["session"] not in EXEC:
            continue

        full = slice_data(rows, idx, 12000)
        d5 = slice_data(rows, idx, 250)
        d15 = aggregate(full, 15)
        d4h = aggregate(full, 240)
        d1d = aggregate(full, 1440)
        if not d1d or len(d1d["closes"]) < 10 or not d15:
            continue

        bias = read_bias(d1d, d4h)
        if bias["direction"] not in ("BULLISH", "BEARISH") or bias["confidence"] < 50:
            continue
        narr = read_narrative(d15, bias["direction"])
        if narr["state"] != "SWEEP_FOUND" or narr["sweep"]["quality"] < 25:
            continue
        trig = read_trigger(d5, narr, bias["direction"])
        if not trig["ready"]:
            continue
        plan = build_plan(d5, d1d, trig, narr, bias)
        if not plan:
            continue
        fk = (round(trig["fvg"]["top"], 2), round(trig["fvg"]["bottom"], 2))
        if fk in seen:
            continue

        is_long = bias["direction"] == "BULLISH"
        mid_o = midnight_open_for_bar(rows, idx)
        ok, freason = entry_accumulation_filters(is_long, plan["entry"], bias, mid_o, hard_midnight=False)
        if not ok:
            rejected.append({"dt": row["dt"], "reason": freason, "entry": plan["entry"], "bias": bias["direction"]})
            continue

        seen.add(fk)
        # TP3
        sw = detect_ict_three_candle_swings(d1d)
        targs = sw["swing_highs"] if is_long else sw["swing_lows"]
        tp3 = None
        for s in targs:
            if (is_long and s["price"] > plan["entry"] + plan["risk"] * 5) or (
                not is_long and s["price"] < plan["entry"] - plan["risk"] * 5
            ):
                tp3 = s["price"]
                break

        # setup range for fib = sweep extreme → opposing swing of impulse
        setup_start = narr["sweep"]["wick_extreme"]
        setup_end = plan["entry"]  # refined later by displacement; use entry as proxy
        # better: use FVG extremes direction
        if is_long:
            setup_start = min(narr["sweep"]["wick_extreme"], plan["sl"])
            setup_end = max(trig["fvg"]["top"], plan["entry"])
        else:
            setup_start = max(narr["sweep"]["wick_extreme"], plan["sl"])
            setup_end = min(trig["fvg"]["bottom"], plan["entry"])

        active = {
            "entry_time": row["dt"],
            "bias": bias["direction"],
            "bias_conf": bias["confidence"],
            "session": sess["session"],
            "is_short": not is_long,
            "atr": plan["atr"],
            "risk": plan["risk"],
            "plan_sl": plan["sl"],
            "risk_pct_a": RISK * 100 * 0.6,
            "risk_pct_b": RISK * 100 * 0.3,
            "risk_pct_c": RISK * 100 * 0.1,
            "pos_a": {
                "active": True, "entry": plan["entry"], "sl": plan["sl"],
                "tp1": plan["tp1"]["price"], "tp1_hit": False, "pnl": 0,
            },
            "pos_b": {
                "active": True, "entry": plan["entry"], "sl": plan["sl"],
                "tp2_price": plan["tp2"].get("price") if isinstance(plan["tp2"], dict) else None,
                "be_set": False, "pnl": 0,
            },
            "pos_c": {
                "active": True, "entry": plan["entry"], "sl": plan["sl"],
                "tp3_price": tp3, "be_set": False, "pnl": 0,
            },
            "setup_start": setup_start,
            "setup_end": setup_end,
            "why": (
                f"BIAS {bias['direction']} conf={bias['confidence']} | "
                f"SWEEP {narr['sweep']['side']} q={narr['sweep']['quality']} | "
                f"FVG CE={plan['entry']:.2f} | {freason}"
            ),
            "entry_filter": freason,
            "sweep_q": narr["sweep"]["quality"],
            "conviction": plan["conviction"],
            "candle_count": 0,
            "mfe_r": 0,
            "events": [],
        }
        c1 = c4 = 0

    # EOM force
    if active:
        last = rows[may1 - 1]
        for k, rk in (("pos_a", "risk_pct_a"), ("pos_b", "risk_pct_b"), ("pos_c", "risk_pct_c")):
            p = active[k]
            if p.get("active"):
                p["active"] = False
                p["exit_reason"] = "EOM"
                is_long = not active["is_short"]
                move = (last["c"] - p["entry"]) if is_long else (p["entry"] - last["c"])
                p["pnl"] = (move / active["risk"]) * active[rk] if active["risk"] else 0
        active["pnl_pct"] = sum(active[k].get("pnl") or 0 for k in ("pos_a", "pos_b", "pos_c"))
        usd = bal * active["pnl_pct"] / 100
        bal += usd
        trades.append({
            "n": len(trades) + 1, "entry_time": active["entry_time"], "exit_time": last["dt"],
            "bias": active["bias"], "entry": active["pos_a"]["entry"], "sl0": active["plan_sl"],
            "pnl_pct": active["pnl_pct"], "pnl_usd": usd, "bal_after": bal,
            "exit_a": "EOM", "exit_b": "EOM", "exit_c": "EOM",
            "mfe_r": active.get("mfe_r"), "phase": active.get("market_phase"),
            "why": active.get("why"), "events": active.get("events", [])[-15:],
        })

    wins = [t for t in trades if t["pnl_usd"] > 0]
    losses = [t for t in trades if t["pnl_usd"] < 0]
    gw = sum(t["pnl_usd"] for t in wins) if wins else 0
    gl = abs(sum(t["pnl_usd"] for t in losses)) if losses else 0
    pf = gw / gl if gl > 0 else (float("inf") if gw else 0)

    print(f"\n{'='*70}")
    print(f"  MATRIX ETH MAY 2025 @2%")
    print(f"  Trades={len(trades)} W={len(wins)} L={len(losses)} WR={len(wins)/len(trades)*100 if trades else 0:.1f}% PF={pf:.2f}")
    print(f"  $100 → ${bal:.2f} ({(bal/100-1)*100:+.2f}%)")
    print(f"  Rejected by PD/Midnight filters: {len(rejected)}")
    for r in rejected[:12]:
        print(f"    skip {r['dt']} {r['bias']} {r['reason']} @ {r['entry']:.2f}")
    print(f"{'='*70}")

    # compare baseline if available
    base_path = os.path.join(OUT, "eth_may_2025_2pct_detailed.json")
    if os.path.exists(base_path):
        base = json.load(open(base_path))
        print(f"  BASELINE clean triple: $100→${base['summary']['end_balance']:.2f} "
              f"({base['summary']['return_pct']:+.2f}%) n={base['summary']['trades']}")
        print(f"  MATRIX:                $100→${bal:.2f} ({(bal/100-1)*100:+.2f}%) n={len(trades)}")
        print(f"  Δ = ${bal - base['summary']['end_balance']:+.2f}")

    out_json = os.path.join(OUT, "eth_may_matrix_2pct.json")
    with open(out_json, "w") as f:
        json.dump({
            "summary": {
                "end": bal, "ret": (bal / 100 - 1) * 100, "n": len(trades),
                "w": len(wins), "l": len(losses), "pf": pf, "rejected": len(rejected),
            },
            "trades": trades,
            "rejected": rejected,
        }, f, indent=2, default=str)

    # markdown
    md = os.path.join(OUT, "ETH_MAY_MATRIX_REPORT.md")
    with open(md, "w", encoding="utf-8") as f:
        f.write("# ETHUSDT May 2025 — Matrix Ride @ 2%\n\n")
        f.write("## Dual-State ICT Engine\n")
        f.write("**ACCUMULATION (entry only):** Midnight Open + Premium/Discount strict (ICT 2022 Judas/PD)\n\n")
        f.write("**EXPANSION (after Displacement score≥80):**\n")
        f.write("1. Kill Soft BE — no R-based BE\n")
        f.write("2. FVG CE Shield 15M (ICT Ep12 Consequent Encroachment)\n")
        f.write("3. DOL velocity → Fib -1.0/-1.5 expansion (ICT Fib)\n")
        f.write("4. ADR≥90% OR DOL expand → bar-by-bar only then\n")
        f.write("5. C holds on wick STL without true displacement (ICT MSS body)\n")
        f.write("6. Displacement score: Energy 2.5-3x body + Body≥75% + FVG≥20% body\n\n")
        f.write(f"## Scoreboard\n\n| | |\n|--|--|\n| Trades | {len(trades)} |\n| W/L | {len(wins)}/{len(losses)} |\n| PF | {pf:.2f} |\n| **Balance** | **$100→${bal:.2f} ({(bal/100-1)*100:+.2f}%)** |\n| Filtered skips | {len(rejected)} |\n\n")
        f.write("## Trades\n\n| # | In | Out | Bias | Entry | PnL% | $ | SoftBE | Ext | A | B | C |\n|---|----|-----|------|-------|------|---|--------|-----|---|---|---|\n")
        for t in trades:
            f.write(
                f"| {t['n']} | {t['entry_time']} | {t['exit_time']} | {t['bias']} | {t['entry']:.2f} | "
                f"{t['pnl_pct']:+.3f} | {t['pnl_usd']:+.2f} | {bool(t.get('soft_be'))} | {bool(t.get('expanded'))} | "
                f"{t['exit_a']} | {t['exit_b']} | {t['exit_c']} |\n"
            )
        f.write("\n## Rejected entries (PD/Midnight)\n\n")
        for r in rejected:
            f.write(f"- {r['dt']} {r['bias']} @ {r['entry']:.2f} — **{r['reason']}**\n")
        f.write("\n## Per-trade events\n\n")
        for t in trades:
            f.write(f"### #{t['n']} {t['entry_time']} {t['bias']} MFE={t.get('mfe_r',0):.2f}R\n")
            f.write(f"{t.get('why')}\n\n")
            for e in t.get("events") or []:
                f.write(f"- {e}\n")
            f.write("\n")
    print(f"Saved {md}\nSaved {out_json}")
    return bal, trades, rejected


if __name__ == "__main__":
    run()
