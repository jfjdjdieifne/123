#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Forensic Detailed Report — Dec 2023 — BTC & ETH — V2.1 Final
Shows: what saw, what did, why decided, why saw — per ICT layers
"""
import csv, datetime, sys, os
from collections import defaultdict
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'core'))

from ict_sessions import classify_session
from ict_layered_brain import read_bias, read_narrative, read_trigger, build_plan, find_dealing_range
from ict_math_engine import detect_ict_three_candle_swings
from ict_matrix_ride import manage_matrix_triple, entry_accumulation_filters, get_ny_day_key

BTC_PATHS = [
    "/home/user/raw_data/BTCUSDT_5m_2017-09-01_to_2025-09-23.csv",
    "data/BTCUSDT_5m_2017-09-01_to_2025-09-23.csv",
]
ETH_PATHS = [
    "/tmp/eth_3_2/ETHUSDT_5m.csv",
    "data/ETHUSDT_5m.csv",
]

def pick_path(cands):
    for p in cands:
        if os.path.exists(p):
            return p
    return cands[0]

BTC_PATH = pick_path(BTC_PATHS)
ETH_PATH = pick_path(ETH_PATHS)
RISK=0.02
MONTH="2023-12"

def load_btc():
    rows=[]
    with open(BTC_PATH) as f:
        r=csv.DictReader(f)
        for row in r:
            if not row['datetime'].startswith("2023-11") and not row['datetime'].startswith("2023-12"):
                continue
            dt_str=row['datetime'][:16]
            dt=datetime.datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
            rows.append({'ts':int(dt.replace(tzinfo=datetime.timezone.utc).timestamp()*1000),'dt':dt_str,'o':float(row['open']),'h':float(row['high']),'l':float(row['low']),'c':float(row['close']),'v':float(row['volume'])})
    return rows

def load_eth():
    rows=[]
    with open(ETH_PATH) as f:
        r=csv.DictReader(f)
        for row in r:
            dt_str=row.get('datetime')
            if not dt_str:
                vals=list(row.values())
                dt_str=vals[1]
            if not dt_str or (not dt_str.startswith("2023-11") and not dt_str.startswith("2023-12")):
                continue
            dt_str=dt_str[:16]
            try:
                dt=datetime.datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
            except:
                continue
            rows.append({'ts':int(dt.replace(tzinfo=datetime.timezone.utc).timestamp()*1000),'dt':dt_str,'o':float(row['open']),'h':float(row['high']),'l':float(row['low']),'c':float(row['close']),'v':float(row['volume'])})
    return rows

def slice_data(rows,end_idx,lookback):
    s=max(0,end_idx-lookback+1)
    ch=rows[s:end_idx+1]
    return {'timestamps':[r['ts'] for r in ch],'opens':[r['o'] for r in ch],'highs':[r['h'] for r in ch],'lows':[r['l'] for r in ch],'closes':[r['c'] for r in ch],'volumes':[r['v'] for r in ch]}

def aggregate(data,tf):
    n=len(data['closes'])
    ratio=tf//5
    if n<ratio:
        return None
    out={'timestamps':[],'opens':[],'highs':[],'lows':[],'closes':[],'volumes':[]}
    for i in range(n//ratio):
        a,b=i*ratio,(i+1)*ratio
        out['timestamps'].append(data['timestamps'][a])
        out['opens'].append(data['opens'][a])
        out['highs'].append(max(data['highs'][a:b]))
        out['lows'].append(min(data['lows'][a:b]))
        out['closes'].append(data['closes'][b-1])
        out['volumes'].append(sum(data['volumes'][a:b]))
    return out

def daily_ctx(rows, idx):
    by=defaultdict(lambda:{"h":-1e18,"l":1e18,"o":None})
    for r in rows[:idx+1]:
        k=get_ny_day_key(r['ts'])
        if by[k]['o'] is None:
            by[k]['o']=r['o']
        by[k]['h']=max(by[k]['h'],r['h'])
        by[k]['l']=min(by[k]['l'],r['l'])
    cur=get_ny_day_key(rows[idx]['ts'])
    completed=sorted(d for d in by if d<cur)
    ranges=[by[d]['h']-by[d]['l'] for d in completed[-10:]]
    return ranges, by[cur]['o'], by[cur]['h'], by[cur]['l'], cur

def midnight_open(rows, idx):
    cur=get_ny_day_key(rows[idx]['ts'])
    for i in range(idx,-1,-1):
        if get_ny_day_key(rows[i]['ts'])!=cur:
            return rows[i+1]['o'] if i+1<=idx else rows[idx]['o']
    return rows[0]['o']

def run_detailed(symbol, rows):
    start_idx=next(i for i,r in enumerate(rows) if r['dt'].startswith(MONTH))
    EXEC={"LONDON_KILLZONE","NY_AM_KILLZONE","NY_PM_KILLZONE"}
    balance=100.0
    trades=[]
    active=None
    entered=set()
    c1=c4=0
    rejected=0
    scans=[]
    detailed_scans=[]
    for idx in range(start_idx, len(rows)):
        row=rows[idx]
        if not row['dt'].startswith(MONTH):
            break
        c1+=1; c4+=1
        if active:
            c5={'o':row['o'],'h':row['h'],'l':row['l'],'c':row['c']}
            c1h=c4h=None
            if c1>=12 and idx>=12:
                ch=rows[idx-11:idx+1]
                c1h={'o':ch[0]['o'],'h':max(x['h'] for x in ch),'l':min(x['l'] for x in ch),'c':row['c']}
                c1=0
            if c4>=48 and idx>=48:
                ch=rows[idx-47:idx+1]
                c4h={'o':ch[0]['o'],'h':max(x['h'] for x in ch),'l':min(x['l'] for x in ch),'c':row['c']}
                c4=0
            hist,d_o,d_h,d_l,dk=daily_ctx(rows,idx)
            ctx={"hist_ranges":hist,"day_open":d_o,"day_high":d_h,"day_low":d_l,"day_key":dk,"setup_start":active.get("setup_start"),"setup_end":active.get("setup_end")}
            # MFE/MAE
            is_short=active['is_short']
            entry=active['pos_a']['entry']
            if is_short:
                fav=entry-row['l']
                adv=row['h']-entry
            else:
                fav=row['h']-entry
                adv=entry-row['l']
            if active['risk']>0:
                active['mfe_r']=max(active.get('mfe_r',0), fav/active['risk'])
                active['mae_r']=max(active.get('mae_r',0), adv/active['risk'])
                active['mfe_price']=max(active.get('mfe_price',entry), row['h']) if not is_short else min(active.get('mfe_price',entry), row['l'])
                active['mae_price']=min(active.get('mae_price',entry), row['l']) if not is_short else max(active.get('mae_price',entry), row['h'])
            events, closed = manage_matrix_triple(c5,c1h,c4h,active,day_ctx=ctx)
            if events:
                for e in events:
                    active.setdefault("event_log", []).append(f"{row['dt']} | {e} | c={row['c']} sl_B={active['pos_b'].get('sl')} sl_C={active['pos_c'].get('sl')}")
            if closed:
                pnl=active.get('pnl_pct') or 0
                usd=balance*pnl/100
                bal_before=balance
                balance+=usd
                active['exit_time']=row['dt']
                active['exit_price']=row['c']
                active['pnl_pct']=pnl
                active['pnl_dollar']=usd
                active['balance_before']=bal_before
                active['balance_after']=balance
                active['exit_reason_a']=active['pos_a'].get('exit_reason')
                active['exit_reason_b']=active['pos_b'].get('exit_reason')
                active['exit_reason_c']=active['pos_c'].get('exit_reason')
                try:
                    dur = (datetime.datetime.strptime(row['dt'], "%Y-%m-%d %H:%M") - datetime.datetime.strptime(active['entry_time'], "%Y-%m-%d %H:%M")).total_seconds()/3600
                    active['duration_h']=round(dur,1)
                except:
                    active['duration_h']=0
                trades.append(active)
                active=None
            continue
        if idx%12!=0:
            continue
        sess=classify_session(row['ts'])
        scan_entry={'time':row['dt'],'ny_time':sess['ny_time'],'session':sess['session'],'executable':sess['session'] in EXEC,'price':row['c']}
        if sess['session'] not in EXEC:
            scan_entry['decision']='HOLD'
            scan_entry['reason']=f"Session {sess['session']} not executable — ICT time filter"
            scans.append(scan_entry)
            detailed_scans.append(scan_entry)
            continue
        full=slice_data(rows, idx, 8000)
        d5=slice_data(rows, idx, 250)
        d15=aggregate(full,15)
        d4h=aggregate(full,240)
        d1d=aggregate(full,1440)
        if not d1d or len(d1d['closes'])<10:
            scan_entry['decision']='HOLD'
            scan_entry['reason']='No Daily data — need 20 daily candles'
            scans.append(scan_entry)
            detailed_scans.append(scan_entry)
            continue
        bias=read_bias(d1d,d4h)
        scan_entry['bias']=bias['direction']
        scan_entry['bias_conf']=bias['confidence']
        scan_entry['bias_reason']=bias['reason']
        scan_entry['dealing_daily']=bias.get('dealing_range')
        if bias['direction'] not in ('BULLISH','BEARISH') or bias['confidence']<50:
            scan_entry['decision']='HOLD'
            scan_entry['reason']=f"BIAS weak: {bias['direction']} conf {bias['confidence']}<50 — no clear HH/HL"
            scans.append(scan_entry)
            detailed_scans.append(scan_entry)
            continue
        if not d15 or len(d15['closes'])<20:
            scan_entry['decision']='HOLD'
            scan_entry['reason']='No 15M data'
            scans.append(scan_entry)
            detailed_scans.append(scan_entry)
            continue
        narr=read_narrative(d15,bias['direction'])
        scan_entry['narrative_state']=narr['state']
        if narr['state']=='SWEEP_FOUND':
            scan_entry['sweep_side']=narr['sweep']['side']
            scan_entry['sweep_level']=narr['sweep']['level']
            scan_entry['sweep_wick']=narr['sweep']['wick_extreme']
            scan_entry['sweep_quality']=narr['sweep']['quality']
            scan_entry['dealing_15m']=narr.get('dealing_range')
        if narr['state']!='SWEEP_FOUND' or (narr.get('sweep') or {}).get('quality',0)<25:
            q=(narr.get('sweep') or {}).get('quality','N/A')
            scan_entry['decision']='HOLD'
            scan_entry['reason']=f"NARRATIVE: no genuine sweep or Q{q}<25 — no liquidity fuel"
            scans.append(scan_entry)
            detailed_scans.append(scan_entry)
            continue
        trig=read_trigger(d5,narr,bias['direction'])
        scan_entry['trigger_ready']=trig['ready']
        if trig['ready']:
            scan_entry['disp_body_mult']=trig['displacement']['body_multiple']
            scan_entry['disp_body_pct']=trig['displacement']['body_pct']
            scan_entry['disp_conv']=trig['displacement']['conviction']
            scan_entry['fvg_bottom']=trig['fvg']['bottom']
            scan_entry['fvg_top']=trig['fvg']['top']
            scan_entry['fvg_ce']=trig['fvg']['ce']
        if not trig['ready']:
            scan_entry['decision']='HOLD'
            scan_entry['reason']=f"TRIGGER not ready: {trig.get('reason')} — no institutional displacement+FVG"
            scans.append(scan_entry)
            detailed_scans.append(scan_entry)
            continue
        plan=build_plan(d5,d1d,trig,narr,bias)
        if not plan:
            scan_entry['decision']='HOLD'
            scan_entry['reason']='PLAN invalid: risk 0.5-8 ATR filter or TP1 RR<1.5 — risk not logical'
            scans.append(scan_entry)
            detailed_scans.append(scan_entry)
            continue
        fk=(round(trig['fvg']['top'],2), round(trig['fvg']['bottom'],2))
        if fk in entered:
            scan_entry['decision']='HOLD'
            scan_entry['reason']='Duplicate FVG — already entered this inefficiency'
            scans.append(scan_entry)
            detailed_scans.append(scan_entry)
            continue
        is_long=bias['direction']=='BULLISH'
        mid=midnight_open(rows, idx)
        disp_score=float(trig['displacement']['conviction'])
        dealing_15m=narr.get('dealing_range')
        ok, reason = entry_accumulation_filters(is_long, plan['entry'], bias, mid, displacement_score=disp_score, dealing_15m=dealing_15m, last_ob_held=True, current_price=plan['entry'])
        scan_entry['filter_reason']=reason
        scan_entry['plan_entry']=plan['entry']
        scan_entry['plan_sl']=plan['sl']
        scan_entry['plan_tp1']=plan['tp1']['price']
        scan_entry['plan_tp2']=plan['tp2'].get('price') if isinstance(plan['tp2'], dict) else None
        scan_entry['plan_risk']=plan['risk']
        scan_entry['plan_sl_atr']=plan['sl_atr']
        if not ok:
            scan_entry['decision']='HOLD PD_FILTER'
            scan_entry['reason']=f"PD_FILTER blocked: {reason} — Premium/Discount law"
            rejected+=1
            scans.append(scan_entry)
            detailed_scans.append(scan_entry)
            continue
        # ENTER
        scan_entry['decision']='ENTER'
        scan_entry['reason']=f"PASS ALL — BIAS {bias['direction']} conf{bias['confidence']} | SWEEP {narr['sweep']['side']} Q{narr['sweep']['quality']} | DISP {trig['displacement']['body_multiple']}x {trig['displacement']['body_pct']}% conv{trig['displacement']['conviction']} | FVG CE {trig['fvg']['ce']} | Filter {reason}"
        detailed_scans.append(scan_entry)
        scans.append(scan_entry)
        entered.add(fk)
        sw=detect_ict_three_candle_swings(d1d)
        targs=sw['swing_highs'] if is_long else sw['swing_lows']
        tp3=None
        for s in targs:
            if (is_long and s['price']>plan['entry']+plan['risk']*5) or (not is_long and s['price']<plan['entry']-plan['risk']*5):
                tp3=s['price']; break
        ss,se = (min(narr['sweep']['wick_extreme'], plan['sl']), max(trig['fvg']['top'], plan['entry'])) if is_long else (max(narr['sweep']['wick_extreme'], plan['sl']), min(trig['fvg']['bottom'], plan['entry']))
        active={
            'symbol':symbol,
            'entry_time':row['dt'],
            'session':sess['session'],
            'ny_time':sess['ny_time'],
            'signal_price':row['c'],
            'bias':bias['direction'],
            'bias_conf':bias['confidence'],
            'bias_reason':bias['reason'],
            'bias_structure':bias.get('structure'),
            'dealing_daily':bias.get('dealing_range'),
            'dealing_15m':narr.get('dealing_range'),
            'sweep':narr['sweep'],
            'displacement':trig['displacement'],
            'fvg':trig['fvg'],
            'plan':plan,
            'tp3':tp3,
            'is_short': not is_long,
            'risk':plan['risk'],
            'atr':plan['atr'],
            'sl_atr':plan['sl_atr'],
            'risk_pct_a':RISK*100*0.6,
            'risk_pct_b':RISK*100*0.3,
            'risk_pct_c':RISK*100*0.1,
            'pos_a':{'active':True,'entry':plan['entry'],'sl':plan['sl'],'tp1':plan['tp1']['price'],'tp1_hit':False,'pnl':0},
            'pos_b':{'active':True,'entry':plan['entry'],'sl':plan['sl'],'tp2_price':plan['tp2'].get('price') if isinstance(plan['tp2'], dict) else None,'be_set':False,'pnl':0},
            'pos_c':{'active':True,'entry':plan['entry'],'sl':plan['sl'],'tp3_price':tp3,'be_set':False,'pnl':0},
            'setup_start':ss,
            'setup_end':se,
            'mfe_r':0,'mae_r':0,'mfe_price':plan['entry'],'mae_price':plan['entry'],
            'candle_count':0,
            'event_log':[f"{row['dt']} OPEN entry={plan['entry']} sl={plan['sl']} tp1={plan['tp1']['price']} filter={reason}"],
            'why_enter':f"BIAS {bias['direction']} conf{bias['confidence']} zone={(bias.get('dealing_range') or {}).get('zone')} | SWEEP {narr['sweep']['side']} Q{narr['sweep']['quality']} lvl={narr['sweep']['level']} wick={narr['sweep']['wick_extreme']} | DISP {trig['displacement']['body_multiple']}x {trig['displacement']['body_pct']}% conv={trig['displacement']['conviction']} | FVG {trig['fvg']['bottom']}-{trig['fvg']['top']} CE={trig['fvg']['ce']} RR1={plan['tp1']['rr']} SL_ATR={plan['sl_atr']} | KZ={sess['session']}",
            'filter_reason':reason,
        }
        c1=c4=0
    summary={
        'symbol':symbol,
        'month':MONTH,
        'engine':'MATRIX_EINSTEIN V2.1 FINAL',
        'start':100,
        'end':round(balance,2),
        'return_pct':round((balance/100-1)*100,2),
        'trades':len(trades),
        'wins':len([t for t in trades if t.get('pnl_dollar',0)>0.01]),
        'losses':len([t for t in trades if t.get('pnl_dollar',0)<-0.01]),
        'scans':len(detailed_scans),
        'rejected_pd':rejected,
    }
    return {'summary':summary,'trades':trades,'scans':detailed_scans}

def main():
    btc_rows=load_btc()
    eth_rows=load_eth()
    print(f"BTC {len(btc_rows)} ETH {len(eth_rows)}")
    btc_res=run_detailed("BTCUSDT", btc_rows)
    eth_res=run_detailed("ETHUSDT", eth_rows)
    # Save markdown
    md_path=os.path.join(os.path.dirname(__file__), '..', '..', 'DETAILED_FORENSIC_DEC2023_V2_1_FINAL.md')
    # also try local
    try:
        with open(md_path,'w',encoding='utf-8') as f:
            write_md(f, btc_res, eth_res)
        print(f"Saved {md_path}")
    except:
        with open("DETAILED_FORENSIC_DEC2023_V2_1_FINAL.md",'w',encoding='utf-8') as f:
            write_md(f, btc_res, eth_res)
        print("Saved DETAILED_FORENSIC_DEC2023_V2_1_FINAL.md")

def write_md(f, btc_res, eth_res):
    f.write("# تقرير مفصّل جداً — ديسمبر 2023 — BTC & ETH — نفس الشهر ونفس السنة — Matrix V2.1 Final\n\n")
    f.write("**رأس المال $100 / مخاطرة 2% (A=1.2% B=0.6% C=0.2%) — المحرك Matrix Einstein V2.1 (Continuation + Harvest Gate + Determinism + Breaker)**\n\n")
    f.write("## الملخص السريع\n\n")
    f.write("| عملة | $100→ | عائد | صفقات | W | L | WR | PF | سكانات | مرفوضة PD |\n|---|---|---|---|---|---|---|---|---|\n")
    for res in [btc_res, eth_res]:
        s=res['summary']
        f.write(f"| {s['symbol']} | ${s['end']} | {s['return_pct']}% | {s['trades']} | {s['wins']} | {s['losses']} | {round(s['wins']/s['trades']*100,1) if s['trades'] else 0}% | - | {s['scans']} | {s['rejected_pd']} |\n")
    f.write("\n---\n\n")

    for res in [btc_res, eth_res]:
        s=res['summary']
        f.write(f"\n# {s['symbol']} — {s['engine']} — {s['month']} — ${s['start']}→${s['end']} ({s['return_pct']}%)\n\n")
        f.write(f"صفقات {s['trades']} رابحة {s['wins']} خاسرة {s['losses']} | سكانات {s['scans']} مرفوضة PD {s['rejected_pd']}\n\n")
        f.write("## جدول سريع لكل الصفقات\n\n")
        f.write("| # | دخول | خروج | Bias | Entry | SL | TP1 | TP2 | TP3 | PnL% | $ | Bal | A | B | C | MFE | MAE | مدة | Session |\n|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|\n")
        for i,t in enumerate(res['trades'],1):
            f.write(f"| {i} | {t['entry_time']} | {t.get('exit_time')} | {t['bias']} | {t['pos_a']['entry']:.2f} | {t['plan']['sl']:.2f} | {t['pos_a'].get('tp1',0):.2f} | {t['pos_b'].get('tp2_price') or 0:.2f} | {t['tp3'] or 0:.2f} | {t.get('pnl_pct',0):+.3f} | {t.get('pnl_dollar',0):+.2f} | {t.get('balance_after',0):.2f} | {t.get('exit_reason_a')} | {t.get('exit_reason_b')} | {t.get('exit_reason_c')} | {t.get('mfe_r',0):.2f}R | {t.get('mae_r',0):.2f}R | {t.get('duration_h',0)}h | {t['session']} |\n")
        f.write("\n## تفصيل كل صفقة — شو شاف وشو عمل ليش قرر وليش شاف\n\n")
        for i,t in enumerate(res['trades'],1):
            f.write(f"\n### صفقة #{i} — {t['bias']} — {t['entry_time']} → {t.get('exit_time')} — PnL {t.get('pnl_pct',0):+.3f}% (${t.get('pnl_dollar',0):+.2f})\n\n")
            f.write(f"**لماذا دخل؟ (4 طبقات)**\n\n")
            f.write(f"- **السياق والجلسة:** Session={t['session']} NY={t['ny_time']} | سعر السوق لحظة الإشارة={t['signal_price']} | Filter={t.get('filter_reason')}\n")
            bias = t['bias']
            f.write(f"- **Layer1 BIAS (Daily+4H):** Direction={t['bias']} Confidence={t['bias_conf']} | Reason={t['bias_reason']} | Structure={t['bias_structure']}\n")
            dd = t.get('dealing_daily') or {}
            f.write(f"  - Dealing Daily: zone={dd.get('zone')} eq={dd.get('equilibrium')} high={(dd.get('high') or {}).get('price') if isinstance(dd.get('high'), dict) else dd.get('erl_high')} low={(dd.get('low') or {}).get('price') if isinstance(dd.get('low'), dict) else dd.get('erl_low')} pct_in_range={dd.get('pct_in_range')} current={dd.get('current')}\n")
            sw = t.get('sweep') or {}
            f.write(f"- **Layer2 NARRATIVE (15M Sweep):** Side={sw.get('side')} Level={sw.get('level')} Wick={sw.get('wick_extreme')} Quality={sw.get('quality')} (min 25) | تعني: سيولة {'بيع' if sw.get('side')=='SSL' else 'شراء'} مسحوبة للشراء/البيع — فتيل اخترق ورجع الإغلاق داخلياً = Genuine\n")
            d15 = t.get('dealing_15m') or {}
            f.write(f"  - Dealing 15M: zone={d15.get('zone')} eq={d15.get('equilibrium')} ERL_H={d15.get('erl_high')} ERL_L={d15.get('erl_low')}\n")
            disp = t.get('displacement') or {}
            f.write(f"- **Layer3 TRIGGER (5M Displacement+FVG):** Dir={disp.get('direction')} BodyMult={disp.get('body_multiple')}x Body%={disp.get('body_pct')}% Conviction={disp.get('conviction')} | تعني: اندفاع مؤسساتي — جسم {disp.get('body_multiple')}x متوسط 5 شموع + جسم {disp.get('body_pct')}% من المدى = نية مؤسساتية\n")
            fvg = t.get('fvg') or {}
            f.write(f"  - FVG: bottom={fvg.get('bottom')} top={fvg.get('top')} **CE(entry)={fvg.get('ce')}** dir={fvg.get('direction')} | فراغ سعري 3 شموع لم يتداول فيه أحد — مغناطيس للمؤسسات\n")
            plan = t.get('plan') or {}
            f.write(f"- **Layer4 PLAN:** Entry={plan.get('entry')} SL={plan.get('sl')} Risk={plan.get('risk')} ATR={plan.get('atr')} SL/ATR={plan.get('sl_atr')} | TP1={plan.get('tp1')} TP2={plan.get('tp2')} TP3={t.get('tp3')}\n")
            f.write(f"  - توزيع مخاطرة: A={t['risk_pct_a']}% B={t['risk_pct_b']}% C={t['risk_pct_c']}% = إجمالي 2%\n")
            f.write(f"  - جملة الدخول: {t.get('why_enter')}\n\n")
            f.write(f"**كيف أدار الصفقة ولماذا خرج؟**\n\n")
            f.write(f"- MFE {t.get('mfe_r',0):.2f}R سعر متطرف لصالحنا {t.get('mfe_price')} | MAE {t.get('mae_r',0):.2f}R سعر ضدنا {t.get('mae_price')} | مدة {t.get('duration_h')} ساعة | Phase {t.get('market_phase','?')}\n")
            f.write(f"- أسباب خروج: A={t.get('exit_reason_a')} B={t.get('exit_reason_b')} C={t.get('exit_reason_c')} — تفسير: ")
            # تفسير خروج
            for leg, r in [('A', t.get('exit_reason_a')), ('B', t.get('exit_reason_b')), ('C', t.get('exit_reason_c'))]:
                if 'SL' in str(r):
                    f.write(f"{leg}=SL ضرب الستوب الابتدائي قبل TP1 — الفكرة فشلت مبكراً. ")
                elif 'TRAIL' in str(r) or 'FORTRESS' in str(r):
                    f.write(f"{leg}=Trail/Fortress — بعد TP1→BE trail خلف ITL/ITH — قفل ربح. ")
                elif 'RISK_CUT' in str(r):
                    f.write(f"{leg}=CE_RISK_CUT MFE<1R — قطع مخاطرة مبكراً بدل -2% كاملة. ")
                elif 'HARVEST' in str(r):
                    f.write(f"{leg}=CE_HARVEST hard lock+MFE≥1.5R — حصد ربح هيكلي. ")
                elif 'SCALE_SHIFT' in str(r):
                    f.write(f"{leg}=SCALE_SHIFT — انتقل لـ 1H/4H بعد harvest. ")
            f.write(f"\n- Balance {t.get('balance_before')} → {t.get('balance_after')}\n")
            f.write(f"- Timeline الأحداث (شو عمل):\n\n")
            f.write("| وقت | حدث | سعر | SL_B | SL_C |\n|------|------|------|------|------|\n")
            for ev in t.get('event_log',[])[:60]:
                f.write(f"| | {ev} | | | |\n")
            f.write("\n")

        f.write(f"\n## كل قرارات الفحص — شو شاف وقرر HOLD ولماذا (Top 100)\n\n")
        f.write("| وقت | Session | سعر | قرار | السبب | Bias | Conf | Sweep Q | Disp Conv | FVG CE | Filter |\n|------|---------|------|-------|-------|------|------|---------|-----------|--------|--------|\n")
        for sc in res['scans'][:100]:
            f.write(f"| {sc.get('time')} | {sc.get('session')} | {sc.get('price')} | {sc.get('decision')} | {sc.get('reason')} | {sc.get('bias')} | {sc.get('bias_conf')} | {sc.get('sweep_quality')} | {sc.get('disp_conv')} | {sc.get('fvg_ce')} | {sc.get('filter_reason')} |\n")
        f.write("\n---\n\n")

if __name__=="__main__":
    main()
