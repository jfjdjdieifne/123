#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Matrix Einstein ONLY — Dec 2023 — BTC & ETH — V3.0-HONEST
$100 / 2% risk (A=1.2% B=0.6% C=0.2%)

V3.0-HONEST — اصلاح جذري لمنطق النتائج:
القاعدة الذهبية: لا تُحسب أي صفقة إلا إذا لمس السعر سعر الدخول فعلاً.
  - كل setup يصبح أمر LIMIT PENDING عند CE (منتصف FVG = مستوى اعادة التوازن ICT).
    مصدر: innercircletrader.net FVG "Consequent Encroachment" + "wait for price to return to the FVG".
  - يُملأ فقط اذا لمس مدى شمعة 5M سعر الدخول → عندئذ تصبح صفقة فعلية.
  - اذا لم يلمس السعر الدخول خلال 72 شمعة (6h) → يُلغى صادقاً (لا ربح لا خسارة لا عدّ).
  - أُلغي: MARKET_FALLBACK_TP1_HIT (يخترع صفقات من أوامر لم تُملأ)، والـfill الفوري
    عند سعر IOFED البعيد (يسجل دخولاً لم يصل اليه السوق → صفقات وهمية).

ما بقي كما هو (الدماغ لم يُمس):
  - Layered Brain + كل الفلاتر + InstitutionalMind (manage_matrix_triple)
  - A/B/C-Survival, SL Filter >=2.8 ATR, Confluence >=4, FAST SCAN, CACHE, KILLZONE.
"""
import csv, datetime, sys, os
from collections import defaultdict
# Ensure core is in path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'core'))

from ict_sessions import classify_session
from ict_layered_brain import read_bias, read_bias_major, read_narrative, read_trigger, build_plan
from ict_math_engine import detect_ict_three_candle_swings, detect_breaker_block_opportunity
from ict_matrix_ride import (
    manage_matrix_triple, entry_accumulation_filters, get_ny_day_key
)

# Data paths
POSSIBLE_BTC = [
    "/home/user/raw_data/BTCUSDT_5m_2017-09-01_to_2025-09-23.csv",
    os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'BTCUSDT_5m_2017-09-01_to_2025-09-23.csv'),
    os.path.join(os.path.dirname(__file__), '..', '..', '..', 'raw_data', 'BTCUSDT_5m_2017-09-01_to_2025-09-23.csv'),
    "data/BTCUSDT_5m_2017-09-01_to_2025-09-23.csv",
]
POSSIBLE_ETH = [
    "/tmp/eth_3_2/ETHUSDT_5m.csv",
    "/home/user/data_audit/eth_extracted_1/ETHUSDT_5m.csv",
    os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'ETHUSDT_5m.csv'),
    "data/ETHUSDT_5m.csv",
]

def pick_path(candidates):
    for p in candidates:
        if os.path.exists(p):
            return p
    return candidates[0]

BTC_PATH = pick_path(POSSIBLE_BTC)
ETH_PATH = pick_path(POSSIBLE_ETH)

RISK = 0.02
MONTH = "2023-12"


def load_btc():
    """Load BTC 2023 data only (Aug-Dec) for fast access."""
    rows = []
    with open(BTC_PATH) as f:
        r = csv.DictReader(f)
        for row in r:
            if not (row['datetime'].startswith("2023-0") or row['datetime'].startswith("2023-1")):
                continue
            dt_str = row['datetime'][:16]
            dt = datetime.datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
            rows.append({
                'ts': int(dt.replace(tzinfo=datetime.timezone.utc).timestamp() * 1000),
                'dt': dt_str,
                'o': float(row['open']),
                'h': float(row['high']),
                'l': float(row['low']),
                'c': float(row['close']),
                'v': float(row['volume']),
            })
    return rows


def load_eth():
    """Load ETH 2023 Nov-Dec data only."""
    rows = []
    with open(ETH_PATH) as f:
        r = csv.DictReader(f)
        for row in r:
            dt_str = row.get('datetime')
            if not dt_str:
                vals = list(row.values())
                dt_str = vals[1]
            if not dt_str or (not dt_str.startswith("2023-11") and not dt_str.startswith("2023-12")):
                continue
            dt_str = dt_str[:16]
            try:
                dt = datetime.datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
            except:
                continue
            rows.append({
                'ts': int(dt.replace(tzinfo=datetime.timezone.utc).timestamp() * 1000),
                'dt': dt_str,
                'o': float(row['open']),
                'h': float(row['high']),
                'l': float(row['low']),
                'c': float(row['close']),
                'v': float(row['volume']),
            })
    return rows


# ═══════════════════════════════════════════════════════════════════════════
# FAST slice_data + aggregate with CACHE
# Cache كل 60 شمعة (5h) — يوفر 8000 operations per scan
# ═══════════════════════════════════════════════════════════════════════════
_CACHE = {'last_idx': -1, 'lookback': 0, 'data': None, 'full': None,
          'd5': None, 'd15': None, 'd4h': None, 'd1d': None}


def _build_cache(rows, idx, lookback=8000):
    """Build cached multi-TF data once per 60 candles (5h)."""
    if _CACHE['last_idx'] >= idx - 12 and _CACHE['data'] is not None:
        return  # Reuse cache

    s = max(0, idx - lookback + 1)
    ch = rows[s:idx + 1]
    full = {
        'timestamps': [r['ts'] for r in ch],
        'opens': [r['o'] for r in ch],
        'highs': [r['h'] for r in ch],
        'lows': [r['l'] for r in ch],
        'closes': [r['c'] for r in ch],
        'volumes': [r['v'] for r in ch],
    }

    # d5: last 250 candles (5M)
    s5 = max(0, idx - 249)
    ch5 = rows[s5:idx + 1]
    d5 = {
        'timestamps': [r['ts'] for r in ch5],
        'opens': [r['o'] for r in ch5],
        'highs': [r['h'] for r in ch5],
        'lows': [r['l'] for r in ch5],
        'closes': [r['c'] for r in ch5],
        'volumes': [r['v'] for r in ch5],
    }

    # d15, d4h, d1d: aggregate from full
    d15 = _aggregate(full, 15)
    d4h = _aggregate(full, 240)
    d1d = _aggregate(full, 1440)

    _CACHE.update({
        'last_idx': idx, 'data': True, 'full': full,
        'd5': d5, 'd15': d15, 'd4h': d4h, 'd1d': d1d,
    })


def _aggregate(data, tf):
    """Aggregate 5M candles to higher TF."""
    n = len(data['closes'])
    ratio = tf // 5
    if n < ratio:
        return None
    out = {'timestamps': [], 'opens': [], 'highs': [], 'lows': [], 'closes': [], 'volumes': []}
    for i in range(n // ratio):
        a, b = i * ratio, (i + 1) * ratio
        out['timestamps'].append(data['timestamps'][a])
        out['opens'].append(data['opens'][a])
        out['highs'].append(max(data['highs'][a:b]))
        out['lows'].append(min(data['lows'][a:b]))
        out['closes'].append(data['closes'][b - 1])
        out['volumes'].append(sum(data['volumes'][a:b]))
    return out


def daily_ctx(rows, idx):
    by = defaultdict(lambda: {"h": -1e18, "l": 1e18, "o": None})
    for r in rows[:idx + 1]:
        k = get_ny_day_key(r['ts'])
        if by[k]['o'] is None:
            by[k]['o'] = r['o']
        by[k]['h'] = max(by[k]['h'], r['h'])
        by[k]['l'] = min(by[k]['l'], r['l'])
    cur = get_ny_day_key(rows[idx]['ts'])
    completed = sorted(d for d in by if d < cur)
    ranges = [by[d]['h'] - by[d]['l'] for d in completed[-10:]]
    return ranges, by[cur]['o'], by[cur]['h'], by[cur]['l'], cur


def midnight_open(rows, idx):
    cur = get_ny_day_key(rows[idx]['ts'])
    for i in range(idx, -1, -1):
        if get_ny_day_key(rows[i]['ts']) != cur:
            return rows[i + 1]['o'] if i + 1 <= idx else rows[idx]['o']
    return rows[0]['o']


def run(symbol, rows):
    # V2.4-FAST: Reset cache between runs to avoid BTC data leak to ETH
    global _CACHE
    _CACHE = {'last_idx': -1, 'lookback': 0, 'data': None, 'full': None,
              'd5': None, 'd15': None, 'd4h': None, 'd1d': None}
    start_idx = next(i for i, r in enumerate(rows) if r['dt'].startswith(MONTH))
    # V2.4-FAST: Expand sessions to include Asian range formation (per ICT 2022)
    # Source: innercircletrader.net "Consolidated Asian Range on a Bullish Day"
    EXEC = {"LONDON_KILLZONE", "NY_AM_KILLZONE", "NY_PM_KILLZONE"}
    balance = 100.0
    trades = []
    active = None
    pending = None          # HONEST EXECUTION: أمر limit ينتظر اللمس الفعلي قبل أن يصبح صفقة
    cancelled = []          # setups لم يلمس السعر دخولها = لا تُحسب (لا ربح ولا خسارة)
    entered = set()
    c1 = c4 = 0
    rejected = 0
    scans = 0
    scan_log = []

    # V2.4-FAST #1: Scan every 5 minutes within killzones (not every 12)
    # Source: innercircletrader.net - "5-minute or lower for trade entry confirmation"
    SCAN_EVERY = 1  # Was 12 in V2.4 = 1hr gap. Now = 5min, matches ICT

    # ═══ HONEST EXECUTION — V3.0 ═══
    # timeout صادق بالشموع: 72 شمعة 5M = 6 ساعات (ضمن أفق الجلسة، مصدر: ICT "5-day horizon" / killzoning)
    # القاعدة: لا صفقة إلا إذا لمس السعر سعر الدخول فعلاً. لا FILL وهمي، لا MARKET_FALLBACK.
    # مصدر: innercircletrader.net FVG: "wait for price to return to the FVG before entering"
    #        إن لم يعد السعر للـFVG → لا دخول. هذا انضباط ICT، وليس خسارة.
    LIMIT_TIMEOUT = 72

    for idx in range(start_idx, len(rows)):
        row = rows[idx]
        if not row['dt'].startswith(MONTH):
            break
        c1 += 1
        c4 += 1

        # ═══ (1) صفقة مفعّلة فعلًا (دخل السعر دخولها) → إدارة بالدماغ ═══
        if active:
            c5 = {'o': row['o'], 'h': row['h'], 'l': row['l'], 'c': row['c']}
            c1h = c4h = None
            if c1 >= 12 and idx >= 12:
                ch = rows[idx - 11:idx + 1]
                c1h = {'o': ch[0]['o'], 'h': max(x['h'] for x in ch), 'l': min(x['l'] for x in ch), 'c': row['c']}
                c1 = 0
            if c4 >= 48 and idx >= 48:
                ch = rows[idx - 47:idx + 1]
                c4h = {'o': ch[0]['o'], 'h': max(x['h'] for x in ch), 'l': min(x['l'] for x in ch), 'c': row['c']}
                c4 = 0

            hist, d_o, d_h, d_l, dk = daily_ctx(rows, idx)
            ctx = {"hist_ranges": hist, "day_open": d_o, "day_high": d_h, "day_low": d_l, "day_key": dk,
                   "setup_start": active.get("setup_start"), "setup_end": active.get("setup_end")}
            is_short = active['is_short']
            entry = active['pos_a']['entry']
            if is_short:
                fav = entry - row['l']
                adv = row['h'] - entry
            else:
                fav = row['h'] - entry
                adv = entry - row['l']
            if active['risk'] > 0:
                active['mfe_r'] = max(active.get('mfe_r', 0), fav / active['risk'])
                active['mae_r'] = max(active.get('mae_r', 0), adv / active['risk'])

            events, closed = manage_matrix_triple(c5, c1h, c4h, active, day_ctx=ctx)
            if events:
                for e in events[-5:]:
                    active.setdefault("events", []).append(f"{row['dt']} {e}")
            if closed:
                pnl = active.get('pnl_pct') or 0
                usd = balance * pnl / 100
                balance += usd
                active['exit_time'] = row['dt']
                active['pnl_pct'] = pnl
                active['pnl_dollar'] = usd
                active['balance_after'] = balance
                trades.append(active)
                active = None
            continue

        # ═══ (2) أمر pending ينتظر اللمس الصادق لسعر الدخول ═══
        if pending:
            entry_price = pending['pos_a']['entry']
            # لمس حقيقي: مدى شمعة 5M يغطي سعر الدخول = السعر تداول هذا المستوى فعلاً
            entry_touched = row['l'] <= entry_price <= row['h']
            if entry_touched:
                # تحويل لصفقة مفعّلة — الدخول حدث فعلاً عند هذا الزمن
                for leg in ('pos_a', 'pos_b', 'pos_c'):
                    pending[leg]['entry_filled'] = True
                pending['signal_time'] = pending['entry_time']   # وقت الإشارة (للأرشفة)
                pending['entry_time'] = row['dt']                # وقت الدخول الفعلي = اللمس
                pending['entry_type'] = "CE_LIMIT_FILLED_HONEST"
                pending.setdefault('events', []).append(
                    f"{row['dt']} ✅ HONEST_LIMIT_FILLED @ {entry_price:.2f} (signal was {pending['signal_time']})")
                active = pending
                pending = None
                c1 = c4 = 0
                continue
            else:
                # لم يُلمس بعد — نقص العداد الصادق. لا FILL، لا FALLBACK.
                pending['limit_candles_left'] -= 1
                if pending['limit_candles_left'] <= 0:
                    pending['cancel_dt'] = row['dt']
                    pending['cancel_reason'] = 'LIMIT_TIMEOUT_NO_TOUCH'
                    pending.setdefault('events', []).append(f"{row['dt']} ❌ LIMIT_TIMEOUT_CANCELLED (price never reached entry)")
                    cancelled.append(pending)
                    pending = None
                continue

        # ═══ (3) مسح جديد لـsetup داخل killzone ═══
        if idx % SCAN_EVERY != 0:
            continue
        sess = classify_session(row['ts'])
        if sess['session'] not in EXEC:
            continue
        scans += 1

        _build_cache(rows, idx, lookback=8000)
        d5 = _CACHE['d5']
        d15 = _CACHE['d15']
        d4h = _CACHE['d4h']
        d1d = _CACHE['d1d']

        if not d1d or len(d1d['closes']) < 10 or not d15:
            continue

        bias = read_bias(d1d, d4h)
        if bias['direction'] not in ('BULLISH', 'BEARISH') or bias['confidence'] < 50:
            scan_log.append({'time': row['dt'], 'reason': f"BIAS {bias['direction']} conf{bias['confidence']}<50"})
            continue

        narr = read_narrative(d15, bias['direction'])
        sweep_obj = narr.get('sweep') or {}
        if narr['state'] != 'SWEEP_FOUND' or sweep_obj.get('quality', 0) < 25:
            continue

        trig = read_trigger(d5, narr, bias['direction'])
        if not trig['ready']:
            continue

        plan = build_plan(d5, d1d, trig, narr, bias)
        if not plan:
            continue

        # NOTE V3.0 HONEST ENTRY: build_plan يضع entry = fvg['ce'] (منتصف FVG) —
        # هذا مستوى إعادة التوازن القانوني ICT (innercircletrader.net FVG Consequent Encroachment).
        # لا نتجاوزه بـ IOFED (الذي كان يضع دخولاً بعيداً لا يلمسه السعر → صفقات وهمية).
        # نحتفظ بـ plan['entry'] = CE، ونجعل الدخول أمر limit صادق يُملأ فقط عند اللمس.
        is_long = bias['direction'] == 'BULLISH'
        fk = (round(trig['fvg']['top'], 2), round(trig['fvg']['bottom'], 2))
        setup_key = (fk, is_long)
        if setup_key in entered:
            continue

        mid = midnight_open(rows, idx)
        disp_score = float(trig['displacement']['conviction'])
        dealing_15m = narr.get('dealing_range')
        last_ob_held = True
        ok, reason = entry_accumulation_filters(
            is_long, plan['entry'], bias, mid,
            displacement_score=disp_score, dealing_15m=dealing_15m,
            last_ob_held=last_ob_held, current_price=plan['entry']
        )
        if not ok:
            rejected += 1
            continue

        # ═══ SL Filter v2 — SL_ATR ≥ 2.8 (على دخول CE الأصلي) ═══
        sl_atr = plan.get('sl_atr', 0)
        if sl_atr > 0 and sl_atr < 2.8:
            rejected += 1
            continue

        # ═══ Confluence Counter v1 — ≥ 4 for Continuation only ═══
        confluence = 0
        if bias.get('direction') in ('BULLISH', 'BEARISH') and bias.get('confidence', 0) >= 70:
            confluence += 1
        if narr.get('sweep') and narr['sweep'].get('quality', 0) >= 50:
            confluence += 1
        if trig.get('displacement') and trig['displacement'].get('conviction', 0) >= 80:
            confluence += 1
        if trig.get('fvg') and trig['fvg'].get('ce') is not None:
            confluence += 1
        if trig.get('displacement', {}).get('index') is not None:
            confluence += 1
        if 'CONT_UNLOCKED' in reason:
            confluence += 1
        if 'CONT_UNLOCKED' in reason and confluence < 4:
            rejected += 1
            continue

        # TP1 RR على دخول CE (build_plan يضمن rr≥1.5، لكن نتأكد)
        tp1_rr = abs(plan['tp1']['price'] - plan['entry']) / plan['risk'] if plan['risk'] > 0 else 0
        if tp1_rr < 1.5:
            rejected += 1
            continue

        entered.add(fk)
        from ict_math_engine import detect_ict_three_candle_swings as detect_sw2
        sw = detect_sw2(d1d)
        targs = sw['swing_highs'] if is_long else sw['swing_lows']
        tp3 = None
        for s in targs:
            if (is_long and s['price'] > plan['entry'] + plan['risk'] * 5) or (not is_long and s['price'] < plan['entry'] - plan['risk'] * 5):
                tp3 = s['price']
                break

        ss, se = (min(narr['sweep']['wick_extreme'], plan['sl']),
                  max(trig['fvg']['top'], plan['entry'])) if is_long else (
        max(narr['sweep']['wick_extreme'], plan['sl']), min(trig['fvg']['bottom'], plan['entry']))

        # ═══ إنشاء أمر PENDING (ليس صفقة بعد) — دخول CE، ينتظر اللمس الصادق ═══
        pending = {
            'symbol': symbol, 'entry_time': row['dt'], 'session': sess['session'], 'ny_time': sess['ny_time'],
            'signal_price': row['c'],
            'bias': bias['direction'], 'bias_conf': bias['confidence'], 'bias_reason': bias['reason'],
            'bias_zone': (bias.get('dealing_range') or {}).get('zone'),
            'sweep_side': narr['sweep']['side'], 'sweep_level': narr['sweep']['level'],
            'sweep_wick': narr['sweep']['wick_extreme'], 'sweep_quality': narr['sweep']['quality'],
            'disp_dir': trig['displacement']['direction'],
            'disp_body_mult': float(trig['displacement']['body_multiple']),
            'disp_body_pct': float(trig['displacement']['body_pct']),
            'disp_conv': float(trig['displacement']['conviction']),
            'fvg_bottom': trig['fvg']['bottom'], 'fvg_top': trig['fvg']['top'], 'fvg_ce': trig['fvg']['ce'],
            'entry': plan['entry'], 'sl': plan['sl'], 'risk': plan['risk'], 'atr': plan['atr'],
            'sl_atr': plan['sl_atr'], 'tp1': plan['tp1'], 'tp2': plan['tp2'], 'tp3': tp3,
            'is_short': not is_long,
            'risk_pct_a': RISK * 100 * 0.6, 'risk_pct_b': RISK * 100 * 0.3, 'risk_pct_c': RISK * 100 * 0.1,
            'pos_a': {'active': True, 'entry': plan['entry'], 'sl': plan['sl'],
                      'tp1': plan['tp1']['price'], 'tp1_hit': False, 'pnl': 0, 'entry_filled': False},
            'pos_b': {'active': True, 'entry': plan['entry'], 'sl': plan['sl'],
                      'tp2_price': plan['tp2'].get('price') if isinstance(plan['tp2'], dict) else None,
                      'be_set': False, 'pnl': 0, 'entry_filled': False},
            'pos_c': {'active': True, 'entry': plan['entry'], 'sl': plan['sl'], 'tp3_price': tp3,
                      'be_set': False, 'pnl': 0, 'entry_filled': False},
            'setup_start': ss, 'setup_end': se, 'mfe_r': 0, 'mae_r': 0, 'candle_count': 0,
            'is_limit_order': True, 'entry_type': 'CE_LIMIT_PENDING',
            'limit_candles_left': LIMIT_TIMEOUT,
            'events': [f"{row['dt']} PENDING_LIMIT entry={plan['entry']} sl={plan['sl']} tp1={plan['tp1']['price']} (CE rebalance, awaits touch)"],
            'why': f"BIAS {bias['direction']} conf{bias['confidence']} zone={(bias.get('dealing_range') or {}).get('zone')} | SWEEP {narr['sweep']['side']} Q{narr['sweep']['quality']} | CE_LIMIT_HONEST"
        }
        c1 = c4 = 0

    summary = {
        'symbol': symbol, 'month': MONTH, 'engine': 'MATRIX_EINSTEIN V3.0-HONEST',
        'start': 100, 'end': round(balance, 2), 'return_pct': round((balance / 100 - 1) * 100, 2),
        'trades': len(trades),
        'wins': len([t for t in trades if t.get('pnl_dollar', 0) > 0.01]),
        'losses': len([t for t in trades if t.get('pnl_dollar', 0) < -0.01]),
        'cancelled_pending': len(cancelled),
        'scans': scans, 'rejected_pd': rejected
    }
    return {'summary': summary, 'trades': trades, 'cancelled': cancelled, 'scans': scan_log}


def main():
    print("Loading BTC...")
    btc_rows = load_btc()
    print(f"BTC {len(btc_rows)} {btc_rows[0]['dt']}->{btc_rows[-1]['dt']}")
    print("Loading ETH...")
    eth_rows = load_eth()
    print(f"ETH {len(eth_rows)} {eth_rows[0]['dt']}->{eth_rows[-1]['dt']}")
    btc_res = run("BTCUSDT", btc_rows)
    eth_res = run("ETHUSDT", eth_rows)
    print("\n=== MATRIX ONLY DEC 2023 V3.0-HONEST (صادق 100%) ===")
    for res in [btc_res, eth_res]:
        s = res['summary']
        print(f"{s['symbol']} ${s['start']}->${s['end']} {s['return_pct']}% Trades={s['trades']} W={s['wins']} L={s['losses']} CancelledPending={s.get('cancelled_pending',0)} Scans={s['scans']} RejPD={s['rejected_pd']}")
        for t in res['trades']:
            sig = t.get('signal_time', t['entry_time'])
            print(f"  sig={sig} FILLED={t['entry_time']} {t['bias']} entry={t['entry']} PnL {t.get('pnl_pct'):+.3f}% MFE {t.get('mfe_r', 0):.2f}R type={t.get('entry_type')}")
        for c in res.get('cancelled', []):
            print(f"  CANCELLED sig={c.get('signal_time', c.get('entry_time','?'))} {c['bias']} entry={c['entry']} ← {c.get('cancel_reason','?')} (لم يلمس السعر الدخول)")
    import json, os
    out_path = os.path.join(os.path.dirname(__file__), '..', '..', 'matrix_dec2023_results.json')
    try:
        with open(out_path, "w") as f:
            json.dump({'BTC': btc_res, 'ETH': eth_res}, f, indent=2, default=str)
        print(f"\nSaved {out_path}")
    except:
        with open("matrix_dec2023_results.json", "w") as f:
            json.dump({'BTC': btc_res, 'ETH': eth_res}, f, indent=2, default=str)
        print("\nSaved matrix_dec2023_results.json")


if __name__ == "__main__":
    main()
