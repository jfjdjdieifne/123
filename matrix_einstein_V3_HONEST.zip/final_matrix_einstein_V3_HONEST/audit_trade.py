#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AUDIT SCRIPT — تدقيق مجهري لكل صفقة من OHLC الحقيقي
يقرأ البيانات الخام ويتحقق:
1. هل السعر ضرب سعر الدخول (فعلاً تفعلت الصفقة)
2. هل ضرب TP1 / TP2 / SL
3. متى بالضبط حدث كل شيء
4. الربح/الخسارة الفعلية من البيانات الخام
"""
import csv, datetime, sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src', 'core'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src', 'runners'))

from run_matrix_only_dec2023 import load_btc, run, RISK, MONTH

# === AUDIT HEADER ===
print("="*80)
print("  🔍 AUDIT MICROSCOPIC — V2.2 FINAL — BTC Dec 2023")
print("  كل صفقة يتم فحصها من OHLC الحقيقي الخام")
print("="*80)

# Load raw BTC data
btc_rows = load_btc()
btc_nov_dec = [r for r in btc_rows if r['dt'].startswith('2023-11') or r['dt'].startswith('2023-12')]
print(f"\n📊 Data loaded: {len(btc_nov_dec)} candles from {btc_nov_dec[0]['dt']} to {btc_nov_dec[-1]['dt']}")

# Run the engine to get trades
res = run("BTCUSDT", btc_nov_dec)
trades = res['trades']

print(f"\n🎯 Total trades: {len(trades)}")
print(f"   Winners: {sum(1 for t in trades if t.get('pnl_pct', 0) > 0)}")
print(f"   Losers: {sum(1 for t in trades if t.get('pnl_pct', 0) < 0)}")
print(f"   Final PnL: {res['summary']['return_pct']:+.2f}%\n")

# === RAW DATA REPLAY PER TRADE ===
def get_candles_between(rows, start_dt, end_dt):
    """Get raw OHLC candles between two datetimes"""
    return [r for r in rows if start_dt <= r['dt'] <= end_dt]

def audit_trade(trade, all_rows, idx):
    """Audit a single trade against raw OHLC data"""
    print(f"\n{'─'*80}")
    print(f"  TRADE #{idx}: {trade['entry_time']} | {trade['bias']}")
    print(f"{'─'*80}")

    entry_dt = trade['entry_time']
    exit_dt = trade.get('exit_time', 'N/A')
    symbol = trade.get('symbol', 'BTCUSDT')

    print(f"  📍 Symbol: {symbol}")
    print(f"  📅 Entry: {entry_dt}")
    print(f"  📅 Exit: {exit_dt}")
    print(f"  💰 Entry Price: {trade['entry']:.2f}")
    print(f"  🛑 SL: {trade['sl']:.2f}")
    print(f"  🎯 TP1: {trade.get('pos_a',{}).get('tp1','?')} ({trade.get('tp1',{}).get('kind','?')} RR={trade.get('tp1',{}).get('rr','?')})")
    tp2 = trade.get('tp2')
    if isinstance(tp2, dict) and 'price' in tp2:
        print(f"  🎯 TP2: {tp2['price']:.2f} ({tp2.get('kind','?')} RR={tp2.get('rr','?')})")
    else:
        print(f"  🎯 TP2: {tp2}")
    print(f"  📊 Risk: {trade['risk']:.2f} (SL/ATR = {trade.get('sl_atr','?')})")
    print(f"  📊 Bias Conf: {trade.get('bias_conf','?')}")
    print(f"  📊 Sweep Q: {trade.get('sweep_quality','?')}")
    print(f"  📊 Disp Conv: {trade.get('disp_conv','?')}")
    print(f"  📊 FVG: [{trade.get('fvg_bottom','?'):.2f} - {trade.get('fvg_top','?'):.2f}] CE={trade.get('fvg_ce','?')}")
    print(f"  📊 Session: {trade.get('session','?')}")
    print(f"  📊 Filter: {trade.get('why','?')[:120]}")

    # Find entry candle
    entry_candle = None
    for i, r in enumerate(all_rows):
        if r['dt'] == entry_dt:
            entry_candle = r
            break
    if entry_candle is None:
        print(f"  ❌ ERROR: Could not find entry candle at {entry_dt}")
        return

    print(f"\n  📍 ENTRY CANDLE: {entry_candle['dt']} O={entry_candle['o']} H={entry_candle['h']} L={entry_candle['l']} C={entry_candle['c']}")
    is_long = trade['bias'] == 'BULLISH'

    # Verify entry was hit
    if is_long:
        entry_hit = entry_candle['l'] <= trade['entry'] <= entry_candle['h']
    else:
        entry_hit = entry_candle['l'] <= trade['entry'] <= entry_candle['h']
    print(f"     Entry {trade['entry']:.2f} was within candle range: {entry_hit}")

    # === REPLAY CANDLE BY CANDLE FROM ENTRY TO EXIT ===
    print(f"\n  📜 CANDLE-BY-CANDLE REPLAY:")
    print(f"     {'Time':<16} {'O':>10} {'H':>10} {'L':>10} {'C':>10} {'MFE':>6} {'MAE':>6} {'Status':<30}")
    print(f"     {'-'*16} {'-'*10} {'-'*10} {'-'*10} {'-'*10} {'-'*6} {'-'*6} {'-'*30}")

    entry_price = trade['entry']
    risk = trade['risk']
    sl = trade['sl']
    tp1 = trade.get('pos_a',{}).get('tp1')
    tp2_price = None
    if isinstance(trade.get('tp2'), dict) and 'price' in trade['tp2']:
        tp2_price = trade['tp2']['price']

    best_fav = 0
    worst_adv = 0
    a_tp1_hit = False
    a_exit_reason = None
    a_exit_price = None
    a_pnl = 0.0

    exit_found = False
    in_trade = False
    for r in all_rows:
        if r['dt'] < entry_dt:
            continue
        if exit_dt and r['dt'] > exit_dt:
            break
        if r['dt'] == entry_dt:
            in_trade = True
        if not in_trade:
            continue

        # Calculate MFE/MAE for this candle
        if is_long:
            fav = r['h'] - entry_price
            adv = entry_price - r['l']
        else:
            fav = entry_price - r['l']
            adv = r['h'] - entry_price

        if fav > best_fav:
            best_fav = fav
        if adv > worst_adv:
            worst_adv = adv

        mfe_r = best_fav / risk if risk > 0 else 0
        mae_r = worst_adv / risk if risk > 0 else 0

        # Check what happened
        status = ""
        # Check SL hit
        if (is_long and r['l'] <= sl) or (not is_long and r['h'] >= sl):
            status = f"🛑 SL HIT @ {sl:.2f}"
        # Check TP1 hit
        elif tp1 and not a_tp1_hit and ((is_long and r['h'] >= tp1) or (not is_long and r['l'] <= tp1)):
            a_tp1_hit = True
            status = f"🎯 TP1 HIT @ {tp1:.2f}"
        # Check TP2 hit
        elif tp2_price and a_tp1_hit and ((is_long and r['h'] >= tp2_price) or (not is_long and r['l'] <= tp2_price)):
            status = f"🏆 TP2 HIT @ {tp2_price:.2f}"
        else:
            status = "─"

        if exit_dt and r['dt'] == exit_dt:
            status = f"⏹️ EXIT @ {r['c']:.2f}"

        print(f"     {r['dt']:<16} {r['o']:>10.2f} {r['h']:>10.2f} {r['l']:>10.2f} {r['c']:>10.2f} {mfe_r:>5.2f}R {mae_r:>5.2f}R {status:<30}")

    # === VERIFY EXIT REASONS PER LEG ===
    print(f"\n  🔍 LEG-BY-LEG VERIFICATION:")
    pa = trade.get('pos_a', {})
    pb = trade.get('pos_b', {})
    pc = trade.get('pos_c', {})

    print(f"     A (1.2% risk = 60% of 2%):")
    print(f"       Entry: {pa.get('entry', '?')}")
    print(f"       SL: {pa.get('sl', '?')}")
    print(f"       TP1: {pa.get('tp1', '?')}")
    print(f"       Exit reason: {pa.get('exit_reason', '?')}")
    print(f"       PnL: {pa.get('pnl', '?')}")

    print(f"     B (0.6% risk = 30% of 2%):")
    print(f"       Entry: {pb.get('entry', '?')}")
    print(f"       SL: {pb.get('sl', '?')}")
    print(f"       TP2_price: {pb.get('tp2_price', '?')}")
    print(f"       Exit reason: {pb.get('exit_reason', '?')}")
    print(f"       PnL: {pb.get('pnl', '?')}")

    print(f"     C (0.2% risk = 10% of 2%):")
    print(f"       Entry: {pc.get('entry', '?')}")
    print(f"       SL: {pc.get('sl', '?')}")
    print(f"       TP3_price: {pc.get('tp3_price', '?')}")
    print(f"       Exit reason: {pc.get('exit_reason', '?')}")
    print(f"       PnL: {pc.get('pnl', '?')}")

    # === OVERALL PnL CHECK ===
    pnl_a = pa.get('pnl', 0) or 0
    pnl_b = pb.get('pnl', 0) or 0
    pnl_c = pc.get('pnl', 0) or 0
    pnl_sum = pnl_a + pnl_b + pnl_c
    reported_pnl = trade.get('pnl_pct', 0)

    print(f"\n  💵 PnL CHECK:")
    print(f"     A+B+C sum: {pnl_sum:+.4f}%")
    print(f"     Reported total: {reported_pnl:+.4f}%")
    match = abs(pnl_sum - reported_pnl) < 0.01
    print(f"     Match: {'✅ YES' if match else '❌ NO — MISMATCH!'}")

    # === MFE CHECK ===
    reported_mfe = trade.get('mfe_r', 0)
    calculated_mfe = (best_fav / risk) if risk > 0 else 0
    print(f"\n  📈 MFE CHECK:")
    print(f"     Reported MFE: {reported_mfe:.2f}R")
    print(f"     Calculated MFE (from raw OHLC): {calculated_mfe:.2f}R")
    mfe_match = abs(reported_mfe - calculated_mfe) < 0.05
    print(f"     Match: {'✅ YES' if mfe_match else '⚠️ CLOSE (within 0.05R)'}")

    print(f"  📉 MAE: {mae_r:.2f}R")
    print(f"  🎯 Best price (favorable): {entry_price + best_fav if is_long else entry_price - best_fav:.2f}")
    print(f"  🛑 Worst price (adverse): {entry_price - worst_adv if is_long else entry_price + worst_adv:.2f}")

# === RUN AUDIT ON EACH TRADE ===
print("\n" + "="*80)
print("  📋 DETAILED TRADE AUDIT — CANDLE BY CANDLE")
print("="*80)

for idx, trade in enumerate(trades, 1):
    audit_trade(trade, btc_nov_dec, idx)

# === SUMMARY VERIFICATION ===
print("\n" + "="*80)
print("  📊 FINAL SUMMARY VERIFICATION")
print("="*80)

# Recalculate from raw trades
total_pnl = 0
for t in trades:
    pa = t.get('pos_a', {}).get('pnl', 0) or 0
    pb = t.get('pos_b', {}).get('pnl', 0) or 0
    pc = t.get('pos_c', {}).get('pnl', 0) or 0
    total_pnl += pa + pb + pc

print(f"\n  Sum of all PnL (raw): {total_pnl:+.4f}%")
print(f"  Reported final return: {res['summary']['return_pct']:+.4f}%")
print(f"  Match: {'✅ YES' if abs(total_pnl - res['summary']['return_pct']) < 0.01 else '❌ NO'}")

# === ADDITIONAL CHECKS ===
print(f"\n  🔎 ADDITIONAL VERIFICATION:")
print(f"     All 7 trades: balance went from $100 to ${100 * (1 + res['summary']['return_pct']/100):.2f}")

# Check for any anomaly
print(f"\n  🚨 ANOMALY DETECTION:")
for idx, t in enumerate(trades, 1):
    # Check if entry price was actually hit
    entry_dt = t['entry_time']
    for r in btc_nov_dec:
        if r['dt'] == entry_dt:
            # Entry must be in candle range
            if not (r['l'] <= t['entry'] <= r['h']):
                print(f"     ⚠️ Trade #{idx}: Entry {t['entry']} NOT in candle range [{r['l']}, {r['h']}]")
            break

    # Check if MFE is reasonable
    if t.get('mfe_r', 0) > 20:
        print(f"     ⚠️ Trade #{idx}: Unusually high MFE {t['mfe_r']:.2f}R")

    # Check if exit time exists
    if not t.get('exit_time'):
        print(f"     ⚠️ Trade #{idx}: No exit time!")

print(f"\n  ✅ Audit complete — checked {len(trades)} trades against raw OHLC data")
