#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Matrix Einstein ONLY — Dec 2023 — BTC & ETH same month/year — Final Organized V2.1
$100 / 2% risk (A=1.2% B=0.6% C=0.2%)
All smart mods merged: Continuation LONG only + Harvest Gate Scale Shift + Determinism + Breaker
"""
import csv, datetime, sys, os
from collections import defaultdict
# Ensure core is in path — organized structure: src/runners -> ../core
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'core'))

from ict_sessions import classify_session
from ict_layered_brain import read_bias, read_bias_major, read_narrative, read_trigger, build_plan
from ict_math_engine import detect_ict_three_candle_swings, detect_breaker_block_opportunity
from ict_matrix_ride import manage_matrix_triple, entry_accumulation_filters, get_ny_day_key

# Data paths — try multiple locations for final zip portability
POSSIBLE_BTC = [
    "/home/user/raw_data/BTCUSDT_5m_2017-09-01_to_2025-09-23.csv",
    os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'BTCUSDT_5m_2017-09-01_to_2025-09-23.csv'),
    os.path.join(os.path.dirname(__file__), '..', '..', '..', 'raw_data', 'BTCUSDT_5m_2017-09-01_to_2025-09-23.csv'),
    "data/BTCUSDT_5m_2017-09-01_to_2025-09-23.csv",
]
POSSIBLE_ETH = [
    "/tmp/eth_3_2/ETHUSDT_5m.csv",
    os.path.join(os.path.dirname(__file__), '..', '..', 'data', 'ETHUSDT_5m.csv'),
    "data/ETHUSDT_5m.csv",
]

def pick_path(candidates):
    for p in candidates:
        if os.path.exists(p):
            return p
    return candidates[0]

BTC_PATH = pick_path(POSSIBLE_BTC)
ETH_PATH = pick_path(POSSIBLE_ETH)

RISK = 0.02
MONTH = "2023-07"

def load_btc():
    rows=[]
    with open(BTC_PATH) as f:
        r=csv.DictReader(f)
        for row in r:
            if not row['datetime'].startswith("2023-07") and not row['datetime'].startswith("2023-07"):
                continue
            dt_str=row['datetime'][:16]
            dt=datetime.datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
            rows.append({'ts':int(dt.replace(tzinfo=datetime.timezone.utc).timestamp()*1000),'dt':dt_str,'o':float(row['open']),'h':float(row['high']),'l':float(row['low']),'c':float(row['close']),'v':float(row['volume'])})
    return rows

def load_eth():
    rows=[]
    with open(ETH_PATH) as f:
        r=csv.DictReader(f)
        for row in r:
            dt_str=row.get('datetime')
            if not dt_str:
                vals=list(row.values())
                dt_str=vals[1]
            if not dt_str or (not dt_str.startswith("2023-07") and not dt_str.startswith("2023-07")):
                continue
            dt_str=dt_str[:16]
            try:
                dt=datetime.datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
            except:
                continue
            rows.append({'ts':int(dt.replace(tzinfo=datetime.timezone.utc).timestamp()*1000),'dt':dt_str,'o':float(row['open']),'h':float(row['high']),'l':float(row['low']),'c':float(row['close']),'v':float(row['volume'])})
    return rows

def slice_data(rows,end_idx,lookback):
    s=max(0,end_idx-lookback+1)
    ch=rows[s:end_idx+1]
    return {'timestamps':[r['ts'] for r in ch],'opens':[r['o'] for r in ch],'highs':[r['h'] for r in ch],'lows':[r['l'] for r in ch],'closes':[r['c'] for r in ch],'volumes':[r['v'] for r in ch]}

def aggregate(data,tf):
    n=len(data['closes'])
    ratio=tf//5
    if n<ratio:
        return None
    out={'timestamps':[],'opens':[],'highs':[],'lows':[],'closes':[],'volumes':[]}
    for i in range(n//ratio):
        a,b=i*ratio,(i+1)*ratio
        out['timestamps'].append(data['timestamps'][a])
        out['opens'].append(data['opens'][a])
        out['highs'].append(max(data['highs'][a:b]))
        out['lows'].append(min(data['lows'][a:b]))
        out['closes'].append(data['closes'][b-1])
        out['volumes'].append(sum(data['volumes'][a:b]))
    return out

def daily_ctx(rows, idx):
    by=defaultdict(lambda:{"h":-1e18,"l":1e18,"o":None})
    for r in rows[:idx+1]:
        k=get_ny_day_key(r['ts'])
        if by[k]['o'] is None:
            by[k]['o']=r['o']
        by[k]['h']=max(by[k]['h'],r['h'])
        by[k]['l']=min(by[k]['l'],r['l'])
    cur=get_ny_day_key(rows[idx]['ts'])
    completed=sorted(d for d in by if d<cur)
    ranges=[by[d]['h']-by[d]['l'] for d in completed[-10:]]
    return ranges, by[cur]['o'], by[cur]['h'], by[cur]['l'], cur

def midnight_open(rows, idx):
    cur=get_ny_day_key(rows[idx]['ts'])
    for i in range(idx,-1,-1):
        if get_ny_day_key(rows[i]['ts'])!=cur:
            return rows[i+1]['o'] if i+1<=idx else rows[idx]['o']
    return rows[0]['o']

def run(symbol, rows):
    start_idx=next(i for i,r in enumerate(rows) if r['dt'].startswith(MONTH))
    EXEC={"LONDON_KILLZONE","NY_AM_KILLZONE","NY_PM_KILLZONE"}
    balance=100.0
    trades=[]
    active=None
    entered=set()
    c1=c4=0
    rejected=0
    scans=0
    scan_log=[]
    for idx in range(start_idx, len(rows)):
        row=rows[idx]
        if not row['dt'].startswith(MONTH):
            break
        c1+=1; c4+=1
        if active:
            c5={'o':row['o'],'h':row['h'],'l':row['l'],'c':row['c']}
            c1h=c4h=None
            if c1>=12 and idx>=12:
                ch=rows[idx-11:idx+1]
                c1h={'o':ch[0]['o'],'h':max(x['h'] for x in ch),'l':min(x['l'] for x in ch),'c':row['c']}
                c1=0
            if c4>=48 and idx>=48:
                ch=rows[idx-47:idx+1]
                c4h={'o':ch[0]['o'],'h':max(x['h'] for x in ch),'l':min(x['l'] for x in ch),'c':row['c']}
                c4=0
            hist,d_o,d_h,d_l,dk=daily_ctx(rows,idx)
            ctx={"hist_ranges":hist,"day_open":d_o,"day_high":d_h,"day_low":d_l,"day_key":dk,"setup_start":active.get("setup_start"),"setup_end":active.get("setup_end")}
            is_short=active['is_short']
            entry=active['pos_a']['entry']
            if is_short:
                fav=entry-row['l']
                adv=row['h']-entry
            else:
                fav=row['h']-entry
                adv=entry-row['l']
            if active['risk']>0:
                active['mfe_r']=max(active.get('mfe_r',0), fav/active['risk'])
                active['mae_r']=max(active.get('mae_r',0), adv/active['risk'])
            events, closed = manage_matrix_triple(c5,c1h,c4h,active,day_ctx=ctx)
            if events:
                for e in events[-5:]:
                    active.setdefault("events", []).append(f"{row['dt']} {e}")
            if closed:
                pnl=active.get('pnl_pct') or 0
                usd=balance*pnl/100
                balance+=usd
                active['exit_time']=row['dt']
                active['pnl_pct']=pnl
                active['pnl_dollar']=usd
                active['balance_after']=balance
                trades.append(active)
                # Breaker Auto-Flip — safe, only on -2% early fail
                breaker_flipped=False
                try:
                    is_full_loss = pnl <= -1.9
                    is_early_fail = active.get('mfe_r',0) < 1.0 and 'ACCUMULATION' in str(active.get('market_phase',''))
                    sess_now = classify_session(row['ts'])
                    if is_full_loss and is_early_fail:
                        breaker_raw = slice_data(rows, idx, 300)
                        if breaker_raw and len(breaker_raw['closes'])>20:
                            inv_idx = len(breaker_raw['closes'])-1
                            orig_sl = active['pos_a'].get('sl') or 0
                            orig_is_long = not active['is_short']
                            breaker_res = detect_breaker_block_opportunity(breaker_raw, inv_idx, orig_sl, orig_is_long, lookback=150)
                            if breaker_res.get('opportunity_found') and breaker_res.get('plan'):
                                plan = breaker_res['plan']
                                is_long_new = plan['direction']=='BUY_LIMIT'
                                try:
                                    full_for_tp3 = slice_data(rows, idx, 20000)
                                    d1d_for_tp3 = aggregate(full_for_tp3, 1440)
                                    from ict_math_engine import detect_ict_three_candle_swings as detect_sw
                                    sw_daily = detect_sw(d1d_for_tp3) if d1d_for_tp3 else {'swing_highs':[],'swing_lows':[]}
                                except:
                                    sw_daily = {'swing_highs':[],'swing_lows':[]}
                                targs_new = sw_daily.get('swing_highs',[]) if is_long_new else sw_daily.get('swing_lows',[])
                                tp3_new=None
                                for s in targs_new:
                                    if (is_long_new and s['price']>plan['entry']+abs(plan['entry']-plan['stop_loss'])*5) or (not is_long_new and s['price']<plan['entry']-abs(plan['entry']-plan['stop_loss'])*5):
                                        tp3_new=s['price']; break
                                active = {
                                    'symbol':symbol,
                                    'entry_time':row['dt']+" (BREAKER_FLIP)",
                                    'session':sess_now['session'],
                                    'ny_time':sess_now['ny_time'],
                                    'signal_price':row['c'],
                                    'bias': 'BULLISH' if is_long_new else 'BEARISH',
                                    'bias_conf': 85,
                                    'bias_reason': f"BREAKER_BLOCK_AUTO_FLIP from failed {active.get('bias')} | {breaker_res.get('narrative','')[:120]}",
                                    'bias_zone': 'BREAKER',
                                    'sweep_quality': 90,
                                    'disp_conv': 85,
                                    'fvg_ce': plan['entry'],
                                    'entry': plan['entry'],
                                    'sl': plan['stop_loss'],
                                    'risk': abs(plan['entry']-plan['stop_loss']),
                                    'atr': 50,
                                    'sl_atr': 2.5,
                                    'tp1': plan.get('tp1') or {'price': plan['tp']},
                                    'tp2': plan.get('tp2'),
                                    'tp3': tp3_new,
                                    'is_short': not is_long_new,
                                    'risk_pct_a':0.02*100*0.6,
                                    'risk_pct_b':0.02*100*0.3,
                                    'risk_pct_c':0.02*100*0.1,
                                    'pos_a':{'active':True,'entry':plan['entry'],'sl':plan['stop_loss'],'tp1':plan['tp'],'tp1_hit':False,'pnl':0},
                                    'pos_b':{'active':True,'entry':plan['entry'],'sl':plan['stop_loss'],'tp2_price':plan.get('tp2',{}).get('price') if isinstance(plan.get('tp2'), dict) else None,'be_set':False,'pnl':0},
                                    'pos_c':{'active':True,'entry':plan['entry'],'sl':plan['stop_loss'],'tp3_price':tp3_new,'be_set':False,'pnl':0},
                                    'setup_start': plan['entry'],
                                    'setup_end': plan['stop_loss'],
                                    'mfe_r':0,'mae_r':0,'candle_count':0,
                                    'events':[f"{row['dt']} BREAKER_FLIP OPEN entry={plan['entry']} sl={plan['stop_loss']}"],
                                    'why': f"AUTO_FLIP: {breaker_res.get('narrative','')}",
                                    'is_breaker_flip': True,
                                }
                                c1=c4=0
                                breaker_flipped=True
                except Exception:
                    pass
                if not breaker_flipped:
                    active=None
            continue
        if idx%12!=0:
            continue
        sess=classify_session(row['ts'])
        if sess['session'] not in EXEC:
            continue
        scans+=1
        full=slice_data(rows, idx, 8000)
        d5=slice_data(rows, idx, 250)
        d15=aggregate(full,15)
        d4h=aggregate(full,240)
        d1d=aggregate(full,1440)
        if not d1d or len(d1d['closes'])<10 or not d15:
            continue
        bias=read_bias(d1d,d4h)
        if bias['direction'] not in ('BULLISH','BEARISH') or bias['confidence']<50:
            scan_log.append({'time':row['dt'],'reason':f"BIAS {bias['direction']} conf{bias['confidence']}<50"})
            continue
        narr=read_narrative(d15,bias['direction'])
        sweep_obj = narr.get('sweep') or {}
        if narr['state']!='SWEEP_FOUND' or sweep_obj.get('quality',0)<25:
            continue
        trig=read_trigger(d5,narr,bias['direction'])
        if not trig['ready']:
            continue
        plan=build_plan(d5,d1d,trig,narr,bias)
        if not plan:
            continue
        fk=(round(trig['fvg']['top'],2), round(trig['fvg']['bottom'],2))
        if fk in entered:
            continue
        is_long=bias['direction']=='BULLISH'
        mid=midnight_open(rows, idx)
        disp_score = float(trig['displacement']['conviction'])
        dealing_15m = narr.get('dealing_range')
        last_ob_held = True
        ok, reason = entry_accumulation_filters(is_long, plan['entry'], bias, mid, displacement_score=disp_score, dealing_15m=dealing_15m, last_ob_held=last_ob_held, current_price=plan['entry'])
        if not ok:
            rejected+=1
            continue
        entered.add(fk)
        from ict_math_engine import detect_ict_three_candle_swings as detect_sw2
        sw=detect_sw2(d1d)
        targs=sw['swing_highs'] if is_long else sw['swing_lows']
        tp3=None
        for s in targs:
            if (is_long and s['price']>plan['entry']+plan['risk']*5) or (not is_long and s['price']<plan['entry']-plan['risk']*5):
                tp3=s['price']; break
        ss,se = (min(narr['sweep']['wick_extreme'], plan['sl']), max(trig['fvg']['top'], plan['entry'])) if is_long else (max(narr['sweep']['wick_extreme'], plan['sl']), min(trig['fvg']['bottom'], plan['entry']))
        active={
            'symbol':symbol,'entry_time':row['dt'],'session':sess['session'],'ny_time':sess['ny_time'],'signal_price':row['c'],
            'bias':bias['direction'],'bias_conf':bias['confidence'],'bias_reason':bias['reason'],'bias_zone':(bias.get('dealing_range') or {}).get('zone'),
            'sweep_side':narr['sweep']['side'],'sweep_level':narr['sweep']['level'],'sweep_wick':narr['sweep']['wick_extreme'],'sweep_quality':narr['sweep']['quality'],
            'disp_dir':trig['displacement']['direction'],'disp_body_mult':float(trig['displacement']['body_multiple']),'disp_body_pct':float(trig['displacement']['body_pct']),'disp_conv':float(trig['displacement']['conviction']),
            'fvg_bottom':trig['fvg']['bottom'],'fvg_top':trig['fvg']['top'],'fvg_ce':trig['fvg']['ce'],
            'entry':plan['entry'],'sl':plan['sl'],'risk':plan['risk'],'atr':plan['atr'],'sl_atr':plan['sl_atr'],'tp1':plan['tp1'],'tp2':plan['tp2'],'tp3':tp3,
            'is_short': not is_long,'risk_pct_a':RISK*100*0.6,'risk_pct_b':RISK*100*0.3,'risk_pct_c':RISK*100*0.1,
            'pos_a':{'active':True,'entry':plan['entry'],'sl':plan['sl'],'tp1':plan['tp1']['price'],'tp1_hit':False,'pnl':0},
            'pos_b':{'active':True,'entry':plan['entry'],'sl':plan['sl'],'tp2_price':plan['tp2'].get('price') if isinstance(plan['tp2'], dict) else None,'be_set':False,'pnl':0},
            'pos_c':{'active':True,'entry':plan['entry'],'sl':plan['sl'],'tp3_price':tp3,'be_set':False,'pnl':0},
            'setup_start':ss,'setup_end':se,'mfe_r':0,'mae_r':0,'candle_count':0,
            'events':[f"{row['dt']} OPEN entry={plan['entry']} sl={plan['sl']} tp1={plan['tp1']['price']}"],
            'why':f"BIAS {bias['direction']} conf{bias['confidence']} zone={ (bias.get('dealing_range') or {}).get('zone')} | SWEEP {narr['sweep']['side']} Q{narr['sweep']['quality']}"
        }
        c1=c4=0
    summary={'symbol':symbol,'month':MONTH,'engine':'MATRIX_EINSTEIN V2.1','start':100,'end':round(balance,2),'return_pct':round((balance/100-1)*100,2),'trades':len(trades),'wins':len([t for t in trades if t.get('pnl_dollar',0)>0.01]),'losses':len([t for t in trades if t.get('pnl_dollar',0)<-0.01]),'scans':scans,'rejected_pd':rejected}
    return {'summary':summary,'trades':trades,'scans':scan_log}

def main():
    print("Loading BTC...")
    btc_rows=load_btc()
    print(f"BTC {len(btc_rows)} {btc_rows[0]['dt']}->{btc_rows[-1]['dt']}")
    print("Loading ETH...")
    eth_rows=load_eth()
    print(f"ETH {len(eth_rows)} {eth_rows[0]['dt']}->{eth_rows[-1]['dt']}")
    btc_res=run("BTCUSDT", btc_rows)
    eth_res=run("ETHUSDT", eth_rows)
    print("\n=== MATRIX ONLY DEC 2023 V2.1 FINAL ===")
    for res in [btc_res, eth_res]:
        s=res['summary']
        print(f"{s['symbol']} ${s['start']}->{s['end']} {s['return_pct']}% Trades={s['trades']} W={s['wins']} L={s['losses']} Scans={s['scans']} RejPD={s['rejected_pd']}")
        for t in res['trades']:
            print(f"  {t['entry_time']} {t['bias']} entry={t['entry']} PnL {t.get('pnl_pct'):+.3f}% MFE {t.get('mfe_r',0):.2f}R")
    import json, os
    out_path = os.path.join(os.path.dirname(__file__), '..', '..', 'matrix_dec2023_results.json')
    # fallback to local
    try:
        with open(out_path,"w") as f:
            json.dump({'BTC':btc_res,'ETH':eth_res}, f, indent=2, default=str)
        print(f"\nSaved {out_path}")
    except:
        with open("matrix_dec2023_results.json","w") as f:
            json.dump({'BTC':btc_res,'ETH':eth_res}, f, indent=2, default=str)
        print("\nSaved matrix_dec2023_results.json")

if __name__=="__main__":
    main()
