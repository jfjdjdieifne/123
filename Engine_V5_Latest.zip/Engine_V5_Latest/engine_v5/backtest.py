"""
Walk-forward backtest runner for Adaptive Narrative Engine V5.
No lookahead:
 - signals computed on closed bar i
 - fills at open i+1
 - trade management uses only closed bars after entry
 - conservative SL-first when SL and TP both inside same bar
"""

import json
import pandas as pd
import numpy as np
from typing import Dict, List

from .core import MarketMemory
from .strategy import AdaptiveNarrativeEngine, EngineConfig, TradePlan


def run_backtest(csv_path: str, cfg: EngineConfig, base_tf: str = "5m", htf_timeframes=("15m", "1h", "4h"), max_bars: int = None, btc_csv: str = None) -> Dict:
    df = pd.read_csv(csv_path)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df = df.sort_values("timestamp").reset_index(drop=True)
    if max_bars:
        df = df.iloc[:max_bars].reset_index(drop=True)

    memory = MarketMemory(df, htf_timeframes=htf_timeframes, base_tf=base_tf)
    engine = AdaptiveNarrativeEngine(memory, cfg)

    # BTC gravity score for alt assets: 24h return normalized by 24h range.
    if btc_csv:
        btc = pd.read_csv(btc_csv)
        btc["timestamp"] = pd.to_datetime(btc["timestamp"])
        btc = btc.sort_values("timestamp").reset_index(drop=True)
        if "BTC" not in str(csv_path).upper():
            window = 288 if base_tf == "5m" else 96
            btc["ret"] = btc["close"].pct_change(window)
            btc["rng"] = (btc["high"].rolling(window).max() - btc["low"].rolling(window).min()) / btc["close"]
            btc["score"] = (btc["ret"] / btc["rng"].replace(0, np.nan)).clip(-2, 2) / 2.0
            merged = pd.merge_asof(df[["timestamp"]], btc[["timestamp", "score"]], on="timestamp", direction="backward")
            engine.btc_score_by_index = merged["score"].fillna(0.0).to_numpy()

    n = len(df)
    for i in range(30, n - 1):
        # fill pending confirmation orders using bar i high/open
        engine.process_pending(i)
        # manage existing trades on closed bar i
        engine.manage_trades(i)
        # consider new signal on closed bar i
        active_plus_pending = len(engine.open_trades) + len(engine.pending_trades)
        if active_plus_pending < cfg.max_open_trades:
            plan = engine.generate_signal(i)
            if plan is not None:
                engine.add_pending(plan)
        equity = engine.balance
        for t in engine.open_trades:
            equity += t.quantity * df['close'].iloc[i]
        engine.equity_curve.append({"time": str(df['timestamp'].iloc[i]), "balance": equity})

    # close any remaining at last close
    if engine.open_trades:
        last_i = n - 1
        last_close = float(df["close"].iloc[last_i])
        for t in list(engine.open_trades):
            engine._close_trade(t, last_i, last_close, "END_OF_DATA")

    return summarize(engine, df)


def summarize(engine: AdaptiveNarrativeEngine, df: pd.DataFrame) -> Dict:
    trades = engine.trades
    rows: List[Dict] = []
    for t in trades:
        rows.append({
            "signal_time": str(t.signal_time),
            "entry_time": str(t.entry_time),
            "map": t.map_type,
            "tier": t.tier,
            "entry": round(t.entry, 6),
            "stop_initial": round(t.stop_initial, 6),
            "stop_final": round(t.stop_current, 6),
            "targets": ";".join([f"{z['type']}:{round(z['price'],6)}" for z in t.targets[:4]]),
            "quantity": t.quantity if t.quantity > 0 else None,
            "cash_used": round(t.cash_used, 4),
            "planned_loss_usd": round(t.planned_loss_usd, 4),
            "net_rr_primary": round(t.net_rr_primary, 4),
            "probability": round(t.probability, 4),
            "expected_r": round(t.expected_r, 4),
            "context": round(t.score_components["context"], 4),
            "wave": round(t.score_components["wave"], 4),
            "location": round(t.score_components["location"], 4),
            "execution": round(t.score_components["execution"], 4),
            "objective": round(t.score_components["objective"], 4),
            "rr_eff": round(t.score_components["rr_efficiency"], 4),
            "exit_time": str(t.exit_time),
            "exit_price": t.exit_price,
            "exit_reason": t.exit_reason,
            "realized_pnl": round(t.realized_pnl, 6),
            "bars_held": t.bars_held,
            "mfe": round(t.mfe, 6),
            "mae": round(t.mae, 6),
            "narrative": t.narrative,
        })
    closed = [t for t in trades if t.state == "CLOSED"]
    wins = [t for t in closed if t.realized_pnl > 0]
    losses = [t for t in closed if t.realized_pnl <= 0]
    pnl = sum(t.realized_pnl for t in closed)
    gross_win = sum(t.realized_pnl for t in wins)
    gross_loss = abs(sum(t.realized_pnl for t in losses))
    expectancy_r = np.mean([t.realized_pnl / max(t.planned_loss_usd, 1e-9) for t in closed]) if closed else 0.0

    return {
        "starting_balance": engine.cfg.balance,
        "ending_balance": round(engine.balance, 6),
        "net_pnl": round(pnl, 6),
        "return_pct": round((engine.balance / engine.cfg.balance - 1.0) * 100.0, 4),
        "trades": len(closed),
        "wins": len(wins),
        "losses": len(losses),
        "win_rate": round(len(wins) / len(closed) * 100.0, 2) if closed else 0.0,
        "profit_factor": round(gross_win / gross_loss, 4) if gross_loss > 0 else None,
        "expectancy_R": round(float(expectancy_r), 4),
        "avg_bars_held": round(float(np.mean([t.bars_held for t in closed])), 2) if closed else 0.0,
        "by_tier": _by_key(closed, "tier"),
        "by_map": _by_key(closed, "map_type"),
        "by_exit": _by_key(closed, "exit_reason"),
        "max_drawdown_pct": _max_drawdown(engine.equity_curve),
        "rejections_sample": engine.rejections[-20:],
        "trades_detail": rows,
    }


def _by_key(trades: List[TradePlan], attr: str) -> Dict:
    out = {}
    for t in trades:
        k = getattr(t, attr)
        if k not in out:
            out[k] = {"count": 0, "pnl": 0.0, "wins": 0}
        out[k]["count"] += 1
        out[k]["pnl"] += t.realized_pnl
        if t.realized_pnl > 0:
            out[k]["wins"] += 1
    for k in out:
        out[k]["pnl"] = round(out[k]["pnl"], 6)
        out[k]["win_rate"] = round(out[k]["wins"] / out[k]["count"] * 100, 2) if out[k]["count"] else 0.0
    return out


def _max_drawdown(equity_curve: List[Dict]) -> float:
    if not equity_curve:
        return 0.0
    balances = np.array([z["balance"] for z in equity_curve], dtype=float)
    peak = np.maximum.accumulate(balances)
    dd = (balances - peak) / np.maximum(peak, 1e-12)
    return round(float(dd.min() * 100.0), 4)
