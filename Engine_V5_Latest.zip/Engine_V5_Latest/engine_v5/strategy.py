"""
Adaptive Narrative Strategy V5
==============================

Instead of brittle vetoes, the engine computes a weighted narrative score:
  Context * Intent * Location * Execution * Objective * Risk Efficiency
and converts it into probability and position size.

Weakness does not automatically kill a trade; it shrinks expectancy and size.
Only impossible/unsafe conditions collapse size to zero.

Spot long only. Entries are evaluated on closed bar i and filled at open i+1.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Tuple
import numpy as np

from .core import (
    MarketMemory,
    ProtectedLow,
    SetupWave,
    Swing,
    FEE,
    SLIPPAGE_BPS,
    clip01,
    sigmoid,
)


@dataclass
class EngineConfig:
    balance: float = 100.0
    base_risk_usd: float = 1.0
    cash_reserve: float = 0.05
    min_notional_usd: float = 10.0
    max_open_trades: int = 3
    allow_map1: bool = True
    allow_map2: bool = True
    setup_expiry_bars: int = 120
    min_expected_r: float = 0.28
    tier_min_rr: Tuple[float, float, float] = (1.25, 1.90, 2.70)  # A scalp, B intraday, C swing
    tier_names: Tuple[str, str, str] = ("SCALP_A", "INTRADAY_B", "SWING_C")
    use_partial_tp: bool = True
    partial_tp_fraction: float = 0.60
    escape_cvd_slope_threshold: float = 0.0
    verbose: bool = False


@dataclass
class TradePlan:
    signal_index: int
    signal_time: object
    entry_index: Optional[int]
    entry_time: object
    map_type: str
    tier: str
    entry: float
    stop_initial: float
    targets: List[Dict]
    quantity: float
    cash_used: float
    planned_loss_usd: float
    net_rr_primary: float
    probability: float
    expected_r: float
    score_components: Dict[str, float]
    narrative: str
    trigger_price: float = 0.0
    pending_expires: int = 0
    is_pending: bool = True
    state: str = "PENDING"
    filled_quantity: float = 0.0
    realized_pnl: float = 0.0
    stop_current: float = 0.0
    tp1_hit: bool = False
    exit_index: Optional[int] = None
    exit_time: object = None
    exit_price: Optional[float] = None
    exit_reason: Optional[str] = None
    bars_held: int = 0
    mfe: float = 0.0
    mae: float = 0.0
    wave: Optional[SetupWave] = None


class AdaptiveNarrativeEngine:
    """
    The engine's brain. It tracks protected lows, structural breaks, dealing ranges,
    PD arrays and liquidity draws, then produces weighted long-only plans.
    """

    def __init__(self, memory: MarketMemory, cfg: EngineConfig):
        self.m = memory
        self.cfg = cfg
        self.protected_lows: List[ProtectedLow] = []
        self.waves: List[SetupWave] = []
        self.trades: List[TradePlan] = []
        self.open_trades: List[TradePlan] = []
        self.balance = cfg.balance
        self.equity_curve = []
        self.rejections = []
        self.outcomes_for_calibration: List[Tuple[np.ndarray, float]] = []
        self.traded_wave_ids = set()
        self.last_signal_index = -1000
        self.last_loss_index = -1000
        self.pending_trades: List[TradePlan] = []
        self.btc_score_by_index: Optional[np.ndarray] = None

    # ------------------------------------------------------------------
    # Feature readers at bar i
    # ------------------------------------------------------------------

    def _base(self, i: int):
        b = self.m.base
        return {
            "open": b.open[i],
            "high": b.high[i],
            "low": b.low[i],
            "close": b.close[i],
            "volume": b.volume[i],
            "atr": max(float(b.atr[i]), 1e-12),
            "close_pos": float(b.close_pos[i]),
            "lower_wick": float(b.lower_wick[i]),
            "upper_wick": float(b.upper_wick[i]),
            "body": float(b.body[i]),
            "range": float(b.rng[i]),
            "vol_z": float(b.vol_z[i]) if not np.isnan(b.vol_z[i]) else 0.0,
            "cvd_slope5": float(b.cvd_slope5[i]) if not np.isnan(b.cvd_slope5[i]) else 0.0,
            "cvd_slope10": float(b.cvd_slope10[i]) if not np.isnan(b.cvd_slope10[i]) else 0.0,
            "price_slope": float(b.price_slope_norm[i]) if not np.isnan(b.price_slope_norm[i]) else 0.0,
            "disp_up": float(b.displacement_up[i]),
            "disp_dn": float(b.displacement_dn[i]),
            "sma20": float(b.sma20[i]),
            "sma50": float(b.sma50[i]),
            "atr_pct": float(b.atr_pct[i]),
            "ts": b.ts[i],
        }

    def _htf_structure(self, i: int, tf: str = "4h") -> Dict:
        tfd = self.m.htfs.get(tf)
        if tfd is None:
            return {"trend": "unknown", "score": 0.4, "draw_above": None, "draw_below": None}
        known_count = int(tfd.known_base_count[i])
        if known_count < 5:
            return {"trend": "unknown", "score": 0.4, "draw_above": None, "draw_below": None}
        highs = [s for s in tfd.swings if s.kind == "high" and s.known_index <= i]
        lows = [s for s in tfd.swings if s.kind == "low" and s.known_index <= i]
        trend = "range"
        score = 0.45
        if len(highs) >= 2 and len(lows) >= 2:
            hh = highs[-1].price > highs[-2].price
            hl = lows[-1].price > lows[-2].price
            lh = highs[-1].price < highs[-2].price
            ll = lows[-1].price < lows[-2].price
            if hh and hl:
                trend = "bullish"
                score = 0.85
            elif lh and ll:
                trend = "bearish"
                score = 0.15
            else:
                trend = "transitional"
                score = 0.5
        # momentum overlay
        k = known_count - 1
        mom = float(tfd.price_slope_norm[k]) if not np.isnan(tfd.price_slope_norm[k]) else 0.0
        score = clip01(score + 0.15 * np.tanh(mom / 1.5))
        # draws on liquidity
        price = float(self.m.base.close[i])
        bsl = [p.price for p in tfd.pools if p.kind == "BSL" and p.known_index <= i and p.price > price and (p.swept_index is None or p.swept_index > i)]
        ssl = [p.price for p in tfd.pools if p.kind == "SSL" and p.known_index <= i and p.price < price and (p.swept_index is None or p.swept_index > i)]
        draw_above = min(bsl) if bsl else None
        draw_below = max(ssl) if ssl else None
        return {"trend": trend, "score": score, "draw_above": draw_above, "draw_below": draw_below, "mom": mom}

    # ------------------------------------------------------------------
    # Structural state updates
    # ------------------------------------------------------------------

    def update_protected_lows(self, i: int):
        b = self.m.base
        # Confirm new base lows as protected-low candidates when their pivot is known now.
        for s in b.swings:
            if s.kind != "low" or s.known_index != i:
                continue
            k = s.index
            if k < 10 or k >= i:
                continue
            # rejection relative to previous 30 lower wicks
            start = max(0, k - 30)
            wicks = b.lower_wick[start:k]
            avg_wick = float(np.mean(wicks)) if len(wicks) else 0.0
            cand_wick = float(b.lower_wick[k])
            rej_ratio = cand_wick / max(avg_wick, 1e-12)
            vol_z = float(b.vol_z[k]) if not np.isnan(b.vol_z[k]) else 0.0
            # CVD absorption/divergence: price made lower low but CVD slope over last 5/10 not confirming
            price_lower = s.price < min(b.low[max(0, k - 10) : k]) if k > 0 else False
            cvd_s5 = float(b.cvd_slope5[k]) if not np.isnan(b.cvd_slope5[k]) else 0.0
            cvd_s10 = float(b.cvd_slope10[k]) if not np.isnan(b.cvd_slope10[k]) else 0.0
            # normalize CVD slope by average volume
            avg_vol = float(np.mean(b.volume[max(0, k - 20) : k])) if k > 0 else 1.0
            cvd_norm = (cvd_s5 + 0.5 * cvd_s10) / max(avg_vol, 1e-12)
            divergence = 0.0
            if price_lower and cvd_norm > -0.02:
                divergence = clip01(0.5 + 10 * cvd_norm)
            close_pos = float(b.close_pos[k])
            quality = clip01(
                0.30 * sigmoid(rej_ratio, 1.5, 2.0)
                + 0.20 * sigmoid(vol_z, 0.0, 2.0)
                + 0.20 * divergence
                + 0.15 * sigmoid(close_pos, 0.55, 6.0)
                + 0.15 * sigmoid(-float(b.displacement_dn[k]), 0.5, 2.0)
            )
            self.protected_lows.append(
                ProtectedLow(
                    price=float(s.price),
                    index=k,
                    known_index=i,
                    atr=float(s.atr),
                    rejection_ratio=rej_ratio,
                    volume_z=vol_z,
                    cvd_divergence=divergence,
                    quality=quality,
                )
            )
        # Invalidation and BOS confirmation
        curr = self._base(i)
        for pl in self.protected_lows:
            if pl.invalid or pl.bos_index is not None:
                continue
            if i <= pl.known_index:
                continue
            # invalid if body closes below low
            if curr["close"] < pl.price - 0.05 * curr["atr"]:
                pl.invalid = True
                pl.invalidated_index = i
                continue
            # candidate highs after protected low known
            highs_after = [s for s in b.swings if s.kind == "high" and s.known_index > pl.known_index and s.known_index < i and s.index > pl.index]
            if not highs_after:
                continue
            level = highs_after[-1].price
            # BOS quality: body close above level, displacement, volume, close position, upper wick not dominant
            if curr["close"] > level:
                disp_margin = (curr["close"] - level) / curr["atr"]
                upper_wick_ratio = curr["upper_wick"] / max(curr["range"], 1e-12)
                body_ratio = curr["body"] / max(curr["range"], 1e-12)
                bos_quality = clip01(
                    0.25 * sigmoid(disp_margin, 0.15, 8.0)
                    + 0.20 * sigmoid(curr["vol_z"], 0.5, 2.5)
                    + 0.20 * sigmoid(curr["close_pos"], 0.65, 8.0)
                    + 0.20 * sigmoid(body_ratio, 0.55, 6.0)
                    + 0.15 * sigmoid(-upper_wick_ratio, -0.35, 6.0)
                )
                # If break is weak, do not hard reject; store lower quality wave.
                if bos_quality > 0.15:
                    term = float(max(curr["high"], max(b.high[pl.index : i + 1])))
                    term_index = int(pl.index + np.argmax(b.high[pl.index : i + 1]))
                    pl.bos_index = i
                    pl.bos_level = float(level)
                    pl.term = term
                    pl.term_index = term_index
                    pl.impulse_quality = bos_quality
                    rng = max(term - pl.price, 1e-12)
                    # Map type by HTF context
                    htf4 = self._htf_structure(i, "4h")
                    htf1 = self._htf_structure(i, "1h")
                    map_type = "MAP1_PRO_TREND" if (htf4["trend"] in ("bullish", "transitional", "range") and htf4["score"] >= 0.45) else "MAP2_COUNTER_TREND"
                    if htf4["trend"] == "bearish" and htf1["score"] < 0.45:
                        map_type = "MAP2_COUNTER_TREND"
                    wave_quality = clip01(0.45 * pl.quality + 0.55 * bos_quality)
                    self.waves.append(
                        SetupWave(
                            origin=pl.price,
                            origin_index=pl.index,
                            term=term,
                            term_index=term_index,
                            bos_level=float(level),
                            bos_index=i,
                            range=rng,
                            impulse_quality=bos_quality,
                            map_type=map_type,
                            quality=wave_quality,
                            expires_index=i + self.cfg.setup_expiry_bars,
                        )
                    )

    def _expire_waves(self, i: int):
        self.waves = [w for w in self.waves if w.expires_index >= i and not (w.term < w.origin)]

    # ------------------------------------------------------------------
    # Location / execution / objective scoring
    # ------------------------------------------------------------------

    def _adaptive_buy_zone(self, wave: SetupWave) -> Tuple[float, float, float]:
        """
        Returns zone_low, zone_high, sweet.
        Strong impulse => shallow institutional re-entry 38-55% retracement.
        Normal impulse => ICT OTE 62-79%.
        Weak impulse => deeper 70-88% to avoid paying premium in weak trend.
        """
        q = wave.impulse_quality
        term = wave.term
        rng = wave.range
        if q > 0.75:
            r_low, r_high = 0.35, 0.58
        elif q > 0.45:
            r_low, r_high = 0.55, 0.79
        else:
            r_low, r_high = 0.70, 0.88
        zone_high = term - rng * r_low  # smaller retracement = higher price
        zone_low = term - rng * r_high
        sweet = term - rng * ((r_low + r_high) / 2.0)
        return float(zone_low), float(zone_high), float(sweet)

    def _pd_array_in_zone(self, i: int, zone_low: float, zone_high: float, wave: SetupWave) -> Tuple[Optional[Dict], float]:
        arrays = self.m.known_pd_arrays(i, "bullish", zone_low, zone_high, tfs=("5m", "15m", "1h"))
        if not arrays:
            return None, 0.0
        best = None
        best_score = -1.0
        for obj in arrays:
            overlap_low = max(obj.low, zone_low)
            overlap_high = min(obj.high, zone_high)
            overlap = max(0.0, overlap_high - overlap_low)
            obj_width = max(obj.high - obj.low, 1e-12)
            overlap_ratio = overlap / obj_width
            ce = obj.ce
            freshness = 1.0
            if hasattr(obj, "known_index"):
                age = max(0, i - obj.known_index)
                freshness = float(np.exp(-age / 250.0))
            score = 0.45 * overlap_ratio + 0.35 * obj.quality + 0.20 * freshness
            if score > best_score:
                best_score = score
                best = {
                    "obj": obj,
                    "level": float(ce if overlap_ratio < 0.25 else overlap_high),
                    "overlap_ratio": float(overlap_ratio),
                    "quality": float(obj.quality),
                    "freshness": freshness,
                    "score": float(score),
                }
        return best, clip01(best_score)

    def _execution_score(self, i: int, zone_low: float, zone_high: float, wave: SetupWave) -> Tuple[float, Dict]:
        curr = self._base(i)
        in_zone = not (curr["high"] < zone_low or curr["low"] > zone_high)
        touch = curr["low"] <= zone_high and curr["close"] >= zone_low * 0.995
        close_pos = curr["close_pos"]
        lower_wick_ratio = curr["lower_wick"] / max(curr["range"], 1e-12)
        body_ratio = curr["body"] / max(curr["range"], 1e-12)
        rejection = clip01(0.5 * sigmoid(close_pos, 0.60, 7.0) + 0.5 * sigmoid(lower_wick_ratio, 0.25, 6.0))
        # effort vs result: healthy if volume not dead and body/range not extreme churn
        vol_health = sigmoid(curr["vol_z"], -0.2, 2.5)
        churn_penalty = sigmoid(curr["vol_z"] - 2.5 * body_ratio, 1.0, 2.0)  # huge vol tiny body
        effort = clip01(0.7 * vol_health - 0.35 * churn_penalty + 0.15)
        # CVD absorption: during pullback, CVD slope should flatten/turn up while price dips
        cvd_turn = clip01(0.55 * sigmoid(curr["cvd_slope5"], 0.0, 25.0 / max(curr["atr"], 1e-12)) + 0.45 * sigmoid(curr["cvd_slope10"], 0.0, 15.0 / max(curr["atr"], 1e-12)))
        # third-bar filter: if last 3 bars are aggressive red with expanding bodies, execution is poor
        b = self.m.base
        if i >= 3:
            red_bodies = np.maximum(b.open[i - 2 : i + 1] - b.close[i - 2 : i + 1], 0.0)
            red_expanding = red_bodies[-1] > red_bodies[-2] > red_bodies[-3] if len(red_bodies) == 3 else False
            vol_expanding = b.volume[i] > b.volume[i - 1] > b.volume[i - 2]
            aggressive_sell = red_expanding and vol_expanding and curr["close_pos"] < 0.35
        else:
            aggressive_sell = False
        sell_pressure_penalty = 0.45 if aggressive_sell else 0.0
        raw = 0.30 * rejection + 0.25 * effort + 0.30 * cvd_turn + 0.15 * (1.0 if in_zone else 0.4 if touch else 0.0)
        score = clip01(raw - sell_pressure_penalty)
        details = {
            "in_zone": bool(in_zone),
            "touch": bool(touch),
            "close_pos": close_pos,
            "lower_wick_ratio": lower_wick_ratio,
            "vol_z": curr["vol_z"],
            "cvd_slope5": curr["cvd_slope5"],
            "cvd_turn": cvd_turn,
            "aggressive_sell": aggressive_sell,
        }
        return score, details

    def _objective_ladder(self, i: int, entry: float, stop: float, wave: SetupWave, tier_idx: int) -> Tuple[List[Dict], Dict, float]:
        """
        Builds a causal draw-on-liquidity ladder.
        Projections are allowed as planning magnetics only when the impulse earned them,
        and their quality is lower than real resting liquidity/PD arrays.
        Returns sorted-by-price objectives, best primary objective, and aggregate quality.
        """
        objs = self.m.known_objectives_above(i, entry)
        term = wave.term
        rng = wave.range
        atr = max(float(self.m.base.atr[i]), 1e-12)
        # Earned projections: strong displacement may target symmetric expansion.
        if wave.impulse_quality > 0.55:
            projected = [
                {"price": float(term), "type": "wave_term", "tf": "setup", "strength": 2},
                {"price": float(term + 0.27 * rng), "type": "ict_projection_-0.27", "tf": "setup", "strength": 1},
            ]
            if wave.impulse_quality > 0.75:
                projected.append({"price": float(term + 0.62 * rng), "type": "ict_projection_-0.62", "tf": "setup", "strength": 1})
        else:
            projected = [{"price": float(term), "type": "wave_term", "tf": "setup", "strength": 1}]
        for p in projected:
            near = [o for o in objs if abs(o["price"] - p["price"]) <= 0.35 * atr]
            if near:
                for n in near:
                    n["strength"] += 1
                    n["type"] = n["type"] + "+" + p["type"]
            else:
                objs.append(p)
        objs = [o for o in objs if o["price"] > entry * (1 + FEE + SLIPPAGE_BPS / 10000)]
        # enrich quality and net rr
        loss_per_coin = entry * (1 + FEE) - stop * (1 - FEE)
        for o in objs:
            dist_atr = (o["price"] - entry) / atr
            tf_weight = {"5m": 0.55, "15m": 0.7, "1h": 0.85, "4h": 1.0, "setup": 0.55}.get(o.get("tf", "setup"), 0.55)
            reward_per_coin = o["price"] * (1 - FEE) - entry * (1 + FEE)
            o["net_rr"] = float(reward_per_coin / loss_per_coin) if loss_per_coin > 0 else -1.0
            projection_penalty = 0.35 if "projection" in o["type"] else 0.0
            o["quality"] = clip01(
                0.40 * min(o.get("strength", 1), 4) / 4.0
                + 0.30 * tf_weight
                + 0.20 * sigmoid(dist_atr, 2.0, 0.35)
                + 0.10 * sigmoid(o["net_rr"], 1.5, 1.2)
                - projection_penalty
            )
        objs.sort(key=lambda z: z["price"])
        if not objs:
            return [], {}, 0.0
        # primary objective: not necessarily nearest. It must have acceptable RR/quality tradeoff.
        min_rr = self.cfg.tier_min_rr[tier_idx]
        acceptable = [o for o in objs if o["net_rr"] >= 0.75 * min_rr and o["quality"] > 0.25]
        if not acceptable:
            acceptable = objs
        primary = max(acceptable, key=lambda o: 0.55 * o["quality"] + 0.45 * sigmoid(o["net_rr"], min_rr, 1.5))
        ladder_quality = clip01(np.mean([o["quality"] for o in objs[:4]]))
        return objs, primary, ladder_quality

    def _choose_tier(self, wave: SetupWave, net_rr: float, objective_quality: float, context_score: float) -> Tuple[int, str]:
        # Tier A: fast, small RR but high execution/context.
        # Tier B: standard intraday. Tier C: swing with HTF draw.
        if wave.map_type == "MAP2_COUNTER_TREND":
            idx = 0 if net_rr < 2.0 else 1
        else:
            if net_rr >= self.cfg.tier_min_rr[2] and context_score > 0.65 and objective_quality > 0.55:
                idx = 2
            elif net_rr >= self.cfg.tier_min_rr[1] or (context_score > 0.6 and objective_quality > 0.5):
                idx = 1
            else:
                idx = 0
        return idx, self.cfg.tier_names[idx]

    # ------------------------------------------------------------------
    # Probability / sizing
    # ------------------------------------------------------------------

    def _probability(self, components: Dict[str, float], net_rr: float, tier_idx: int) -> float:
        weights = {
            "context": 0.20,
            "wave": 0.20,
            "location": 0.20,
            "execution": 0.20,
            "objective": 0.12,
            "rr_efficiency": 0.08,
        }
        base = sum(weights[k] * components[k] for k in weights)
        # conservative structural prior: most raw patterns fail; high scores must earn probability
        base = clip01(0.18 + 0.72 * base)
        # calibrated online using realized outcomes: simple Bayesian shrinkage toward actual edge
        if len(self.outcomes_for_calibration) >= 25:
            X = np.array([x for x, _ in self.outcomes_for_calibration][-200:])
            y = np.array([y for _, y in self.outcomes_for_calibration][-200:])
            feats = np.array([
                components["context"],
                components["wave"],
                components["location"],
                components["execution"],
                components["objective"],
                min(net_rr / 5.0, 1.0),
                tier_idx / 2.0,
            ])
            p = self._logistic_probability(X, y, feats)
            # blend model and structural score
            return clip01(0.65 * p + 0.35 * base)
        return clip01(0.25 + 0.70 * base)

    @staticmethod
    def _logistic_probability(X, y, feats):
        # lightweight online logistic via closed-form ridge-ish gradient steps; avoids heavy dependencies
        w = np.zeros(X.shape[1] + 1)
        Xb = np.hstack([X, np.ones((X.shape[0], 1))])
        feats_b = np.append(feats, 1.0)
        lr = 0.08
        for _ in range(60):
            z = Xb @ w
            p = 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))
            grad = Xb.T @ (p - y) / len(y) + 0.02 * w
            w -= lr * grad
        z = float(feats_b @ w)
        return float(1.0 / (1.0 + np.exp(-np.clip(z, -30, 30))))

    def _risk_plan(self, entry: float, stop: float, target: float, probability: float, expected_r: float, components: Dict[str, float]) -> Dict:
        slip = entry * SLIPPAGE_BPS / 10000.0
        eff_entry = entry + slip
        loss_per_coin = eff_entry * (1 + FEE) - stop * (1 - FEE)
        reward_per_coin = target * (1 - FEE) - eff_entry * (1 + FEE)
        net_rr = reward_per_coin / loss_per_coin if loss_per_coin > 0 else -1.0
        # confidence multiplier: not a veto, just size elasticity
        quality = clip01(
            0.25 * components["context"]
            + 0.20 * components["wave"]
            + 0.20 * components["location"]
            + 0.20 * components["execution"]
            + 0.15 * components["objective"]
        )
        risk_mult = 0.25 + 1.75 * quality  # 0.25x to 2.0x base risk
        allowed_loss = self.cfg.base_risk_usd * risk_mult
        # Capital deployment ceiling: even high-confidence spot trades should not lock all account cash.
        # This allows multiple concurrent ideas and avoids one trade starving the engine.
        max_alloc_fraction = 0.35
        spendable = min(self.balance * (1 - self.cfg.cash_reserve), self.cfg.balance * max_alloc_fraction * (0.5 + quality))
        qty_by_risk = allowed_loss / max(loss_per_coin, 1e-12)
        qty_by_cash = spendable / max(eff_entry * (1 + FEE), 1e-12)
        qty = max(0.0, min(qty_by_risk, qty_by_cash))
        cash_used = qty * eff_entry * (1 + FEE)
        planned_loss = qty * loss_per_coin
        return {
            "net_rr": float(net_rr),
            "quantity": float(qty),
            "cash_used": float(cash_used),
            "planned_loss": float(planned_loss),
            "allowed_loss": float(allowed_loss),
            "risk_mult": float(risk_mult),
            "eff_entry": float(eff_entry),
        }

    # ------------------------------------------------------------------
    # Signal generation
    # ------------------------------------------------------------------

    def generate_signal(self, i: int) -> Optional[TradePlan]:
        if i < 30 or i >= self.m.n - 1:
            return None
        self.update_protected_lows(i)
        self._expire_waves(i)
        if len(self.open_trades) >= self.cfg.max_open_trades:
            return None
        # anti-machine-gun: small breathing space, not a cage
        if i - self.last_signal_index < 2:
            return None
        if i - self.last_loss_index < 6:
            return None
        curr = self._base(i)

        # BTC gravity: alts cannot reliably long when BTC order flow is heavy down.
        btc_score = 0.0
        if self.btc_score_by_index is not None and i < len(self.btc_score_by_index):
            btc_score = float(self.btc_score_by_index[i])
        if btc_score < -0.25:
            return None

        # Highest conviction first: fresh sell-side liquidity sweep + bullish displacement + value retest.
        sweep_plan = self._evaluate_sweep_reversal(i, curr)
        if sweep_plan is not None:
            return sweep_plan

        if not self.waves:
            return None
        # evaluate strongest untraded wave; do not collapse all possibility into one object
        candidate_waves = [w for w in self.waves if id(w) not in self.traded_wave_ids]
        if not candidate_waves:
            return None
        candidate_waves.sort(key=lambda w: w.quality, reverse=True)
        for wave in candidate_waves:
            plan = self._evaluate_wave(i, wave, curr)
            if plan is not None:
                return plan
        return None

    def _evaluate_sweep_reversal(self, i: int, curr: Dict) -> Optional[TradePlan]:
        """
        Classic institutional long:
        1) SSL below an obvious low is swept and price closes back above.
        2) Bullish displacement follows, leaving imbalance.
        3) Price retraces into CE/discount of the displacement and reclaims.
        Target is buy-side liquidity above.
        """
        b = self.m.base
        # recent swept SSL pools within last 36 bars
        sweeps = [
            p for p in self.m.all_pools
            if p.kind == "SSL" and p.swept_index is not None and 0 <= i - p.swept_index <= 36 and p.price < curr["close"]
        ]
        if not sweeps:
            return None
        sweep = max(sweeps, key=lambda p: p.strength)
        sweep_idx = int(sweep.swept_index)
        if sweep_idx >= i:
            return None
        # need bullish displacement after sweep: at least one 3-bar up displacement > 1.2 ATR and body dominance
        disp_window = range(max(sweep_idx + 1, i - 12), i + 1)
        disp_candidates = [k for k in disp_window if b.displacement_up[k] > 1.2]
        if not disp_candidates:
            return None
        # HTF/LTF context before wasting computation: long sweep reversals need LTF order-flow improvement and not bearish HTF.
        htf4 = self._htf_structure(i, "4h")
        htf1 = self._htf_structure(i, "1h")
        if htf1["score"] < 0.55 or htf4["score"] < 0.35:
            return None
        disp_idx = max(disp_candidates)
        disp_strength = float(b.displacement_up[disp_idx])
        # displacement must carry volume, not thin drift
        if float(b.vol_z[disp_idx]) < 0.25:
            return None
        # displacement leg from lowest low after sweep to high at/after disp
        seg_low = float(np.min(b.low[sweep_idx : i + 1]))
        seg_high = float(np.max(b.high[disp_idx : i + 1]))
        rng = max(seg_high - seg_low, 1e-12)
        ce = (seg_high + seg_low) / 2.0
        # ICT execution: the displacement leaves CE as the mean threshold. We want a touch/reaction there.
        # If bar closes back above CE: market leg. If it merely taps CE but does not close far below: limit fill proxy.
        close_above_ce = curr["close"] > ce
        tapped_ce = curr["low"] <= ce + 0.10 * curr["atr"] and curr["close"] >= ce - 0.35 * curr["atr"]
        if close_above_ce and curr["close_pos"] > 0.55:
            entry = float(curr["close"])
            trigger_price = entry
        elif tapped_ce:
            entry = float(min(curr["open"], ce))
            trigger_price = float(ce)
        else:
            return None
        # CVD must not be collapsing at decision
        if curr["cvd_slope5"] < 0 and curr["cvd_slope10"] < 0:
            return None
        objectives = self.m.known_objectives_above(i, entry)
        if not objectives:
            return None
        # primary target: nearest strong BSL; if too close, next
        for o in objectives:
            o["net_rr_tmp"] = (o["price"] * (1 - FEE) - entry * (1 + FEE)) / max(entry * (1 + FEE) - (seg_low - 0.45 * curr["atr"]) * (1 - FEE), 1e-12)
        good_targets = [o for o in objectives if o.get("net_rr_tmp", 0) >= 1.2]
        if not good_targets:
            return None
        primary = good_targets[0]
        stop = float(seg_low - max(1.0 * curr["atr"], 0.0025 * entry))
        if entry <= stop or (entry - stop) < 0.90 * curr["atr"]:
            return None
        # scores
        context_score = clip01(0.35 * (1.0 - htf4["score"]) + 0.65 * htf1["score"])
        if context_score < 0.50:
            return None
        wave_quality = clip01(0.45 * sigmoid(disp_strength, 1.2, 2.0) + 0.35 * sigmoid(sweep.strength, 2.0, 2.0) + 0.20 * sigmoid(curr["vol_z"], 0.0, 2.0))
        location_score = clip01(0.75 * sigmoid((ce - curr["close"]) / curr["atr"], 0.0, 3.0) + 0.25)
        exec_score = clip01(0.45 * sigmoid(curr["close_pos"], 0.6, 8.0) + 0.35 * sigmoid(curr["cvd_slope5"], 0.0, 20.0 / curr["atr"]) + 0.20 * sigmoid(curr["vol_z"], 0.0, 2.0))
        objective_quality = clip01(0.5 + 0.1 * primary.get("strength", 1))
        plan = self._risk_plan(entry, stop, primary["price"], 0.5, 0.0, {"context": context_score, "wave": wave_quality, "location": location_score, "execution": exec_score, "objective": objective_quality, "rr_efficiency": 0.5})
        net_rr = plan["net_rr"]
        tier_idx = 0 if net_rr < 1.8 else 1
        tier_name = self.cfg.tier_names[tier_idx]
        components = {
            "context": context_score,
            "wave": wave_quality,
            "location": location_score,
            "execution": exec_score,
            "objective": objective_quality,
            "rr_efficiency": clip01(sigmoid(net_rr, 1.5, 1.5)),
        }
        probability = self._probability(components, net_rr, tier_idx)
        expected_r = probability * max(net_rr, 0.0) - (1.0 - probability)
        plan = self._risk_plan(entry, stop, primary["price"], probability, expected_r, components)
        if exec_score < 0.50 or expected_r < 0.35 or net_rr < 1.25 or plan["cash_used"] < self.cfg.min_notional_usd:
            return None
        # TP1 partial at 0.8R or first objective if close
        loss_per_coin = plan["eff_entry"] * (1 + FEE) - stop * (1 - FEE)
        tp_partial = (plan["eff_entry"] * (1 + FEE) + 0.80 * loss_per_coin) / (1 - FEE)
        tp1 = {"price": float(tp_partial), "type": "sweep_partial_0.8R", "tf": "risk", "strength": 1, "quality": 0.35, "net_rr": 0.8}
        targets = [tp1, primary]
        farther = [o for o in good_targets[1:] if o["price"] > primary["price"]][:2]
        targets.extend(farther)
        narrative = (
            f"SSL sweep عند {sweep.price:.5f} بقوة {sweep.strength} ثم displacement صاعد {disp_strength:.2f} ATR. "
            f"رجوع إلى CE {ce:.5f} واسترجاع إغلاق. الهدف {primary['type']} {primary['price']:.5f}. "
            f"Tier {tier_name} netRR={net_rr:.2f} EV={expected_r:.2f}R."
        )
        return TradePlan(
            signal_index=i,
            signal_time=self.m.base_df["timestamp"].iloc[i],
            entry_index=None,
            entry_time=None,
            map_type="SWEEP_REVERSAL",
            tier=tier_name,
            entry=entry,
            stop_initial=stop,
            targets=targets,
            quantity=plan["quantity"],
            cash_used=plan["cash_used"],
            planned_loss_usd=plan["planned_loss"],
            net_rr_primary=float(net_rr),
            probability=float(probability),
            expected_r=float(expected_r),
            score_components=components,
            narrative=narrative,
            trigger_price=entry,
            pending_expires=i + 2,
            is_pending=True,
            state="PENDING",
            wave=None,
        )

    def _evaluate_wave(self, i: int, wave: SetupWave, curr: Dict) -> Optional[TradePlan]:
        if wave.map_type == "MAP1_PRO_TREND" and not self.cfg.allow_map1:
            return None
        if wave.map_type == "MAP2_COUNTER_TREND" and not self.cfg.allow_map2:
            return None

        zone_low, zone_high, sweet = self._adaptive_buy_zone(wave)
        # location score: current bar relative to zone; prefer inside zone, not premium
        price = curr["close"]
        if price > zone_high:
            loc_score = clip01(0.25 * sigmoid((zone_high - price) / max(curr["atr"], 1e-12), -1.0, 1.5))
        elif zone_low <= price <= zone_high:
            depth = (zone_high - price) / max(zone_high - zone_low, 1e-12)
            loc_score = clip01(0.55 + 0.45 * sigmoid(depth, 0.35, 4.0))
        else:
            # below zone may be deeper value but risk of invalidation; still possible if close to zone
            loc_score = clip01(0.40 * sigmoid((price - zone_low) / max(curr["atr"], 1e-12), 0.0, 2.0))

        pd_best, pd_score = self._pd_array_in_zone(i, zone_low, zone_high, wave)
        exec_score, exec_details = self._execution_score(i, zone_low, zone_high, wave)

        # The engine is flexible, not suicidal: it does not fire unless price is actually interacting with the value zone.
        # This is not a strategy veto; it is an address filter. No address => no delivery.
        # Allow breakout-retest premium up to 1 ATR above zone when impulse is strong; deep discount when weak.
        premium_allowance = (0.25 + 0.75 * wave.impulse_quality) * curr["atr"]
        near_zone = not (curr["high"] < zone_low - 0.25 * curr["atr"] or curr["low"] > zone_high + premium_allowance)
        pd_near = pd_best is not None and pd_score > 0.20
        if not (near_zone or pd_near):
            return None

        # Contextual regime gates expressed as weights, not superstition:
        # MAP1 wants price above slow mean and fast mean supportive.
        # MAP2 wants recent SSL sweep + price still below slow mean but showing micro strength.
        trend_support = curr["close"] > curr["sma50"] and curr["sma20"] >= curr["sma50"] * (1 - 0.0002)
        if wave.map_type == "MAP1_PRO_TREND":
            if not trend_support:
                return None

        if wave.map_type == "MAP2_COUNTER_TREND":
            recent_ssl = [
                p for p in self.m.all_pools
                if p.kind == "SSL" and p.swept_index is not None and 0 <= i - p.swept_index <= 96 and p.price <= wave.origin * 1.002
            ]
            if not recent_ssl:
                return None
            # counter-trend only when price is still generally below slow mean but close is reclaiming short mean
            if not (curr["close"] < curr["sma50"] and curr["close"] > curr["sma20"]):
                return None

        htf4 = self._htf_structure(i, "4h")
        htf1 = self._htf_structure(i, "1h")

        # context: combine HTF trend with map intent and enforce map-context alignment
        if wave.map_type == "MAP1_PRO_TREND":
            context_score = clip01(0.65 * htf4["score"] + 0.35 * htf1["score"])
            if htf4["trend"] not in ("bullish", "transitional", "range") or context_score < 0.55:
                return None
        else:
            exhaustion = clip01(1.0 - htf4["score"])
            improvement = htf1["score"]
            context_score = clip01(0.55 * exhaustion + 0.45 * improvement)
            # counter-trend only when HTF is bearish/transitional and LTF shows real improvement
            if htf4["trend"] not in ("bearish", "transitional") or htf1["score"] < 0.50 or context_score < 0.52:
                return None

        # entry level: if strong PD array, use its level; otherwise sweet/zone blend
        if pd_best is not None and pd_score > 0.2:
            entry_plan = float(0.6 * pd_best["level"] + 0.4 * sweet)
        else:
            entry_plan = float(sweet)
        # Entry: pay only when the bar interacts with value and reclaims it.
        # This allows both wick-rejection and body-reclaim, but forbids chasing and knife-catching.
        touched_value = curr["low"] <= zone_high and curr["high"] >= zone_low
        reclaimed = curr["close"] > max(curr["open"], zone_low)
        close_strength = curr["close_pos"] > 0.52
        if not (touched_value and reclaimed and close_strength):
            return None
        trigger_price = float(curr["close"])  # market on next open proxy
        entry = trigger_price
        entry_quality = clip01(0.5 + 0.5 * sigmoid((curr["close"] - entry_plan) / max(curr["atr"], 1e-12), 0.0, 3.0))

        # stop: narrative invalidation, not fixed percent
        # Narrative invalidation stop: structural but breathing.
        # Minimum noise distance prevents being taken out by ordinary 15m/5m jitter.
        noise_buffer = max(0.80 * curr["atr"], 0.0025 * entry)
        stop_candidates = [wave.origin - noise_buffer, zone_low - noise_buffer]
        if pd_best is not None and hasattr(pd_best["obj"], "low"):
            stop_candidates.append(pd_best["obj"].low - noise_buffer)
            stop_candidates.append(pd_best["obj"].ce - 1.50 * noise_buffer)
        if wave.map_type == "MAP2_COUNTER_TREND":
            stop_candidates.append(wave.bos_level - noise_buffer)
        recent_lows = [s for s in self.m.base.swings if s.kind == "low" and s.known_index <= i and s.index > wave.bos_index]
        if recent_lows:
            stop_candidates.append(recent_lows[-1].price - noise_buffer)
        stop_candidates = [s for s in stop_candidates if s < entry * (1 - FEE)]
        if not stop_candidates:
            stop = wave.origin - noise_buffer
        else:
            # require at least 1.2 ATR risk when possible; otherwise take deepest candidate
            viable = [s for s in stop_candidates if (entry - s) >= 1.20 * curr["atr"]]
            stop = max(viable) if viable else min(stop_candidates)
        if entry <= stop or (entry - stop) < 0.90 * curr["atr"]:
            return None

        # Preliminary tier for objective selection: use wave/context heuristic before net RR is final.
        prelim_tier_idx = 0 if wave.map_type == "MAP2_COUNTER_TREND" else 1
        objectives, primary, objective_quality = self._objective_ladder(i, entry, stop, wave, prelim_tier_idx)
        if not objectives or not primary:
            self._reject(i, "no_objective_above", curr, wave, loc_score, exec_score)
            return None
        plan = self._risk_plan(entry, stop, primary["price"], 0.5, 0.0, {"context": context_score, "wave": wave.quality, "location": loc_score, "execution": exec_score, "objective": objective_quality, "rr_efficiency": 0.5})
        net_rr = plan["net_rr"]
        rr_efficiency = clip01(sigmoid(net_rr, 1.5, 1.5))
        tier_idx, tier_name = self._choose_tier(wave, net_rr, objective_quality, context_score)
        tier_min_rr = self.cfg.tier_min_rr[tier_idx]
        # If tier changed, re-select primary with tier-aware RR preference.
        objectives, primary, objective_quality = self._objective_ladder(i, entry, stop, wave, tier_idx)
        plan = self._risk_plan(entry, stop, primary["price"], 0.5, 0.0, {"context": context_score, "wave": wave.quality, "location": loc_score, "execution": exec_score, "objective": objective_quality, "rr_efficiency": rr_efficiency})
        net_rr = plan["net_rr"]

        components = {
            "context": context_score,
            "wave": wave.quality,
            "location": clip01(0.70 * loc_score + 0.30 * pd_score),
            "execution": exec_score,
            "objective": objective_quality,
            "rr_efficiency": rr_efficiency,
        }
        probability = self._probability(components, net_rr, tier_idx)
        expected_r = probability * max(net_rr, 0.0) - (1.0 - probability)
        # re-size with final components
        plan = self._risk_plan(entry, stop, primary["price"], probability, expected_r, components)

        # Quality floor: structural maps must be stronger than sweep-reversal scalps.
        if wave.map_type == "MAP1_PRO_TREND":
            if exec_score < 0.52 or components["location"] < 0.50 or objective_quality < 0.38 or wave.quality < 0.58 or expected_r < 0.40:
                return None
        else:
            if exec_score < 0.55 or components["location"] < 0.48 or objective_quality < 0.38 or wave.quality < 0.55 or expected_r < 0.45:
                return None
        # too many signals in same session/day destroy edge; allow max 4 entries per 24h base bars
        recent_entries = [t for t in self.trades if t.entry_index is not None and i - t.entry_index <= 288]
        if len(recent_entries) >= 4:
            return None

        if plan["cash_used"] < self.cfg.min_notional_usd or expected_r < self.cfg.min_expected_r or net_rr < tier_min_rr * 0.85:
            self._reject(i, f"low_expectancy tier={tier_name} net_rr={net_rr:.2f} expR={expected_r:.2f} notional={plan['cash_used']:.1f}", curr, wave, loc_score, exec_score)
            return None

        # Target ladder:
        # TP1 = first objective that pays at least 1.0R net, or a pure risk partial at 1R if no liquidity that close.
        # TP2 = primary quality objective
        # TP3 = farther external draw when available
        loss_per_coin = plan["eff_entry"] * (1 + FEE) - stop * (1 - FEE)
        one_r_price = (plan["eff_entry"] * (1 + FEE) + 1.0 * loss_per_coin) / (1 - FEE)
        tp1_candidates = [o for o in objectives if o.get("net_rr", 0.0) >= 1.0]
        # take first liquidity partial at healthy distance; if none before 1.5R, use risk partial at 1.5R
        partial_price = (plan["eff_entry"] * (1 + FEE) + 1.5 * loss_per_coin) / (1 - FEE)
        if tp1_candidates and tp1_candidates[0]["price"] <= one_r_price * 1.75:
            tp1 = tp1_candidates[0]
        else:
            tp1 = {"price": float(partial_price), "type": "risk_partial_1.5R", "tf": "risk", "strength": 1, "quality": 0.35, "net_rr": 1.5}
        farther = [o for o in objectives if o["price"] > tp1["price"]]
        targets = [tp1, primary]
        if farther:
            targets.extend(farther[:2])
        # de-duplicate by price
        seen = set()
        clean_targets = []
        for t in targets:
            key = round(float(t["price"]), 8)
            if key not in seen:
                seen.add(key)
                clean_targets.append(t)
        targets = clean_targets[:4]

        narrative = self._compose_narrative(wave, components, exec_details, tier_name, net_rr, expected_r, pd_best, primary)

        trade = TradePlan(
            signal_index=i,
            signal_time=self.m.base_df["timestamp"].iloc[i],
            entry_index=None,
            entry_time=None,
            map_type=wave.map_type,
            tier=tier_name,
            entry=entry,
            trigger_price=trigger_price,
            pending_expires=i + 4,
            is_pending=True,
            stop_initial=stop,
            targets=targets,
            quantity=plan["quantity"],
            cash_used=plan["cash_used"],
            planned_loss_usd=plan["planned_loss"],
            net_rr_primary=float(net_rr),
            probability=float(probability),
            expected_r=float(expected_r),
            score_components=components,
            narrative=narrative,
            stop_current=stop,
            wave=wave,
        )
        return trade

    def _compose_narrative(self, wave, components, exec_details, tier_name, net_rr, expected_r, pd_best, primary):
        parts = []
        if wave.map_type == "MAP1_PRO_TREND":
            parts.append("HTF يسمح بالشراء مع التيار؛ الحوت بنى قاعًا محميًا ثم كسر الهيكل باندفاع.")
        else:
            parts.append("سياق مضاد: استنزاف بيعي + كسر هيكلي صاعد صغير؛ نريد ارتدادًا خاطفًا لا زواجًا من العملة.")
        parts.append(f"جودة الموجة {wave.quality:.2f} والاندفاع {wave.impulse_quality:.2f}.")
        if pd_best:
            parts.append(f"وجد PD array داخل الخصم بجودة {pd_best['quality']:.2f} وتداخل {pd_best['overlap_ratio']:.2f}.")
        else:
            parts.append("لا PD array قوي داخل الخصم؛ الاعتماد على منطقة OTE التكيفية فقط.")
        parts.append(f"التنفيذ: close_pos={exec_details['close_pos']:.2f}, vol_z={exec_details['vol_z']:.2f}, CVD_turn={exec_details['cvd_turn']:.2f}.")
        parts.append(f"الهدف الأساسي {primary['type']} عند {primary['price']:.2f} بجودة {primary.get('quality',0):.2f}.")
        parts.append(f"الطبقة {tier_name} | netRR={net_rr:.2f} | EV={expected_r:.2f}R.")
        return " ".join(parts)

    def _reject(self, i: int, reason: str, curr: Dict, wave: SetupWave, loc: float, exec_score: float):
        if len(self.rejections) < 2000:
            self.rejections.append({
                "time": str(self.m.base_df['timestamp'].iloc[i]),
                "reason": reason,
                "map": wave.map_type,
                "price": curr["close"],
                "location_score": round(loc, 3),
                "execution_score": round(exec_score, 3),
                "wave_quality": round(wave.quality, 3),
            })

    # ------------------------------------------------------------------
    # Trade management
    # ------------------------------------------------------------------

    def manage_entry_bar(self, i: int):
        """Manage trades that just filled on bar i, using high/low after open only.
        On entry bar we do not let intrabar wick stop us unless open gaps below stop.
        The narrative must actually close below invalidation to kill a fresh entry.
        """
        curr = self._base(i)
        for trade in list(self.open_trades):
            if trade.entry_index != i or trade.state != "OPEN":
                continue
            # conservative: if open gaps below stop, exit at open
            if curr["open"] <= trade.stop_current:
                self._close_trade(trade, i, curr["open"], "STOP_GAP")
                continue
            # targets can be taken intrabar after open
            if self.cfg.use_partial_tp and len(trade.targets) >= 1:
                tp1 = trade.targets[0]["price"]
                if curr["high"] >= tp1 and tp1 > curr["open"]:
                    partial_qty = trade.quantity * self.cfg.partial_tp_fraction
                    proceeds = partial_qty * tp1 * (1 - FEE)
                    self.balance += proceeds
                    trade.realized_pnl += partial_qty * (tp1 * (1 - FEE) - trade.entry * (1 + FEE))
                    trade.quantity -= partial_qty
                    trade.tp1_hit = True
                    be = trade.entry * (1 + FEE) / (1 - FEE)
                    trade.stop_current = max(trade.stop_current, be)
                    if trade.quantity <= 1e-12:
                        self._close_trade(trade, i, tp1, "TP1_FULL")
                        continue
            if len(trade.targets) >= 2:
                tp_final = trade.targets[-1]["price"]
            elif trade.targets:
                tp_final = trade.targets[0]["price"]
            else:
                tp_final = None
            if tp_final and curr["high"] >= tp_final and tp_final > curr["open"]:
                self._close_trade(trade, i, tp_final, "TARGET_FINAL")
                continue
            # only close-stop on entry bar, not wick-stop
            if curr["close"] < trade.stop_current:
                self._close_trade(trade, i, curr["close"], "STOP_CLOSE_ENTRY_BAR")
                continue

    def manage_trades(self, i: int):
        curr = self._base(i)
        b = self.m.base
        for trade in list(self.open_trades):
            if trade.entry_index == i:
                # entry bar handled by manage_entry_bar after open
                continue
            trade.bars_held = i - trade.entry_index
            trade.mfe = max(trade.mfe, curr["high"] - trade.entry)
            trade.mae = min(trade.mae, curr["low"] - trade.entry)

            # 1) Structural trailing: move stop only when new confirmed bullish structure appears AND trade has profit room.
            if i >= trade.entry_index + 3:
                initial_risk = max(trade.entry - trade.stop_initial, 1e-12)
                profit_r = (curr["close"] - trade.entry) / initial_risk
                if profit_r > 0.9:
                    recent_lows = [s for s in b.swings if s.kind == "low" and s.known_index <= i and s.index > trade.entry_index]
                    if recent_lows:
                        buffer = max(0.45 * curr["atr"], 0.0012 * curr["close"])
                        new_protect = recent_lows[-1].price - buffer
                        # never trail into noise: protected stop must be at least 0.35 initial risk above entry after 1R
                        min_allowed_stop = trade.entry + 0.35 * initial_risk if profit_r > 1.2 else trade.entry
                        if new_protect > trade.stop_current and new_protect >= min_allowed_stop and new_protect < curr["close"] - 0.25 * curr["atr"]:
                            trade.stop_current = float(new_protect)

            # 2) Stop first in same bar (conservative)
            if curr["low"] <= trade.stop_current:
                exit_price = trade.stop_current
                self._close_trade(trade, i, exit_price, "STOP_PROTECTED" if trade.stop_current >= trade.entry else "STOP")
                continue

            # 3) Targets with partials
            if self.cfg.use_partial_tp and not trade.tp1_hit and len(trade.targets) >= 1:
                tp1 = trade.targets[0]["price"]
                if curr["high"] >= tp1:
                    partial_qty = trade.quantity * self.cfg.partial_tp_fraction
                    proceeds = partial_qty * tp1 * (1 - FEE)
                    self.balance += proceeds
                    pnl = partial_qty * (tp1 * (1 - FEE) - trade.entry * (1 + FEE))
                    trade.realized_pnl += pnl
                    trade.quantity -= partial_qty
                    trade.tp1_hit = True
                    # move stop to fee-adjusted breakeven after partial
                    be = trade.entry * (1 + FEE) / (1 - FEE)
                    trade.stop_current = max(trade.stop_current, be)
                    if trade.quantity <= 1e-12:
                        self._close_trade(trade, i, tp1, "TP1_FULL")
                        continue

            # 4) Final target for runner
            if len(trade.targets) >= 2:
                tp_final = trade.targets[-1]["price"]
            elif trade.targets:
                tp_final = trade.targets[0]["price"]
            else:
                tp_final = curr["close"]
            if curr["high"] >= tp_final:
                self._close_trade(trade, i, tp_final, "TARGET_FINAL")
                continue

            # 5) Narrative escape: effort/result flips against us
            cvd_collapse = curr["cvd_slope5"] < 0 and curr["cvd_slope10"] < 0
            heavy_sell = curr["close_pos"] < 0.15 and curr["vol_z"] > 1.8 and curr["body"] > 0.60 * curr["range"]
            below_entry = curr["close"] < trade.entry * (1 - 0.0012)
            if trade.bars_held >= 3 and heavy_sell and below_entry:
                self._close_trade(trade, i, curr["close"], "NARRATIVE_ESCAPE")
                continue
            if trade.bars_held >= 10 and cvd_collapse and curr["close"] < trade.stop_current + 0.15 * (trade.entry - trade.stop_current):
                self._close_trade(trade, i, curr["close"], "CVD_BLEED_ESCAPE")
                continue

            # 6) Time decay: scalp trades must work fast; higher tiers get more time
            max_bars = {"SCALP_A": 36, "INTRADAY_B": 96, "SWING_C": 288}.get(trade.tier, 96)
            if trade.bars_held > max_bars and curr["close"] <= trade.entry:
                self._close_trade(trade, i, curr["close"], "TIME_DECAY")
                continue

    def _close_trade(self, trade: TradePlan, i: int, price: float, reason: str):
        remaining = trade.quantity
        if remaining > 0:
            proceeds = remaining * price * (1 - FEE)
            self.balance += proceeds
            pnl = remaining * (price * (1 - FEE) - trade.entry * (1 + FEE))
            trade.realized_pnl += pnl
            trade.quantity = 0.0
        # release unused reserved cash proportionally? cash_used already spent for full qty; partial proceeds returned.
        # For accounting simplicity, realized_pnl tracks economic result; balance includes proceeds.
        trade.state = "CLOSED"
        trade.exit_index = i
        trade.exit_time = self.m.base_df["timestamp"].iloc[i]
        trade.exit_price = float(price)
        trade.exit_reason = reason
        if trade in self.open_trades:
            self.open_trades.remove(trade)
        # record outcome for calibration: win if realized R > 0
        r_actual = trade.realized_pnl / max(trade.planned_loss_usd, 1e-9)
        if trade.realized_pnl < 0:
            self.last_loss_index = i
        feats = [
            trade.score_components["context"],
            trade.score_components["wave"],
            trade.score_components["location"],
            trade.score_components["execution"],
            trade.score_components["objective"],
            min(trade.net_rr_primary / 5.0, 1.0),
            {"SCALP_A": 0.0, "INTRADAY_B": 0.5, "SWING_C": 1.0}.get(trade.tier, 0.5),
        ]
        self.outcomes_for_calibration.append((np.array(feats), 1.0 if r_actual > 0 else 0.0))

    def add_pending(self, trade: TradePlan):
        self.pending_trades.append(trade)
        self.last_signal_index = trade.signal_index
        if trade.wave is not None:
            self.traded_wave_ids.add(id(trade.wave))

    def process_pending(self, i: int):
        curr = self._base(i)
        for pend in list(self.pending_trades):
            if i > pend.pending_expires:
                self.pending_trades.remove(pend)
                continue
            # cancel if market already invalidates before fill
            if curr["close"] < pend.stop_initial:
                self.pending_trades.remove(pend)
                continue
            # fill semantics:
            # market rejection plan: trigger near close, fill at next open
            # limit value plan: fill if bar trades down to limit; fill at min(open, limit)
            is_limit = pend.trigger_price < curr["open"] - 1e-12
            if is_limit:
                filled = curr["low"] <= pend.trigger_price
                fill = min(curr["open"], pend.trigger_price) if filled else None
            else:
                filled = curr["high"] >= pend.trigger_price
                fill = curr["open"] if curr["open"] >= pend.trigger_price else pend.trigger_price
            if filled and fill is not None:
                pend.entry = float(fill)
                pend.entry_index = i
                pend.entry_time = self.m.base_df["timestamp"].iloc[i]
                pend.is_pending = False
                pend.state = "OPEN"
                pend.stop_current = float(pend.stop_initial)
                # recompute quantity for actual fill; stop/target distances slightly changed
                self.balance -= pend.cash_used
                self.open_trades.append(pend)
                self.trades.append(pend)
                self.pending_trades.remove(pend)
                # manage entry bar after fill
                self.manage_entry_bar(i)
