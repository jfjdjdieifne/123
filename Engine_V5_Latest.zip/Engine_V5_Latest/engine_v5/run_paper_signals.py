#!/usr/bin/env python3
"""
Run Adaptive Narrative Engine V5 in paper/backtest mode.

Example:
  python3 -m engine_v5.run_paper_signals \
    --csv repo_123/extracted/project/SOLUSDT_5m_last_month_real.csv \
    --base-tf 5m \
    --btc-csv repo_123/extracted/project/btcusdt_15m_last_month.csv \
    --out engine_v5/paper_signals_SOLUSDT.json

This is paper mode: no exchange keys, no real orders.
"""

import argparse
import json
from .backtest import run_backtest
from .strategy import EngineConfig


def main():
    ap = argparse.ArgumentParser(description="ICT Adaptive Narrative Engine V5 - paper/backtest runner")
    ap.add_argument("--csv", required=True, help="OHLCV csv with timestamp,open,high,low,close,volume")
    ap.add_argument("--base-tf", default="5m", choices=["1m", "5m", "15m", "1h"])
    ap.add_argument("--btc-csv", default=None, help="BTC OHLCV csv for gravity filter on alts")
    ap.add_argument("--balance", type=float, default=100.0)
    ap.add_argument("--risk-usd", type=float, default=1.0)
    ap.add_argument("--max-open", type=int, default=1)
    ap.add_argument("--disable-map1", action="store_true")
    ap.add_argument("--disable-map2", action="store_true")
    ap.add_argument("--out", default="engine_v5/paper_signals.json")
    args = ap.parse_args()

    htf = ("1h", "4h") if args.base_tf == "15m" else ("15m", "1h", "4h")
    cfg = EngineConfig(
        balance=args.balance,
        base_risk_usd=args.risk_usd,
        max_open_trades=args.max_open,
        allow_map1=not args.disable_map1,
        allow_map2=not args.disable_map2,
    )
    res = run_backtest(args.csv, cfg, base_tf=args.base_tf, htf_timeframes=htf, btc_csv=args.btc_csv)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2, default=str)

    print("\n=== V5 Paper Run ===")
    print("File:", args.csv)
    print("Trades:", res["trades"])
    print("Win rate:", res["win_rate"], "%")
    print("Net PnL:", res["net_pnl"], "USDT")
    print("Profit factor:", res["profit_factor"])
    print("Expectancy R:", res["expectancy_R"])
    print("Max drawdown:", res["max_drawdown_pct"], "%")
    print("Full JSON:", args.out)


if __name__ == "__main__":
    main()
