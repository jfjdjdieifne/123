"""
ICT Adaptive Narrative Engine V5 - Core
=======================================

Pure Spot Long Only.
No lookahead: every object carries known_index / known_time and can be used only after confirmation.
No rigid strategy veto: weakness becomes lower weight, lower probability, smaller size.
Only non-negotiable safety rails remain:
  - invalid data / insufficient history
  - entry only on next open
  - planned loss cap
  - fee/slippage-aware negative expectancy => size collapses to zero

ICT research anchors:
- Premium/discount and OTE 62-79, 70.5 sweet spot [2](https://ictflow.com/blog/ict-optimal-trade-entry-ote) [3](https://liquidityhunters.cl/en/glossary/optimal-trade-entry/)
- Displacement + FVG + CE entry [2](https://fxnx.com/en/blog/ict-displacement-read-institutional-momentum) [3](https://innercircletrader.net/tutorials/fair-value-gap-trading-strategy/)
- Liquidity pools, sweeps, BSL/SSL, IRL/ERL [3](https://www.ictkillzone.com/ict-liquidity) [2](https://innercircletrader.net/tutorials/ict-liquidity-sweep-vs-liquidity-run/)
- CVD absorption/divergence [4](https://zitaplus.com/blog/analysis/cumulative-volume-delta-divergence-details--strategies/) [5](https://www.backquant.com/learn/cvd)
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Tuple
import numpy as np
import pandas as pd

FEE = 0.001
SLIPPAGE_BPS = 5  # conservative spot market order slippage, bps of entry

# ----------------------------------------------------------------------------
# Numeric helpers
# ----------------------------------------------------------------------------

def atr_from_df(df: pd.DataFrame, period: int = 14) -> np.ndarray:
    prev_close = df["close"].shift(1)
    tr = pd.concat(
        [
            df["high"] - df["low"],
            (df["high"] - prev_close).abs(),
            (df["low"] - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    return tr.rolling(period, min_periods=1).mean().to_numpy()


def rolling_slope(values: np.ndarray, window: int) -> np.ndarray:
    """Vectorized least-squares slope over a rolling window."""
    if len(values) < window:
        out = np.full(len(values), np.nan)
        if len(values) >= 2:
            out[-1] = np.polyfit(np.arange(len(values)), values, 1)[0]
        return out
    x = np.arange(window, dtype=float)
    xm = x - x.mean()
    denom = float((xm * xm).sum())
    shape = (len(values) - window + 1, window)
    strides = (values.strides[0], values.strides[0])
    mat = np.lib.stride_tricks.as_strided(values, shape=shape, strides=strides)
    ym = mat - mat.mean(axis=1, keepdims=True)
    slopes = (ym @ xm) / denom
    out = np.full(len(values), np.nan)
    out[window - 1 :] = slopes
    return out


def rolling_zscore(values: np.ndarray, window: int) -> np.ndarray:
    s = pd.Series(values)
    mean = s.rolling(window, min_periods=max(5, window // 4)).mean()
    std = s.rolling(window, min_periods=max(5, window // 4)).std(ddof=0)
    z = (s - mean) / (std + 1e-12)
    return z.to_numpy()


def sigmoid(x: float, center: float = 0.55, steepness: float = 9.0) -> float:
    z = float(np.clip(-steepness * (x - center), -60.0, 60.0))
    return float(1.0 / (1.0 + np.exp(z)))


def clip01(x: float) -> float:
    return float(max(0.0, min(1.0, x)))


# ----------------------------------------------------------------------------
# Causal objects
# ----------------------------------------------------------------------------

@dataclass
class Swing:
    kind: str  # high/low
    index: int  # candle index where extreme occurred
    price: float
    known_index: int  # first base index where this swing is known
    atr: float
    timeframe: str


@dataclass
class FVG:
    kind: str  # bullish/bearish
    low: float
    high: float
    ce: float
    created_index: int
    known_index: int
    timeframe: str
    displacement: float
    parent_volume_z: float
    quality: float = 0.5
    mitigated_index: Optional[int] = None


@dataclass
class OrderBlock:
    kind: str  # bullish/bearish
    low: float
    high: float
    ce: float
    created_index: int
    known_index: int
    timeframe: str
    displacement: float
    volume_z: float
    quality: float = 0.5
    mitigated_index: Optional[int] = None


@dataclass
class LiquidityPool:
    kind: str  # BSL above highs, SSL below lows
    price: float
    strength: int
    known_index: int
    timeframe: str
    swept_index: Optional[int] = None


@dataclass
class ProtectedLow:
    price: float
    index: int
    known_index: int
    atr: float
    rejection_ratio: float
    volume_z: float
    cvd_divergence: float
    quality: float
    invalid: bool = False
    invalidated_index: Optional[int] = None
    bos_index: Optional[int] = None
    bos_level: Optional[float] = None
    term: Optional[float] = None
    term_index: Optional[int] = None
    impulse_quality: Optional[float] = None


@dataclass
class SetupWave:
    origin: float
    origin_index: int
    term: float
    term_index: int
    bos_level: float
    bos_index: int
    range: float
    impulse_quality: float
    map_type: str  # MAP1_PRO_TREND or MAP2_COUNTER_TREND
    quality: float
    expires_index: int


# ----------------------------------------------------------------------------
# Timeframe container
# ----------------------------------------------------------------------------

TF_MINUTES = {"1m": 1, "5m": 5, "15m": 15, "1h": 60, "4h": 240, "1d": 1440}


@dataclass
class TimeframeData:
    tf: str
    df: pd.DataFrame
    open: np.ndarray
    high: np.ndarray
    low: np.ndarray
    close: np.ndarray
    volume: np.ndarray
    ts: np.ndarray
    atr: np.ndarray
    body: np.ndarray
    rng: np.ndarray
    lower_wick: np.ndarray
    upper_wick: np.ndarray
    close_pos: np.ndarray
    vol_z: np.ndarray
    cvd_delta: np.ndarray
    cvd: np.ndarray
    cvd_slope5: np.ndarray
    cvd_slope10: np.ndarray
    price_slope_norm: np.ndarray
    displacement_up: np.ndarray
    displacement_dn: np.ndarray
    sma20: np.ndarray
    sma50: np.ndarray
    atr_pct: np.ndarray
    known_base_count: np.ndarray  # how many tf candles are closed for each base bar
    swings: List[Swing] = field(default_factory=list)
    fvgs: List[FVG] = field(default_factory=list)
    obs: List[OrderBlock] = field(default_factory=list)
    pools: List[LiquidityPool] = field(default_factory=list)


def prepare_timeframe(tf: str, df: pd.DataFrame, base_ts: np.ndarray) -> TimeframeData:
    df = df.copy().reset_index(drop=True)
    close = df["close"].to_numpy(dtype=float)
    high = df["high"].to_numpy(dtype=float)
    low = df["low"].to_numpy(dtype=float)
    open_ = df["open"].to_numpy(dtype=float)
    volume = df["volume"].to_numpy(dtype=float)
    ts = pd.to_datetime(df["timestamp"]).values

    atr = atr_from_df(df, 14)
    body = np.abs(close - open_)
    rng = np.maximum(high - low, 1e-12)
    lower_wick = np.minimum(open_, close) - low
    upper_wick = high - np.maximum(open_, close)
    close_pos = (close - low) / rng

    vol_z = rolling_zscore(volume, 50)
    hl = np.maximum(high - low, 1e-12)
    delta = ((close - low) / hl - 0.5) * 2.0 * volume
    cvd = np.cumsum(delta)
    cvd_slope5 = rolling_slope(cvd, 5)
    cvd_slope10 = rolling_slope(cvd, 10)

    # normalized price slope over 8 bars by ATR
    price_slope = rolling_slope(close, 8)
    price_slope_norm = price_slope / np.maximum(atr, 1e-12)

    # displacement proxies over 3 closed bars: return per ATR with body dominance
    ret3 = np.full(len(close), np.nan)
    if len(close) > 3:
        ret3[3:] = (close[3:] - close[:-3]) / np.maximum(atr[3:], 1e-12)
    body_ratio3 = np.full(len(close), np.nan)
    if len(close) > 3:
        sum_body = pd.Series(body).rolling(3, min_periods=3).sum().to_numpy()
        sum_range = pd.Series(rng).rolling(3, min_periods=3).sum().to_numpy()
        body_ratio3[2:] = (sum_body[2:] / np.maximum(sum_range[2:], 1e-12))
    displacement_up = np.where((ret3 > 0) & (body_ratio3 > 0.55), ret3 * np.maximum(body_ratio3, 0.1), 0.0)
    displacement_dn = np.where((ret3 < 0) & (body_ratio3 > 0.55), -ret3 * np.maximum(body_ratio3, 0.1), 0.0)

    sma20 = pd.Series(close).rolling(20, min_periods=10).mean().to_numpy()
    sma50 = pd.Series(close).rolling(50, min_periods=25).mean().to_numpy()
    atr_pct = atr / np.maximum(close, 1e-12)

    # known mapping: tf candle with start ts[k] closes at ts[k] + tf_minutes.
    tf_minutes = TF_MINUTES[tf]
    tf_close = ts + np.timedelta64(tf_minutes, "m")
    known_base_count = np.searchsorted(tf_close, base_ts, side="right")

    return TimeframeData(
        tf=tf,
        df=df,
        open=open_,
        high=high,
        low=low,
        close=close,
        volume=volume,
        ts=ts,
        atr=atr,
        body=body,
        rng=rng,
        lower_wick=lower_wick,
        upper_wick=upper_wick,
        close_pos=close_pos,
        vol_z=vol_z,
        cvd_delta=delta,
        cvd=cvd,
        cvd_slope5=cvd_slope5,
        cvd_slope10=cvd_slope10,
        price_slope_norm=price_slope_norm,
        displacement_up=np.nan_to_num(displacement_up, nan=0.0),
        displacement_dn=np.nan_to_num(displacement_dn, nan=0.0),
        sma20=np.nan_to_num(sma20, nan=close.mean()),
        sma50=np.nan_to_num(sma50, nan=close.mean()),
        atr_pct=np.nan_to_num(atr_pct, nan=0.001),
        known_base_count=known_base_count,
    )


# ----------------------------------------------------------------------------
# Feature cache for one base series
# ----------------------------------------------------------------------------

class MarketMemory:
    """
    Builds causal maps for base timeframe and higher timeframes.
    All detectors are generated with known_index so walk-forward cannot see future.
    """

    def __init__(self, base_df: pd.DataFrame, htf_timeframes: Tuple[str, ...] = ("15m", "1h", "4h"), base_tf: str = "5m"):
        self.base_tf = base_tf
        self.base_df = base_df.copy().reset_index(drop=True)
        self.base_df["timestamp"] = pd.to_datetime(self.base_df["timestamp"])
        self.base_ts = self.base_df["timestamp"].values
        self.n = len(self.base_df)

        self.base = prepare_timeframe(base_tf, self.base_df, self.base_ts)
        self.htfs: Dict[str, TimeframeData] = {}
        for tf in htf_timeframes:
            if TF_MINUTES[tf] <= TF_MINUTES[base_tf]:
                continue
            htf_df = self._resample(tf)
            self.htfs[tf] = prepare_timeframe(tf, htf_df, self.base_ts)

        self._detect_swings_all()
        self._detect_fvgs_obs_all()
        self._detect_liquidity_pools_all()
        self._index_causal_objects()

    def _resample(self, tf: str) -> pd.DataFrame:
        rule = {"1m": "1min", "5m": "5min", "15m": "15min", "1h": "1h", "4h": "4h", "1d": "1D"}[tf]
        df = self.base_df.set_index("timestamp").resample(rule).agg(
            open=("open", "first"),
            high=("high", "max"),
            low=("low", "min"),
            close=("close", "last"),
            volume=("volume", "sum"),
        ).dropna().reset_index()
        return df

    def _detect_swings_all(self):
        self._detect_swings(self.base, pivot=2)
        for tf, tfd in self.htfs.items():
            pivot = 2 if tf in ("15m", "1h") else 3
            self._detect_swings(tfd, pivot=pivot)

    def _detect_swings(self, tfd: TimeframeData, pivot: int):
        high = tfd.high
        low = tfd.low
        n = len(tfd.df)
        # confirmation: pivot k is known at k+pivot
        for k in range(pivot, n - pivot):
            window_low = low[k - pivot : k + pivot + 1]
            window_high = high[k - pivot : k + pivot + 1]
            known = k + pivot
            if low[k] == window_low.min() and low[k] <= low[k - 1] and low[k] <= low[k + 1]:
                known_base = self._tf_index_to_base_known(tfd, known)
                if known_base is not None:
                    tfd.swings.append(Swing("low", k, float(low[k]), known_base, float(tfd.atr[k]), tfd.tf))
            if high[k] == window_high.max() and high[k] >= high[k - 1] and high[k] >= high[k + 1]:
                known_base = self._tf_index_to_base_known(tfd, known)
                if known_base is not None:
                    tfd.swings.append(Swing("high", k, float(high[k]), known_base, float(tfd.atr[k]), tfd.tf))
        tfd.swings.sort(key=lambda s: s.known_index)

    def _tf_index_to_base_known(self, tfd: TimeframeData, tf_known_index: int) -> Optional[int]:
        if tf_known_index < 0 or tf_known_index >= len(tfd.df):
            return None
        # candle tf_known_index closes at ts + tf_minutes
        close_time = tfd.ts[tf_known_index] + np.timedelta64(TF_MINUTES[tfd.tf], "m")
        idx = int(np.searchsorted(self.base_ts, close_time, side="left"))
        if idx >= self.n:
            idx = self.n - 1
        return idx

    def _detect_fvgs_obs_all(self):
        self._detect_fvgs_obs(self.base)
        for tfd in self.htfs.values():
            self._detect_fvgs_obs(tfd)

    def _detect_fvgs_obs(self, tfd: TimeframeData):
        n = len(tfd.df)
        high = tfd.high
        low = tfd.low
        close = tfd.close
        open_ = tfd.open
        atr = tfd.atr
        vol_z = tfd.vol_z
        for i in range(1, n - 1):
            c1_high = high[i - 1]
            c3_low = low[i + 1]
            c1_low = low[i - 1]
            c3_high = high[i + 1]
            body_mid = abs(close[i] - open_[i])
            disp = body_mid / max(atr[i], 1e-12)
            known = i + 1
            known_base = self._tf_index_to_base_known(tfd, known)
            if known_base is None:
                continue
            parent_z = float(vol_z[i]) if not np.isnan(vol_z[i]) else 0.0
            quality = clip01(0.25 + 0.25 * min(disp / 2.0, 1.5) + 0.25 * sigmoid(parent_z, 0.5, 3.0) + 0.25 * (body_mid / max(tfd.rng[i], 1e-12)))
            # bullish FVG
            if c1_high < c3_low and close[i] > open_[i] and disp > 0.45:
                fvg = FVG(
                    kind="bullish",
                    low=float(c1_high),
                    high=float(c3_low),
                    ce=float((c1_high + c3_low) / 2.0),
                    created_index=i,
                    known_index=known_base,
                    timeframe=tfd.tf,
                    displacement=float(disp),
                    parent_volume_z=parent_z,
                    quality=quality,
                )
                tfd.fvgs.append(fvg)
            # bearish FVG
            if c1_low > c3_high and close[i] < open_[i] and disp > 0.45:
                fvg = FVG(
                    kind="bearish",
                    low=float(c3_high),
                    high=float(c1_low),
                    ce=float((c1_low + c3_high) / 2.0),
                    created_index=i,
                    known_index=known_base,
                    timeframe=tfd.tf,
                    displacement=float(disp),
                    parent_volume_z=parent_z,
                    quality=quality,
                )
                tfd.fvgs.append(fvg)
            # bullish OB: last bearish candle before bullish displacement
            if close[i - 1] < open_[i - 1] and close[i] > open_[i]:
                grabs_low = low[i] < low[i - 1]
                closes_above = close[i] > high[i - 1]
                strong = disp > 0.8
                if grabs_low and closes_above and strong:
                    ob = OrderBlock(
                        kind="bullish",
                        low=float(low[i - 1]),
                        high=float(high[i - 1]),
                        ce=float((low[i - 1] + high[i - 1]) / 2.0),
                        created_index=i - 1,
                        known_index=known_base,
                        timeframe=tfd.tf,
                        displacement=float(disp),
                        volume_z=float(vol_z[i]) if not np.isnan(vol_z[i]) else 0.0,
                        quality=clip01(0.25 + 0.3 * min(disp / 2.0, 1.5) + 0.25 * sigmoid(float(vol_z[i]) if not np.isnan(vol_z[i]) else 0.0, 0.5, 3.0) + 0.2 * (body_mid / max(tfd.rng[i], 1e-12))),
                    )
                    tfd.obs.append(ob)
            # bearish OB: last bullish candle before bearish displacement
            if close[i - 1] > open_[i - 1] and close[i] < open_[i]:
                grabs_high = high[i] > high[i - 1]
                closes_below = close[i] < low[i - 1]
                strong = disp > 0.8
                if grabs_high and closes_below and strong:
                    ob = OrderBlock(
                        kind="bearish",
                        low=float(low[i - 1]),
                        high=float(high[i - 1]),
                        ce=float((low[i - 1] + high[i - 1]) / 2.0),
                        created_index=i - 1,
                        known_index=known_base,
                        timeframe=tfd.tf,
                        displacement=float(disp),
                        volume_z=float(vol_z[i]) if not np.isnan(vol_z[i]) else 0.0,
                        quality=clip01(0.25 + 0.3 * min(disp / 2.0, 1.5) + 0.25 * sigmoid(float(vol_z[i]) if not np.isnan(vol_z[i]) else 0.0, 0.5, 3.0) + 0.2 * (body_mid / max(tfd.rng[i], 1e-12))),
                    )
                    tfd.obs.append(ob)

        tfd.fvgs.sort(key=lambda x: x.known_index)
        tfd.obs.sort(key=lambda x: x.known_index)
        self._mitigate_objects(tfd)

    def _mitigate_objects(self, tfd: TimeframeData):
        high = tfd.high
        low = tfd.low
        for fvg in tfd.fvgs:
            start = fvg.created_index + 2
            for k in range(start, len(tfd.df)):
                if fvg.kind == "bullish" and low[k] <= fvg.low:
                    fvg.mitigated_index = self._tf_index_to_base_known(tfd, k)
                    break
                if fvg.kind == "bearish" and high[k] >= fvg.high:
                    fvg.mitigated_index = self._tf_index_to_base_known(tfd, k)
                    break
        for ob in tfd.obs:
            start = ob.created_index + 2
            for k in range(start, len(tfd.df)):
                if ob.kind == "bullish" and low[k] <= ob.low:
                    ob.mitigated_index = self._tf_index_to_base_known(tfd, k)
                    break
                if ob.kind == "bearish" and high[k] >= ob.high:
                    ob.mitigated_index = self._tf_index_to_base_known(tfd, k)
                    break

    def _detect_liquidity_pools_all(self):
        self._detect_liquidity_pools(self.base)
        for tfd in self.htfs.values():
            self._detect_liquidity_pools(tfd)

    def _detect_liquidity_pools(self, tfd: TimeframeData, tolerance_atr: float = 0.25, cluster_window: int = 60):
        swings = tfd.swings
        for i, s in enumerate(swings):
            near = [x for x in swings if x.kind == s.kind and abs(x.index - s.index) <= cluster_window and abs(x.price - s.price) <= tolerance_atr * max(s.atr, x.atr, 1e-12)]
            strength = min(4, len(near))
            if strength >= 2:
                pool = LiquidityPool(
                    kind="BSL" if s.kind == "high" else "SSL",
                    price=float(s.price),
                    strength=strength,
                    known_index=s.known_index,
                    timeframe=tfd.tf,
                )
                tfd.pools.append(pool)
        # dedupe near same price
        tfd.pools.sort(key=lambda p: p.known_index)
        out: List[LiquidityPool] = []
        for p in tfd.pools:
            if not any(abs(p.price - q.price) <= tolerance_atr * max(tfd.atr[-1], 1e-12) and p.kind == q.kind for q in out[-30:]):
                out.append(p)
        tfd.pools = out
        # mark sweeps causally
        for p in tfd.pools:
            start = int(np.searchsorted(tfd.ts, self.base_ts[min(p.known_index, self.n - 1)], side="left"))
            for k in range(max(0, start), len(tfd.df)):
                if p.kind == "BSL" and tfd.high[k] >= p.price and tfd.close[k] < p.price:
                    p.swept_index = self._tf_index_to_base_known(tfd, k)
                    break
                if p.kind == "SSL" and tfd.low[k] <= p.price and tfd.close[k] > p.price:
                    p.swept_index = self._tf_index_to_base_known(tfd, k)
                    break

    def _index_causal_objects(self):
        # simple sorted lists; queries use binary search by known_index
        self.all_swings = sorted(self.base.swings + [s for tfd in self.htfs.values() for s in tfd.swings], key=lambda x: x.known_index)
        self.all_fvgs = sorted(self.base.fvgs + [f for tfd in self.htfs.values() for f in tfd.fvgs], key=lambda x: x.known_index)
        self.all_obs = sorted(self.base.obs + [o for tfd in self.htfs.values() for o in tfd.obs], key=lambda x: x.known_index)
        self.all_pools = sorted(self.base.pools + [p for tfd in self.htfs.values() for p in tfd.pools], key=lambda x: x.known_index)

    # Query helpers ----------------------------------------------------------

    def known_swings(self, i: int, kind: Optional[str] = None, tfs: Optional[Tuple[str, ...]] = None) -> List[Swing]:
        out = [s for s in self.all_swings if s.known_index <= i]
        if kind:
            out = [s for s in out if s.kind == kind]
        if tfs:
            out = [s for s in out if s.timeframe in tfs]
        return out

    def known_pd_arrays(self, i: int, kind: str, price_low: float, price_high: float, tfs: Optional[Tuple[str, ...]] = None) -> List:
        fvgs = [
            f for f in self.all_fvgs
            if f.known_index <= i and f.kind == kind and (f.mitigated_index is None or f.mitigated_index > i) and not (f.high < price_low or f.low > price_high)
        ]
        obs = [
            o for o in self.all_obs
            if o.known_index <= i and o.kind == kind and (o.mitigated_index is None or o.mitigated_index > i) and not (o.high < price_low or o.low > price_high)
        ]
        if tfs:
            fvgs = [f for f in fvgs if f.timeframe in tfs]
            obs = [o for o in obs if o.timeframe in tfs]
        return fvgs + obs

    def known_objectives_above(self, i: int, entry: float) -> List[Dict]:
        objs: List[Dict] = []
        # swing highs / BSL pools
        for s in self.known_swings(i, kind="high"):
            if s.price > entry:
                objs.append({"price": float(s.price), "type": "swing_high", "tf": s.timeframe, "strength": 1})
        for p in self.all_pools:
            if p.known_index <= i and p.kind == "BSL" and p.price > entry and (p.swept_index is None or p.swept_index > i):
                objs.append({"price": float(p.price), "type": "equal_high_pool", "tf": p.timeframe, "strength": p.strength})
        # bearish FVG/OB bottoms as resistance targets
        for f in self.all_fvgs:
            if f.known_index <= i and f.kind == "bearish" and f.low > entry and (f.mitigated_index is None or f.mitigated_index > i):
                objs.append({"price": float(f.low), "type": "bearish_fvg", "tf": f.timeframe, "strength": int(1 + f.quality)})
        for o in self.all_obs:
            if o.known_index <= i and o.kind == "bearish" and o.low > entry and (o.mitigated_index is None or o.mitigated_index > i):
                objs.append({"price": float(o.low), "type": "bearish_ob", "tf": o.timeframe, "strength": int(1 + o.quality)})
        # dedupe near prices
        objs.sort(key=lambda z: z["price"])
        out = []
        atr_now = float(self.base.atr[min(i, self.n - 1)])
        for obj in objs:
            if not any(abs(obj["price"] - z["price"]) <= 0.15 * max(atr_now, 1e-12) for z in out[-20:]):
                out.append(obj)
        return out

    def known_objectives_below(self, i: int, entry: float) -> List[Dict]:
        objs: List[Dict] = []
        for s in self.known_swings(i, kind="low"):
            if s.price < entry:
                objs.append({"price": float(s.price), "type": "swing_low", "tf": s.timeframe, "strength": 1})
        for p in self.all_pools:
            if p.known_index <= i and p.kind == "SSL" and p.price < entry and (p.swept_index is None or p.swept_index > i):
                objs.append({"price": float(p.price), "type": "equal_low_pool", "tf": p.timeframe, "strength": p.strength})
        for f in self.all_fvgs:
            if f.known_index <= i and f.kind == "bullish" and f.high < entry and (f.mitigated_index is None or f.mitigated_index > i):
                objs.append({"price": float(f.high), "type": "bullish_fvg_support", "tf": f.timeframe, "strength": int(1 + f.quality)})
        objs.sort(key=lambda z: -z["price"])
        out = []
        atr_now = float(self.base.atr[min(i, self.n - 1)])
        for obj in objs:
            if not any(abs(obj["price"] - z["price"]) <= 0.15 * max(atr_now, 1e-12) for z in out[-20:]):
                out.append(obj)
        return out
