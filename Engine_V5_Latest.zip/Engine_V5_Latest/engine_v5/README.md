# ICT Adaptive Narrative Engine V5 — Paper Research Build

## ما هذا؟
محرك Spot Long Only مبني على مفاهيم ICT/SMC:
- Liquidity sweeps (BSL/SSL)
- Displacement + FVG + CE
- Order Blocks / Breaker concepts
- Premium/Discount و OTE التكيفي
- CVD proxy للامتصاص والانحراف
- أهداف سيولة حقيقية + أهداف إسقاطية فقط عندما يثبت الاندفاع قوته

## الفرق الجوهري عن V4
V4 كان يرفض الصفقة إذا فشل veto واحد.  
V5 يحول الضعف إلى **وزن أقل + احتمال أقل + حجم أصغر**.

لكن تبقى قواعد أمان غير قابلة للتفاوض:
1. لا lookahead.
2. القرار على شمعة مغلقة.
3. التنفيذ واقعي: market بعد إغلاق إشارة أو limit/confirmation.
4. الرسوم والانزلاق داخل RR.
5. Spot buy only.

## البنية
- `core.py`
  - MarketMemory: ذاكرة سببية لكل الفريمات.
  - كل swing/FVG/OB/pool لديه `known_index`.
- `strategy.py`
  - AdaptiveNarrativeEngine: يقيم الموجات والسياق والتنفيذ والأهداف.
  - ثلاث خرائط:
    - `SWEEP_REVERSAL`: أعلى قناعة — جرف SSL + displacement + رجوع إلى CE.
    - `MAP1_PRO_TREND`: شراء مع الاتجاه بعد BOS وخصم تكيفي.
    - `MAP2_COUNTER_TREND`: ارتداد خاطف بعد sweep و CHoCH/BOS صغير.
- `backtest.py`
  - Walk-forward bar-by-bar.
  - إدارة صفقة: partial TP، trailing هيكلي، escape عند انهيار CVD/جهد بيعي.
- `run_paper_signals.py`
  - تشغيل Paper/Backtest وإخراج JSON.

## كيف تشغّل
```bash
python3 -m engine_v5.run_paper_signals \
  --csv repo_123/extracted/project/SOLUSDT_5m_last_month_real.csv \
  --base-tf 5m \
  --btc-csv repo_123/extracted/project/btcusdt_15m_last_month.csv \
  --out engine_v5/paper_signals_SOLUSDT.json
```

## نتائج أولية على بيانات الشهر المرفقة
النتائج الحالية **ليست إثبات edge** بعد.  
الشهر المرفق صغير، وأغلب الألت كوينز كانت بيئات صعبة/هابطة، والمحرك بعد التشديد أصبح قليل الصفقات وخفيف الخسارة لكنه لم يثبت ربحية مستقرة.

هذا يعني أن V5 أصبح:
- أكثر أمانًا من overtrading
- أكثر احترامًا للسياق
- أقل مطاردة
- لكنه ما يزال يحتاج:
  1. بيانات 3–6 أشهر على الأقل.
  2. 1m/5m execution حقيقي.
  3. CVD حقيقي من trades وليس proxy OHLC.
  4. Paper trading حي لأسابيع.

## ماذا بعد؟
1. جمع بيانات أطول.
2. تشغيل Paper يومي وتسجيل Journal.
3. مقارنة إشارات V5 مع حركة السوق الحقيقية.
4. ضبط الأوزان على validation لا على نفس شهر التطوير.
