# تشريح مجهري لأخطاء Engine-X على تيست التيكات الخاص فيك

## الداتا
- الملف: `user_ticks2.csv`
- التيكات: 198 tick
- الفترة: 2024-01-15 08:00:00 → 08:02:54
- الحجم الكلي: ~3113 BTC
- Bar sizes المختبرة: 1 / 2 / 5 BTC

---

# النتيجة الحالية

```text
BAR 1.0 → Plans: 0 | SSL sweeps: 0 | Disp up: 112 | Bullish FVG: 76
BAR 2.0 → Plans: 0 | SSL sweeps: 0 | Disp up: 115 | Bullish FVG: 73
BAR 5.0 → Plans: 0 | SSL sweeps: 0 | Disp up: 130 | Bullish FVG: 71
```

يعني المحرك يرى:
- displacement صاعدة كثيرة
- FVGs كثيرة
- لكنه لا يكتشف SSL sweep صحيحة
- لذلك لا يبني setup كامل

---

# الخطأ المجهري الأول: Sweep Detection لا يلتقط SSL في هذا التيست

المحرك حاليًا يكتشف sweep فقط إذا:

```text
low <= prior_low
close > prior_low
significant penetration or volume
```

لكن في التيست تبعك، معظم الحركات هي:

```text
low = prior_low
close = prior_low + 5
volume = 2 BTC
recent_vol = 2 BTC
```

فالشرط:

```text
significant = penetration >= 0.05 ATR or volume >= 1.25× recent_vol
```

لا يتحقق لأن:
- penetration صغير
- volume ليس أكبر من المتوسط

### مثال من التيست

```text
CAND SWEEP low=49970 close=49975 roll_low=49970 vol=2.0 recent_vol=2.0
CAND SWEEP low=49985 close=49990 roll_low=49985 vol=2.0 recent_vol=2.0
CAND SWEEP low=49990 close=49995 roll_low=49990 vol=2.0 recent_vol=2.0
```

هذه sweep-like reclaims، لكن المحرك يرفضها لأنها ليست “كبيرة” بما يكفي.

---

# الخطأ المجهري الثاني: Premium/Discount rejection عالي جدًا

أكثر rejection:

```text
SETUP REJECTED premium/no-discount depth=0.00 < 0.20
```

السبب:

المحرك يحسب:

```text
retrace_depth = (disp_leg_high - price) / disp_leg_range
```

لكن في التيست، السعر غالبًا فوق أو قرب disp_leg_high، لذلك:

```text
depth = 0.00
```

فيرفض لأنه يظن أنك تشتري premium.

### مثال

```text
DISP up move_atr=13.00 cvd_delta=3.0
SETUP REJECTED premium/no-discount depth=0.00 < 0.20
```

---

# الخطأ المجهري الثالث: no targets above

حتى عندما يمر absorption، يرفض بسبب:

```text
SETUP REJECTED no targets above
```

السبب:
- الأهداف تعتمد على BSL pools
- التيست فيه أهداف قريبة جدًا
- أو لا يوجد BSL pool فوق الدخول يحقق RR المطلوب

### مثال

```text
FVG bullish 50150-50180 ce=50165
SETUP REJECTED no targets above
```

---

# الخطأ المجهري الرابع: Stop tight / instant stop

في المحاولات السابقة التي دخل فيها المحرك، كانت الصفقات تضرب ستوب بسرعة:

```text
BUY 49930 → SELL 49870 STOP
BUY 49860 → SELL 49800 STOP
BUY 49920 → SELL 49860 STOP
```

السبب:
- الستوب كان قريب جدًا
- التيست فيه pullbacks عنيفة
- المحرك يخرج قبل أن تأخذ الحركة وقتها

---

# الخلاصة الميكروسكوبية

المحرك حاليًا عنده 3 مشاكل رئيسية على هذا التيست:

1. **Sweep detection صارم جدًا**
   - لا يلتقط micro sweep/reclaim
   - لأن volume/penetration غير كافيين

2. **Premium/Discount filter صارم جدًا**
   - يرفض depth=0.00
   - بينما التيست فيه حركات سريعة لا تعطي retracement عميق

3. **Target logic ضيق**
   - لا يجد أهداف فوق الدخول تحقق RR
   - لأن BSL pools قريبة أو غير موجودة

---

# الإصلاح المقترح “الذكي” بدون تخمين

## 1) Sweep detection مرن للتيكات السريعة

بدل:

```text
penetration >= 0.05 ATR or volume >= 1.25× avg
```

نستخدم:

```text
penetration >= 0.02 ATR
or reclaim strength = (close - low) / range >= 0.60
or volume >= 1.15× avg
```

هذا يلتقط micro sweep/reclaim في التيكات السريعة.

---

## 2) Premium/Discount مرن حسب قوة displacement

بدل depth ثابت 0.20:

```text
if displacement strong:
    min_depth = 0.08
elif normal:
    min_depth = 0.15
else:
    min_depth = 0.25
```

يعني إذا الاندفاع قوي، المحرك يقبل دخول أقرب إلى القمة ولا يفوت الحركة.

---

## 3) Target ladder أذكى

بدل انتظار BSL pool فقط:

نستخدم:

```text
1) nearest swing high
2) FVG high
3) displacement high
4) displacement high + 0.27×range
5) BSL pool
```

ونختار أول هدف يحقق:

```text
net RR >= session_min_rr
```

وليس بالضرورة BSL pool فقط.

---

## 4) Stop مرن لكن غير انتحاري

Stop يكون:

```text
max(
    fvg.low - 0.20 ATR,
    entry - 0.50 ATR,
    recent_swing_low - 0.10 ATR
)
```

وليس فقط:

```text
entry - min_stop_distance
```

---

# الحكم النهائي على التيست

المحرك **ليس غبيًا**، لكنه حاليًا:

```text
حافظ قواعد أكثر مما يفهم التيست
```

يرى displacement وFVG، لكن:
- يرفض sweep
- يرفض premium
- لا يجد targets

لذلك لا يدخل.

الإصلاح الصحيح ليس تخفيف عشوائي، بل:

```text
Sweep detection أدق للتيكات
Premium filter مرن حسب قوة الاندفاع
Target ladder أوسع
Stop مرن غير انتحاري
```
