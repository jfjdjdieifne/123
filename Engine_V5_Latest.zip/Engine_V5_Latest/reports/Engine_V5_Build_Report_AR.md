# تقرير بناء V5 — من “مثالي حافظ” إلى “مرن يفهم” مع صدق اختباري

## ما الذي تم بناؤه فعليًا

### 1) محرك جديد منفصل `engine_v5/`
لم أرقّع النسخة القديمة ترقيعًا عشوائيًا. بنيت مسارًا جديدًا:

- `engine_v5/core.py`
  - ذاكرة سوق سببية Multi-Timeframe.
  - كل كائن (Swing, FVG, OB, Liquidity Pool) يولد معه `known_index`.
  - لا يُستخدم أي كائن قبل زمن معرفته.
- `engine_v5/strategy.py`
  - عقل القرار: Context / Intent / Location / Execution / Objective / Risk.
  - الأوزان تحجم الصفقة بدل veto الأعمى.
- `engine_v5/backtest.py`
  - Walk-forward bar-by-bar.
  - صفقة على next decision، إدارة بعد الدخول، SL-first عند الغموض.
- `engine_v5/run_paper_signals.py`
  - runner للباكتيست/الورقي.

---

## الفلسفة الجديدة

### بدل: “إذا شرط واحد فشل → لا صفقة”
صار:

```text
Score = Context × Intent × Location × Execution × Objective × RR efficiency
Probability = structural score + online calibration from past outcomes
Expected_R = Probability × Net_RR - (1 - Probability)
Size = f(Expected_R, confidence, volatility, cash cap)
```

إذا كانت الصفقة ضعيفة:
- probability تنخفض
- size يصغر
- قد يصل الحجم إلى ما تحت minimum notional فلا تنفذ

أما الأمان الصلب فبقي:
- لا lookahead
- لا أهداف مفبركة بلا liquidity/projection مشروطة
- لا شراء في انهيار بدون امتصاص
- spot buy only

---

## الخرائط داخل V5

### 1) SWEEP_REVERSAL — أعلى قناعة
وهي أقرب شيء لسلوك ICT الحقيقي:

1. SSL pool تُجرف.
2. السعر يغلق فوق المستوى → sweep لا breakdown.
3. displacement صاعد بحجم وزخم.
4. رجوع إلى CE/منتصف الحركة.
5. هدف = BSL أو bearish FVG/OB معروف قبل الدخول.

### 2) MAP1_PRO_TREND
- HTF bullish/transitional.
- protected low + BOS.
- خصم تكيفي:
  - импульس قوي → خصم ضحل
  - импульس ضعيف → خصم أعمق
- Stop تحت structure/PD array مع تنفس ATR.
- أهداف داخلية وخارجية.

### 3) MAP2_COUNTER_TREND
- فقط بعد sweep و LTF improvement.
- هدف خاطف.
- حجم أصغر.
- خروج أسرع.

---

## ما الذي اختبرته على بياناتك

البيانات:
- BTCUSDT 15m شهر
- SOL/AVAX/DOGE/PEPE/WIF 5m شهر

### ماذا حدث أثناء التطوير؟
1. النسخة الأولى المرنة overtraded وخسرت بسرعة.
2. أصلحت:
   - مطاردة السعر
   - stops ضيقة
   - أهداف قريبة تلتهمها الرسوم
   - counter-trend بدون sweep
   - دخول بدون reclaim
   - BTC gravity للألت كوينز
3. بعد التشديد:
   - عدد الصفقات قل كثيرًا
   - الخسارة القصوى انخفضت
   - لكن النتيجة الصافية على الشهر ما تزال غير مثبتة Edge.

### النتيجة الصادقة
على بيانات الشهر المرفقة:
- V5 لم يحقق ربحًا مستقرًا عبر كل الأصول.
- بعض الأصول أظهرت سلوكًا أفضل (WIF/AVAX/DOGE في فلاتر معينة).
- لكن العينة صغيرة جدًا ولا تكفي للحكم.

هذا ليس فشلًا في الفكرة؛ هذا يعني أن:
- شهر واحد لا يكفي
- CVD proxy أضعف من CVD الحقيقي
- الألت كوينز تحتاج فلتر BTC أقوى وبيانات أكثر

---

## لماذا لم “أجمّل” النتائج؟
لأن قاعدتك الأساسية: ممنوع هبد وممنوع سطحية.  
لا أستطيع أن أقول “المحرك صار يوزع أرباحًا” بينما الاختبار على شهر واحد لا يثبت ذلك.

الصدق الهندسي هنا:
- المحرك أصبح أكثر عقلانية من V4.
- أقل مثالية عمياء.
- أكثر احترامًا للسياق.
- لكن لا يوجد دليل إحصائي كافٍ بعد على edge حقيقي.

---

## الخطوة الصحيحة الآن

### لا ننتقل للايف
ولا حتى نثق بالأرقام الحالية.

### المطلوب:
1. بيانات 3–6 أشهر:
   - 1m أو 5m
   - BTC + SOL + 2–3 ألت عالية السيولة
2. CVD حقيقي:
   - aggTrades/taker buy sell
3. Paper trading حي:
   - إشارات
   - journal
   - reconciliation
4. Optimization على validation:
   - ليس على نفس بيانات التطوير

---

## كيف تشغل V5 الآن

```bash
python3 -m engine_v5.run_paper_signals \
  --csv repo_123/extracted/project/SOLUSDT_5m_last_month_real.csv \
  --base-tf 5m \
  --btc-csv repo_123/extracted/project/btcusdt_15m_last_month.csv \
  --out engine_v5/paper_signals_SOLUSDT.json
```

---

## الخلاصة

V5 هو الاتجاه الصحيح:
- لا veto أعمى
- لا أرقام جامدة بلا معنى
- لا مثالية تعطّل التداول
- لا غش مستقبلي

لكنه ما يزال **بحثيًا**:
- يحتاج بيانات أكثر
- CVD حقيقي
- Paper حي
- ضبط أوزان على عينات منفصلة

هذا هو الطريق الصادق من “محرك حافظ” إلى “محرك فاهم”.
