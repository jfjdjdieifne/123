# تشريح مجهري + خطة تحويل المحرك من “حافظ مثالي أعمى” إلى “فاهم مرن يتنفس مع السوق”
**التاريخ:** 2026-07-22  
**المشروع:** ICT_Super_Engine_Causal_RR3_V4  
**الوضع المطلوب:** Spot Buy Only — No Lookahead — Bar-by-Bar — Multi-Timeframe — Paper Trading أولاً  
**السياسة الجديدة المختارة:** RR طبقي ذكي (سكالب/يومي/أسبوعي) بدل RR≥3 ثابت خنّاق.

> **الخلاصة الصادقة:** المحرك الحالي ليس “غبيًا”؛ هو صارم بنيويًا بشكل صحيح من جهة منع الغش المستقبلي، لكنه تحول إلى **مصفاة مثالية مفرطة**: يفضّل أن لا يتداول إطلاقًا على أن يأخذ صفقة غير “مثالية”. في سوق حقيقي، الشكل المثالي الكامل نادر، بينما الفرص اليومية/الساعية موجودة إذا تحول المحرك من “بوابة AND واحدة” إلى **مصفوفة قرار سياقية مرنة**: سياق + نية + موقع + تنفيذ + هدف + حجم.

---

## 1) الدليل الرقمي على الاختناق المثالي

من ملف `causal_narrative_rr3_results.json` على BTCUSDT 15m لمدة شهر:

| المرحلة | العدد | القراءة |
|---|---:|---|
| شموع مراقبة | 2,780 | السوق يتحرك طبيعي |
| سياق 4H صاعد Map1 | 662 | فقط 23.8% من الوقت |
| Protected Low مرشح | 76 | معقول |
| BOS سببي | 36 | جيد |
| لمس Discount | 105 | يوجد عودة لمناطق |
| Micro Trigger | 9 | هنا بدأت المثالية الزائدة |
| هدف سيولة موجود | 9 | موجود |
| Net RR ≥ 3 | **1** | **الاختناق الأكبر** |
| صفقات منفذة | **1** | صفقة واحدة خاسرة -1$ |

وفي فحص مرن أعدته على نفس البيانات (بدون تنفيذ، فقط قياس عنق الزجاجة):

- عند تخفيف micro trigger والسماح بخصم 30–79% بدل 50–79% فقط:
  - BTC 15m: 96 setupًا.
  - SOL/AVAX/DOGE/PEPE/WIF 5m: من 116 إلى 313 setupًا لكل عملة.
- لكن مع الهدف القديم “أقرب قمة 15m مؤكدة” + RR≥3: **صفر صفقة**.
- السبب: أقرب قمة مؤكدة كانت غالبًا قريبة جدًا من الدخول.
  - متوسط العائد إلى أقرب قمة 15m = **0.068% فقط**.
  - الوسيط = **0.035% فقط**.
- عند استخدام هدف أكثر واقعية (Term أو Term+0.27 أو Term+0.62) مع Stop عند Breaker/مستوى الكسر بدل القاع البعيد:
  - من 64 setupًا صالحًا لحساب RR:
    - الهدف = Term: 21 صفقة ≥1.5R، 10 صفقات ≥3R.
    - الهدف = Term + 0.27 Range: 33 صفقة ≥1.5R، 20 صفقة ≥3R.
    - الهدف = Term + 0.62 Range: 54 صفقة ≥1.5R، 26 صفقة ≥3R.

**النتيجة:** السوق كان يعطي فرصًا، لكن “هدف السيولة القريب جدًا + RR3 الصافي” قتلها. هذا ليس انضباطًا فقط؛ هذا مثالية تجعل المحرك “حافظ مش فاهم”.

---

## 2) لماذا صار المحرك “حافظ مش فاهم”؟

### 2.1 سلسلة AND صلبة بدون تعويض سياقي
في `engine/core/narrative_gate.py` البوابة الحالية تفرض:

- HTF bullish
- Protected low verified
- BOS confirmed
- In discount
- Execution rejection
- Objective exists
- Net RR ≥ 3

إذا سقط شرط واحد → رفض كامل.  
هذا ممتاز كـ “فرامل أمان”، لكنه سيء كـ “عقل قرار”؛ لأن السوق لا يعطي كل الشروط بنسبة 100% في كل صفقة.

**الفاهم** يفرّق بين:
- **Veto صلب:** لا يمكن تجاوزه أبدًا، مثل lookahead، شراء في Premium، لا invalidation، لا هدف حقيقي.
- **Weight مرن:** يمكن أن يعوّضه دليل أقوى، مثل جودة displacement، امتصاص CVD، موقع FVG/OB، قوة HTF draw.

المحرك الحالي يعامل معظم الشروط كـ veto، فيتجمد.

---

### 2.2 RR≥3 كشرط قبول وحيد يقتل السكالب واليومي
شرط 3R net مناسب لصفقات منتقاة جدًا، لكنه ليس مناسبًا لكل الفريمات.

- سكالب 1m/5m: كثير من الفرص الصحيحة 1.2–2R، لكنها عالية الاحتمال وسريعة.
- يومي 15m/1H: 1.8–3R معقول.
- أسبوعي 4H/Daily: 3R+ منطقي لأن الهدف سيولة خارجية أبعد.

المحرك الحالي يفرض 3R على الجميع، فينتظر “الصفقة الأسطورية” التي قد تأتي مرة بالشهر.

---

### 2.3 Target Resolver ضيّق جدًا
في `causal_narrative_rr3_audit.py` الهدف = أقرب swing high مؤكد فوق الدخول.

هذا صحيح منهجيًا ضد اختراع الأهداف، لكنه ناقص سرديًا؛ لأنه يتجاهل:

- Term نفسه كسيولة/مغناطيس أول.
- Equal highs pools.
- Bearish FVG/OB على فريم أعلى.
- Internal range liquidity بعد كسر Term.
- External liquidity على 1H/4H.
- Measured move كمنطقة احتمال، لا كهدف مفبرك.

عندما يكون أقرب swing high فوق الدخول ببضع عشرات الدولارات فقط على BTC، لا يمكن لأي RR أن يعيش.

---

### 2.4 Stop Loss مثالي بعيد بدل Stop سردي عضلي
المحرك الصارم يضع SL تحت origin/protected low.  
هذا آمن نظريًا، لكنه يجعل Risk كبيرًا جدًا عندما يكون الدخول浅/قريب من Term.

النتيجة:
- Entry صحيح.
- Target قريب.
- SL بعيد.
- RR ينهار.

المطلوب حسب قواعده أنت:
- في الترند الصاعد القوي: Stop تحت قاع شمعة الانطلاق/أول FVG، ليس دائمًا القاع البعيد.
- في الفجوات العريضة: Stop تحت Breaker أو 50% FVG.
- في Counter-Trend: Stop تحت قاع Breaker مباشرة، لا القاع المتطرف البعيد.

---

### 2.5 Map2 شبه معطّل رغم أنه مصدر الصفقات في السوق الهابط/المتذبذب
في التقرير الصارم: 2 sweeps فقط على 4H خلال شهر BTC.  
لكن الفحص المرن أظهر أن LTF CHoCH proxy بعد sweeps/سياقات مشابهة يتكرر مئات المرات على 5m للألت كوينز.

المحرك الحالي يخاف من Map2 لأنه تاريخيًا استخدم أهدافًا مفبركة بنسب Range.  
الحل ليس إلغاء Map2، بل:

- Map2 = صفقة خاطفة بهدف HTF FVG/OB أو أول BSL داخلية.
- RR طبقي أصغر.
- حجم أصغر.
- خروج أسرع.
- veto صارم إذا كان Bleeding/CVD ينهار.

---

### 2.6 بعض الوحدات البرمجية فيها “لمسات مستقبلية” إن استُخدمت مباشرة في Live/Backtest
هذا لا يعني أن كل المشروع غش؛ النسخة `causal_narrative_rr3_audit.py` أفضل بكثير ومنضبطة.  
لكن وحدات `engine/core` الأصلية فيها مواضع يجب إعادة بنائها زمنياً قبل أي Paper:

- `fvg_detector.py` و`orderblock_detector.py` يقرآن `df.iloc[i+1]` لاكتشاف FVG.
  - صحيح ميكانيكيًا أن FVG يتأكد بعد إغلاق الشمعة الثالثة، لكن في walk-forward يجب أن يصبح معروفًا فقط عند `known_at_index = i+1`، وليس داخل حلقة ترى المستقبل.
- `orderblock_detector.py` يفحص mitigation عبر `for k in range(i+1, len(df))`.
  - هذا lookahead صريح إذا استخدم أثناء القرار.
- `counter_trend_execution.py` يفحص `touch_idx+3` CVD بعد اللمس.
  - هذا مستقبل صريح إذا دخل بناءً على touch_idx الحالي.
- `swing_detector.py` يستخدم `candidate_index+1` volume.
  - يجب أن يُستبدل بسلوك مؤكد قبل القرار أو بحالة “pending” حتى تغلق شمعة تالية.

**القاعدة الذهبية:**  
أي كائن FVG/OB/Swing/Target يجب أن يحمل:
```text
created_at_index
known_at_index
invalidated_at_index
mitigated_at_index
```
ولا يُستخدم إلا إذا `known_at_index <= decision_index`.

---

### 2.7 CVD الحالي Proxy وليس Spot CVD حقيقي
المحرك يشتق CVD من:
```text
(close - low)/(high - low) × volume
```
هذا approximation مفيد، لكنه ليس CVD حقيقي مبني على aggressor trades.

لذلك في Paper/Live يجب:
- إما سحب `aggTrades`/taker buy sell من Binance أو KuCoin.
- أو بقاء OHLC proxy مع تسميته “CVD Proxy” وتخفيض وزنه، وعدم استخدامه كدليل وحيد.

---

## 3) الفلسفة الصحيحة للمحرك المرن “مثل الماء”

المحرك المرن لا يعني “رخو” أو “يشتري أي شيء”.  
المحرك المرن يعني:

1. **يفهم السياق قبل الشكل.**
2. **يقيس الجهد مقابل النتيجة.**
3. **يعرف متى يكون السوق متسرعًا فيأخذ دخولًا ضحلًا، ومتى يكون هشًا فيطلب خصمًا عميقًا.**
4. **يربط الهدف بالمكان الذي توجد فيه سيولة فعلًا، لا بنسبة فيبوناتشي فقط.**
5. **يغيّر الحجم حسب الجودة، لا يرفض الصفقة كليًا إذا كانت الجودة متوسطة.**
6. **يخرج مبكرًا عندما تتغير السردية، بدل أن ينتظر TP أو SL فقط.**

---

## 4) المعماري المقترح: V5 — Contextual Narrative Engine

### 4.1 الطبقات الست

```text
1. Context Layer   : ما هو السوق؟ Bullish / Bearish / Range / High-Beta / Thin liquidity
2. Intent Layer    : ماذا تريد الحيتان؟ Sweep؟ Accumulation؟ Distribution؟ Defense؟
3. Location Layer  : أين نحن من Range؟ Premium / Discount / CE / Breaker / FVG / OB
4. Execution Layer : كيف يتنفس السعر عند المنطقة؟ Effort vs Result / CVD / Wick / 3rd bar
5. Objective Layer : إلى أين يوجد مال/سيولة؟ Target ladder حقيقي
6. Risk Layer      : كم ندخل؟ وأين نُبطل؟ وكيف نخرج إن تغيرت القصة؟
```

كل طبقة تعطي:
- Score 0→1
- Confidence 0→1
- Vetoes منفصلة

ثم القرار النهائي ليس `if/else` أعمى، بل:

```text
Trade_Quality = weighted_sum(context, intent, location, execution, objective)
Expected_R = Probability × Reward_R - (1 - Probability) × Loss_R
Accept if:
  no hard veto
  Expected_R > threshold
  Net RR meets tier minimum
  fees/slippage affordable
```

---

## 5) سياسة RR الطبقية الذكية — بديل RR≥3 الثابت

### Tier A — Scalp / Momentum / Hourly
**الفريمات:** 1m/5m/15m  
**السياق:** Pro-trend قوي أو Counter-trend بعد sweep + CHoCH واضح.  
**الهدف:** أول IRL/Bearish FVG/EQH قريبة.  
**RR المطلوب:**  
- Net RR ≥ 1.3–1.8 فقط.
- لكن بشرط Execution قوي وCVD مؤيد.
- حجم صغير/متوسط.
- خروج سريع عند أول إشارة امتصاص معاكس.

### Tier B — Intraday / Daily
**الفريمات:** 15m/1H  
**السياق:** Map1 مع HTF bullish أو Map2 بعد HTF sweep قوي.  
**الهدف:** Term + BSL داخلية أو HTF PD array.  
**RR المطلوب:**  
- Net RR ≥ 2.0–2.5.
- حجم أكبر من Tier A إذا كانت الجودة عالية.

### Tier C — Swing / Weekly
**الفريمات:** 4H/Daily  
**السياق:** HTF liquidity sweep + HTF CHoCH/BOS + discount عميق.  
**الهدف:** External liquidity / EQH / 4H bearish FVG بعيد.  
**RR المطلوب:**  
- Net RR ≥ 3.0+.
- حجم محسوب بدقة، وصبر أكبر.

### Expected Value بدل RR وحده
لكل صفقة:

```text
P_success = f(
  HTF alignment,
  displacement quality,
  CVD absorption,
  location inside discount,
  target quality,
  liquidity environment,
  volatility regime
)

EV_R = P_success × Net_Reward_R - (1 - P_success) × 1R
```

أمثلة قرار:
- صفقة 1.5R لكن P=0.65 → EV = 0.65×1.5 - 0.35 = 0.625R → مقبولة Tier A.
- صفقة 3R لكن P=0.25 → EV = 0.75 - 0.75 = 0 → مرفوضة رغم شكلها “مثالي”.

بهذا يصبح المحرك “يفكر”: لا يقدّس RR، ولا يقدّس الشكل.

---

## 6) خرائط الدخول المرنة — كما طلبت بالضبط

## 6.1 Map1: Pro-Trend Spot Buy — صيد الارتدادات الضحلة

### السردية
السوق صاعد. الحوت لا يحتاج تنظيف عميق؛ يكتفي بخصم داخلي سريع ثم يكمل.

### القرار الأصح
بدل انتظار 70.5–79% دائمًا:

- إذا كان displacement قويًا:
  - منطقة الشراء تنكمش إلى 30–50% من الموجة أو حافة FVG العلوية.
- إذا كان الصعود ضعيفًا متداخلًا:
  - نطلب خصمًا أعمق 61.8–79%.

### توزيع الدخول
- **70% عند أول ملامسة للحافة العلوية للفجوة/منطقة الخصم الضحلة**  
  إذا كان:
  - BOS قوي.
  - CVD 5 شموع متصاعد.
  - 3rd bar نزولي ضعيف/متداخل بأحجام متناقصة.
- **30% عند CE/50% FVG أو OB مخفي داخل الفجوة**  
  كحماية لمتوسط سعر أفضل.

### Stop المرن
ليس دائمًا تحت القاع البعيد:
- تحت قاع شمعة الانطلاق الأولى، أو
- تحت 50% FVG، أو
- تحت Breaker/آخر شمعة بيع قبل displacement.

إذا كانت الفجوة عريضة جدًا:
- نرفض الدخول الكامل من الأعلى.
- ندخل 30% فقط من الأعلى، و70% بالعمق.
- أو نرفض إذا كان fee erosion > 15% من الهدف.

### الهدف
سلم أهداف:
1. أول سيولة داخلية فوق الدخول.
2. Term / آخر قمة.
3. Term + measured move 0.27.
4. Term + 0.62 أو EQH/HTF BSL.

الخروج:
- إذا تفعّل 70% من الأعلى فقط → صفقة momentum، هدف أقرب.
- إذا تفعّل 100% بالعمق → صفقة quality، نمدد للهدف الأبعد.

---

## 6.2 Map2: Counter-Trend Spot Buy — شراء الانهاك بعد جرف السيولة

### السردية
السوق هابط. لا نشتري كل ارتداد. نشتري فقط عندما ينفد جهد البائعين.

### شروط الفهم لا الحفظ
1. Sweep/جرف سيولة تحت قاع مهم.
2. CVD 5 شموع لا يؤكد البيع:
   - السعر يكسر القاع.
   - CVD يثبت أو يرتفع → امتصاص.
3. CHoCH/MSS على LTF بجسم لا ذيل.
4. العودة إلى Breaker أو CE/FVG.
5. 3rd bar filter:
   - إذا كان النزول للمنطقة عنيفًا بأحجام متزايدة → ممنوع.
   - إذا كان نزيفًا بطيئًا بأحجام متناقصة → مقبول.

### توزيع الدخول
- **40% عند Breaker Block**  
  لأن الحوت غالبًا يعيد اختبار سقف الهيكل المخترق.
- **60% عند CE / منتصف FVG**  
  لأن الفجوة قد تُملأ نصفيًا قبل الانطلاق.

### Stop المرن
- تحت قاع Breaker مباشرة، أو
- تحت 50% FVG، أو
- تحت قاع الشمعة الوسيطة داخل الفجوة.

ليس تحت القاع المتطرف البعيد إلا إذا كان قريبًا ومنطقيًا.

### الهدف
- TP1: أول Bearish FVG داخلي / أول قمة هابطة رئيسية.
- TP2: أقرب Bearish OB / HTF resistance.
- لا طمع في انعكاس أسبوعي كامل.
- Counter-trend = خاطف؛ نأخذ الربح ونعود كاش.

---

## 7) كتالوج الفخاخ الذي يجب أن يحمله V5 داخل وزنه

| الفخ | الشكل | القرار |
|---|---|---|
| فخ الاختراق الوهمي | كسر قمة بجسم قريب من الحافة بدون displacement | Suspended حتى تأكيد |
| فخ الذيل العلوي | كسر قمة ثم إغلاق بذيل علوي طويل | Liquidity swept، لا شراء |
| فخ الدعم الشبح | قاع جميل لكن حجم الارتداد ضعيف | Weak low، لا protected |
| فخ خط الاتجاه | قيعان منتظمة R² مرتفع | Liquidity pool، انتظر الجرف |
| فخ FVG الشبح | FVG من شمعة ضعيفة الحجم | Ghost FVG، حظر |
| فخ OB المكسور | هبوط للمنطقة بشموع حمراء متزايدة الجسم | Failed OB، إلغاء |
| فخ Bleeding | نزول بطيء مع CVD ينهار | لا شراء، توزيع/غياب دعم |
| فخ Equal Lows | قاعان متساويان تمامًا | لا stop تحتهما مباشرة؛ انتظر sweep |
| فخ Equal Highs | قمتان متساويتان فوقك | هدف مغناطيسي، لكن خروج عنده غالبًا |
| فخ التمويل/Inflows | شكل شرائي + inflows ضخمة للمنصات | Hard block إذا live data متوفر |

---

## 8) إدارة الصفقة Bar-by-Bar — لا نترك المال على الطاولة ولا نتجمد

### 8.1 قاعدة الإبطال اللحظي
بعد الدخول على `next_open`:

- إذا ظهرت شمعة/شموع:
  - حجم بيعي شاذ.
  - CVD proxy ينهار.
  - إغلاق في أسفل 15–20% من المدى.
  - بدون امتصاص شرائي.
→ **Exit فوري على next_open** أو تسييل 50% على الأقل حسب Tier.

### 8.2 Trailing ذكي
لا ننقل Stop إلى Breakeven عشوائيًا.

يُحرك فقط عند:
- كسر هيكل داخلي جديد.
- ظهور FVG/OB صاعد جديد.
- إغلاق شمعة دفع جديدة تؤكد استمرار التدفق.

عندها:
- Stop تحت قاع الكتلة الجديدة.
- ليس تحت أي ذيل عشوائي.

### 8.3 Scaling حسب جودة الدخول
- دخول عالي/30% فقط → هدف قريب، صفقة momentum.
- دخول عميق/100% → هدف أبعد، runner.
- CVD قوي + displacement → تقليل jni الأرباح المبكر.
- انحراف CVD سلبي والسعر يرتفع → خروج استباقي.

---

## 9) Multi-Timeframe الحقيقي — بدون تسريب

### 9.1 مبدأ العزل الزمني
لكل فريم:
```text
candle known only after close
pivot known after p bars
FVG known after 3rd candle close
OB known after displacement candle close
Target known before decision index
```

### 9.2 هرم الفريمات المقترح

| الدور | فريم | الوظيفة |
|---|---|---|
| Bias/Draw | Daily/4H | أين المال الكبير؟ |
| Context | 4H/1H | Bullish/Bearish/Range + HTF PD arrays |
| Setup | 1H/15m | BOS/CHoCH/Sweep/Discount |
| Trigger | 5m/1m | Micro absorption/wick/CVD |
| Execution | Next open | لا fill داخل شمعة القرار |

### 9.3 قواعد المنع
- لا يستخدم 5m معلومات 15m/4H لم تُغلق بعد.
- لا يستخدم 1m معلومات 5m لم تُغلق بعد.
- لا يدخل على نفس شمعة الإشارة.
- عند تعارض SL/TP داخل شمعة واحدة في backtest: SL أولاً (محافظة).

---

## 10) البيانات المطلوبة قبل Paper

1. **1m/5m لعدة أشهر** وليس شهرًا واحدًا.
   - BTC + SOL على الأقل.
   - فترات Bull / Bear / Range / Crash / Pump.
2. **رسوم حقيقية**:
   - Maker/Taker.
   - Spread.
   - Slippage تقديري.
   - Minimum notional.
3. **CVD حقيقي إن أمكن**:
   - aggTrades/taker buy volume.
   - وإلا OHLC proxy بوزن مخفض.
4. **Order book snapshots للايف لاحقًا**:
   - عمق Asks/Bids.
   - تقدير الانزلاق قبل market order.
5. **Trade Journal إلزامي**:
   - لماذا دخل؟
   - أي Tier؟
   - ما الهدف؟
   - ما السردية؟
   - ما الذي كان سيُبطلها؟
   - MFE/MAE.
   - سبب الخروج.

---

## 11) مواصفات V5 التنفيذية — ماذا نبني بعد الموافقة

### Module 1: CausalMemory
- يخزن كل كائن بتاريخ خلق ومعرفة.
- لا يسمح باستخدام أي كائن مستقبلي.
- Circular buffers للفريمات.
- DNA vault للسيولات القديمة (اختياري).

### Module 2: RegimeClassifier
- يحدد:
  - Trending bull/bear.
  - Choppy range.
  - High volatility / thin liquidity.
  - Weekend/night liquidity regime.
- يعدّل حساسية الفلاتر تلقائيًا.

### Module 3: NarrativeScorer
- Context score
- Intent score
- Location score
- Execution score
- Objective score
- Hard vetoes

### Module 4: AdaptiveLocationEngine
- Discount zone يتمدد/ينكمش حسب displacement mass.
- Buy zone ليست ثابتة 50–79%.
- Wide FVG handling: split entries.
- Nested FVG handling: overlap zone.

### Module 5: TargetLadderResolver
يعيد قائمة أهداف مرتبة:
1. Internal liquidity
2. Term
3. EQH pool
4. Bearish FVG/OB HTF
5. Measured move zones
6. External liquidity

ثم يختار Tier target:
- Scalp: أول هدف قابل للتنفيذ ≥ min Tier RR.
- Daily: هدف متوسط.
- Swing: هدف خارجي.

### Module 6: TieredRiskSizer
- Max loss per trade قابل للضبط.
- Size = f(EV, confidence, RR, liquidity, volatility).
- Confluence يغيّر الحجم، لا يرفع المخاطرة الأساسية فوق حدك.
- Fee-aware breakeven.

### Module 7: BarByBarTradeManager
- Escape filter.
- Structural trailing.
- Partial take profit.
- Time stop اختياري للـ scalp.
- Candle-close invalidation.

### Module 8: PaperExecutor + Journal
- إشارات فقط في البداية.
- يحاكي next-open fills.
- يسجل كل رفض وسببه.
- يولد funnel يومي/أسبوعي.

---

## 12) خطة الإصلاح على 5 مراحل

### المرحلة 1 — تجميد النسخ القديمة وإنشاء V5 Core
- لا نحذف القديم؛ نجعله reference.
- نبني `engine_v5/` منفصل.
- نبدأ بـ CausalMemory + TargetLadder + TieredRiskSizer.

### المرحلة 2 — إعادة تعريف Map1 المرن
- Pro-trend بشروط:
  - HTF not bearish hard block.
  - BOS/MSS بجسم + displacement.
  - Adaptive discount.
  - Split entry 70/30 أو 30/70 حسب قوة displacement.
  - Flexible SL: candle low / 50% FVG / breaker.
- نختبر على BTC/SOL 5m/15m/1H.

### المرحلة 3 — إحياء Map2 الخاطف
- Counter-trend فقط بعد:
  - Sweep confirmed.
  - CHoCH confirmed.
  - CVD absorption.
  - 3rd bar bleeding filter.
- Split entry 40/60 Breaker/CE.
- هدف أول قريب جدًا.

### المرحلة 4 — Multi-Timeframe Paper Engine
- 1m → 5m → 15m → 1H → 4H → Daily.
- كل فريم معزول زمنيًا.
- إشارات Paper مع journal.

### المرحلة 5 — Live readiness
- WebSocket async.
- Slippage filter.
- Fee erosion filter.
- Telegram batching.
- Heartbeat/reconnect.
- Watchdog.
- لا live إلا بعد Paper reconciliation.

---

## 13) ما الذي سيتغير رقميًا في سلوك المحرك؟

### قبل V5
- ينتظر كل الشروط.
- يرفض 96 فرصة لأن أقرب هدف صغير.
- صفقة واحدة بالشهر.
- مثالي لكنه غير قابل للتشغيل اليومي.

### بعد V5
- يصنف الفرص:
  - A+ : حجم أكبر، هدف أبعد.
  - B : حجم متوسط، هدف أقرب.
  - C : سكالب صغير أو رفض.
- يقبل صفقات 1.3–2R عندما يكون الاحتمال عاليًا.
- يرفض صفقات 5R عندما تكون السردية ضعيفة.
- ينتج فرصًا يومية/ساعية/أسبوعية حسب السوق.
- يخرج عندما تتغير القصة، لا عندما يضرب SL فقط.

---

## 14) الضوابط الحمراء التي لن نكسرها

1. **Spot Buy Only** — لا short/futures/leverage.
2. **No Lookahead** — القرار يرى `past = df.iloc[:i+1]` فقط.
3. **Entry next open** — لا fill خيالي داخل شمعة القرار.
4. **لا أهداف مفبركة** — Fibonacci projection منطقة بحث فقط، الهدف يحتاج liquidity/PD array معروف قبل الدخول.
5. **لا مخاطرة مفتوحة** — Risk per trade محدد، والحجم لا يتجاوزه.
6. **CVD proxy يوسم proxy** — لا ندّعي أنه spot CVD حقيقي إلا ببيانات trades.
7. **لا live قبل Paper** — إشارات + journal + reconciliation أولاً.

---

## 15) القرار الصحيح الآن

المسار الأصح ليس “تخفيف الفلاتر عشوائيًا” ولا “ترك RR3 يخنق المشروع”.

القرار الأصح:

> **بناء V5 كمحرك narratif طبقي: يحتفظ بصرامة منع الغش والمستقبل، لكنه يستبدل بوابة AND المثالية بمصفوفة جودة + EV + RR طبقي + أهداف حقيقية متعددة + إدارة صفقة مرنة.**

بهذا يتحول من:
```text
“أنا لا أتداول إلا إذا كان كل شيء مثاليًا”
```
إلى:
```text
“أنا أفهم السياق، أقيس الجهد، أختار الموقع، أزن الهدف، ثم آخذ الصفقة بالحجم المناسب”
```
