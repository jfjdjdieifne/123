"""Causal ICT target resolver.
Fibonacci projections may help locate interest, but this module never manufactures a
tradable target from a projection. A target must be a confirmed, pre-entry liquidity/PD level.
"""
from dataclasses import dataclass
from typing import Iterable, List

@dataclass(frozen=True)
class ICTObjective:
    price: float
    kind: str                 # buy_side_swing_liquidity / equal_high_pool / bearish_fvg / bearish_ob
    known_at_index: int
    strength: int=1
    source: str=""

class CausalTargetResolver:
    def long_objectives(self, *, entry: float, decision_index: int, objectives: Iterable[ICTObjective]) -> List[ICTObjective]:
        """Only levels known strictly before decision time and above a long entry survive."""
        valid=[o for o in objectives if o.known_at_index < decision_index and o.price > entry]
        # Nearest executable objective first; duplicate levels are left to caller only once.
        return sorted(valid,key=lambda o:o.price)

    def select_first_net_rr_objective(self, *, entry, stop, decision_index, objectives, risk_sizer, balance, required_net_rr=3.0):
        for objective in self.long_objectives(entry=entry,decision_index=decision_index,objectives=objectives):
            plan=risk_sizer.plan(entry=entry,stop=stop,target=objective.price,balance=balance,required_net_rr=required_net_rr)
            if plan.accepted:
                return objective,plan
        return None, risk_sizer.plan(entry=entry,stop=stop,target=entry,balance=balance,required_net_rr=required_net_rr)
