"""
Pure Displacement Concept - المفهوم الفيزيائي للفرصة الخارقة
Philosophy: In behavioral physics of crypto markets derived from deepest secrets of SMC/ICT, super opportunity is not geometric shape but explosion of big financial energy charge that makes hole in fabric of equilibrium between supply and demand.

Institutional Displacement:
To change direction of body moving fast down (bearish market or corrective), you need collision with opposite force possessing mass and energy multiples of falling body.

Mechanism of Kinetic Explosion:
When institutions decide to launch real explosive rally, they don't buy softly; they pump Aggressive Market Orders ultra huge in fractions of second.
Result: This violent pumping eats all available sell offers in Order Book instantly. Due to market emptiness from sellers at those prices, price forced to jump vertical sharp high to create huge bullish candle very large with full body extended up. This process called physically in ICT as Displacement.

Why super opportunity cancels need for deep mitigation and OB touch?
Dumb defensive engines programmed by classic books always wait for price to drop after BOS to bottom of wave to touch OB. But in super opportunity opposite happens due to Upward Momentum Inertia:
Whale who pumped hundreds of millions up still has pending buy orders thirsty in top, buying momentum so strong that sellers completely unable to push price to drop again to bottom.
If engine waits OB at bottom, price will never bounce to it, coin will fly 50% or 100% up and super opportunity lost, bot will catch only fragile weak trades.

Kinetic Steroid Matrix - Mathematical Matrix for explosive energy:
To declare current breakout as super bullish opportunity not normal move, engine calculates two physical equations at second of break candle close:

1. Relative Displacement Index RDI - Rocket Impulse Speed:
RDI = (Close[X] - Origin_Price) / (Candles_Count_In_Wave * ATR(14))
Explanation: Engine calculates net price distance from launch low to break candle close divided by time taken (number of candles). If RDI>2.5, physically: This rise is sharp and vertical abnormal and خارق, price flies with jet propulsion.

2. Z-Score of Kinetic Volume - Anomalous Liquidity Density:
Z_volume = (Recent_Wave_Volume - Mean(Volume_100)) / StdDev(Volume_100)
If Z-Score>3.0, knows volume flow represents huge positive statistical anomaly cannot be manufactured by retail humans; it is official fingerprint signature of entry of brute force of whales.

Shallow FVG Hunting - Aggressive Attack Mode:
When both conditions met RDI>2.5 AND Z-Score>3.0, engine automatically issues immediate order to suspend its strict defensive filters and switches to Aggressive Attack Mode:
[Confirm super opportunity: RDI and Z-Score extreme] -> [Cancel condition waiting deep OB at bottom 0%] -> [Extract first nearest FVG to peak: Shallow FVG] -> [Place inevitable pending Spot Buy at first cent of top line of gap]

Shallow Mitigation Gate:
Huge impulse candle left behind imbalance void (FVG between Candle1 and 3). In aggressive mode, engine determines exact first cent of top line of this shallow sub FVG nearest peak (Low of Candle3) and places Spot Buy directly there.
Physical Reason: This gap works as Magnetic Pull. Price will drop to it ultra fast and quick to fill price void and rebalance and activate remaining whale orders, then explode directly up resuming rocket rally without giving anyone chance to buy from bottom.

Protected Momentum SL - Momentum Invalidation Price:
If engine places Stop Loss in aggressive mode below distant historical low Origin 0%, Risk-to-Reward destroyed and trade becomes dumb. Whale intelligence forces engine to apply Momentum Invalidation Price law:
Place Stop below lowest price (Low) of original huge breaking impulse candle itself by one cent.
Behavioral justification strict: If this whale impulse is real and explosion honest, institutions that pumped millions in that candle will not allow price to drop entirely and break low they launched from; because that means failure of their rally and entering loss; therefore low of this candle is solid and very close safety wall to entry, giving portfolio super returns Risk-to-Reward >1:5 minimum because loss distance microscopic and precisely determined.

Traps - Aggressive Mode:
Market makers know smart bots chase impulsive candles, therefore make trap called Buying Climax Trap to trap them.
Behavioral Trap: Huge green candle breaks high, RDI and Z-Score huge, bot switches to aggressive and buys from first pullback, then price collapses and crushes portfolio.
How engine detects smartly? Places CVD Convergence Filter: looks at Spot CVD in same second of breakout.
- If candle huge and RDI huge but Spot CVD records lower high or declines down (sharp negative divergence between price movement and cumulative volume delta)
- Thinking: This bullish impulse is not honest super opportunity for whale entry; this is Exhaustion Rally (Distribution) where market makers raise price violently for last time by market to activate short stops and lure buying bots, while they sell and get rid of their coins from under table.
- Decisive Action: Engine executes immediate cancellation of aggressive mode and returns to strict defensive mode to block buying and protect spot liquidity from freezing at top.
"""

import pandas as pd
import numpy as np
from typing import Dict

class PureDisplacementSignal:
    def __init__(self):
        self.rdi = None
        self.z_volume = None
        self.is_hyper_displacement = False
        self.is_valid = False
        self.profile = None  # AGGRESSIVE_ATTACK_MODE or CONSERVATIVE_DEFENSE
        self.shallow_fvg = None
        self.entry_price = None
        self.momentum_sl = None
        self.rr = None
        self.cvd_divergence = False
        self.is_buying_climax_trap = False
        self.reason = ""
    
    def to_dict(self):
        return {
            'rdi': self.rdi,
            'z_volume': self.z_volume,
            'is_hyper': self.is_hyper_displacement,
            'is_valid': self.is_valid,
            'profile': self.profile,
            'shallow_fvg': self.shallow_fvg,
            'entry_price': self.entry_price,
            'momentum_sl': self.momentum_sl,
            'rr': self.rr,
            'cvd_divergence': self.cvd_divergence,
            'is_climax_trap': self.is_buying_climax_trap,
            'reason': self.reason
        }

class PureDisplacementEngine:
    def __init__(self, atr_period=14, rdi_threshold=2.5, z_volume_threshold=3.0):
        self.atr_period = atr_period
        self.rdi_thresh = rdi_threshold
        self.z_thresh = z_volume_threshold
    
    def calculate_atr(self, df):
        tr1 = df['high'] - df['low']
        tr2 = (df['high'] - df['close'].shift()).abs()
        tr3 = (df['low'] - df['close'].shift()).abs()
        tr = pd.concat([tr1,tr2,tr3], axis=1).max(axis=1)
        return tr.rolling(self.atr_period).mean().fillna(tr.mean())
    
    def calculate_rdi(self, df: pd.DataFrame, origin_idx: int, break_idx: int, atr_series: pd.Series) -> float:
        """
        RDI = (Close[X] - Origin_Price) / (Candles_Count_In_Wave * ATR(14))
        """
        origin_price = df['low'].iloc[origin_idx] if origin_idx < len(df) else df['low'].min()
        close_x = df['close'].iloc[break_idx]
        candles_count = break_idx - origin_idx + 1
        atr = atr_series.iloc[break_idx] if break_idx < len(atr_series) else 1.0
        
        if candles_count <=0 or atr==0:
            return 0
        
        distance = close_x - origin_price
        rdi = distance / (candles_count * atr)
        return rdi
    
    def calculate_z_volume(self, df: pd.DataFrame, break_idx: int) -> float:
        """
        Z_volume = (Recent_Wave_Volume - Mean(Volume_100)) / StdDev(Volume_100)
        Recent_Wave_Volume = sum volume of wave from origin to break
        For simplicity, volume of break candle vs last 100
        """
        vol_current = df['volume'].iloc[break_idx]
        lookback = 100
        start = max(0, break_idx-lookback)
        vol_mean = df['volume'].iloc[start:break_idx].mean() if break_idx>start else vol_current
        vol_std = df['volume'].iloc[start:break_idx].std() if break_idx>start else 1.0
        if vol_std < 1e-9:
            return 0
        z = (vol_current - vol_mean) / vol_std
        # Also consider wave volume
        origin_idx = max(0, break_idx-10)  # last 10 candles wave
        wave_vol = df['volume'].iloc[origin_idx:break_idx+1].sum()
        wave_mean = vol_mean * (break_idx-origin_idx+1)
        wave_std = vol_std * np.sqrt(break_idx-origin_idx+1) if vol_std>0 else 1
        z_wave = (wave_vol - wave_mean) / wave_std if wave_std>0 else 0
        # Return max of single and wave
        return max(z, z_wave)
    
    def calculate_cvd(self, df):
        cvd=[]
        running=0
        for _,row in df.iterrows():
            hl=row['high']-row['low']
            if hl>0:
                buy_factor=(row['close']-row['low'])/hl
                delta_factor=(buy_factor-0.5)*2
                delta=delta_factor*row['volume']
            else:
                delta=0
            running+=delta
            cvd.append(running)
        return pd.Series(cvd, index=df.index)
    
    def check_cvd_divergence(self, df: pd.DataFrame, break_idx: int) -> Dict:
        """
        Buying Climax Trap: huge green candle breaks high, RDI and Z huge, but Spot CVD records lower high or declines down
        Price new high but CVD lower high = bearish divergence distribution
        """
        cvd = self.calculate_cvd(df)
        
        # Find previous swing high before break
        lookback = 20
        start = max(0, break_idx-lookback)
        # Find previous high
        prev_high_idx = df['high'].iloc[start:break_idx].idxmax()
        if isinstance(prev_high_idx, str):
            prev_high_idx = df.index.get_loc(prev_high_idx) if prev_high_idx in df.index else start
        
        if prev_high_idx >= break_idx:
            return {'is_divergence': False, 'type': 'NO_PREV_HIGH'}
        
        price_prev_high = df['high'].iloc[prev_high_idx]
        price_curr_high = df['high'].iloc[break_idx]
        cvd_prev = cvd.iloc[prev_high_idx]
        cvd_curr = cvd.iloc[break_idx]
        
        # Price makes higher high but CVD makes lower high => bearish divergence => Buying Climax Trap
        if price_curr_high > price_prev_high and cvd_curr < cvd_prev:
            return {
                'is_divergence': True,
                'type': 'BEARISH_DIVERGENCE_BUYING_CLIMAX',
                'price_prev': price_prev_high,
                'price_curr': price_curr_high,
                'cvd_prev': cvd_prev,
                'cvd_curr': cvd_curr
            }
        
        # Also check CVD declining while price rising
        # Last 3 CVD slope negative while price slope positive
        if break_idx >=3:
            recent_cvd = cvd.iloc[break_idx-3:break_idx+1]
            recent_price = df['close'].iloc[break_idx-3:break_idx+1]
            # Simple: CVD down, price up
            if recent_cvd.iloc[-1] < recent_cvd.iloc[0] and recent_price.iloc[-1] > recent_price.iloc[0]:
                return {
                    'is_divergence': True,
                    'type': 'CVD_DECLINING_PRICE_RISING_EXHAUSTION',
                    'cvd_start': recent_cvd.iloc[0],
                    'cvd_end': recent_cvd.iloc[-1],
                    'price_start': recent_price.iloc[0],
                    'price_end': recent_price.iloc[-1]
                }
        
        return {'is_divergence': False}
    
    def find_shallow_fvg(self, df: pd.DataFrame, break_idx: int) -> Dict:
        """
        Shallow FVG Hunting: extract first nearest FVG to peak (shallow FVG)
        Shallow FVG is FVG closest to peak, formed by last 3 candles before break
        """
        # Look for bullish FVG where High C1 < Low C3, with C2 being displacement candle (break_idx or break_idx-1)
        for i in range(max(1, break_idx-5), break_idx):
            if i+1 >= len(df) or i-1 <0:
                continue
            c1 = df.iloc[i-1]
            c2 = df.iloc[i]
            c3 = df.iloc[i+1]
            if c1['high'] < c3['low'] and c2['close'] > c2['open']:
                # This is bullish FVG
                # Check if it's shallow (close to peak)
                # Shallow means its low is close to recent high
                recent_high = df['high'].iloc[max(0,break_idx-5):break_idx+1].max()
                distance_to_peak = recent_high - c3['low']
                # If distance small (< ATR), it's shallow
                return {
                    'c1_idx': i-1,
                    'c2_idx': i,
                    'c3_idx': i+1,
                    'low': c1['high'],  # bottom of FVG
                    'high': c3['low'],  # top of FVG = Low of C3
                    'ce': (c1['high']+c3['low'])/2,
                    'distance_to_peak': distance_to_peak,
                    'is_shallow': distance_to_peak < 2  # will compare with ATR later
                }
        return None
    
    def analyze(self, df: pd.DataFrame, origin_idx: int, break_idx: int) -> PureDisplacementSignal:
        sig = PureDisplacementSignal()
        
        atr_series = self.calculate_atr(df)
        
        rdi = self.calculate_rdi(df, origin_idx, break_idx, atr_series)
        z_vol = self.calculate_z_volume(df, break_idx)
        
        sig.rdi = rdi
        sig.z_volume = z_vol
        
        is_hyper = (rdi > self.rdi_thresh) and (z_vol > self.z_thresh)
        sig.is_hyper_displacement = is_hyper
        
        # Check CVD divergence for Buying Climax Trap
        cvd_div = self.check_cvd_divergence(df, break_idx)
        sig.cvd_divergence = cvd_div['is_divergence']
        
        if cvd_div['is_divergence']:
            sig.is_buying_climax_trap = True
            sig.is_valid = False
            sig.profile = "CONSERVATIVE_DEFENSE"
            sig.reason = f"Buying Climax Trap: Price new high {cvd_div.get('price_curr')} > {cvd_div.get('price_prev')} but CVD lower high {cvd_div.get('cvd_curr')} < {cvd_div.get('cvd_prev')} => Exhaustion Rally distribution, market makers raising price violently for last time to activate short stops and lure buying bots while they sell under table - Cancel aggressive mode return to defensive"
            return sig
        
        if is_hyper:
            # Aggressive Attack Mode
            sig.profile = "AGGRESSIVE_ATTACK_MODE"
            
            # Find shallow FVG
            shallow_fvg = self.find_shallow_fvg(df, break_idx)
            sig.shallow_fvg = shallow_fvg
            
            if shallow_fvg:
                entry_price = shallow_fvg['high']  # Top of shallow FVG = Low of Candle3 = first cent of top line
                # Momentum SL: below lowest low of parent impulse candle (displacement candle)
                parent_low = df['low'].iloc[shallow_fvg['c2_idx']]
                momentum_sl = parent_low - 0.01
                
                sig.entry_price = entry_price
                sig.momentum_sl = momentum_sl
                
                # Risk Reward >1:5 minimum because loss distance microscopic
                risk = entry_price - momentum_sl
                # Assume TP at recent high + 2*ATR or termination
                recent_high = df['high'].iloc[max(0,break_idx-3):break_idx+1].max()
                reward = (recent_high + atr_series.iloc[break_idx]*2) - entry_price
                rr = reward / risk if risk>0 else 0
                sig.rr = rr
                sig.is_valid = True
                sig.reason = f"Hyper Displacement Detected RDI {rdi:.2f}>2.5 and Z-Vol {z_vol:.2f}>3.0 => Pure Institutional Displacement. Shallow FVG at {shallow_fvg['low']:.2f}-{shallow_fvg['high']:.2f} CE {shallow_fvg['ce']:.2f} Entry at top {entry_price:.2f} Momentum SL at parent low {momentum_sl:.2f} RR 1:{rr:.1f} - Bypassing deep OB requirement, hunting magnetic pull"
            else:
                sig.is_valid = False
                sig.reason = f"Hyper Displacement RDI {rdi:.2f} Z {z_vol:.2f} but no shallow FVG found"
        else:
            # Conservative Defense
            sig.profile = "CONSERVATIVE_DEFENSE"
            sig.is_valid = False
            sig.reason = f"Not hyper displacement: RDI {rdi:.2f} <=2.5 or Z {z_vol:.2f} <=3.0 - Price lacks institutional commitment, next pullback will be deep to clean weak buyers, wait for Deep OB 70.5-79%"
        
        return sig

class DynamicProfileSwitcher:
    """
    Brain of Engine - Dynamic Profile Switching Engine
    Function: Cancel fixed numbers completely, transform decision into relative logical inference based on current market environment
    Engine enters chart blind, extracts criteria from breaths of current coin via Contextual Normalization
    """
    def __init__(self):
        self.displacement_engine = PureDisplacementEngine()
    
    def evaluate(self, df: pd.DataFrame, origin_idx: int, break_idx: int) -> Dict:
        atr_series = self.displacement_engine.calculate_atr(df)
        
        # Z-Score Volume
        lookback = 100
        start = max(0, break_idx-lookback)
        vol_mean = df['volume'].iloc[start:break_idx].mean() if break_idx>start else df['volume'].mean()
        vol_std = df['volume'].iloc[start:break_idx].std() if break_idx>start else 1
        vol_current = df['volume'].iloc[break_idx]
        z_vol = (vol_current - vol_mean) / vol_std if vol_std>0 else 0
        
        # ADI = Adaptive Displacement Index
        # ADI = (Termination_Price - Origin_Price) / (N * ATR)
        origin_price = df['low'].iloc[origin_idx]
        term_price = df['high'].iloc[break_idx]
        N = break_idx - origin_idx + 1
        atr = atr_series.iloc[break_idx]
        adi = (term_price - origin_price) / (N * atr) if N>0 and atr>0 else 0
        
        is_vol_anomaly = z_vol > 2.5
        is_velocity_anomaly = adi > 3.0
        
        if is_vol_anomaly and is_velocity_anomaly:
            profile = "AGGRESSIVE_ATTACK_MODE"
            conclusion = "Wave possesses hyper-impulsive institutional characteristics. High displacement detected."
            action = {
                "Allow_Shallow_FVG_Entry": True,
                "Deactivate_Deep_OB_Requirement": True,
                "Entry_Price_Symmetric": df['high'].iloc[break_idx-1] if break_idx>0 else term_price,
                "Tight_Protected_Stop_Loss": df['low'].iloc[break_idx] - 0.01,
                "Target_Take_Profit": term_price + atr*2
            }
        else:
            profile = "CONSERVATIVE_DEFENSE"
            conclusion = "Price lacks Institutional commitment, next pullback will be deep to clean weak buyers"
            action = {
                "Allow_Shallow_FVG_Entry": False,
                "Require_Deep_OB": True,
                "Deep_OB_Zone": "70.5-79% OTE",
                "Stop_Loss": "Origin 0% Historical Sacred Low"
            }
        
        # Pure displacement analysis
        pure_sig = self.displacement_engine.analyze(df, origin_idx, break_idx)
        
        return {
            "Dynamic_Switcher_Status": "EVALUATING_MARKET_STRUCTURE_VELOCITY",
            "Environmental_Statistical_Inputs": {
                "Target_Asset": "SOL/USDT",
                "Current_Wave_Candles_Count": N,
                "Volume_Z_Score_Calculated": z_vol,
                "Adaptive_Displacement_Index_ADI": adi
            },
            "Cognitive_Inference_Machine": {
                "Is_Volume_Anomaly_True": is_vol_anomaly,
                "Is_Velocity_Anomaly_True": is_velocity_anomaly,
                "Conclusion": conclusion
            },
            "Active_Profile_Execution": {
                "Current_Hormone_State": profile,
                "Filter_Relaxation": {
                    "Allow_Shallow_FVG_Entry": profile=="AGGRESSIVE_ATTACK_MODE",
                    "Deactivate_Deep_OB_Requirement": profile=="AGGRESSIVE_ATTACK_MODE"
                },
                "Calculated_Risk_Parameters": {
                    "Entry_Price_Symmetric": action.get("Entry_Price_Symmetric"),
                    "Tight_Protected_Stop_Loss": action.get("Tight_Protected_Stop_Loss"),
                    "Target_Take_Profit": action.get("Target_Take_Profit")
                }
            },
            "Pure_Displacement_Signal": pure_sig.to_dict()
        }
