"""Structural/narrative decision gate.
Weights rank valid narratives; hard vetoes protect the strategy. A strong-looking candle
cannot override missing market structure, invalidation, or a missing ICT objective.
"""
from dataclasses import dataclass

@dataclass(frozen=True)
class NarrativeDecision:
    accepted: bool
    state: str
    score: float
    reasons: tuple

class NarrativeGate:
    def evaluate_long_map1(self, *, htf_bullish, protected_low_verified, bos_confirmed,
                           in_discount, execution_rejection, objective_exists, net_rr_ok,
                           structural_quality=0., displacement_quality=0., location_quality=0., execution_quality=0.):
        hard=[
            (htf_bullish,"HTF_MAP_MISMATCH"),
            (protected_low_verified,"PROTECTED_LOW_NOT_VERIFIED"),
            (bos_confirmed,"BOS_NOT_CONFIRMED"),
            (in_discount,"NOT_IN_DISCOUNT"),
            (execution_rejection,"NO_EXECUTION_REJECTION"),
            (objective_exists,"NO_PREEXISTING_ICT_OBJECTIVE"),
            (net_rr_ok,"NET_RR_BELOW_3"),
        ]
        failed=tuple(reason for ok,reason in hard if not ok)
        # These four dimensions are explanatory weights, never an override for a veto.
        score=sum(max(0.,min(1.,x)) for x in (structural_quality,displacement_quality,location_quality,execution_quality))/4
        if failed: return NarrativeDecision(False,"REJECT",score,failed)
        return NarrativeDecision(True,"MAP1_EXECUTION_APPROVED",score,("STRUCTURE_LOCATION_EXECUTION_OBJECTIVE_ALIGNED",))
