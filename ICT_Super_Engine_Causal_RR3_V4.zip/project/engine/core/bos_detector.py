"""
BOS Break of Structure - Thinking Protocol with Triple Energy Check
Implements your specification:
1. Multi-Fractal Close Filter: Close_Position = (Close-Low)/(High-Low) >0.75
2. Context-Aware Volume Profile: Volume Bollinger Band upper outlier
3. Internal Delta Momentum: Effort vs Result = (Close-Open)/Volume - absorption/churning
Plus:
- Dynamic Displacement Threshold: Close - Last_High > ATR*0.2
- Fake Close Trap -> Suspended State
- High Liquidity Sweep Trap -> long upper wick detection
Sources:
- BOS requires body close not wick [chartwhisperer, edgeflo, kucoin]
- Volume expanding, CVD confirmation [chartwhisperer, algoalpha]
- Displacement large-bodied [quantum-algo, strike.money]
- ATR buffer filter [trendo, volumebreakout]
- Wick rejection = liquidity sweep [quantum-algo, edgeflo]
"""
import pandas as pd
import numpy as np
from typing import Dict, List

class BOS_Signal:
    def __init__(self, index, price, type, last_high_price, last_high_index):
        self.index = index
        self.price = price
        self.type = type  # BOS_bullish, BOS_bearish, FAKE_CLOSE_TRAP, LIQUIDITY_SWEPT, SUSPENDED
        self.last_high_price = last_high_price
        self.last_high_index = last_high_index
        self.close_position = None
        self.volume_outlier = False
        self.effort_vs_result = None
        self.displacement_atr_ratio = None
        self.upper_wick_ratio = None
        self.is_valid = False
        self.reason = ""
        
    def to_dict(self):
        return {
            'index': self.index,
            'price': self.price,
            'type': self.type,
            'last_swing_price': self.last_high_price,
            'last_swing_index': self.last_high_index,
            'close_position': self.close_position,
            'volume_outlier': self.volume_outlier,
            'effort_vs_result': self.effort_vs_result,
            'displacement_atr_ratio': self.displacement_atr_ratio,
            'upper_wick_ratio': self.upper_wick_ratio,
            'is_valid': self.is_valid,
            'reason': self.reason
        }

class BOSDetector:
    def __init__(self, atr_period=14, volume_lookback=50, close_position_threshold=0.75, displacement_atr_factor=0.2):
        self.atr_period = atr_period
        self.volume_lookback = volume_lookback
        self.close_pos_thresh = close_position_threshold
        self.disp_factor = displacement_atr_factor
        
    def calculate_atr(self, df: pd.DataFrame) -> pd.Series:
        high = df['high']
        low = df['low']
        close = df['close']
        tr1 = high - low
        tr2 = (high - close.shift()).abs()
        tr3 = (low - close.shift()).abs()
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = tr.rolling(max(2, len(df)//2)).mean() if len(df) < self.atr_period else tr.rolling(self.atr_period).mean()
        return atr.fillna(tr.expanding().mean()).fillna(0.5)
    
    def calculate_volume_bollinger(self, df: pd.DataFrame, idx: int) -> Dict:
        """Volume Bollinger Band for last 50 candles - outlier detection"""
        start = max(0, idx - self.volume_lookback)
        volumes = df['volume'].iloc[start:idx]
        if len(volumes) < 10:
            mean_val = volumes.mean() if len(volumes)>0 else 0
            curr = df['volume'].iloc[idx] if idx < len(df) else 0
            ratio = curr / mean_val if mean_val>0 else 0
            return {'is_outlier': False, 'mean': mean_val, 'upper_band': mean_val*1.5, 'current': curr, 'ratio': ratio, 'std': 0}
        
        mean = volumes.mean()
        std = volumes.std()
        upper_band = mean + 2*std  # 2 std per context-aware profile
        
        current_vol = df['volume'].iloc[idx]
        is_outlier = current_vol > upper_band
        
        return {
            'is_outlier': is_outlier,
            'mean': mean,
            'std': std,
            'upper_band': upper_band,
            'current': current_vol,
            'ratio': current_vol / mean if mean>0 else 0
        }
    
    def analyze_candle(self, df: pd.DataFrame, idx: int, last_swing_high: float, atr_series: pd.Series) -> BOS_Signal:
        candle = df.iloc[idx]
        high = candle['high']
        low = candle['low']
        close = candle['close']
        open_ = candle['open']
        volume = candle['volume'] if 'volume' in df.columns else 0
        
        # Only if high breaks last swing high
        if high <= last_swing_high:
            return None
        
        # Calculate filters
        # 1. Close Position: (Close-Low)/(High-Low)
        hl_range = high - low
        close_position = (close - low) / hl_range if hl_range > 0 else 0
        
        # 2. Volume Outlier
        vol_info = self.calculate_volume_bollinger(df, idx)
        
        # 3. Effort vs Result
        body = close - open_
        effort_vs_result = body / volume if volume > 0 else 0
        # For bullish, body positive. If volume huge but body tiny, effort high result low = absorption
        # Calculate previous avg effort
        prev_efforts = []
        start = max(0, idx-10)
        for j in range(start, idx):
            b = df['close'].iloc[j] - df['open'].iloc[j]
            v = df['volume'].iloc[j] if 'volume' in df.columns else 1
            if v>0:
                prev_efforts.append(b / v)
        avg_effort = np.mean(prev_efforts) if prev_efforts else effort_vs_result
        # If current effort < 0.3 * avg_effort and volume outlier, it's churning/absorption
        is_churning = vol_info['is_outlier'] and abs(effort_vs_result) < abs(avg_effort)*0.3 and abs(body) < hl_range*0.3
        
        # 4. Displacement: Close - Last_High > ATR*0.2
        atr = atr_series.iloc[idx]
        displacement = close - last_swing_high
        disp_ratio = displacement / atr if atr>0 else 0
        has_safe_distance = displacement > atr * self.disp_factor
        
        # 5. Upper Wick Trap: long upper wick
        upper_wick = high - max(open_, close)
        body_abs = abs(body)
        upper_wick_ratio = upper_wick / hl_range if hl_range>0 else 0
        body_ratio = body_abs / hl_range if hl_range>0 else 0
        is_liquidity_sweep = upper_wick_ratio > 0.6 or (body_abs>0 and upper_wick > body_abs*2)
        
        # Decision logic - Triple Energy Check
        signal = BOS_Signal(idx, close, 'BOS_bullish', last_swing_high, 0)
        signal.close_position = close_position
        signal.volume_outlier = vol_info['is_outlier']
        signal.effort_vs_result = effort_vs_result
        signal.displacement_atr_ratio = disp_ratio
        signal.upper_wick_ratio = upper_wick_ratio
        
        # Check conditions in order of causality
        if is_liquidity_sweep:
            signal.type = 'LIQUIDITY_SWEPT'
            signal.is_valid = False
            signal.reason = f"ذيل علوي طويل {upper_wick_ratio:.2f} >0.6 أو أكبر من الجسم 2x: الحوت ضرب ستوبات فوق القمة وانسحب - فخ سيولة"
            return signal
        
        if not (close > last_swing_high):
            # Body not closed above, only wick
            signal.type = 'WICK_ONLY'
            signal.is_valid = False
            signal.reason = "وِك فقط فوق القمة، الجسم لم يغلق فوقها - Sweep وليس BOS [مصدر: body close required]"
            return signal
        
        # Fake Close Trap: close barely above high, less than ATR*0.2
        if not has_safe_distance:
            signal.type = 'SUSPENDED'
            signal.is_valid = False
            signal.reason = f"إغلاق مشكوك {displacement:.2f} < ATR*{self.disp_factor}={atr*self.disp_factor:.2f}: قريب جداً من القمة، مسافة أمان غير كافية، حالة تجميد بانتظار الشمعة القادمة"
            return signal
        
        # Energy checks
        if close_position < self.close_pos_thresh:
            signal.type = 'WEAK_CLOSE'
            signal.is_valid = False
            signal.reason = f"Close Position {close_position:.2f} <0.75: المشترون لم يحافظوا على السيطرة حتى النهاية"
            return signal
        
        if not vol_info['is_outlier']:
            # Not necessarily fail, but weaker - we treat as warning, not fail if other filters strong
            # For strict protocol, require outlier
            # But allow if displacement strong and close_position strong
            if close_position < 0.85 or disp_ratio < 0.3:
                signal.type = 'LOW_VOLUME'
                signal.is_valid = False
                signal.reason = f"حجم {vol_info['current']:.0f} ليس خارج قناة Bollinger العلوية {vol_info['upper_band']:.0f}: لا يوجد بصمة حوت"
                return signal
        
        if is_churning:
            signal.type = 'CHURNING_ABSORPTION'
            signal.is_valid = False
            signal.reason = f"جهد ضخم حجم {volume} لكن نتيجة ضعيفة جسم {body:.2f}: امتصاص أو تصريف خفي Effort={effort_vs_result:.6f} vs Avg={avg_effort:.6f}"
            return signal
        
        # All filters passed
        signal.is_valid = True
        signal.type = 'BOS_bullish'
        signal.reason = f"تحقق الفلاتر الثلاثة: Close_Pos {close_position:.2f}>0.75 + Volume Outlier {vol_info['ratio']:.1f}x + Safe Distance {disp_ratio:.2f} ATR + No Sweep"
        return signal
    
    def detect(self, df: pd.DataFrame, swings: List[Dict]) -> List[BOS_Signal]:
        atr_series = self.calculate_atr(df)
        
        # Find last confirmed swing highs
        swing_highs = [s for s in swings if s['type']=='high']
        if not swing_highs:
            return []
        
        signals = []
        
        # For each candle after last swing high
        for idx in range(len(df)):
            if idx < 1:
                continue
            
            # Find most recent swing high before this candle
            recent_highs = [h for h in swing_highs if h['index'] < idx]
            if not recent_highs:
                continue
            
            last_high = recent_highs[-1]
            
            # Check if close breaks it (previous close <= last_high and current close > last_high)
            # Also check high breaks for early detection
            prev_close = df['close'].iloc[idx-1]
            curr_close = df['close'].iloc[idx]
            
            # Trigger condition: high > last_high (potential) and close > last_high (for valid) or wick only (for trap detection)
            # We analyze any candle that wicks above
            if df['high'].iloc[idx] > last_high['price']:
                sig = self.analyze_candle(df, idx, last_high['price'], atr_series)
                if sig:
                    sig.last_high_index = last_high['index']
                    signals.append(sig)
        
        # Filter duplicates: keep first valid per high
        return signals
    
    def analyze(self, df: pd.DataFrame, swings: List[Dict]) -> Dict:
        signals = self.detect(df, swings)
        
        valid_bos = [s.to_dict() for s in signals if s.is_valid and s.type=='BOS_bullish']
        fake_traps = [s.to_dict() for s in signals if not s.is_valid and s.type=='FAKE_CLOSE_TRAP']
        sweeps = [s.to_dict() for s in signals if s.type=='LIQUIDITY_SWEPT']
        suspended = [s.to_dict() for s in signals if s.type=='SUSPENDED']
        weak_close = [s.to_dict() for s in signals if s.type=='WEAK_CLOSE']
        churning = [s.to_dict() for s in signals if s.type=='CHURNING_ABSORPTION']
        
        # Update cognitive memory: after valid BOS, activate search for discount
        cognitive_state = "SEARCH_BOS"
        if valid_bos:
            cognitive_state = "SEARCH_DISCOUNT"  # تم تفعيل وضع البحث عن مناطق الخصم
        
        return {
            'all_signals': [s.to_dict() for s in signals],
            'valid_bos': valid_bos,
            'liquidity_swept': sweeps,
            'suspended': suspended,
            'fake_close_traps': fake_traps,
            'weak_close': weak_close,
            'churning': churning,
            'cognitive_state': cognitive_state,
            'total': len(signals)
        }
