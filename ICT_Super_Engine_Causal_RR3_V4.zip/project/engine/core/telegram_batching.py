"""
Telegram Rate Limit Insulator - Message Batching / Coalescing
Problem: Telegram Bot API rate limit if sends more than 30 messages per second, may freeze notification thread
Telegram enforces: 30 messages per second from one flow globally, 1 message per second per chat, 20 messages per minute per group [StackOverflow Telegram bot rate limits, BotHelp, Bot API FAQ]
Short-term exceeding is not big deal but Telegram pauses for 30 seconds, next time for 120 seconds, flow stops completely until cool down [BotHelp, Telegraf issue 331]

Solution: Program inside back Telegram queue algorithm Message Batching / Coalescing:
If bot finds several sequential kinetic updates in fractions of second, don't send separately; merge millimeter into one coordinated updated message, and require interval not less than 0.5 second between message and next, giving smooth continuous reports without triggering Telegram firewall

Implementation: Token-bucket rate limiter + per-chat locks + coalescing queue

Sources:
- When sending messages inside particular chat, avoid sending more than one message per second. We may allow short bursts that go over this limit, but eventually you'll begin receiving 429 errors. If you're sending bulk notifications to multiple users, API will not allow more than 30 messages per second or so [Telegram Bot FAQ, Telegraf]
- 30 messages/second global, 1 message/second per chat, 20 messages/minute per group [Bot API Rate Limits Explained, BotHelp]
- Need robust queue with per-chat rate limiting, retry logic, background worker [Bot API Rate Limits Explained]
- Use aiolimiter library AsyncLimiter(25,1) global leave headroom below 30/sec hard limit, per-chat AsyncLimiter(1,1) [Bot API Rate Limits Explained]
- Broadcasting leaves BotHelp at average rate 20 messages per second [BotHelp]
- RetryAfter exception handling with asyncio.sleep(e.retry_after) [Bot API Rate Limits]
"""

import asyncio
from collections import defaultdict, deque
import time
from typing import Dict, List

class TelegramBatchingQueue:
    """
    Message Batching / Coalescing: If several sequential kinetic updates in fractions of second, merge into one coordinated updated message
    Require interval not less than 0.5 second between message and next
    """
    def __init__(self, min_interval_sec=0.5, global_rate=25, per_chat_rate=1):
        self.min_interval = min_interval_sec
        self.global_rate = global_rate  # 25/sec leave headroom below 30 hard limit
        self.per_chat_rate = per_chat_rate  # 1/sec per chat
        
        self.queue = asyncio.Queue()
        self.last_sent_time = defaultdict(float)  # per chat last sent
        self.global_tokens = global_rate
        self.global_last_refill = time.time()
        
        # Coalescing buffer: if multiple updates for same signal type within 0.5 sec, merge
        self.coalescing_buffer = {}  # key -> {messages: [], last_update: timestamp}
        self.coalescing_window = 0.5  # 0.5 sec window to coalesce
    
    async def put(self, chat_id: int, message: str, signal_type: str = "GENERAL"):
        """
        Put message into queue, but if same signal_type for same chat within coalescing window, merge
        """
        key = f"{chat_id}_{signal_type}"
        now = time.time()
        
        # Check if there's recent message of same type within window
        if key in self.coalescing_buffer:
            last_update = self.coalescing_buffer[key]['last_update']
            if now - last_update < self.coalescing_window:
                # Merge: append to existing buffer instead of new message
                self.coalescing_buffer[key]['messages'].append(message)
                self.coalescing_buffer[key]['last_update'] = now
                # Don't put new item, will be sent as merged
                return
        
        # New entry or outside window
        self.coalescing_buffer[key] = {
            'messages': [message],
            'last_update': now,
            'chat_id': chat_id,
            'signal_type': signal_type
        }
        
        # Put coalesced key into queue
        await self.queue.put(key)
    
    async def get_merged_message(self, key: str) -> str:
        """Merge messages in buffer for this key into one coordinated message"""
        if key not in self.coalescing_buffer:
            return ""
        
        messages = self.coalescing_buffer[key]['messages']
        if len(messages) == 1:
            merged = messages[0]
        else:
            # Merge millimeter into one coordinated updated message
            # Example: BOS, FVG, price inside OB updates in fractions of second -> merge into one report
            merged = "\n".join([f"• {msg}" for msg in messages])
            # Add header
            merged = f"📊 Batched Update ({len(messages)} signals in {self.coalescing_window}s):\n" + merged
        
        # Clear buffer after getting
        del self.coalescing_buffer[key]
        return merged
    
    async def sender_worker(self, bot):
        """
        Background worker that sends messages with rate limiting
        Implements token-bucket: global 25/sec, per-chat 1/sec, plus 0.5 sec min interval
        """
        while True:
            try:
                key = await self.queue.get()
                chat_id = int(key.split('_')[0])
                
                # Enforce per-chat interval 0.5 sec
                now = time.time()
                last_sent = self.last_sent_time[chat_id]
                time_since_last = now - last_sent
                if time_since_last < self.min_interval:
                    await asyncio.sleep(self.min_interval - time_since_last)
                
                # Enforce global rate limit token bucket
                # Refill tokens based on time passed
                now = time.time()
                time_passed = now - self.global_last_refill
                self.global_tokens = min(self.global_rate, self.global_tokens + time_passed * self.global_rate)
                self.global_last_refill = now
                
                if self.global_tokens < 1:
                    # Not enough tokens, wait
                    await asyncio.sleep((1 - self.global_tokens) / self.global_rate)
                    self.global_tokens = 0
                else:
                    self.global_tokens -= 1
                
                # Get merged message
                merged_text = await self.get_merged_message(key)
                if not merged_text:
                    continue
                
                # Send with retry logic for 429
                try:
                    await bot.send_message(chat_id=chat_id, text=merged_text)
                    self.last_sent_time[chat_id] = time.time()
                except Exception as e:
                    # Check if RetryAfter
                    if "RetryAfter" in str(type(e)) or "429" in str(e):
                        # Extract retry_after if available, else sleep 30 sec per BotHelp: Telegram pauses for 30 seconds, next time 120 seconds
                        retry_after = 30
                        try:
                            retry_after = e.retry_after
                        except:
                            pass
                        await asyncio.sleep(retry_after)
                        # Re-queue the key
                        await self.queue.put(key)
                    else:
                        # Other error, log and continue
                        print(f"Telegram send error: {e}")
                
                self.queue.task_done()
            
            except Exception as ex:
                print(f"Sender worker error: {ex}")
                await asyncio.sleep(1)

# Usage:
# batching_queue = TelegramBatchingQueue(min_interval_sec=0.5, global_rate=25, per_chat_rate=1)
# asyncio.create_task(batching_queue.sender_worker(bot))
# 
# When engine wants to send:
# await batching_queue.put(chat_id=12345, message="BOS Confirmed at 112.10", signal_type="BOS")
# await batching_queue.put(chat_id=12345, message="FVG formed 110.15-110.50", signal_type="FVG")
# If both within 0.5 sec, they will be merged into one message:
# 📊 Batched Update (2 signals in 0.5s):
# • BOS Confirmed at 112.10
# • FVG formed 110.15-110.50
# This gives smooth continuous reports without triggering Telegram firewall 30 messages/sec
