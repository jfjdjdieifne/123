"""
Adaptive Position Sizing - Confluence Multiplier
Philosophy: Dumb bots buy fixed amount every time - حسابي انتحار لأن أبعاد الشارت متغيرة.
Smart engine doesn't fix buy amount, fixes Risk Amount (Allowed Loss USD), and leaves spot allocation to expand/shrink dynamically based on immediate market volatility.

Mechanism:
1. Confluence Multiplier M = W_Structure + W_Volume + W_Delta + W_Context (0.25x to 2.5x)
Base Risk = 1% of portfolio, Adaptive Risk = Base_Risk * M (0.25% to 2.5%)
Risk_Distance = (Entry - Stop)/Entry
Allowed_Loss_USD = Total_Balance * (Base_Risk * M)
Spot_Allocation = Allowed_Loss_USD / Risk_Distance

Why smart not fear?
If Risk_Distance tiny 1.5% (millimeter stop), engine will mathematically pump huge amount of portfolio into trade.
If market wild and stop far 10% to protect from wicks, engine will automatically buy tiny spot amount.
In both cases, financial result if wall broken and stop hit is same exact USD loss predetermined (e.g., 100$), giving ironclad stability and courage without emotions.

Sub-cells weighting via Statistical Anomaly Z-Score:

W_Structure Max 0.80+ : Multi-Timeframe Alignment BOS/CHoCH geometry
- Golden 0.80+: Entry from Map1 bullish trend 4H intact + entry from FVG/OB 15M after real BOS with safe distance
- Silver 0.40+: Entry from Map2 bearish HTF but HTF Sweep + CHoCH confirmed on 5M body close
- Dangerous 0.10+: BOS without safe distance or sub structure sideways Noise

W_Volume Max 0.60+: Z-Score of volume of launch/sweep candle vs last 100 candles
- Rocket 0.60+: Z-Score >3.0 (volume is rare huge positive anomaly massive institutional liquidity)
- Medium 0.30+: Z-Score 1.5-3.0
- Fragile 0.00: Volume near mean or below => zero to lower multiplier prevent fake breakout

W_Delta Max 0.60+: Whale buying doctrine via Spot CVD and Slingshot Flip moment
- Aggressive Absorption 0.60+: Price touches OB and Spot CVD explodes vertically up simultaneously with reversal candle ClosePos>0.85 => proves whale eating market sell offers ultra fast
- Silent Rebound 0.20+: slight price rebound but CVD rises slowly wobbly (buyer buying softly not aggressively)
- Churning Hidden 0.10- (Deduct points!): Volume huge but CVD falling or wobbly and body small (huge effort no real result) => deduct immediately protect portfolio

W_Context Max 0.50+: Macro On-Chain Intelligence
- Ideal 0.50+: Funding Rate cool stable <7-day avg and Spot Exchange Inflows negative/zero (no intention to distribute)
- Overheated 0.20- (Deduct): Funding excessively high 3x above avg or huge coin inflows suddenly into exchanges => deduct points to reduce position size anticipating whale betrayal strikes

Trap: Too-Good-To-Be-True
Scenario: Price reaches OB in deep discount OTE, technical shape genius perfect millimeter FVG+OB overlap, normal bots go All-In.
Engine checks weight matrix: Volume dead small (W_Volume=0) and Funding crazy high (W_Context=-0.20)
Math: M=0.80+0.00+0.20-0.20=0.80x
M fell below 1.0! Engine infers: "Trade shape tempting as geometric trap, but real energy weak and environment dangerous". Engine does not waste trade; reduces spot buy automatically to tiny amount. If fails and stops, loss microscopic, if succeeds and flies, profit taken without leaving money on table.
"""

import numpy as np
from typing import Dict

class ConfluenceWeighter:
    def __init__(self):
        pass
    
    def calculate_z_score(self, current: float, mean: float, std: float) -> float:
        if std == 0:
            return 0
        return (current - mean) / std
    
    def weight_structure(self, map_type: str, bos_real: bool, has_safe_distance: bool, is_noise: bool) -> float:
        """
        W_Structure Max 0.80+
        Golden 0.80+: Map1 bullish 4H intact + 15M FVG/OB after real BOS with safe distance
        Silver 0.40+: Map2 bearish HTF but HTF Sweep + CHoCH 5M body close
        Dangerous 0.10+: break without safe distance or sideways Noise
        """
        if map_type == "Map1_Bullish_ProTrend" and bos_real and has_safe_distance and not is_noise:
            return 0.80
        elif map_type == "Map2_CounterTrend" and bos_real:  # HTF Sweep + CHoCH confirmed
            return 0.40
        elif not has_safe_distance or is_noise:
            return 0.10
        else:
            return 0.30
    
    def weight_volume(self, volume_z_score: float) -> float:
        """
        W_Volume Max 0.60+
        Rocket 0.60+ if Z>3.0
        Medium 0.30+ if 1.5-3.0
        Fragile 0.00 if near mean
        """
        if volume_z_score > 3.0:
            return 0.60
        elif 1.5 <= volume_z_score <= 3.0:
            return 0.30
        else:
            return 0.00
    
    def weight_delta(self, is_aggressive_absorption: bool, close_pos: float, is_silent: bool, is_churning: bool) -> float:
        """
        W_Delta Max 0.60+
        Aggressive Absorption 0.60+: OB touch + Spot CVD explodes vertically + ClosePos>0.85
        Silent Rebound 0.20+: slight rebound but CVD rising slowly wobbly
        Churning Hidden -0.10 deduction: volume huge but CVD falling/wobbly and body small
        """
        if is_churning:
            return -0.10  # Deduct
        if is_aggressive_absorption and close_pos > 0.85:
            return 0.60
        elif is_silent:
            return 0.20
        else:
            return 0.10
    
    def weight_context(self, funding_z_score: float, inflow_z_score: float) -> float:
        """
        W_Context Max 0.50+
        Ideal 0.50+: Funding cool stable <7d avg and Inflows negative/zero
        Overheated -0.20 deduction: Funding excessively high 3x above avg or huge inflows
        """
        # Funding
        funding_weight = 0
        if funding_z_score <= 1.0:
            funding_weight = 0.25  # cool
        elif funding_z_score > 3.0:
            funding_weight = -0.20  # overheated deduction
        elif funding_z_score > 2.0:
            funding_weight = -0.10
        
        # Inflow
        inflow_weight = 0
        if inflow_z_score <= 0.5:
            inflow_weight = 0.25  # ideal negative/zero
        elif inflow_z_score > 2.5:
            inflow_weight = -0.20
        elif inflow_z_score > 1.5:
            inflow_weight = -0.10
        
        total = funding_weight + inflow_weight
        return max(-0.20, min(0.50, total))
    
    def calculate_multiplier(self, map_type: str, bos_real: bool, has_safe_distance: bool, is_noise: bool,
                             volume_z_score: float,
                             is_aggressive_absorption: bool, close_pos: float, is_silent: bool, is_churning: bool,
                             funding_z_score: float, inflow_z_score: float) -> Dict:
        w_struct = self.weight_structure(map_type, bos_real, has_safe_distance, is_noise)
        w_vol = self.weight_volume(volume_z_score)
        w_delta = self.weight_delta(is_aggressive_absorption, close_pos, is_silent, is_churning)
        w_context = self.weight_context(funding_z_score, inflow_z_score)
        
        M = w_struct + w_vol + w_delta + w_context
        M = max(0.25, min(2.50, M))  # Clamp 0.25x to 2.50x per spec
        
        # Cognitive conclusion
        if M >= 1.80:
            conclusion = "High_Volume_Institutional_Rally_With_Minor_Funding_Risk_Proceed_With_Enhanced_Size"
        elif M >= 1.20:
            conclusion = "Solid Confluence - Proceed with increased size"
        elif M >= 0.80:
            conclusion = "Geometric trap shape tempting but real energy weak and environment dangerous - Reduced size"
        else:
            conclusion = "Low confluence - Tiny size or skip"
        
        return {
            'Component_Weights': {
                'Structure_Weight': w_struct,
                'Volume_Z_Score_Weight': w_vol,
                'CVD_Slingshot_Weight': w_delta,
                'On_Chain_Context_Weight': w_context
            },
            'Final_Multiplier_M': M,
            'Cognitive_Conclusion': conclusion
        }

class AdaptivePositionSizer:
    def __init__(self, base_risk_pct=1.0):
        self.base_risk_pct = base_risk_pct  # 1% default
        self.weighter = ConfluenceWeighter()
    
    def calculate(self, total_balance: float, entry_price: float, stop_loss_price: float,
                  map_type: str, bos_real: bool, has_safe_distance: bool, is_noise: bool,
                  volume_z_score: float,
                  is_aggressive_absorption: bool, close_pos: float, is_silent: bool, is_churning: bool,
                  funding_z_score: float, inflow_z_score: float) -> Dict:
        
        # Risk Distance
        risk_distance = abs(entry_price - stop_loss_price) / entry_price if entry_price>0 else 0
        
        # Confluence Multiplier
        confluence = self.weighter.calculate_multiplier(
            map_type, bos_real, has_safe_distance, is_noise,
            volume_z_score,
            is_aggressive_absorption, close_pos, is_silent, is_churning,
            funding_z_score, inflow_z_score
        )
        M = confluence['Final_Multiplier_M']
        
        # Adaptive Risk
        adaptive_risk_pct = self.base_risk_pct * M  # 0.25% to 2.5%
        allowed_loss_usd = total_balance * (adaptive_risk_pct / 100.0)
        
        # Spot Allocation
        spot_allocation = allowed_loss_usd / risk_distance if risk_distance>0 else 0
        
        # If risk_distance tiny 1.5% => allocation huge (courage)
        # If risk_distance huge 10% => allocation tiny (protection)
        # But loss if stopped is same allowed_loss_usd (e.g., 100$)
        
        return {
            'Confluence_Engine_Status': 'CALCULATING_MULTIPLIER',
            'Component_Weights': confluence['Component_Weights'],
            'Final_Multiplier_M': M,
            'Base_Risk_Percentage': self.base_risk_pct,
            'Adaptive_Risk_To_Execute': f"{adaptive_risk_pct:.2f}%_Of_Total_Capital",
            'Risk_Distance': f"{risk_distance*100:.2f}%",
            'Allowed_Loss_USD': allowed_loss_usd,
            'Spot_Allocation_USD': spot_allocation,
            'Spot_Allocation_Coins': spot_allocation / entry_price if entry_price>0 else 0,
            'Cognitive_Conclusion': confluence['Cognitive_Conclusion']
        }
