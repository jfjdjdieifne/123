"""
Macro On-Chain Intelligence - Environmental Filter - Radar Geopolitical
Philosophy: This cell is external intelligence device. Even if technical chart is perfect in discount zone, real-time On-Chain data and composite order book may reveal whales flooding market with supply behind scenes.

API Live Telemetry Matrix:
[Discount Zone Technical Valid] -> [API Pull: Funding Rate live + Inflows] -> [Processing: StdDev and Z-Score environmental variable] -> [Result: Activate strict digital block or pass trade with support points]

Filter 1: Adaptive Funding Rate Threshold - Cooling Forward Heat
Traditional dumb bots put block at fixed funding number (e.g., if funding >0.01% stop). This is primitive because natural funding rates differ per coin and per market periods (crazy bullish market vs dead bearish market).

Dynamic Calculation Statistical Normalization:
Pull funding rate data for last 168 hours (average movement full week) for target coin, calculate:
- Mean μ_funding
- StdDev σ_funding

Funding Heat Z-Score Equation:
Z_funding = (Current_Funding_Rate - μ_funding) / σ_funding

Thinking:
- If Z_funding >3.0 (terrifying positive anomaly): Market suffers from fever and madness and record levels of greed from leverage buyers Hyper-Leveraged Longs. Market makers and platforms preparing sharp bearish massacre to liquidate these greedy and rebalance market. Our spot OBs will be pierced and crushed under forced selling liquidation cascades.
  Decision: Activate HARD BLOCK absolute digital block; close buy button, cancel pending orders, step aside like fox watching liquidation massacre without losing dollar.
- If Z_funding <=1.0: Funding cool stable healthy, grant full support points in weight processor.

Filter 2: Spot Exchange Inflow Outlier Check - Whale Dumping Vector
On spot chart you may see perfect rebound, but whale may be at same moment transferring mountains of real coin from own wallet to exchange to sell market and distribute on bots and greedy buyers.

Live Flow Volatility: Scan Spot Exchange Inflows last 48 hours as Rolling Window, extract StdDev σ_inflow

Whale Dumping Vector Equation:
Z_inflow = (Recent_Inflow_Volume - μ_inflow) / σ_inflow

Thinking:
- If Z_inflow >2.5 (vertical sharp rise of coin inflows to exchanges): Whales shipping huge real coin to sell and distribute directly market Institutional Distribution. Demand line and OB technical will not stand second against this overwhelming real supply flood.
  Decision: Launch CANCEL_AND_ABORT; delete trade immediately from execution cells, block immediate buying until Inflow returns to natural stable levels (below Mean), protecting from trap of falling knife supported by whales.

Divergent Distribution Trap:
Scenario: Price drops smoothly with decreasing volume perfect towards deep discount OTE 79%. Chart screams 100% safe buy. Normal bots pump liquidity.
Engine connects behind scenes; discovers Spot Inflow Z-Score=3.2 (huge whale flow to exchanges) and Funding Z=2.8 (market overheated futures).
Decision: Links events; Smooth decline on chart is just trick and price pinning from market makers to attract max small buyers to provide counterparty liquidity, while real whale transfers and distributes under table. Engine rejects trade entirely and writes in logs: [STRUCTURAL DIVERGENCE: CHART LIES, ON-CHAIN TELLS THE TRUTH - TRADE ABORTED]

State Matrix Logs:
{
  Telemetry_Status: ENVIRONMENTAL_CHECK_ACTIVE,
  Funding_Rate_Metric: {Current, Rolling_7D_Mean, Z_Score, Status COOL_SAFE},
  Exchange_Inflow_Metric: {Current_Spike_USD, Rolling_48H_Mean_USD, Z_Score, Status WHALE_DUMPING_ALERT_CRITICAL},
  Environmental_Gatekeeper_Decision: HARD_BLOCK_TRIGGERED,
  Reason: Inflow Anomaly detected (3.82 >2.5). Chart configuration ignored due to high on-chain selling threat.
}
"""

import numpy as np
from typing import Dict, List

class EnvironmentalFilter:
    def __init__(self, funding_z_threshold=3.0, inflow_z_threshold=2.5):
        self.funding_z_thresh = funding_z_threshold
        self.inflow_z_thresh = inflow_z_threshold
    
    def calculate_z_score(self, current: float, mean: float, std: float) -> float:
        if std < 1e-9:
            return 0.0
        return (current - mean) / std
    
    def check_funding_rate(self, current_funding: float, funding_history_168h: List[float]) -> Dict:
        """
        Adaptive Funding Rate Threshold
        Pull last 168h funding data, calculate mean and std, Z-Score
        """
        if len(funding_history_168h) < 10:
            return {'z_score': 0, 'status': 'INSUFFICIENT_DATA', 'decision': 'PASS'}
        
        mean = np.mean(funding_history_168h)
        std = np.std(funding_history_168h)
        z = self.calculate_z_score(current_funding, mean, std)
        
        if z > 3.0:
            status = "HYPER_LEVERAGED_LONG_FOMO"
            decision = "HARD_BLOCK"
            reason = f"Funding Z-Score {z:.2f}>3.0 terrifying positive anomaly - Market suffers fever madness record greed Hyper-Leveraged Longs, makers preparing massacre to liquidate greedy, our OBs will be pierced crushed under liquidation cascades"
        elif z > 2.0:
            status = "WARMING"
            decision = "REDUCE_SIZE"
            reason = f"Funding Z {z:.2f} warming, reduce position size"
        elif z <= 1.0:
            status = "COOL_SAFE"
            decision = "PASS_FULL_SUPPORT"
            reason = f"Funding cool stable healthy Z {z:.2f} <=1.0 grant full support points"
        else:
            status = "NEUTRAL"
            decision = "PASS"
            reason = f"Funding neutral Z {z:.2f}"
        
        return {
            'current': current_funding,
            'mean': mean,
            'std': std,
            'z_score': z,
            'status': status,
            'decision': decision,
            'reason': reason
        }
    
    def check_exchange_inflow(self, recent_inflow_usd: float, inflow_history_48h: List[float]) -> Dict:
        """
        Spot Exchange Inflow Outlier Check
        Scan last 48h inflows as rolling window, std dev, Z-Score
        """
        if len(inflow_history_48h) < 10:
            return {'z_score': 0, 'status': 'INSUFFICIENT_DATA', 'decision': 'PASS'}
        
        mean = np.mean(inflow_history_48h)
        std = np.std(inflow_history_48h)
        z = self.calculate_z_score(recent_inflow_usd, mean, std)
        
        if z > 2.5:
            status = "WHALE_DUMPING_ALERT_CRITICAL"
            decision = "CANCEL_AND_ABORT"
            reason = f"Inflow Z {z:.2f}>2.5 vertical sharp rise - Whales shipping huge real coin to sell distribute directly market Institutional Distribution. Demand line and OB technical will not stand second against overwhelming real supply flood. Delete trade immediately, block buying until Inflow returns below Mean, protect from falling knife"
        elif z > 1.5:
            status = "ELEVATED"
            decision = "REDUCE_SIZE"
            reason = f"Inflow elevated Z {z:.2f}"
        elif z <= 0.5:
            status = "IDEAL_NEGATIVE_ZERO"
            decision = "PASS_FULL_SUPPORT"
            reason = f"Inflow ideal negative/zero Z {z:.2f} no intention to distribute"
        else:
            status = "NEUTRAL"
            decision = "PASS"
            reason = f"Inflow neutral Z {z:.2f}"
        
        return {
            'current_spike_usd': recent_inflow_usd,
            'mean_usd': mean,
            'std': std,
            'z_score': z,
            'status': status,
            'decision': decision,
            'reason': reason
        }
    
    def analyze(self, current_funding: float, funding_history_168h: List[float],
                recent_inflow_usd: float, inflow_history_48h: List[float]) -> Dict:
        
        funding_res = self.check_funding_rate(current_funding, funding_history_168h)
        inflow_res = self.check_exchange_inflow(recent_inflow_usd, inflow_history_48h)
        
        # Combined decision
        if funding_res['decision'] == 'HARD_BLOCK' or inflow_res['decision'] == 'CANCEL_AND_ABORT':
            gatekeeper_decision = "HARD_BLOCK_TRIGGERED"
            reason = f"{'Funding Anomaly ' + str(funding_res['z_score']) + ' >3.0 ' if funding_res['z_score']>3.0 else ''} {'Inflow Anomaly ' + str(inflow_res['z_score']) + ' >2.5' if inflow_res['z_score']>2.5 else ''} Chart ignored due to high on-chain selling threat"
        elif funding_res['decision'] == 'REDUCE_SIZE' or inflow_res['decision'] == 'REDUCE_SIZE':
            gatekeeper_decision = "REDUCE_SIZE"
            reason = "One of metrics elevated, reduce size"
        else:
            gatekeeper_decision = "PASS"
            reason = "Environment cool safe, chart configuration valid"
        
        # Check Divergent Distribution Trap
        # Chart says safe buy but On-Chain says whale dumping + funding overheated
        is_divergent_trap = (funding_res['z_score'] > 2.5 and inflow_res['z_score'] > 2.5)
        if is_divergent_trap:
            gatekeeper_decision = "HARD_BLOCK_TRIGGERED_DIVERGENT_DISTRIBUTION"
            reason = "STRUCTURAL DIVERGENCE: CHART LIES, ON-CHAIN TELLS THE TRUTH - TRADE ABORTED - Smooth decline on chart is just trick and price pinning to attract max small buyers to provide counterparty liquidity, while real whale transfers and distributes under table"
        
        return {
            'Telemetry_Status': 'ENVIRONMENTAL_CHECK_ACTIVE',
            'Funding_Rate_Metric': {
                'Current': funding_res['current'],
                'Rolling_7D_Mean': funding_res['mean'],
                'Z_Score': funding_res['z_score'],
                'Status': funding_res['status']
            },
            'Exchange_Inflow_Metric': {
                'Current_Spike_USD': inflow_res['current_spike_usd'],
                'Rolling_48H_Mean_USD': inflow_res['mean_usd'],
                'Z_Score': inflow_res['z_score'],
                'Status': inflow_res['status']
            },
            'Environmental_Gatekeeper_Decision': gatekeeper_decision,
            'Reason': reason,
            'Funding_Detail': funding_res,
            'Inflow_Detail': inflow_res,
            'Is_Divergent_Trap': is_divergent_trap
        }
