"""Spot-only, fee-aware position sizing.
Risk policy never moves Entry/SL/TP. It only converts a structural trade into a quantity
whose worst planned stop loss is <= risk_usd.
"""
from dataclasses import dataclass

@dataclass(frozen=True)
class SpotRiskPlan:
    quantity: float
    cash_used: float
    planned_loss_usd: float
    net_rr: float
    min_target_for_net_rr: float
    accepted: bool
    reason: str

class NetRiskSizer:
    def __init__(self, entry_fee=0.001, exit_fee=0.001, max_risk_usd=1.0, cash_reserve_fraction=0.05):
        self.entry_fee=entry_fee; self.exit_fee=exit_fee
        self.max_risk_usd=max_risk_usd; self.cash_reserve_fraction=cash_reserve_fraction

    def plan(self, *, entry, stop, target, balance, required_net_rr=3.0):
        if not (entry > stop > 0 and target > entry and balance > 0):
            return SpotRiskPlan(0,0,0,0,0,False,"invalid_price_or_balance")
        loss_per_coin=entry*(1+self.entry_fee)-stop*(1-self.exit_fee)
        reward_per_coin=target*(1-self.exit_fee)-entry*(1+self.entry_fee)
        net_rr=reward_per_coin/loss_per_coin
        min_target=(entry*(1+self.entry_fee)+required_net_rr*loss_per_coin)/(1-self.exit_fee)
        if net_rr < required_net_rr:
            return SpotRiskPlan(0,0,0,net_rr,min_target,False,"objective_target_below_net_rr_requirement")
        qty_by_risk=self.max_risk_usd/loss_per_coin
        spendable=balance*(1-self.cash_reserve_fraction)
        qty_by_cash=spendable/(entry*(1+self.entry_fee))
        qty=min(qty_by_risk,qty_by_cash)
        loss=qty*loss_per_coin
        return SpotRiskPlan(qty,qty*entry*(1+self.entry_fee),loss,net_rr,min_target,True,"accepted")
