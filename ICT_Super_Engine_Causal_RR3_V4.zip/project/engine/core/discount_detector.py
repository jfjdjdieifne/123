"""
Discount Array - Dynamic Premium/Discount with VPVR POC + OTE Thinking
Implements your spec:
- Origin = True Protected Low (0%)
- Termination = New High after BOS (100%)
- POC via Volume Profile Visible Range (VPVR)
- Dynamic Equilibrium = (POC + Median 50%)/2
- Adaptive OTE: Hyper-Impulsive -> shallow 50-61.8%, Weak -> deep 70.5-79%
- Traps: Induced Low (FVG Distribution) + Liquidity Bleeding (Spot CVD collapse)
Sources:
- POC = price with highest volume, magnet, fair value [volume profile guides]
- VAH/VAL 70% value area, above premium below discount [quantcrawler]
- OTE 62-79% zone, 70.5 sweet spot midpoint [tradingstrategyguides, fxnx, liquidityhunters]
- Only valid after BOS/displacement [fxnx]
- Hyper-impulsive = large candles minimal overlap [algostorm]
"""
import pandas as pd
import numpy as np
from typing import Dict, List
from sklearn.linear_model import LinearRegression

class DiscountSignal:
    def __init__(self):
        self.origin = None
        self.termination = None
        self.poc = None
        self.median_50 = None
        self.dynamic_equilibrium = None
        self.premium_zone = None
        self.discount_zone = None
        self.impulse_strength = None
        self.is_hyper_impulsive = False
        self.recommended_buy_range = None  # (low, high) of OTE zone adapted
        self.is_induced_trap = False
        self.is_bleeding_trap = False
        self.cognitive_state = {}
        
    def to_dict(self):
        return {
            'origin': self.origin,
            'termination': self.termination,
            'poc': self.poc,
            'median_50': self.median_50,
            'dynamic_equilibrium': self.dynamic_equilibrium,
            'premium_zone': self.premium_zone,
            'discount_zone': self.discount_zone,
            'impulse_strength': self.impulse_strength,
            'is_hyper': self.is_hyper_impulsive,
            'buy_range': self.recommended_buy_range,
            'induced_trap': self.is_induced_trap,
            'bleeding_trap': self.is_bleeding_trap,
            'cognitive': self.cognitive_state
        }

class DiscountDetector:
    def __init__(self, volume_bins=20):
        self.bins = volume_bins
        
    def calculate_poc(self, df: pd.DataFrame, low_price: float, high_price: float) -> float:
        """
        VPVR POC: price level with highest volume between low and high
        Approximate by binning prices
        """
        # Filter df between low and high index range? Actually price range
        # Use candles where low >= origin and high <= termination? Simpler use all candles between origin index and termination index
        # But we need price range filtering
        
        # Create price bins between low and high
        bins = np.linspace(low_price, high_price, self.bins)
        volume_per_bin = np.zeros(self.bins-1)
        
        for _, row in df.iterrows():
            # Use typical price = (high+low+close)/3 as representative
            typical = (row['high'] + row['low'] + row['close']) / 3
            if low_price <= typical <= high_price:
                # Find bin
                idx = np.digitize(typical, bins) - 1
                idx = max(0, min(idx, len(volume_per_bin)-1))
                volume_per_bin[idx] += row['volume']
        
        if volume_per_bin.sum() == 0:
            # Fallback to median
            return (low_price + high_price) / 2
        
        max_bin_idx = np.argmax(volume_per_bin)
        # POC = middle of max bin
        poc = (bins[max_bin_idx] + bins[max_bin_idx+1]) / 2
        return poc
    
    def calculate_impulse_strength(self, df: pd.DataFrame, origin_idx: int, term_idx: int) -> Dict:
        """
        Hyper-Impulsive vs Weak/Gradual
        Hyper: few candles, huge volume, large bodies, minimal overlap
        """
        if origin_idx >= term_idx:
            return {'is_hyper': False, 'score': 0}
        
        segment = df.iloc[origin_idx:term_idx+1]
        num_candles = len(segment)
        
        # Total volume vs average
        avg_vol = df['volume'].mean()
        total_vol = segment['volume'].sum()
        vol_ratio = total_vol / (avg_vol * num_candles) if avg_vol>0 else 1
        
        # Average body size
        bodies = abs(segment['close'] - segment['open'])
        avg_body = bodies.mean()
        atr_proxy = (segment['high'] - segment['low']).mean()
        body_atr_ratio = avg_body / atr_proxy if atr_proxy>0 else 0
        
        # Overlapping: count bearish candles inside bullish impulse
        bullish = len(segment[segment['close'] > segment['open']])
        bearish = len(segment[segment['close'] < segment['open']])
        overlap_ratio = bearish / num_candles if num_candles>0 else 0
        
        # Displacement: price move / num_candles (speed)
        price_move = segment['high'].max() - segment['low'].min()
        speed = price_move / num_candles if num_candles>0 else 0
        
        # Scoring
        # Hyper if: few candles (<10), vol_ratio >1.8, body_atr_ratio >0.6, overlap <0.2, speed high
        is_hyper = (num_candles <= 10 and vol_ratio > 1.8 and body_atr_ratio > 0.5 and overlap_ratio < 0.3)
        
        # Weak if: many candles >15, overlap >0.4, body small
        is_weak = (num_candles > 15 or overlap_ratio > 0.4 or body_atr_ratio < 0.4)
        
        return {
            'num_candles': num_candles,
            'vol_ratio': vol_ratio,
            'avg_body': avg_body,
            'body_atr_ratio': body_atr_ratio,
            'overlap_ratio': overlap_ratio,
            'speed': speed,
            'is_hyper': is_hyper,
            'is_weak': is_weak,
            'score': vol_ratio * body_atr_ratio / (overlap_ratio+0.1)
        }
    
    def detect_fvg_distribution(self, df: pd.DataFrame, fvg_list: List[Dict], current_price: float, discount_zone_low: float, discount_zone_high: float) -> bool:
        """
        Induced Low Trap: if huge unfilled FVGs exist deeper at 75% and current bounce at 52% is fake
        """
        if not fvg_list:
            return False
        
        # Find unmitigated bullish FVGs within discount zone but deeper than current price
        deep_fvgs = []
        shallow_bounce = current_price
        
        for fvg in fvg_list:
            if fvg['type'] != 'bullish' or fvg['mitigated']:
                continue
            # FVG low/high within discount zone
            if discount_zone_low <= fvg['low'] <= discount_zone_high or discount_zone_low <= fvg['high'] <= discount_zone_high:
                # Deep if near 75% level
                if fvg['low'] < shallow_bounce - (discount_zone_high - discount_zone_low)*0.2:  # deeper
                    deep_fvgs.append(fvg)
        
        # If deep FVGs exist and we are bouncing at shallow level without filling them, it's inducement
        if deep_fvgs and shallow_bounce > min([f['low'] for f in deep_fvgs]) + (discount_zone_high - discount_zone_low)*0.2:
            return True
        
        return False
    
    def detect_liquidity_bleeding(self, df: pd.DataFrame, current_idx: int) -> Dict:
        """
        Liquidity Bleeding: increasing bearish volume + Spot CVD collapsing
        CVD proxy = cumulative sum of (close - open) * volume or (close - low)/(high-low) delta
        """
        lookback = 10
        start = max(0, current_idx - lookback)
        segment = df.iloc[start:current_idx+1]
        
        if len(segment) < 5:
            return {'is_bleeding': False}
        
        # Bearish volume increasing?
        bearish_volumes = []
        bullish_volumes = []
        cvd = 0
        cvd_values = []
        
        for _, row in segment.iterrows():
            body = row['close'] - row['open']
            vol = row['volume']
            # Delta approx
            if row['high'] != row['low']:
                delta_factor = (row['close'] - row['low']) / (row['high'] - row['low'])  # 0-1, >0.5 buying
                delta = (delta_factor - 0.5) * 2 * vol  # -vol to +vol
            else:
                delta = body * vol / 100
            
            cvd += delta
            cvd_values.append(cvd)
            
            if body < 0:
                bearish_volumes.append(vol)
            else:
                bullish_volumes.append(vol)
        
        # Check if bearish volumes increasing
        if len(bearish_volumes) >= 3:
            x = np.arange(len(bearish_volumes)).reshape(-1,1)
            y = np.array(bearish_volumes)
            if len(y) >= 2:
                model = LinearRegression().fit(x, y)
                slope_bear_vol = model.coef_[0]
                bear_vol_increasing = slope_bear_vol > 0
            else:
                bear_vol_increasing = False
        else:
            bear_vol_increasing = False
            slope_bear_vol = 0
        
        # CVD collapsing?
        if len(cvd_values) >= 3:
            x = np.arange(len(cvd_values)).reshape(-1,1)
            y = np.array(cvd_values)
            model = LinearRegression().fit(x, y)
            slope_cvd = model.coef_[0]
            cvd_collapsing = slope_cvd < 0 and cvd < 0  # decreasing and negative
        else:
            cvd_collapsing = False
            slope_cvd = 0
        
        is_bleeding = bear_vol_increasing and cvd_collapsing
        
        return {
            'is_bleeding': is_bleeding,
            'bear_vol_increasing': bear_vol_increasing,
            'slope_bear_vol': slope_bear_vol,
            'cvd_collapsing': cvd_collapsing,
            'slope_cvd': slope_cvd,
            'cvd': cvd
        }
    
    def analyze(self, df: pd.DataFrame, origin_idx: int, origin_price: float, term_idx: int, term_price: float, fvg_list: List[Dict]=None, current_idx: int=None, current_price: float=None) -> DiscountSignal:
        """
        Main analysis
        origin = True Protected Low 0%
        termination = New High after BOS 100%
        """
        signal = DiscountSignal()
        signal.origin = origin_price
        signal.termination = term_price
        
        # 1. Core Matrix Bounds
        low = min(origin_price, term_price)
        high = max(origin_price, term_price)
        
        # 2. POC via VPVR
        poc = self.calculate_poc(df.iloc[origin_idx:term_idx+1] if origin_idx<term_idx else df, low, high)
        signal.poc = poc
        
        # 3. Median 50%
        median_50 = (low + high) / 2
        signal.median_50 = median_50
        
        # 4. Dynamic Equilibrium = (POC + Median)/2 per your spec
        dyn_eq = (poc + median_50) / 2
        signal.dynamic_equilibrium = dyn_eq
        
        # 5. Split zones
        signal.premium_zone = (dyn_eq, high)
        signal.discount_zone = (low, dyn_eq)
        
        # 6. Impulse strength
        strength = self.calculate_impulse_strength(df, origin_idx, term_idx)
        signal.impulse_strength = strength
        signal.is_hyper_impulsive = strength['is_hyper']
        
        # 7. Adaptive OTE zone
        range_size = high - low
        if strength['is_hyper']:
            # Shallow discount: 50-61.8% (just below equilibrium)
            # For bullish: origin 0% low, termination 100% high, discount is below eq
            # 50% is median, 61.8% is 61.8% retracement from high
            # So buy zone from 50% to 61.8% (measured from high down)
            # Convert to price: high - range*0.5 to high - range*0.618
            buy_low = high - range_size*0.618
            buy_high = high - range_size*0.5
            signal.recommended_buy_range = (buy_low, buy_high)
        else:
            # Deep discount: 70.5-79% OTE
            buy_low = high - range_size*0.79
            buy_high = high - range_size*0.705
            signal.recommended_buy_range = (buy_low, buy_high)
        
        # 8. Trap detection - only if current price provided
        if current_idx is not None and current_price is not None:
            # Induced trap via FVG distribution
            if fvg_list:
                signal.is_induced_trap = self.detect_fvg_distribution(df, fvg_list, current_price, low, dyn_eq)
            
            # Bleeding trap via CVD
            bleed_info = self.detect_liquidity_bleeding(df, current_idx)
            signal.is_bleeding_trap = bleed_info['is_bleeding']
        
        # 9. Cognitive state JSON
        # Check if current price in discount or premium
        if current_price is None:
            # Use last close
            current_price = df['close'].iloc[-1]
            current_idx = len(df)-1
        
        if current_price > dyn_eq:
            state = "Price_In_Premium_Zone"
            action = "Block_All_Market_Buy_Orders - Buying here is financial suicide"
        else:
            state = "Price_In_Discount_Zone"
            if signal.is_bleeding_trap:
                state = "Price_In_Discount_But_Bleeding"
                action = "Freeze_Uptrend_Map - Real distribution, cancel buys to protect capital from bagholding"
            elif signal.is_induced_trap:
                state = "Price_In_Shallow_Discount_Inducement"
                action = "Reject_Buy_Wait_Deep - Current bounce at 52% is fake, whale needs to fill deep FVGs at 75%"
            else:
                action = "Block_All_Market_Buy_Orders_And_Prepare_For_Next_Phase - Monitor FVG/OB in OTE"
        
        signal.cognitive_state = {
            "Current_State": state,
            "Origin_True_Protected_Low": f"{low:.2f}",
            "Termination_New_High": f"{high:.2f}",
            "POC": f"{poc:.2f}",
            "Dynamic_Equilibrium": f"{dyn_eq:.2f}",
            "Premium_Zone": f"{dyn_eq:.2f} to {high:.2f} - NO BUY",
            "Discount_Zone": f"{low:.2f} to {dyn_eq:.2f} - Watch",
            "Target_Discount_Range": f"From {signal.recommended_buy_range[0]:.2f} to {signal.recommended_buy_range[1]:.2f} ({'Shallow 50-61.8% Hyper' if signal.is_hyper_impulsive else 'Deep 70.5-79% OTE Weak'})",
            "FVG_Magnetic_Pull": "Active if bullish FVG inside buy range",
            "Action": action,
            "Impulse_Info": f"Candles={strength['num_candles']} VolRatio={strength['vol_ratio']:.1f}x BodyATR={strength['body_atr_ratio']:.2f} Overlap={strength['overlap_ratio']:.2f} => {'Hyper-Impulsive' if strength['is_hyper'] else 'Weak/Gradual'}"
        }
        
        return signal
