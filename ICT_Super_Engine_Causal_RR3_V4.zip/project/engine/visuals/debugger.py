"""
Visual Debugger - Plots extracted zones on test chart
For manual Ground Truth comparison
"""
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # silent backend
import matplotlib.pyplot as plt
import matplotlib.patches as patches

def plot_test_scenario(df, swings_result, liquidity_result, fvg_result=None, structure_result=None, title="Behavioral Test", save_path="/home/user/test_plot.png"):
    fig, ax = plt.subplots(figsize=(14, 8))
    
    # Plot candles as line + high/low
    ax.plot(df.index, df['close'], color='black', linewidth=1, label='Close')
    ax.plot(df.index, df['high'], color='gray', alpha=0.3, linewidth=0.5)
    ax.plot(df.index, df['low'], color='gray', alpha=0.3, linewidth=0.5)
    
    # Plot swings
    swings = swings_result.get('all_swings', [])
    for s in swings:
        if s['type'] == 'low':
            ax.scatter(s['index'], s['price'], color='green', marker='^', s=100, zorder=5)
        else:
            ax.scatter(s['index'], s['price'], color='red', marker='v', s=100, zorder=5)
    
    # Protected lows
    for pl in swings_result.get('true_protected_lows', []):
        ax.scatter(pl['index'], pl['price'], color='lime', edgecolors='black', marker='*', s=300, zorder=6, label='True Protected Low')
        if pl['confirmation_level']:
            ax.axhline(pl['confirmation_level'], color='lime', linestyle='--', alpha=0.5)
    
    # Liquidity pools
    for pool in liquidity_result.get('ssl_pools', []) + liquidity_result.get('bsl_pools', []):
        color = 'blue' if pool['type'] == 'SSL' else 'orange'
        ax.axhline(pool['price'], color=color, linestyle='-', alpha=0.6, linewidth=2)
        for idx in pool['indices']:
            ax.plot([idx, idx], [pool['price']-1, pool['price']+1], color=color, linewidth=3)
        # Label
        ax.text(pool['indices'][0], pool['price'], f"{pool['type']} {pool['price']:.2f}", color=color, fontsize=8)
    
    # Swept pools
    for pool in liquidity_result.get('swept_pools', []):
        ax.scatter(pool['sweep_index'], pool['sweep_price'] if pool.get('sweep_price') else pool['price'], 
                  color='purple', marker='X', s=200, zorder=7, label='Sweep Confirmed')
    
    # FVGs
    if fvg_result:
        for fvg in fvg_result.get('all_fvgs', []):
            color = 'green' if fvg['type'] == 'bullish' else 'red'
            rect = patches.Rectangle(
                (fvg['index_start'], fvg['low']),
                fvg['index_end'] - fvg['index_start'],
                fvg['high'] - fvg['low'],
                linewidth=1,
                edgecolor=color,
                facecolor=color,
                alpha=0.2
            )
            ax.add_patch(rect)
            ax.text(fvg['index_start'], fvg['ce'], f"{fvg['type']} FVG", color=color, fontsize=7)
    
    # Structure breaks
    if structure_result:
        for br in structure_result.get('all_breaks', []):
            color = 'green' if 'bullish' in br['type'] else 'red'
            ax.scatter(br['index'], br['price'], color=color, marker='o', s=150, zorder=8)
            ax.text(br['index'], br['price'], br['type'], color=color, fontsize=7, rotation=45)
    
    ax.set_title(title)
    ax.set_xlabel("Candle Index")
    ax.set_ylabel("Price")
    ax.legend(loc='best')
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close()
    print(f"Plot saved to {save_path}")
    return save_path
