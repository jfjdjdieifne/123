import sys
sys.path.insert(0, '/home/user/project/engine')
from core.net_risk_sizer import NetRiskSizer

def test_one_dollar_stop_includes_fees():
    s=NetRiskSizer(entry_fee=.001, exit_fee=.001, max_risk_usd=1.0)
    p=s.plan(entry=100, stop=98, target=107, balance=100, required_net_rr=3)
    assert p.accepted
    assert p.planned_loss_usd <= 1.0000001
    assert p.net_rr >= 3

def test_rejects_pretty_but_sub_3r_target():
    s=NetRiskSizer(max_risk_usd=1.)
    p=s.plan(entry=100, stop=98, target=105, balance=100, required_net_rr=3)
    assert not p.accepted
    assert p.reason == 'objective_target_below_net_rr_requirement'
