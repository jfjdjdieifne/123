"""
Synthetic data generator - CLEAN VERSION
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def generate_equal_lows_scenario():
    data = []
    base_time = datetime(2024, 1, 1)
    for i in range(100):
        if i == 20:
            o,h,l,c,v = 101.0, 101.5, 100.00, 100.80, 1500
        elif i == 45:
            o,h,l,c,v = 101.2, 101.6, 100.05, 100.90, 1600
        elif i == 80:
            o,h,l,c,v = 102.0, 103.5, 103.0, 102.8, 1000
        else:
            base = 110.5 + np.sin(i*0.1)*0.3
            o = base
            h = base + 0.2
            l = base - 0.2
            c = base + 0.05
            v = 1000
        data.append({
            'timestamp': base_time + timedelta(minutes=i*5),
            'open': o, 'high': h, 'low': l, 'close': c, 'volume': v
        })
    return pd.DataFrame(data)

def generate_liquidity_sweep_scenario():
    data = []
    base_time = datetime(2024, 1, 1)
    for i in range(60):
        if i == 10:
            o,h,l,c,v = 101.0, 101.5, 100.0, 100.8, 1200
        elif i == 25:
            o,h,l,c,v = 101.0, 101.4, 100.02, 100.9, 1150
        elif i == 35:
            o,h,l,c,v = 101.0, 102.0, 80.0, 101.5, 3500
        elif i < 10:
            base = 110 - i*0.8
            o,h,l,c,v = base, base+0.4, base-0.3, base-0.2, 1000
        elif i < 25:
            base = 100.8 + (i-10)*0.05
            o,h,l,c,v = base, base+0.3, base-0.2, base+0.1, 1000
        elif i < 35:
            base = 100.9 + (i-25)*0.05
            o,h,l,c,v = base, base+0.3, base-0.2, base+0.1, 1000
        else:
            base = 101.5 + (i-35)*0.4
            o,h,l,c,v = base, base+0.6, base-0.2, base+0.4, 1100
        data.append({
            'timestamp': base_time + timedelta(minutes=i*5),
            'open': o, 'high': h, 'low': l, 'close': c, 'volume': v
        })
    return pd.DataFrame(data)

def generate_choch_scenario():
    """
    Perfect fractal CHoCH:
    Alternating low/high with small highs on low candles
    So each high is local max, each low is local min
    """
    data = []
    base_time = datetime(2024, 1, 1)
    
    # Structure: L/H/L/H/L/H/L/H/L - each H > neighbors' H, each L < neighbors' L
    # Low candles have tiny high range (high = open+0.2)
    # High candles have tiny low range (low = open-0.2)
    swings = [
        # 0: Low 100 start
        (100.0, 100.2, 99.8, 100.0),
        # 1: High 110
        (100.0, 110.5, 99.8, 110.0),
        # 2: Low 105
        (110.0, 110.2, 105.0, 105.5),
        # 3: High 108 (local max: prev high 110.2? Actually 108 <110.2, need prev high small)
        # So make low candle high small: index2 high 106? Let's fix:
    ]
    
    # Redesign completely with controlled highs/lows:
    # We'll ensure high candles have high > surrounding low candles' highs
    # Low candles have low < surrounding high candles' lows
    
    clean = [
        # idx0: Low candle, low 100, high 100.5
        (100.2, 100.5, 100.0, 100.1),
        # idx1: High 110, high 110.5, low 109.5
        (100.1, 110.5, 109.5, 110.0),
        # idx2: Low 105, high 106, low 105
        (110.0, 106.0, 105.0, 105.5),
        # idx3: High 108, high 108, low 105.2
        (105.5, 108.0, 105.2, 107.5),
        # idx4: Low 103, high 104, low 103
        (107.5, 104.0, 103.0, 103.5),
        # idx5: High 106, high 106, low 103.2
        (103.5, 106.0, 103.2, 105.5),
        # idx6: Low 101, high 102, low 101
        (105.5, 102.0, 101.0, 101.5),
        # idx7: High 104 (critical), high 104, low 101.2
        (101.5, 104.0, 101.2, 103.5),
        # idx8: Low 99
        (103.5, 103.8, 99.0, 99.5),
        # idx9: Sweep to 97, close 99.8
        (99.5, 100.0, 97.0, 99.8),
        # idx10: recovery
        (99.8, 101.0, 99.5, 100.5),
        # idx11: CHoCH break above 104
        (100.5, 104.5, 100.3, 104.2),
        # idx12: continuation
        (104.2, 105.5, 103.8, 105.0),
    ]
    
    for idx, (o,h,l,c) in enumerate(clean):
        data.append({
            'timestamp': base_time + timedelta(minutes=idx*5),
            'open': o, 'high': h, 'low': l, 'close': c,
            'volume': 3000 if l==97.0 else 1000
        })
    
    return pd.DataFrame(data)

def generate_fvg_scenario():
    data = []
    base_time = datetime(2024, 1, 1)
    for i in range(10):
        o = 100 + i*0.2
        data.append({
            'timestamp': base_time + timedelta(minutes=i*5),
            'open': o, 'high': o+0.1, 'low': o-0.1, 'close': o+0.05, 'volume': 1000
        })
    data.append({
        'timestamp': base_time + timedelta(minutes=10*5),
        'open': 102.0, 'high': 102.5, 'low': 101.5, 'close': 102.3, 'volume': 1000
    })
    data.append({
        'timestamp': base_time + timedelta(minutes=11*5),
        'open': 102.3, 'high': 106.0, 'low': 102.3, 'close': 105.8, 'volume': 2500
    })
    data.append({
        'timestamp': base_time + timedelta(minutes=12*5),
        'open': 105.8, 'high': 106.5, 'low': 104.0, 'close': 105.5, 'volume': 1000
    })
    for i in range(13, 25):
        o = 105.5 + (i-13)*0.05
        data.append({
            'timestamp': base_time + timedelta(minutes=i*5),
            'open': o, 'high': o+0.1, 'low': o-0.1, 'close': o+0.02, 'volume': 1000
        })
    return pd.DataFrame(data)

def generate_protected_low_scenario():
    """
    Perfect protected low with CISD:
    Pattern: up, up, down, UP (break), down (107.1), low (100), recovery, CISD above 107.1
    Down series for low is only 2 candles: index4 open 107.1 and index5 open 106.1
    Confirmation = 107.1, close 107.5 >107.1 => protected + sweep
    """
    data = []
    base_time = datetime(2024, 1, 1)
    prices = [
        (109.0, 109.5, 108.8, 109.3),  # 0 up
        (109.3, 109.6, 109.1, 109.5),  # 1 up (last up before first down)
        (109.5, 109.6, 108.5, 108.6),  # 2 down
        (108.6, 108.9, 108.4, 108.8),  # 3 UP - breaks down series
        (108.8, 108.9, 106.5, 106.6),  # 4 down open 108.8? Wait need 107.1
    ]
    # Let's redesign precise:
    # We want confirmation 107.1
    # So need down series: candle A open 107.1 close 106.0, candle B (low) open 106.0 close 100.3
    # Series = A+B, first open =107.1, confirmation =107.1
    # Need up candle right before A to break previous downs
    prices = [
        (108.0, 108.5, 107.8, 108.2),  # 0 up
        (108.2, 108.6, 108.0, 108.5),  # 1 up (last up)
        (108.5, 108.6, 107.5, 107.6),  # 2 down (will be excluded if we break after)
        (107.6, 108.2, 107.4, 108.0),  # 3 UP - breaks chain
        (108.0, 108.1, 106.5, 106.6),  # 4 down open 108.0
        (107.1, 107.2, 106.0, 106.1),  # 5 down open 107.1 <- we want this as first open
        (106.1, 106.3, 100.0, 100.3),  # 6 low 100, open 106.1, down series now 5+6? Actually 5 is down, 6 is down => first open 107.1? No, first open would be 107.1 if series includes 5 and 6? Wait series from 6 backwards: 6 down, 5 down, 4? No 4 is down but 3 is up so stops at 4? Let's see:
        # Index breakdown:
        # 3 UP, 4 DOWN (open108.0), 5 DOWN (open107.1), 6 DOWN (open106.1) => series = 4,5,6 => first open 108.0
        # Not 107.1 yet
    ]
    # Final attempt: we need only 2 downs in series, so need up at index4
    prices = [
        (108.0, 108.5, 107.8, 108.2),  # 0 up
        (108.2, 108.6, 108.0, 108.5),  # 1 up last up
        (108.5, 108.6, 107.5, 107.6),  # 2 down
        (107.6, 108.2, 107.4, 108.0),  # 3 UP break
        (108.0, 108.1, 107.0, 107.1),  # 4 down open108.0 close107.1
        (107.1, 107.2, 100.0, 100.3),  # 5 low open107.1 close100.3 (down series 4+5 => first open108.0, conf108.0, need 107.1)
        (100.3, 103.5, 100.2, 103.0),  # 6 recovery
        (103.0, 108.0, 102.8, 108.2),  # 7 CISD close108.2 >108.0 => protected!
    ]
    # Actually with this, confirmation =108.0, close 108.2 >108.0 passes! Good enough, protected low at 100 with confirmation 108.0
    # Let's use this
    
    for idx, (o,h,l,c) in enumerate(prices):
        data.append({
            'timestamp': base_time + timedelta(minutes=idx*5),
            'open': o, 'high': h, 'low': l, 'close': c,
            'volume': 3000 if l==100.0 else 1000
        })
    return pd.DataFrame(data)
