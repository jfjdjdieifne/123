"""BOS Behavioral Tests"""
import sys
sys.path.append('/home/user')
from engine.tests.synthetic_data_bos import *
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector

def run_bos_tests():
    print("="*70)
    print("BOS BEHAVIORAL TESTING - Triple Energy Check")
    print("="*70)
    
    tests = [
        ("REAL BOS should PASS", generate_bos_real_scenario(), True),
        ("FAKE CLOSE TRAP should FAIL as SUSPENDED", generate_bos_fake_close_trap(), False),
        ("LIQUIDITY SWEEP TRAP should FAIL as SWEPT", generate_bos_liquidity_sweep_trap(), False),
        ("CHURNING TRAP should FAIL", generate_bos_churning_trap(), False),
    ]
    
    passed = 0
    for name, df, should_be_valid in tests:
        sd = ProtectedSwingDetector(pivot_length=1)
        swings = sd.analyze(df)['all_swings']
        bos = BOSDetector()
        res = bos.analyze(df, swings)
        
        valid = len(res['valid_bos']) > 0
        if valid == should_be_valid:
            print(f"✅ PASS | {name}: valid={valid} as expected")
            print(f"   Details: {res['all_signals'][0] if res['all_signals'] else 'no signal'}")
            passed += 1
        else:
            print(f"❌ FAIL | {name}: expected valid={should_be_valid} got valid={valid}")
            print(f"   All signals: {res['all_signals']}")
    
    print("="*70)
    print(f"BOS RESULTS: {passed}/{len(tests)} passed")
    if passed == len(tests):
        print("🎯 BOS CELL INTELLIGENT - DISTINGUISHES REAL FROM TRAPS")
    print("="*70)

if __name__ == "__main__":
    run_bos_tests()
