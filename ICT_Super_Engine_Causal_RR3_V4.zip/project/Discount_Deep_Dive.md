# المحطة الثالثة: Discount Array - منطقة الخصم الديناميكية

## الفلسفة: لماذا لا يشتري الحوت فوراً بعد BOS؟

بعد BOS وتشكل قمة جديدة، يدخل الريتيل في FOMO ويشتري من القمة.
الحوت لا يمكنه الشراء من القمة: أحجام بالملايين، شراء غالي يرفع متوسط دخوله.
**الحوت يتوقف عن الشراء، يبيع أجزاء صغيرة ليدفع السعر للهبوط (تصحيح) بهدف إعادته لمنطقة Underpriced / Discount حيث ترقد أوامره المعلقة.**

**وظيفة الانجن:** تحديد الحدود الرقمية الدقيقة ومنع الشراء الفوري في Premium منعاً باتاً.

---

## ميكانيكية حساب النطاق المتغير - Adaptive Premium/Discount Matrix

### الفرق بين الغبي والذكي:
- **الغبي:** يرسم فيبوناتشي ثابت 50% أو 61.8%
- **الذكي:** يفهم أن عمق التصحيح يختلف حسب قوة الدفع وحجم السيولة - Contextual Relativity

### 1. حدود المعركة Core Matrix Bounds
- `Origin_Point` = القاع المحمي الحقيقي من المحطة 1 = 0%
- `Termination_Point` = القمة الجديدة بعد BOS = 100%

### 2. POC عبر VPVR - Volume Profile Visible Range

**المفهوم:** POC هو السعر الذي شهد أضخم تبادل مالي وضخ سيولة من الحوت أثناء الصعود.

**التعريف المصدري:**
- POC = price level with highest volume, magnet, fair value [tradingwyckoff][futureshive]
- Value Area High/Low = 70% of volume, above VAH = premium, below VAL = discount [quantcrawler][futureshive]
- POC acts as magnetic level where price often returns [nicebreakout]

**التطبيق بدون رقم ثابت:**
- نقسم المدى السعري بين القاع والقمة إلى 20 bin
- نحسب حجم التداول لكل bin باستخدام Typical Price = (High+Low+Close)/3
- Bin مع أعلى حجم = POC
- هذا يتكيف مع كل عملة وفريم، لا رقم ثابت

**المعادلة الديناميكية للحد الفاصل:**
```
Median_50% = (Origin + Termination)/2
Dynamic_Equilibrium = (POC + Median_50)/2
```
أنت طلبت هذه المعادلة تحديداً: متوسط POC مع 50%.

### 3. تقسيم النطاق الإدراكي
- **Premium Zone:** أي سعر أعلى من Dynamic_Equilibrium = إغلاق زر الشراء تماماً
- **Discount Zone:** أي سعر أسفل Dynamic_Equilibrium = خلايا الصياد تستعد

```
[القمة 100%] 
  | Premium: الشراء انتحار مالي
[Dynamic Equilibrium = (POC+50%)/2]
  | Discount: هنا يشتري الحوت
[القاع 0%]
```

**المصدر:** Premium = upper half above Equilibrium, Discount = lower half below [FibAlgo ICT Premium/Discount][ctrader Premium Discount Zones]

---

## التفكير الاستنتاجي لعمق التصحيح

### الحالة أ: موجة فائقة القوة Hyper-Impulsive

**الاستنتاج الفكري:**
> صعد السعر في عدد شموع قليل جداً، حجم تراكمي شاذ ضخم، جسم كبير، لا تداخل => الحيتان شرسون ومستعجلون، لن يسمحوا بهبوط عميق إلى 70-80%

**القرار الديناميكي:**
- عدد شموع <=8، vol_ratio >1.5x، body_atr_ratio >0.5، overlap <0.25، سرعة عالية
- رفع حدود الشراء لتكون قريبة مباشرة أسفل Dynamic_Equilibrium: **50% إلى 61.8%**

### الحالة ب: موجة مجهدة Weak/Gradual

**الاستنتاج:**
> صعود بطيء متعرج، تداخل كبير، أحجام عادية => الصعود هش، الحيتان لم يضخوا كميات، الهبوط سيكون عميق لتنظيف السوق

**القرار:**
- تضييق منطقة الشراء إلى **Deep Discount OTE 70.5-79%**

**المصدر OTE:**
- OTE zone 62-79%, 70.5 sweet spot midpoint between 61.8 and 79 [tradingstrategyguides][fxnx][liquidityhunters][ictflow]
- Only valid after displacement/BOS [fxnx: "Before you even think about grabbing Fibonacci tool, you need BOS"][arongroups]
- 70.5% is not standard fib, it's algorithmic midpoint [fxnx]

---

## كتالوج الخدع في منطقة الخصم

### الفخ الأول: الدخول المبكر المستدرج - Induced Low Trap

**السيناريو:** يهبط لـ 52% خصم، ارتداد فرعي قوي، البوتات تشتري، فجأة ينهار لـ 70%.

**كشف المحرك:** تحليل توزيع FVG
- إذا وجد فجوات ضخمة غير ممتلئة عند 75% في الأسفل، والارتداد الحالي عند 52% هو ارتداد مصطنع (Inducement) لخلق سيولة جديدة
- المنطق: الحوت يحتاج الهبوط لملء الفجوات العميقة قبل الصعود الحقيقي

**التطبيق:**
- نفحص unmitigated bullish FVGs داخل Discount Zone لكن أعمق من السعر الحالي بـ 20%
- إذا موجودة والسعر الحالي يرتد من مستوى ضحل => Induced Trap => رفض الشراء وانتظار بصبر

**المصدر:** FVG imbalance must be filled, market seeks efficiency [litefinance][liquidityscan: "Signs of Invalidation - Acceleration into gap"]

### الفخ الثاني: استنزاف السيولة الفورية - Liquidity Bleeding

**السيناريو:** هبوط ليفترس الخصم لكن مصحوب بارتفاع حجم بيعي، شموع حمراء أضخم.

**كشف المحرك:** مراقبة Spot CVD
- CVD proxy = sum((Close-Low)/(High-Low) delta * Volume)
- إذا الدلتا تنهار لأسفل بحدة + حجم بيعي يتزايد (slope_bear_vol >0 و slope_cvd <0) => تصريف حقيقي وليس تصحيح

**القرار:** تجميد خريطة الاتجاه الصاعد بالكامل وإلغاء أوامر الشراء لحماية رأس المال من التعليق.

**المصدر:** [forexfactory: delta confirmation for breakout][trendo: footprint, cumulative delta show absorption][algostorm: displacement = explosive move indicating strong participation]

---

## تحديث الحالة الإدراكية

```json
{
  "Current_State": "Price_In_Discount_Zone",
  "Origin": "155.00$ True Protected Low",
  "Termination": "180.00$ New High",
  "POC": "162.30$",
  "Dynamic_Equilibrium": "163.50$",
  "Premium_Zone": "163.50 to 180.00 - NO BUY - انتحار مالي",
  "Discount_Zone": "155.00 to 163.50 - Watch",
  "Target_Discount_Range": "From 155.00 to 151.20 (Deep 70.5-79% OTE Weak)",
  "FVG_Magnetic_Pull": "Active_At_152.50$",
  "Action": "Block_All_Market_Buy_Orders_And_Prepare_For_Next_Phase",
  "Impulse_Info": "Candles=18 VolRatio=1.0x Overlap=0.35 => Weak/Gradual => Deep OTE"
}
```

المحرك أتم واجبه: منع الشراء العالي، وحدد بدقة أين منطقة الأمان الرخيصة للحوت.

---

## عملي وليس نظري - باكتيست بدون غش

- لا نستخدم مستقبل: POC وحساب Impulse يستخدم فقط [Origin:Termination] الماضي، لا ينظر للأمام
- في الباكتيست: ننتظر السعر يدخل Discount Zone شمعة بشمعة، لا نقفز للمستقبل
- Live: نفس المنطق، Block Buy في Premium، انتظر Discount بفارغ الصبر

**المرونة:** المحرك لا يشترط 100% كما شرحت أنت، بل يتكيف: Hyper=>50-61.8%، Weak=>70.5-79%، وهذا هو العملي الذي يشتغل لايف.

---

## القواعد المحفورة لا أنساها

- Deep Thinking + توسع مصدري لكل نقطة
- No Lookahead, Walk-Forward, Bar-by-Bar
- Spot Buy Only
- Behavioral Testing: 10/10 Protected Low + 4/4 BOS + Discount traps tests
- No fixed dumb numbers except proven: 50% Equilibrium, 95% R2, 70.5% sweet spot
- أذكى من أوامرك: POC + OTE المرن + FVG Distribution + CVD Bleeding
