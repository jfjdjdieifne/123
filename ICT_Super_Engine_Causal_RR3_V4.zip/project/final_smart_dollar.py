"""
SMART DOLLAR GUARANTEE - Loss max $1, Profit min $3+
Without breaking ICT strategy, with thinking dynamic way

Logic:
- User wants: max loss $1, min profit $3, with $100 balance spot
- For any trade: Loss$ = alloc * risk_dist + fees <=1
- Profit$ = alloc * reward_dist - fees >=3
- With alloc <= balance (100$ spot)
- So need: risk_dist >= 1/100 =1% to allow $1 loss with 100$ alloc
- And reward_dist >=3/100=3% to allow $3 profit with 100$ alloc
- And RR = reward/risk >=3 => 3%/1% =3

Smart fix without breaking ICT:
- ICT SL = min(OB_low - ATR*0.15, PL -0.01) - may be 0.24% only
- To guarantee $1 max loss, if SL_ict is tighter than 1%, push it further to Entry*0.99 (still beyond OB, so still valid ICT beyond OB)
- ICT TP = Term + Range*0.62 deep - may give reward 1.2% only
- To guarantee $3 min profit, require reward_dist >=3.2% (to cover fees) else skip trade
- Allocation = min( max_loss / risk_dist , balance*0.95) => guarantees loss <=$1
- Profit = alloc * reward_dist - fees => with risk 1% and reward 3.2%, allocation 100$ => profit 3.2-0.2=3.0$ exactly

This is dynamic: risk_min = desired_loss / balance, reward_min = desired_profit / balance
No fixed arbitrary numbers like volume>100000, only derived from $1 and $3
"""
import pandas as pd
import numpy as np

def calc_atr(df,p=14):
    h=df['high']; l=df['low']; c=df['close']
    tr1=h-l; tr2=(h-c.shift()).abs(); tr3=(l-c.shift()).abs()
    tr=pd.concat([tr1,tr2,tr3],axis=1).max(axis=1)
    return tr.rolling(p).mean().fillna(tr.expanding().mean()).fillna(0.5)

def calc_poc(seg,low_p,high_p,bins=20):
    edges=np.linspace(low_p,high_p,bins)
    vol_bins=np.zeros(bins-1)
    for _,row in seg.iterrows():
        typical=(row['high']+row['low']+row['close'])/3
        if low_p <= typical <= high_p:
            idx=np.digitize(typical,edges)-1
            idx=max(0,min(idx,len(vol_bins)-1))
            vol_bins[idx]+=row['volume']
    if vol_bins.sum()==0:
        return (low_p+high_p)/2
    return (edges[np.argmax(vol_bins)]+edges[np.argmax(vol_bins)+1])/2

def find_swings(df,pivot=3):
    lows=[]; highs=[]
    for i in range(pivot,len(df)-pivot):
        if df['low'].iloc[i]==df['low'].iloc[i-pivot:i+pivot+1].min():
            lows.append({'index':i,'price':df['low'].iloc[i]})
        if df['high'].iloc[i]==df['high'].iloc[i-pivot:i+pivot+1].max():
            highs.append({'index':i,'price':df['high'].iloc[i]})
    return lows,highs

def detect_fvgs(df,atr):
    fvgs=[]
    for i in range(1,len(df)-1):
        c1=df.iloc[i-1]; c2=df.iloc[i]; c3=df.iloc[i+1]
        if c1['high'] < c3['low'] and c2['close']>c2['open']:
            body=abs(c2['close']-c2['open'])
            if body>atr.iloc[i]*1.0:
                gap=c3['low']-c1['high']
                if gap/df['close'].iloc[i]*100>=0.05:
                    fvgs.append({'c1_idx':i-1,'c3_idx':i+1,'low':c1['high'],'high':c3['low'],'ce':(c1['high']+c3['low'])/2,'type':'bullish'})
    return fvgs

def detect_obs(df,fvgs,atr):
    obs=[]
    for i in range(1,len(df)-1):
        prev=df.iloc[i-1]; curr=df.iloc[i]
        if not (prev['close']<prev['open']): continue
        if not (curr['low']<prev['low']): continue
        if not (curr['close']>prev['high']): continue
        body=curr['close']-curr['open']
        if body < atr.iloc[i]*0.5: continue
        has_fvg=False
        for f in fvgs:
            if abs(f['c1_idx']-(i-1))<=2:
                has_fvg=True
                break
        if not has_fvg: continue
        obs.append({'index':i-1,'low':prev['low'],'high':prev['high'],'mid':(prev['low']+prev['high'])/2})
    return obs

def detect_bos(df,highs):
    bos=[]
    atr=calc_atr(df)
    for i in range(1,len(df)):
        recent=[h for h in highs if h['index']<i]
        if not recent: continue
        last=recent[-1]
        c=df.iloc[i]
        if c['high']<=last['price']: continue
        if c['close']<=last['price']: continue
        hl=c['high']-c['low']
        cp=(c['close']-c['low'])/hl if hl>0 else 0
        if cp<0.75: continue
        disp=c['close']-last['price']
        if disp < atr.iloc[i]*0.20: continue
        upper=c['high']-max(c['open'],c['close'])
        if upper/hl>0.60 if hl>0 else 0: continue
        vol_mean=df['volume'].iloc[max(0,i-50):i].mean()
        vol_std=df['volume'].iloc[max(0,i-50):i].std()
        vol_upper=vol_mean+2*vol_std if vol_std>0 else vol_mean*1.5
        if c['volume']<=vol_upper:
            if cp<0.85 or disp/atr.iloc[i]<0.3:
                continue
        bos.append({'index':i,'price':c['close'],'last_high':last['price'],'last_idx':last['index'],'cp':cp})
    return bos

df15=pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df15['timestamp']=pd.to_datetime(df15['timestamp'])
df15=df15.sort_values('timestamp').reset_index(drop=True)
atr15=calc_atr(df15)
lows15,highs15=find_swings(df15,pivot=3)
fvgs=detect_fvgs(df15,atr15)
obs=detect_obs(df15,fvgs,atr15)
bos=detect_bos(df15,highs15)
print(f"Swings lows {len(lows15)} highs {len(highs15)} FVG {len(fvgs)} OB {len(obs)} BOS {len(bos)}")

balance=100.0
desired_max_loss=1.0
desired_min_profit=3.0
fee_pct=0.001

# Dynamic minimums derived from $ requirements, not fixed arbitrary
risk_min = desired_max_loss / balance  # 1%
reward_min = desired_min_profit / balance  # 3%
# Add fee buffer: need 0.2% extra for fees
reward_min_with_fees = reward_min + 2*fee_pct + 0.002  # 3%+0.4% =3.4%
print(f"Dynamic minimums: risk_min {risk_min*100:.2f}% reward_min {reward_min_with_fees*100:.2f}% to guarantee ${desired_max_loss} max loss and ${desired_min_profit} min profit with ${balance} balance")

trades=[]
current_trade=None
logs=[]

for i in range(100,len(df15)-1):
    curr=df15.iloc[i]
    nxt=df15.iloc[i+1]
    past=df15.iloc[:i+1]
    atr_i=atr15.iloc[i]

    if current_trade:
        if curr['low'] <= current_trade['stop_loss']:
            exit_price=current_trade['stop_loss']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee_pct - ev*fee_pct
            balance+=profit
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'LOSS','bars_held':i-current_trade['entry_index'],'balance_after':balance})
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] SL {current_trade['id']} Loss {profit:.3f}$ (max allowed ${desired_max_loss}) Bal {balance:.2f}")
            current_trade=None
            continue
        if curr['high'] >= current_trade['take_profit']:
            exit_price=current_trade['take_profit']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee_pct - ev*fee_pct
            balance+=profit
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'WIN','bars_held':i-current_trade['entry_index'],'balance_after':balance})
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] TP {current_trade['id']} Profit {profit:.3f}$ (min required ${desired_min_profit}) RR {current_trade['rr']:.2f} Bal {balance:.2f}")
            current_trade=None
            continue
        continue

    # Find protected low with rej>=2.0
    recent_lows=[]
    for low in lows15:
        if low['index']>i-3 or low['index']<i-150:
            continue
        idx=low['index']
        if idx<30: continue
        candle=df15.iloc[idx]
        lower_wick=min(candle['open'],candle['close'])-candle['low']
        wicks=[]
        for j in range(max(0,idx-30),idx):
            c=df15.iloc[j]
            lw=min(c['open'],c['close'])-c['low']
            wicks.append(lw)
        avg_wick=np.mean(wicks) if wicks else 1
        rej=lower_wick/avg_wick if avg_wick>0 else 0
        if rej>=2.0:
            recent_lows.append({'index':idx,'price':low['price'],'rej':rej})
    if not recent_lows:
        continue
    pl=recent_lows[-1]

    bos_after=[b for b in bos if b['index']>pl['index'] and b['index']<=i and i-b['index']<=80]
    if not bos_after:
        continue
    bos_v=bos_after[-1]

    origin_idx=pl['index']
    origin_price=pl['price']
    term_price=past['high'].iloc[origin_idx:].max()
    range_size=term_price-origin_price
    if range_size<=0:
        continue

    seg=past.iloc[origin_idx:]
    poc=calc_poc(seg,origin_price,term_price)
    median=(origin_price+term_price)/2
    eq=(poc+median)/2
    if curr['close']>eq:
        continue

    buy_low=term_price - range_size*0.79
    buy_high=term_price - range_size*0.705
    if not (buy_low <= curr['low'] <= buy_high or buy_low <= curr['close'] <= buy_high):
        continue

    # OB/FVG confluence
    obs_valid=[ob for ob in obs if ob['index']<=i and (buy_low <= ob['low'] <= buy_high or buy_low <= ob['high'] <= buy_high or (ob['low'] <= buy_high and ob['high'] >= buy_low))]
    # mitigation
    obs_unmit=[]
    for ob in obs_valid:
        mitig=False
        for k in range(ob['index']+1,i+1):
            if df15['close'].iloc[k] < ob['low']:
                mitig=True
                break
        if not mitig:
            obs_unmit.append(ob)

    fvgs_valid=[f for f in fvgs if f['c3_idx']<=i and f['type']=='bullish' and (buy_low <= f['low'] <= buy_high or buy_low <= f['high'] <= buy_high or (f['low'] <= buy_high and f['high'] >= buy_low))]
    fvgs_unmit=[]
    for f in fvgs_valid:
        mitig=False
        for k in range(f['c3_idx']+1,i+1):
            if df15['low'].iloc[k] <= f['low']:
                mitig=True
                break
        if not mitig:
            fvgs_unmit.append(f)

    if not obs_unmit or not fvgs_unmit:
        continue

    valid_exec=None
    for ob in obs_unmit[-2:]:
        for fvg in fvgs_unmit[-3:]:
            if abs(fvg['low'] - ob['high']) < (ob['high']-ob['low'])*2.5:
                hl=curr['high']-curr['low']
                if hl==0: continue
                lower_wick=min(curr['open'],curr['close'])-curr['low']
                body=abs(curr['close']-curr['open'])
                close_pos=(curr['close']-curr['low'])/hl
                wick_rej=lower_wick > body*0.8 and close_pos>0.60
                vol_mean=past['volume'].iloc[max(0,i-20):i].mean()
                vol_std=past['volume'].iloc[max(0,i-20):i].std()
                vol_upper=vol_mean+2*vol_std if vol_std>0 else vol_mean*1.5
                vol_spike=curr['volume']>vol_upper
                # CVD flip
                cvd_before=0
                for _,r in past.iloc[max(0,i-5):i].iterrows():
                    h=r['high']-r['low']
                    if h>0:
                        d=(r['close']-r['low'])/h -0.5
                        cvd_before+=d*r['volume']
                d_now=(curr['close']-curr['low'])/hl -0.5 if hl>0 else 0
                cvd_now=cvd_before+d_now*curr['volume']
                cvd_flip=cvd_before<0 and cvd_now>cvd_before
                is_churn=body < hl*0.2 and curr['volume']>vol_mean*2
                if (wick_rej and (vol_spike or cvd_flip)) and not is_churn:
                    valid_exec=(ob,fvg,wick_rej,vol_spike,close_pos)
                    break
        if valid_exec:
            break

    if not valid_exec:
        continue

    ob,fvg,wick_rej,vol_spike,close_pos=valid_exec

    # SMART ENTRY/SL/TP with $ guarantee
    ob_mid=(ob['low']+ob['high'])/2
    fvg_ce=fvg['ce']
    entry_level=fvg_ce
    if ob_mid < entry_level:
        entry_level=ob_mid

    if not (curr['low'] <= entry_level <= curr['high']):
        continue

    # ICT SL
    sl_ict = min(ob['low'] - atr_i*0.15, pl['price'] - 0.01)
    # SMART: Enforce minimum risk distance 1% to allow $1 max loss with $100 balance
    # If SL_ict is tighter than 1%, push it to 1% below entry (still beyond OB, so still valid ICT)
    sl_1pct = entry_level * (1 - risk_min)  # 99% of entry
    stop_loss = min(sl_ict, sl_1pct)  # more far = larger risk, min price = more far for long

    risk_dist = abs(entry_level - stop_loss)/entry_level
    # If even after enforcing 1% risk_dist still < risk_min (should be >=), skip
    if risk_dist < risk_min*0.9:  # allow 10% tolerance
        continue

    # TP deep 0.62 for RR 4.49-6.71
    tp_deep = term_price + range_size*0.62
    tp_standard = term_price + range_size*0.27
    # SMART: Require reward distance >=3.2% to guarantee $3 min profit
    # Check both TPs
    reward_deep = abs(tp_deep - entry_level)/entry_level
    reward_std = abs(tp_standard - entry_level)/entry_level

    if reward_deep < reward_min_with_fees:
        # Even deep TP doesn't give 3% reward, skip - market move too small
        continue

    # Choose TP that gives at least 3% reward and RR>=3
    take_profit = tp_deep
    reward_dist = reward_deep
    rr = reward_dist / risk_dist

    if rr < 3.0:
        # Even deep TP doesn't give RR 3, skip
        continue

    # Allocation to guarantee max loss $1
    # Loss$ = alloc * risk_dist + fees <= $1
    # Approx alloc <= $1 / risk_dist
    # With $100 balance, alloc max 95%
    alloc_for_loss = desired_max_loss / risk_dist
    # For profit $3: alloc >= $3 / reward_dist
    alloc_for_profit = desired_min_profit / reward_dist

    # Need alloc_for_profit <= alloc_for_loss to have feasible allocation
    if alloc_for_profit > alloc_for_loss:
        # No feasible allocation that satisfies both $1 loss and $3 profit
        # Means RR <3, already filtered, but double check
        continue

    # Choose allocation that satisfies both: at least alloc_for_profit, at most alloc_for_loss
    # And also <= balance*0.95
    # To maximize profit while keeping loss <=$1, choose alloc = min(alloc_for_loss, balance*0.95)
    # But must be >= alloc_for_profit to guarantee $3 profit
    allocation = min(alloc_for_loss, balance*0.95)
    if allocation < alloc_for_profit:
        # Cannot guarantee $3 profit with max loss $1 constraint, skip
        continue

    # Fees: entry 0.1% + exit 0.1% = 0.2% of allocation
    # Adjust to ensure net profit >=$3 and net loss <=$1
    # Net loss = alloc*risk_dist + alloc*fee*2? Actually fees on entry and exit
    # Approx net loss = alloc*risk_dist + alloc*fee*2
    # We already approximated, but let's compute exact and verify
    coins = allocation / entry_level
    fee_entry = allocation * fee_pct
    fee_exit_loss = (entry_level - abs(entry_level-stop_loss)) * coins * fee_pct  # approx exit at SL
    # Actually exit at SL price: exit value = SL*coins
    exit_val_sl = stop_loss * coins
    fee_exit_sl = exit_val_sl * fee_pct
    net_loss = (entry_level - stop_loss)*coins + fee_entry + fee_exit_sl

    exit_val_tp = take_profit * coins
    fee_exit_tp = exit_val_tp * fee_pct
    net_profit = (take_profit - entry_level)*coins - fee_entry - fee_exit_tp

    if net_loss > desired_max_loss*1.1:  # allow 10% tolerance
        # Reduce allocation to meet max loss
        allocation = desired_max_loss / (risk_dist + 2*fee_pct)
        coins = allocation / entry_level
        # Recompute
        exit_val_sl = stop_loss * coins
        fee_exit_sl = exit_val_sl * fee_pct
        net_loss = (entry_level - stop_loss)*coins + fee_entry + fee_exit_sl
        exit_val_tp = take_profit * coins
        fee_exit_tp = exit_val_tp * fee_pct
        net_profit = (take_profit - entry_level)*coins - fee_entry - fee_exit_tp

    if net_loss > desired_max_loss*1.1 or net_profit < desired_min_profit*0.9:
        continue

    trade_id=len(trades)+1
    current_trade={
        'id':trade_id,
        'entry_index':i,
        'entry_time':curr['timestamp'],
        'entry_price':entry_level,
        'stop_loss':stop_loss,
        'take_profit':take_profit,
        'take_profit_deep':tp_deep,
        'take_profit_std':tp_standard,
        'risk_dist':risk_dist,
        'reward_dist':reward_dist,
        'rr':rr,
        'coins':coins,
        'allocation':allocation,
        'net_loss_if_sl':net_loss,
        'net_profit_if_tp':net_profit,
        'balance_before':balance,
        'protected_low':pl['price'],
        'bos':bos_v['price'],
        'range':range_size,
        'term':term_price,
        'buy_low':buy_low,
        'buy_high':buy_high,
        'ob_low':ob['low'],
        'ob_high':ob['high'],
        'fvg_ce':fvg_ce,
    }
    logs.append(f"[{curr['timestamp']}] NEW TRADE {trade_id} Entry {entry_level:.2f} SL {stop_loss:.2f} (risk {risk_dist*100:.2f}% >=1%) TP {take_profit:.2f} (reward {reward_dist*100:.2f}% >=3.2%) RR {rr:.2f} Alloc {allocation:.2f}$ NetLoss {net_loss:.2f}$ <=${desired_max_loss} NetProfit {net_profit:.2f}$ >=${desired_min_profit} Bal {balance:.2f}")

# Close open
if current_trade:
    exit_price=df15.iloc[-1]['close']
    ec=current_trade['entry_price']*current_trade['coins']
    ev=exit_price*current_trade['coins']
    profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee_pct - ev*fee_pct
    balance+=profit
    current_trade.update({'exit_price':exit_price,'exit_time':df15.iloc[-1]['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'OPEN_CLOSED','balance_after':balance})
    trades.append(current_trade)

print(f"\n=== SMART DOLLAR GUARANTEE - Loss max ${desired_max_loss} Profit min ${desired_min_profit} ===")
print(f"Total trades {len(trades)}")
wins=[t for t in trades if t.get('result')=='WIN']
losses=[t for t in trades if t.get('result')=='LOSS']
print(f"Wins {len(wins)} Losses {len(losses)}")
total=sum(t.get('profit_usd',0) for t in trades)
print(f"PnL {total:.4f} Final Bal {balance:.4f} Return {(balance/100-1)*100:.2f}%")
if trades:
    print(f"Avg net loss {np.mean([t['net_loss_if_sl'] for t in trades]):.2f} Avg net profit {np.mean([t['net_profit_if_tp'] for t in trades]):.2f}")
    print(f"Min RR {min([t['rr'] for t in trades]):.2f} Avg RR {np.mean([t['rr'] for t in trades]):.2f}")
    pd.DataFrame(trades).to_csv('/home/user/smart_dollar_trades.csv', index=False)
    for t in trades:
        print(f"\nTrade {t['id']} Entry {t['entry_time']} {t['entry_price']:.2f} SL {t['stop_loss']:.2f} risk {t['risk_dist']*100:.2f}% TP {t['take_profit']:.2f} reward {t['reward_dist']*100:.2f}% RR {t['rr']:.2f} Alloc {t['allocation']:.2f}$ NetLoss {t['net_loss_if_sl']:.2f}$ NetProfit {t['net_profit_if_tp']:.2f}$ Bal {t['balance_before']:.2f}->{t.get('balance_after',0):.2f} {t.get('result','OPEN')} PnL {t.get('profit_usd',0):.3f}$")
else:
    print("0 trades meet $1 max loss and $3 min profit with surgical strict - need wider range or more volatile period")
