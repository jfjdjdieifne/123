"""
Map2 Counter-Trend Surgical - HTF Sweep + LTF CHoCH + LTF Discount OB
Strict per spec, no relaxation
"""
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.htf_sweep_detector import HTFSweepDetector
from engine.core.ltf_choch_detector import LTFChoCHDetector
from engine.core.orderblock_detector import OrderBlockDetector
from engine.core.fvg_detector import FVGDetector

def calc_atr(df, p=14):
    h=df['high']; l=df['low']; c=df['close']
    tr1=h-l; tr2=(h-c.shift()).abs(); tr3=(l-c.shift()).abs()
    tr=pd.concat([tr1,tr2,tr3],axis=1).max(axis=1)
    return tr.rolling(p).mean().fillna(tr.expanding().mean()).fillna(0.5)

df15=pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df15['timestamp']=pd.to_datetime(df15['timestamp'])
df15=df15.sort_values('timestamp').reset_index(drop=True)

# Resample to 4H
df4h=df15.set_index('timestamp').resample('4h').agg({'open':'first','high':'max','low':'min','close':'last','volume':'sum'}).dropna().reset_index()
print(f"15m {len(df15)} 4h {len(df4h)}")

# HTF swings on 4H
swing4h=ProtectedSwingDetector(pivot_length=2)
swings4h=swing4h.analyze(df4h)
lows4h=[s for s in swings4h['all_swings'] if s['type']=='low']
print(f"4H lows {len(lows4h)}")

# Detect major low: most recent HTF low before current time
# Simulate walk-forward: for each 15m i, find 4H past <= current time, last major low
# Then check if 4H sweep occurred recently

sweep_det=HTFSweepDetector(volume_lookback=50, volume_std_factor=2.5)
choch_det=LTFChoCHDetector(atr_period=14, significance_atr_factor=1.5, momentum_factor=2.0)

trades=[]
balance=100.0
fee=0.001
current_trade=None
logs=[]
state="MONITOR_HTF"

last_sweep=None
last_choch=None

# Precompute FVGs for 4H bearish for TP
ob_det=OrderBlockDetector()
fvg_det=FVGDetector(min_displacement_atr=1.0, min_gap_pct=0.05)
fvgs15=fvg_det.detect(df15)
print(f"FVGs 15m strict {len(fvgs15)}")

for i in range(100, len(df15)-1):
    curr=df15.iloc[i]
    nxt=df15.iloc[i+1]
    past15=df15.iloc[:i+1]
    # 4H past up to current time
    past4h=df4h[df4h['timestamp']<=curr['timestamp']]
    if len(past4h)<10:
        continue

    # Manage trade
    if current_trade:
        # SL = LTF Origin Low -0.01
        # TP1 75% = first bearish FVG 4H, TP2 = nearest bearish OB 4H
        # Simplified: TP = LTF validation high + range*0.5? Per spec counter-trend exit at first bearish HTF FVG
        # For this backtest, use TP = term + range*0.5 (bearish FVG magnet)
        if curr['low'] <= current_trade['stop_loss']:
            exit_price=current_trade['stop_loss']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'LOSS','bars_held':i-current_trade['entry_index'],'balance_after':balance,'exit_reason':'SL LTF Origin broken - whale surrendered'})
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] MAP2 SL {current_trade['id']} Loss {profit:.3f} Bal {balance:.2f}")
            current_trade=None
            state="MONITOR_HTF"
            last_sweep=None
            last_choch=None
            continue
        if curr['high'] >= current_trade['take_profit']:
            exit_price=current_trade['take_profit']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'WIN','bars_held':i-current_trade['entry_index'],'balance_after':balance,'exit_reason':'TP Bearish HTF FVG magnet'})
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] MAP2 TP {current_trade['id']} Profit {profit:.3f} RR {current_trade['rr']:.2f} Bal {balance:.2f}")
            current_trade=None
            state="MONITOR_HTF"
            last_sweep=None
            last_choch=None
            continue
        continue

    if state=="MONITOR_HTF":
        # Find last major low in 4H past
        # Major low = last swing low with price
        recent_lows=[l for l in lows4h if l['index'] < len(past4h)-2]
        if not recent_lows:
            continue
        major_low=recent_lows[-1]
        major_low_price=major_low['price']
        # Check if recent 4H candle swept it
        # Look at last 2 4H candles
        for idx in range(max(0,len(past4h)-3), len(past4h)):
            row=past4h.iloc[idx]
            # Use sweep detector analyze on past4h with major low
            # Simplified geometric check: low < major and close > major
            if row['low'] < major_low_price and row['close'] > major_low_price:
                # Check volume spike
                vol_mean=past4h['volume'].iloc[max(0,idx-50):idx].mean() if idx>0 else row['volume']
                vol_std=past4h['volume'].iloc[max(0,idx-50):idx].std() if idx>0 else 0
                vol_upper=vol_mean+2.5*vol_std if vol_std>0 else vol_mean*2.5
                vol_spike=row['volume']>vol_upper
                # For strict, require vol spike
                if not vol_spike:
                    continue
                # Valid sweep found
                last_sweep={'index':idx,'timestamp':row['timestamp'],'price':row['close'],'low':row['low'],'major_low':major_low_price,'volume_ratio':row['volume']/vol_mean if vol_mean>0 else 0}
                state="WAIT_CHOCHO"
                logs.append(f"[{curr['timestamp']}] MAP2 HTF SWEEP detected at {row['timestamp']} Low {row['low']:.2f} < Major {major_low_price:.2f} Close {row['close']:.2f} >Major Vol {row['volume']:.0f} vs upper {vol_upper:.0f} ratio {row['volume']/vol_mean:.1f}x")
                break

    elif state=="WAIT_CHOCHO":
        # Need to find CHoCH on LTF (15m) after sweep
        # Sweep timestamp -> find its position in 15m index
        sweep_time=last_sweep['timestamp'] if last_sweep else None
        if not sweep_time:
            state="MONITOR_HTF"
            continue
        # Find recent lower high that caused last low before sweep
        # Use choch detector
        # Find sweep index in 15m
        # Approximate: 15m candles after sweep time
        # Use past15 which includes up to curr
        # Find target high: last swing high before lowest low that is near sweep
        # Simplified: use ProtectedSwingDetector to find swing highs in last 30 candles before curr
        swing_ltf=ProtectedSwingDetector(pivot_length=1)
        swings_ltf=swing_ltf.analyze(past15)
        highs=[s for s in swings_ltf['all_swings'] if s['type']=='high' and s['index'] < i and s['index'] >= i-50]
        if not highs:
            continue
        # Most recent lower high
        target_high=highs[-1]
        # Distance filter ATR*1.5
        atr=calc_atr(past15).iloc[-1]
        sub_low=past15['low'].iloc[target_high['index']:i+1].min()
        distance=target_high['price'] - sub_low
        if distance < atr*1.5:
            # internal noise
            continue
        # CHoCH if close > target_high price with body
        if curr['close'] > target_high['price'] and curr['high'] > target_high['price']:
            # Check close pos >0.60
            hl=curr['high']-curr['low']
            cp=(curr['close']-curr['low'])/hl if hl>0 else 0
            if cp<0.60:
                continue
            # Volume spike
            vol_mean=past15['volume'].iloc[max(0,i-20):i].mean()
            vol_spike=curr['volume']>vol_mean*1.2
            if not vol_spike:
                continue
            # Valid CHoCH
            last_choch={'price':curr['close'],'target_high':target_high['price'],'target_idx':target_high['index'],'origin_low':last_sweep['low'],'choch_time':curr['timestamp'],'choch_index':i}
            state="WAIT_DISCOUNT_OB"
            logs.append(f"[{curr['timestamp']}] MAP2 CHOCH valid Close {curr['close']:.2f} > Target {target_high['price']:.2f} Distance {distance/atr:.2f} ATR VolSpike {vol_spike} CP {cp:.2f} OriginLow {last_sweep['low']:.2f}")

    elif state=="WAIT_DISCOUNT_OB":
        # LTF Discount: Origin = LTF origin low (sweep low), Term = CHoCH breakout high (recent high)
        origin_price=last_sweep['low'] if last_sweep else None
        if not origin_price:
            state="MONITOR_HTF"
            continue
        term_price=past15['high'].iloc[last_choch['target_idx']:].max() if last_choch else curr['high']
        range_size=term_price-origin_price
        if range_size<=0:
            continue
        # Micro POC etc simplified: use median 50% and POC
        # For counter-trend, buy range should be discount below dynamic eq? Actually LTF discount array per spec: LTF_Origin_Low 0% LTF_Validation_High 100%
        # Dynamic Eq = (Micro-POC + Median)/2 - block buy above Eq
        # For simplicity, use OTE 70.5-79% deep? But for counter-trend, movement is fast, should use shallow? Spec says LTF discount
        # Use 50-79% for LTF? Let's use 70.5-79% deep for RR
        buy_low=term_price - range_size*0.79
        buy_high=term_price - range_size*0.705
        # Price must be in discount (below Eq)
        # For this quick test, just check if curr close inside buy range
        if not (buy_low <= curr['close'] <= buy_high) and not (buy_low <= curr['low'] <= buy_high):
            # If price breaks below origin, invalidate
            if curr['low'] < origin_price - 0.01:
                logs.append(f"[{curr['timestamp']}] MAP2 INVALIDATED Origin broken {curr['low']:.2f} < {origin_price:.2f}")
                state="MONITOR_HTF"
                last_sweep=None
                last_choch=None
            continue
        # Find LTF OB: last bearish candle before CHoCH that grabbed low
        # Use OrderBlockDetector bullish OBs up to i
        obs_filtered=[o for o in ob_det.detect_bullish_obs(past15, ob_det.detect_fvgs(past15)) if o.index <= i]
        valid_obs=[ob for ob in obs_filtered if (buy_low <= ob.low <= buy_high) or (buy_low <= ob.high <= buy_high) or (ob.low <= buy_high and ob.high >= buy_low)]
        if not valid_obs:
            # Allow FVG alone for LTF?
            fvg_list=fvg_det.detect(past15)
            valid_fvg=[f for f in fvg_list if f.type=='bullish' and not f.mitigated and (buy_low <= f.low <= buy_high or buy_low <= f.high <= buy_high)]
            if not valid_fvg:
                continue
            ob=valid_fvg[-1]  # use FVG as OB proxy
            ob_low=ob.low
            ob_high=ob.high
            ob_mid=(ob_low+ob_high)/2
        else:
            ob=valid_obs[-1]
            ob_low=ob.low
            ob_high=ob.high
            ob_mid=(ob_low+ob_high)/2

        # Execution triggers: CVD Slingshot + Micro Wick Rejection
        hl=curr['high']-curr['low']
        if hl==0:
            continue
        lower_wick=min(curr['open'],curr['close'])-curr['low']
        body=abs(curr['close']-curr['open'])
        close_pos=(curr['close']-curr['low'])/hl
        wick_rej=close_pos>0.70 and lower_wick>body*0.5

        # CVD Slingshot: CVD before negative and now sharply rising
        # Simplified
        vol_mean=past15['volume'].iloc[max(0,i-20):i].mean()
        # CVD proxy
        cvd=0
        for _,r in past15.iloc[max(0,i-5):i].iterrows():
            hl_r=r['high']-r['low']
            if hl_r>0:
                delta=(r['close']-r['low'])/hl_r -0.5
                cvd+=delta*r['volume']
        hl_r=curr['high']-curr['low']
        delta_now=(curr['close']-curr['low'])/hl_r -0.5 if hl_r>0 else 0
        cvd_now=cvd+delta_now*curr['volume']
        cvd_flip=cvd<0 and cvd_now>cvd and close_pos>0.6

        if not (wick_rej and cvd_flip):
            # Require both for Map2 per spec
            continue

        # Entry at LTF OB 50% or FVG CE
        entry_level=ob_mid
        if not (curr['low'] <= entry_level <= curr['high']):
            continue

        # SL = LTF Origin Low -0.01 per spec counter-trend
        stop_loss=origin_price - 0.01
        # TP: first bearish HTF FVG on 4H (bearish FVG magnet) - for simplicity use term + range*0.5? Actually counter-trend TP is bearish FVG on HTF
        # We will approximate TP = term + range*0.5? Wait counter-trend is long against bearish HTF, TP should be first bearish FVG on 4H above
        # For this test, find first bearish FVG in 4H past that is above term
        # Resample bearish FVGs from 4H - simplified use past4h FVG detection
        # For speed, use TP = term + range*0.5 as first target (75% position) and term + range*1.0 as second
        # Per spec: TP1 75% first bearish HTF FVG, TP2 25% nearest bearish HTF OB before collapse
        # We'll use TP = entry + range*0.5 for TP1
        take_profit=entry_level + range_size*0.5  # 50% of range = quick 5-15% as per spec

        risk=abs(entry_level-stop_loss)
        reward=abs(take_profit-entry_level)
        rr=reward/risk if risk>0 else 0
        if rr<1.5:
            # try deeper TP
            take_profit=entry_level + range_size*0.8
            reward=abs(take_profit-entry_level)
            rr=reward/risk if risk>0 else 0
            if rr<1.2:
                continue

        # Position sizing
        allowed_loss=balance*0.01*1.5  # M 1.5
        risk_dist=abs(entry_level-stop_loss)/entry_level
        spot_alloc=allowed_loss/risk_dist if risk_dist>0 else 0
        spot_alloc=min(spot_alloc, balance*0.95)
        coins=spot_alloc/entry_level

        trade_id=len(trades)+1
        current_trade={
            'id': trade_id,
            'entry_index': i,
            'entry_time': curr['timestamp'],
            'entry_price': entry_level,
            'stop_loss': stop_loss,
            'take_profit': take_profit,
            'rr': rr,
            'coins': coins,
            'spot_allocation_usd': spot_alloc,
            'balance_before': balance,
            'origin_low': origin_price,
            'term': term_price,
            'range': range_size,
            'buy_low': buy_low,
            'buy_high': buy_high,
            'ob_low': ob_low,
            'ob_high': ob_high,
            'wick_rej': wick_rej,
            'cvd_flip': cvd_flip,
            'close_pos': close_pos,
            'htf_sweep': last_sweep,
            'choch_price': last_choch['price'] if last_choch else 0,
        }
        logs.append(f"[{curr['timestamp']}] MAP2 NEW TRADE {trade_id} Entry {entry_level:.2f} SL {stop_loss:.2f} TP {take_profit:.2f} RR {rr:.2f} Bal {balance:.2f} Origin {origin_price:.2f} Term {term_price:.2f} Buy {buy_low:.2f}-{buy_high:.2f} OB {ob_low:.2f}-{ob_high:.2f} Wick {wick_rej} CVD {cvd_flip}")

if current_trade:
    exit_price=df15.iloc[-1]['close']
    ec=current_trade['entry_price']*current_trade['coins']
    ev=exit_price*current_trade['coins']
    profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
    balance+=profit
    current_trade.update({'exit_price':exit_price,'exit_time':df15.iloc[-1]['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'OPEN_CLOSED','bars_held':len(df15)-current_trade['entry_index'],'balance_after':balance})
    trades.append(current_trade)

print(f"\n=== MAP2 COUNTER-TREND RESULT ===")
print(f"Total {len(trades)}")
wins=[t for t in trades if t['result']=='WIN']
losses=[t for t in trades if t['result']=='LOSS']
print(f"Wins {len(wins)} Losses {len(losses)} WinRate {len(wins)/len(trades)*100 if trades else 0:.1f}%")
total=sum(t['profit_usd'] for t in trades)
print(f"PnL {total:.4f}$ Final Bal {balance:.4f}$ Return {(balance/100-1)*100:.2f}%")
if trades:
    pd.DataFrame(trades).to_csv('/home/user/map2_trades_last_month.csv', index=False)
    for t in trades:
        print(f"\nTrade {t['id']} {t['result']} Entry {t['entry_time']} {t['entry_price']:.2f} Exit {t.get('exit_time')} {t.get('exit_price',0):.2f} PnL {t['profit_usd']:.4f}$ RR {t['rr']:.2f} Bal {t['balance_before']:.2f}->{t['balance_after']:.2f} SL {t['stop_loss']:.2f} TP {t['take_profit']:.2f} Origin {t['origin_low']:.2f} Term {t['term']:.2f}")
