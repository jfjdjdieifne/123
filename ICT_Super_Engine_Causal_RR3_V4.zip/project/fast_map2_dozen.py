import pandas as pd, numpy as np
df15=pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df15['timestamp']=pd.to_datetime(df15['timestamp'])
df4h=df15.set_index('timestamp').resample('4h').agg({'open':'first','high':'max','low':'min','close':'last','volume':'sum'}).dropna().reset_index()

def calc_atr(df,p=14):
    h=df['high']; l=df['low']; c=df['close']
    tr1=h-l; tr2=(h-c.shift()).abs(); tr3=(l-c.shift()).abs()
    tr=pd.concat([tr1,tr2,tr3],axis=1).max(axis=1)
    return tr.rolling(p).mean().fillna(tr.expanding().mean()).fillna(0.5)

# Find 4h lows pivot 2
def find_lows(df,pivot=2):
    lows=[]
    for i in range(pivot,len(df)-pivot):
        if df['low'].iloc[i]==df['low'].iloc[i-pivot:i+pivot+1].min():
            lows.append((i,df['low'].iloc[i],df['timestamp'].iloc[i]))
    return lows

lows4h=find_lows(df4h,pivot=2)
sweeps=[]
for i in range(1,len(df4h)):
    recent=[l for l in lows4h if l[0]<i]
    if not recent:
        continue
    major=recent[-1]
    c=df4h.iloc[i]
    vol_mean=df4h['volume'].iloc[max(0,i-50):i].mean()
    if c['low']<major[1] and c['close']>major[1] and c['volume']>vol_mean*1.5:
        sweeps.append({'idx':i,'timestamp':c['timestamp'],'major_low':major[1],'sweep_low':c['low'],'sweep_close':c['close']})
print(f"Sweeps {len(sweeps)}")
for s in sweeps:
    print(s)

# For each sweep, look 48h ahead in 15m for CHoCH and OB
trades=[]
for sweep in sweeps:
    sweep_time=sweep['timestamp']
    # 15m window 48h after sweep
    window=df15[(df15['timestamp']>=sweep_time) & (df15['timestamp']<=sweep_time+pd.Timedelta(hours=48))].reset_index(drop=True)
    if len(window)<30:
        continue
    # Find recent lower high before sweep low? Use simple swing highs in window first 10 candles
    # For CHoCH, need to break recent lower high that caused sweep low
    # Find swing highs pivot 1
    highs=[]
    for i in range(1,len(window)-1):
        if window['high'].iloc[i]==window['high'].iloc[i-1:i+2].max():
            highs.append((i,window['high'].iloc[i]))
    if not highs:
        continue
    # Target high = last high before lowest low in first 10 candles?
    # For simplicity, take first high
    target=highs[0] if highs else (0,window['high'].iloc[0])
    atr_w=calc_atr(window)
    # Look for CHoCH: close > target high
    for i in range(1,len(window)-1):
        c=window.iloc[i]
        hl=c['high']-c['low']
        cp=(c['close']-c['low'])/hl if hl>0 else 0
        if c['close']>target[1] and cp>0.60:
            # distance ATR*1.5
            sub_low=window['low'].iloc[:i+1].min()
            dist=target[1]-sub_low
            atr_i=atr_w.iloc[i]
            if dist>=atr_i*1.5:
                # Found CHoCH
                origin_low=sweep['sweep_low']
                term_high=window['high'].iloc[:i+1].max()
                range_size=term_high-origin_low
                if range_size<=0:
                    continue
                buy_low=term_high - range_size*0.79
                buy_high=term_high - range_size*0.705
                # Look for OB in buy zone within next 20 candles
                for j in range(i+1, min(i+20, len(window)-1)):
                    cj=window.iloc[j]
                    # Check if price in buy zone
                    if not (buy_low <= cj['low'] <= buy_high or buy_low <= cj['close'] <= buy_high):
                        continue
                    # Wick rejection + CVD flip simplified
                    hl_j=cj['high']-cj['low']
                    cp_j=(cj['close']-cj['low'])/hl_j if hl_j>0 else 0
                    lower_wick=min(cj['open'],cj['close'])-cj['low']
                    body=abs(cj['close']-cj['open'])
                    wick_rej=cp_j>0.70 and lower_wick>body*0.5
                    # Entry at OB mid? Use close as proxy
                    entry=cj['close']
                    sl=origin_low - 0.01
                    risk=(entry-sl)/entry
                    if risk<0.005 or risk>0.03:
                        continue
                    tp=entry + range_size*0.6
                    reward=(tp-entry)/entry
                    rr=reward/risk if risk>0 else 0
                    if rr<3.0:
                        continue
                    # Valid Map2 scalp
                    trades.append({
                        'sweep_time':sweep_time,
                        'choch_time':window['timestamp'].iloc[i],
                        'entry_time':cj['timestamp'],
                        'entry_price':entry,
                        'sl':sl,
                        'tp':tp,
                        'rr':rr,
                        'risk':risk*100,
                        'reward':reward*100,
                        'range':range_size,
                        'origin':origin_low,
                        'term':term_high,
                    })
                    break
            break

print(f"\nMap2 trades found {len(trades)}")
for t in trades:
    print(t)
