"""
Optimized Super Backtest - $100 1% Risk - No Lookahead via filtered precomputed indexes
"""
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression

from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.orderblock_detector import OrderBlockDetector
from engine.core.position_sizing import ConfluenceWeighter

class BalancedBOS(BOSDetector):
    def __init__(self):
        super().__init__(atr_period=14, volume_lookback=20)
        self.close_pos_thresh = 0.60
        self.disp_factor = 0.10
        self.upper_wick_thresh = 0.70
    def calculate_volume_bollinger(self, df, idx):
        start = max(0, idx-20)
        vol_mean = df['volume'].iloc[start:idx].mean() if idx>start else df['volume'].mean()
        curr = df['volume'].iloc[idx]
        is_outlier = curr > vol_mean*1.2
        return {'is_outlier': is_outlier, 'mean': vol_mean, 'upper_band': vol_mean*1.2, 'current': curr, 'ratio': curr/vol_mean if vol_mean>0 else 0, 'std': df['volume'].iloc[start:idx].std() if idx>start else 0}

def z_score(curr, mean, std):
    if std==0 or pd.isna(std) or mean==0:
        return 0
    return (curr-mean)/std

def calc_atr(df, period=14):
    high=df['high']; low=df['low']; close=df['close']
    tr1=high-low
    tr2=(high-close.shift()).abs()
    tr3=(low-close.shift()).abs()
    tr=pd.concat([tr1,tr2,tr3], axis=1).max(axis=1)
    atr=tr.rolling(period).mean().fillna(tr.expanding().mean()).fillna(0.5)
    return atr

def calc_poc(seg, low_p, high_p, bins=20):
    edges=np.linspace(low_p, high_p, bins)
    vol_bins=np.zeros(bins-1)
    for _,row in seg.iterrows():
        typical=(row['high']+row['low']+row['close'])/3
        if low_p <= typical <= high_p:
            idx=np.digitize(typical, edges)-1
            idx=max(0,min(idx,len(vol_bins)-1))
            vol_bins[idx]+=row['volume']
    if vol_bins.sum()==0:
        return (low_p+high_p)/2
    return (edges[np.argmax(vol_bins)]+edges[np.argmax(vol_bins)+1])/2

# Load
df=pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df['timestamp']=pd.to_datetime(df['timestamp'])
df=df.sort_values('timestamp').reset_index(drop=True)
print(f"DF {len(df)} {df['timestamp'].iloc[0]} -> {df['timestamp'].iloc[-1]}")

# Precompute detectors once on full DF
swing_det=ProtectedSwingDetector(pivot_length=2)
swing_sens=ProtectedSwingDetector(pivot_length=1)

print("Precompute swings...")
swings_res_full=swing_det.analyze(df)
swings_sens_res=swing_sens.analyze(df)
all_swings_sens=swings_sens_res['all_swings']

print(f"Protected lows full: {len(swings_res_full['all_swings'])}")

bos_det=BalancedBOS()
bos_res_full=bos_det.analyze(df, all_swings_sens)
print(f"BOS valid full: {len(bos_res_full['valid_bos'])}")

ob_det=OrderBlockDetector()
print("Precompute FVG/OB...")
fvgs_full=ob_det.detect_fvgs(df)
obs_full=ob_det.detect_bullish_obs(df, fvgs_full)
print(f"FVG {len(fvgs_full)} OB {len(obs_full)}")

# Convert to simple lists for filtering
# swings_res_full['all_swings'] is list of dicts
protected_list=swings_res_full['all_swings']  # will filter later
true_protected=swings_res_full['true_protected_lows']

# For faster lookup, create dict by index
# But we will just filter each time (list comprehension) - 2831 * 100 length ~ 283k operations fine

weighter=ConfluenceWeighter()
atr_full=calc_atr(df)

initial_balance=100.0
balance=initial_balance
base_risk_pct=1.0
fee_pct=0.001

trades=[]
equity_curve=[]
current_trade=None
logs=[]

for i in range(50, len(df)-1):
    past=df.iloc[:i+1]
    curr=df.iloc[i]
    nxt=df.iloc[i+1]

    equity_curve.append({'timestamp': curr['timestamp'], 'balance': balance})

    # Manage trade
    if current_trade:
        if curr['low'] <= current_trade['stop_loss']:
            exit_price=current_trade['stop_loss']
            entry_cost=current_trade['entry_price']*current_trade['coins']
            exit_val=exit_price*current_trade['coins']
            fee_entry=entry_cost*fee_pct
            fee_exit=exit_val*fee_pct
            profit= (exit_price-current_trade['entry_price'])*current_trade['coins'] - fee_entry - fee_exit
            balance+=profit
            current_trade.update({
                'exit_price': exit_price,
                'exit_time': curr['timestamp'],
                'profit_usd': profit,
                'profit_pct': (exit_price/current_trade['entry_price']-1)*100,
                'result': 'LOSS',
                'bars_held': i-current_trade['entry_index'],
                'exit_reason': 'SL - Protected Low broken',
                'balance_after': balance,
                'fee_total': fee_entry+fee_exit
            })
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] EXIT SL {current_trade['id']} Loss {profit:.2f}$ Bal {balance:.2f}$")
            current_trade=None
            continue
        if curr['high'] >= current_trade['take_profit']:
            exit_price=current_trade['take_profit']
            entry_cost=current_trade['entry_price']*current_trade['coins']
            exit_val=exit_price*current_trade['coins']
            fee_entry=entry_cost*fee_pct
            fee_exit=exit_val*fee_pct
            profit= (exit_price-current_trade['entry_price'])*current_trade['coins'] - fee_entry - fee_exit
            balance+=profit
            current_trade.update({
                'exit_price': exit_price,
                'exit_time': curr['timestamp'],
                'profit_usd': profit,
                'profit_pct': (exit_price/current_trade['entry_price']-1)*100,
                'result': 'WIN',
                'bars_held': i-current_trade['entry_index'],
                'exit_reason': 'TP - Term+0.27 extension',
                'balance_after': balance,
                'fee_total': fee_entry+fee_exit
            })
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] EXIT TP {current_trade['id']} Profit {profit:.2f}$ RR {current_trade['rr']:.2f} Bal {balance:.2f}$")
            current_trade=None
            continue
        continue

    # Filter protected lows up to i - pivot_length (2) to avoid lookahead needing future confirmation
    recent_pl=[pl for pl in protected_list if pl['type']=='low' and pl['index'] <= i-2 and pl['index'] >= i-150 and pl['protected'] and not pl['is_ghost'] and not pl['is_trap'] and pl['rejection_ratio'] and pl['rejection_ratio']>=1.0]
    if not recent_pl:
        recent_pl=[pl for pl in true_protected if pl['index'] <= i-2 and pl['index'] >= i-150]
    if not recent_pl:
        continue
    pl=recent_pl[-1]

    # BOS up to i
    recent_bos=[b for b in bos_res_full['valid_bos'] if b['index'] <= i and b['index'] > pl['index'] and i - b['index'] <= 80]
    if not recent_bos:
        continue
    bos=recent_bos[-1]

    # Discount
    origin_idx=pl['index']
    origin_price=pl['price']
    term_price=past['high'].iloc[origin_idx:].max()
    range_size=term_price-origin_price
    if range_size <=0:
        continue

    seg=past.iloc[origin_idx:]
    poc=calc_poc(seg, origin_price, term_price)
    median_50=(origin_price+term_price)/2
    dyn_eq=(poc+median_50)/2

    if curr['close'] > dyn_eq:
        continue

    buy_low=term_price - range_size*0.79
    buy_high=term_price - range_size*0.705

    if not (buy_low <= curr['close'] <= buy_high) and not (buy_low <= curr['low'] <= buy_high):
        continue

    # Bleeding check quick
    lookback=10
    seg_bleed=past.iloc[max(0,i-lookback):i+1]
    bear_vols=[r['volume'] for _,r in seg_bleed.iterrows() if r['close']<r['open']]
    bear_inc=False
    if len(bear_vols)>=3:
        try:
            x=np.arange(len(bear_vols)).reshape(-1,1)
            model=LinearRegression().fit(x, np.array(bear_vols))
            bear_inc=model.coef_[0]>0
        except:
            bear_inc=False
    cvd=0
    cvd_vals=[]
    for _,r in seg_bleed.iterrows():
        hl=r['high']-r['low']
        if hl>0:
            delta=(r['close']-r['low'])/hl -0.5
            cvd+=delta*r['volume']
            cvd_vals.append(cvd)
    cvd_collapse=False
    if len(cvd_vals)>=3:
        try:
            x=np.arange(len(cvd_vals)).reshape(-1,1)
            model=LinearRegression().fit(x, np.array(cvd_vals))
            cvd_collapse=model.coef_[0]<0 and cvd<0
        except:
            cvd_collapse=False
    if bear_inc and cvd_collapse:
        continue

    # OB/FVG filtered up to i
    # FVGs up to i
    recent_fvgs=[f for f in fvgs_full if f.c1_idx <= i and not f.is_ghost]
    # Check mitigation up to i for FVG: if low <= fvg.low (bullish) then mitigated
    unmitigated_fvgs=[]
    for f in recent_fvgs:
        mitigated=False
        # For bullish FVG, mitigated if price closed below low after its formation
        if f.c3_idx < i:
            for k in range(f.c3_idx+1, i+1):
                if df['low'].iloc[k] <= f.low:
                    mitigated=True
                    break
        if not mitigated:
            unmitigated_fvgs.append(f)
    recent_fvgs=unmitigated_fvgs

    recent_obs=[]
    for ob in obs_full:
        if ob.index > i:
            continue
        # check mitigation up to i: close below ob.low
        mitigated=False
        for k in range(ob.index+1, i+1):
            if df['close'].iloc[k] < ob.low:
                mitigated=True
                break
        if not mitigated:
            recent_obs.append(ob)

    valid_obs=[ob for ob in recent_obs if (buy_low <= ob.low <= buy_high) or (buy_low <= ob.high <= buy_high) or (ob.low <= buy_high and ob.high >= buy_low)]
    if not valid_obs:
        continue

    valid_exec=None
    for ob in valid_obs[-3:]:
        for fvg in recent_fvgs[-5:]:
            if abs(fvg.low - ob.high) < (ob.high-ob.low)*3:
                hl_range=curr['high']-curr['low']
                if hl_range==0:
                    continue
                lower_wick=min(curr['open'], curr['close'])-curr['low']
                body=abs(curr['close']-curr['open'])
                close_pos=(curr['close']-curr['low'])/hl_range if hl_range>0 else 0
                wick_rej=lower_wick > body*0.5 and close_pos>0.55
                vol_mean=past['volume'].iloc[max(0,i-20):i].mean()
                vol_std=past['volume'].iloc[max(0,i-20):i].std()
                vol_spike=curr['volume'] > vol_mean*1.2
                z_vol=z_score(curr['volume'], vol_mean, vol_std)
                is_extreme_churn=body < hl_range*0.15 and curr['volume'] > vol_mean*2.5
                if (wick_rej or vol_spike) and not is_extreme_churn:
                    valid_exec=(ob,fvg,wick_rej,vol_spike,close_pos,z_vol,vol_mean,body,hl_range)
                    break
        if valid_exec:
            break

    if not valid_exec:
        continue

    ob,fvg,wick_rej,vol_spike,close_pos,z_vol,vol_mean,body,hl_range=valid_exec

    # Confluence M
    atr_curr=atr_full.iloc[i]
    disp=bos['price']-bos['last_swing_price']
    has_safe=disp > atr_curr*0.1
    map_type="Map1_Bullish_ProTrend"
    w_struct=weighter.weight_structure(map_type, True, has_safe, False)
    w_vol=weighter.weight_volume(z_vol)
    is_aggressive=wick_rej and close_pos>0.85 and vol_spike and z_vol>2.0
    is_silent=close_pos>0.6 and not is_aggressive
    is_churning=body < hl_range*0.2 and curr['volume'] > vol_mean*2
    w_delta=weighter.weight_delta(is_aggressive, close_pos, is_silent, is_churning)
    w_context=weighter.weight_context(0.0,0.0)
    M=w_struct+w_vol+w_delta+w_context
    M=max(0.25,min(2.50,M))

    entry_price=nxt['open']
    stop_loss=pl['price'] - 0.01
    tp_standard=term_price + range_size*0.27
    tp_deep=term_price + range_size*0.62
    take_profit=tp_standard
    risk=abs(entry_price-stop_loss)
    reward=abs(take_profit-entry_price)
    rr=reward/risk if risk>0 else 0
    if rr<1.5:
        take_profit=tp_deep
        reward=abs(take_profit-entry_price)
        rr=reward/risk if risk>0 else 0
        if rr<1.5:
            continue

    risk_dist=abs(entry_price-stop_loss)/entry_price
    if risk_dist==0:
        continue
    allowed_loss=balance*0.01*M
    allowed_loss=min(allowed_loss, balance*0.025)
    spot_alloc=allowed_loss/risk_dist
    spot_alloc=min(spot_alloc, balance*0.95)
    coins=spot_alloc/entry_price if entry_price>0 else 0

    trade_id=len(trades)+1
    current_trade={
        'id': trade_id,
        'entry_index': i+1,
        'entry_time': nxt['timestamp'],
        'entry_price': entry_price,
        'stop_loss': stop_loss,
        'take_profit': take_profit,
        'take_profit_deep': tp_deep,
        'take_profit_standard': tp_standard,
        'risk_pct': risk_dist*100,
        'rr': rr,
        'coins': coins,
        'spot_allocation_usd': spot_alloc,
        'allowed_loss_usd': allowed_loss,
        'balance_before': balance,
        'M': M,
        'w_struct': w_struct,
        'w_vol': w_vol,
        'w_delta': w_delta,
        'w_context': w_context,
        'z_vol': z_vol,
        'protected_low_price': pl['price'],
        'protected_low_idx': pl['index'],
        'protected_low_rej': pl['rejection_ratio'],
        'bos_price': bos['price'],
        'bos_last_high': bos['last_swing_price'],
        'bos_close_pos': bos['close_position'],
        'buy_range_low': buy_low,
        'buy_range_high': buy_high,
        'dyn_eq': dyn_eq,
        'poc': poc,
        'term_price': term_price,
        'origin_price': origin_price,
        'range_size': range_size,
        'ob_low': ob.low,
        'ob_high': ob.high,
        'fvg_low': fvg.low,
        'fvg_high': fvg.high,
        'fvg_ce': fvg.ce,
        'wick_rej': wick_rej,
        'vol_spike': vol_spike,
        'close_pos': close_pos,
        'reason': f"PL {pl['price']:.2f} rej {pl['rejection_ratio']:.1f} + BOS {bos['price']:.2f} brk {bos['last_swing_price']:.2f} CP {bos['close_position']:.2f} Z {z_vol:.1f} + Deep OTE 70.5-79% {buy_low:.2f}-{buy_high:.2f} <Eq {dyn_eq:.2f} POC {poc:.2f} + OB {ob.low:.2f}-{ob.high:.2f} FVG CE {fvg.ce:.2f} Wick {wick_rej} VolSpike {vol_spike} M {M:.2f} RR {rr:.2f}"
    }
    logs.append(f"[{curr['timestamp']}] NEW TRADE {trade_id} Entry {entry_price:.2f} SL {stop_loss:.2f} TP {take_profit:.2f} RR {rr:.2f} M {M:.2f} Bal {balance:.2f}$ Alloc {spot_alloc:.2f}$")

# Close open at end
if current_trade:
    exit_price=df.iloc[-1]['close']
    entry_cost=current_trade['entry_price']*current_trade['coins']
    exit_val=exit_price*current_trade['coins']
    fee_entry=entry_cost*fee_pct
    fee_exit=exit_val*fee_pct
    profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - fee_entry - fee_exit
    balance+=profit
    current_trade.update({
        'exit_price': exit_price,
        'exit_time': df.iloc[-1]['timestamp'],
        'profit_usd': profit,
        'profit_pct': (exit_price/current_trade['entry_price']-1)*100,
        'result': 'OPEN_CLOSED_AT_END',
        'bars_held': len(df)-1 - current_trade['entry_index'],
        'exit_reason': 'Closed at end',
        'balance_after': balance,
        'fee_total': fee_entry+fee_exit
    })
    trades.append(current_trade)

print(f"\n=== FINAL $100 1% Last Month ===")
print(f"Total {len(trades)}")
wins=[t for t in trades if t['result']=='WIN']
losses=[t for t in trades if t['result']=='LOSS']
win_rate=len(wins)/len(trades)*100 if trades else 0
total_pnl=sum(t['profit_usd'] for t in trades)
print(f"Wins {len(wins)} Losses {len(losses)} WinRate {win_rate:.1f}%")
print(f"Total PnL {total_pnl:.4f}$ Final Bal {balance:.4f}$ Return {(balance/100-1)*100:.2f}%")
avg_win=np.mean([t['profit_usd'] for t in wins]) if wins else 0
avg_loss=np.mean([t['profit_usd'] for t in losses]) if losses else 0
avg_rr=np.mean([t['rr'] for t in trades]) if trades else 0
print(f"Avg Win {avg_win:.4f}$ Avg Loss {avg_loss:.4f}$ Avg RR {avg_rr:.2f}")
if trades:
    pd.DataFrame(trades).to_csv('/home/user/super_backtest_100usd_trades_detailed.csv', index=False)
    print("Saved trades csv")
    with open('/home/user/super_backtest_100usd_logs.txt','w') as f:
        for l in logs:
            f.write(l+'\n')
    for t in trades:
        print(f"\nTrade {t['id']} {t['result']} Entry {t['entry_time']} {t['entry_price']:.2f} -> Exit {t.get('exit_time')} {t.get('exit_price',0):.2f} P/L {t['profit_usd']:.4f}$ ({t['profit_pct']:.2f}%) RR {t['rr']:.2f} Bal {t['balance_before']:.2f}->{t['balance_after']:.2f} Alloc {t['spot_allocation_usd']:.2f}$ Coins {t['coins']:.6f} SL {t['stop_loss']:.2f} TP {t['take_profit']:.2f} OB {t['ob_low']:.2f}-{t['ob_high']:.2f} FVG CE {t['fvg_ce']:.2f}")
