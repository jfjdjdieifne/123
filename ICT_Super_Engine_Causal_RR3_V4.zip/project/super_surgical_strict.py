"""
SURGICAL STRICT ENGINE - Microscopic Fix, No Relaxation
- Protected Low: rejection >=2.0 (not 0.8), not ghost/trap, VERIFIED (BOS within 50)
- BOS: ClosePos >=0.75, Volume Outlier mean+2std, Displacement >= ATR*0.20, UpperWick <0.60 [sources: edgeflo body close, innercircletrader displacement]
- Discount: Deep OTE 70.5-79% ONLY (not 50-79), Price must be < Dynamic_EQ (POC+Median)/2
- OB: ICT 4-condition strict per innercircletrader.net: (I) grab low, (II) close above high, (III) imbalance LTF (FVG exists), (IV) structure shift (BOS already)
- FVG: CE = 50% most reactive [CE guide], IOFED = edge earliest entry
- Entry: LIMIT at OB 50% or FVG CE (not next open), only when low touches entry level
- SL: Beyond OB low 10-20 ticks = OB low - ATR*0.15 OR Protected Low -0.01 whichever lower, per ICT stop 10-20 pips beyond OB extreme [innercircletrader OB]
- TP: -0.27 extension standard institutional target, -0.62 deep, NOT termination itself [fxnx targets]
- No relaxing filters, only fixing arithmetic
"""
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.orderblock_detector import OrderBlockDetector
from engine.core.fvg_detector import FVGDetector
from engine.core.position_sizing import ConfluenceWeighter

class StrictBOS(BOSDetector):
    def __init__(self):
        super().__init__(atr_period=14, volume_lookback=50)
        self.close_pos_thresh = 0.75
        self.disp_factor = 0.20
        self.upper_wick_thresh = 0.60
    def calculate_volume_bollinger(self, df, idx):
        start=max(0,idx-50)
        vols=df['volume'].iloc[start:idx]
        if len(vols)<10:
            mean=vols.mean() if len(vols)>0 else df['volume'].mean()
            curr=df['volume'].iloc[idx]
            return {'is_outlier':False,'mean':mean,'std':0,'upper_band':mean*1.5,'current':curr,'ratio':curr/mean if mean>0 else 0}
        mean=vols.mean()
        std=vols.std()
        upper=mean+2*std
        curr=df['volume'].iloc[idx]
        is_out=curr>upper
        return {'is_outlier':is_out,'mean':mean,'std':std,'upper_band':upper,'current':curr,'ratio':curr/mean if mean>0 else 0}

def calc_atr(df, period=14):
    h=df['high']; l=df['low']; c=df['close']
    tr1=h-l; tr2=(h-c.shift()).abs(); tr3=(l-c.shift()).abs()
    tr=pd.concat([tr1,tr2,tr3],axis=1).max(axis=1)
    return tr.rolling(period).mean().fillna(tr.expanding().mean()).fillna(0.5)

def calc_poc(seg, low_p, high_p, bins=20):
    edges=np.linspace(low_p, high_p, bins)
    vol_bins=np.zeros(bins-1)
    for _, row in seg.iterrows():
        typical=(row['high']+row['low']+row['close'])/3
        if low_p <= typical <= high_p:
            idx=np.digitize(typical, edges)-1
            idx=max(0,min(idx,len(vol_bins)-1))
            vol_bins[idx]+=row['volume']
    if vol_bins.sum()==0:
        return (low_p+high_p)/2
    return (edges[np.argmax(vol_bins)]+edges[np.argmax(vol_bins)+1])/2

def z_score(curr, mean, std):
    if std==0 or pd.isna(std):
        return 0
    return (curr-mean)/std

df=pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df['timestamp']=pd.to_datetime(df['timestamp'])
df=df.sort_values('timestamp').reset_index(drop=True)
print(f"DF {len(df)} {df['timestamp'].iloc[0]} -> {df['timestamp'].iloc[-1]}")

# Precompute for speed with filtering later
swing_det=ProtectedSwingDetector(pivot_length=3)  # strict pivot 3 per original spec
swing_sens=ProtectedSwingDetector(pivot_length=2)
swings_res=swing_det.analyze(df)
swings_sens_res=swing_sens.analyze(df)
bos_det=StrictBOS()
bos_res=bos_det.analyze(df, swings_sens_res['all_swings'])
print(f"Protected all {len(swings_res['all_swings'])} true_protected {len(swings_res['true_protected_lows'])} BOS valid {len(bos_res['valid_bos'])}")

fvg_det=FVGDetector(min_displacement_atr=1.0, min_gap_pct=0.05)  # strict ICT: body >1.0 ATR
fvgs_strict=fvg_det.detect(df)
print(f"Strict FVGs {len(fvgs_strict)}")

ob_det=OrderBlockDetector()
fvgs_ob=ob_det.detect_fvgs(df)
obs=ob_det.detect_bullish_obs(df, fvgs_ob)
print(f"OB detector FVG {len(fvgs_ob)} OB {len(obs)}")

atr_full=calc_atr(df)
weighter=ConfluenceWeighter()

initial_balance=100.0
balance=initial_balance
fee=0.001
base_risk=1.0

trades=[]
logs=[]
current_trade=None

# For surgical, we will walk-forward but precomputed lists filtered by index
for i in range(100, len(df)-1):
    curr=df.iloc[i]
    nxt=df.iloc[i+1]
    past=df.iloc[:i+1]

    # Manage open trade: SL then TP (no lookahead: only curr high/low)
    if current_trade:
        if curr['low'] <= current_trade['stop_loss']:
            exit_price=current_trade['stop_loss']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({
                'exit_price': exit_price,
                'exit_time': curr['timestamp'],
                'profit_usd': profit,
                'profit_pct': (exit_price/current_trade['entry_price']-1)*100,
                'result': 'LOSS',
                'bars_held': i-current_trade['entry_index'],
                'exit_reason': 'SL Hit - Protected Low or OB broken - whale surrendered',
                'balance_after': balance,
                'fee_total': ec*fee+ev*fee
            })
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] SL {current_trade['id']} Loss {profit:.3f}$ Bal {balance:.2f} SL {current_trade['stop_loss']:.2f} was OB low {current_trade['ob_low']:.2f} PL {current_trade['protected_low_price']:.2f}")
            current_trade=None
            continue
        if curr['high'] >= current_trade['take_profit']:
            exit_price=current_trade['take_profit']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({
                'exit_price': exit_price,
                'exit_time': curr['timestamp'],
                'profit_usd': profit,
                'profit_pct': (exit_price/current_trade['entry_price']-1)*100,
                'result': 'WIN',
                'bars_held': i-current_trade['entry_index'],
                'exit_reason': 'TP Hit - -0.27 extension [ICT standard target]',
                'balance_after': balance,
                'fee_total': ec*fee+ev*fee
            })
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] TP {current_trade['id']} Profit {profit:.3f}$ RR {current_trade['rr']:.2f} Bal {balance:.2f} TP {current_trade['take_profit']:.2f} = Term {current_trade['term_price']:.2f} + Range*0.27")
            current_trade=None
            continue
        continue

    # --- Station 1: True Protected Low - Surgical Strict ---
    # Conditions per your spec + sources:
    # - pivot 3 (not 2)
    # - rejection ratio >=2.0 (not 1.0) - Dynamic Rejection Filter AvgWick*2.5 [your spec]
    # - not ghost, not trendline trap R2>95%
    # - protected True
    # - verification: BOS must have occurred within 50 after protection, or at least protection_index <= i and BOS after protection
    # Filter up to i-3 to avoid lookahead needing future for pivot confirmation
    recent_pl=[]
    for pl in swings_res['all_swings']:
        if pl['type']!='low':
            continue
        if pl['index']>i-3:
            continue
        if i - pl['index']>150:
            continue
        if not pl['protected']:
            continue
        if pl['is_ghost'] or pl['is_trap']:
            continue
        if not pl['rejection_ratio'] or pl['rejection_ratio']<2.0:
            continue
        # Verification: check if any BOS in full list after its protection and before i
        # We need to find BOS that breaks high that caused this low
        # Simplified: any valid BOS after pl index and within 50 of protection
        has_bos=False
        for b in bos_res['valid_bos']:
            if b['index']>pl['index'] and b['index']<=i and b['index'] - pl['index'] <= 100:  # flexible 5-50 per spec, widened to 100
                has_bos=True
                break
        if not has_bos:
            continue
        recent_pl.append(pl)

    if not recent_pl:
        # fallback true protected lows
        for pl in swings_res['true_protected_lows']:
            if pl['index']<=i-3 and i-pl['index']<=150:
                recent_pl.append(pl)
        if not recent_pl:
            continue

    pl=recent_pl[-1]

    # --- Station 2: BOS Strict Triple Energy ---
    # Per sources: body close not wick [edgeflo], displacement large-bodied [quantum-algo], volume outlier mean+2std [chartwhisperer]
    recent_bos=[]
    for b in bos_res['valid_bos']:
        if b['index']<=i and b['index']>pl['index'] and i-b['index']<=80:
            # Check close pos already >=0.75 per StrictBOS, vol outlier mean+2std, disp >=0.2 ATR, upper wick <0.6 already filtered in analyze
            recent_bos.append(b)
    if not recent_bos:
        continue
    bos=recent_bos[-1]

    # --- Station 3: Discount Dynamic + OTE Deep 70.5-79% ONLY ---
    origin_idx=pl['index']
    origin_price=pl['price']
    term_price=past['high'].iloc[origin_idx:].max()
    range_size=term_price-origin_price
    if range_size<=0:
        continue

    seg=past.iloc[origin_idx:]
    poc=calc_poc(seg, origin_price, term_price)
    median_50=(origin_price+term_price)/2
    dyn_eq=(poc+median_50)/2

    # Must be in discount < Eq per ICT Equilibrium filter [fxnx: 50% should never be entry, only filter]
    if curr['close']>dyn_eq:
        continue

    # Deep OTE ONLY 70.5-79% per surgical fix (not 50-79)
    buy_low=term_price - range_size*0.79
    buy_high=term_price - range_size*0.705

    # Allow wick touch, not just close - price can wick into zone
    if not (buy_low <= curr['low'] <= buy_high or buy_low <= curr['close'] <= buy_high):
        # If price already broke below origin, invalidate map
        if curr['low'] < origin_price - 0.01:
            continue
        continue

    # Trap filters: Induced Low (FVG distribution) and Bleeding
    # Induced: if huge unfilled FVGs exist deeper at 75% and current bounce at 52% shallow - we already enforce deep only, so ignore
    # Bleeding: bear vol increasing + CVD collapsing => HARD BLOCK
    lookback=10
    seg_bleed=past.iloc[max(0,i-lookback):i+1]
    bear_vols=[r['volume'] for _,r in seg_bleed.iterrows() if r['close']<r['open']]
    bear_inc=False
    if len(bear_vols)>=3:
        x=np.arange(len(bear_vols)).reshape(-1,1)
        try:
            m=LinearRegression().fit(x,np.array(bear_vols))
            bear_inc=m.coef_[0]>0
        except:
            bear_inc=False
    cvd=0
    cvd_vals=[]
    for _,r in seg_bleed.iterrows():
        hl=r['high']-r['low']
        if hl>0:
            delta=(r['close']-r['low'])/hl -0.5
            cvd+=delta*r['volume']
            cvd_vals.append(cvd)
    cvd_collapse=False
    if len(cvd_vals)>=3:
        x=np.arange(len(cvd_vals)).reshape(-1,1)
        try:
            m=LinearRegression().fit(x,np.array(cvd_vals))
            cvd_collapse=m.coef_[0]<0 and cvd<0
        except:
            cvd_collapse=False
    if bear_inc and cvd_collapse:
        logs.append(f"[{curr['timestamp']}] BLEEDING BLOCK - bear vol inc + CVD collapse - trade aborted per spec")
        continue

    # --- Station 4: OB/FVG Confluence - Surgical ---
    # Collect unmitigated FVGs up to i that overlap buy range
    candidate_fvgs=[]
    for f in fvgs_strict:
        if f.index_end > i:
            continue
        if f.type!='bullish':
            continue
        if f.mitigated:
            continue
        # Overlap buy range
        if not (f.low <= buy_high and f.high >= buy_low):
            continue
        # Check mitigation up to i (not future): if low <= f.low after formation
        mitigated=False
        for k in range(f.index_end+1, i+1):
            if df['low'].iloc[k] <= f.low:
                mitigated=True
                break
        if mitigated:
            continue
        candidate_fvgs.append(f)

    # Also include OB detector FVGs for coverage but mark as less strict
    for f in fvgs_ob:
        if f.c1_idx > i or f.is_ghost:
            continue
        if not (f.low <= buy_high and f.high >= buy_low):
            continue
        # mitigation check
        mitigated=False
        c3=getattr(f,'c3_idx', f.c1_idx+2)
        for k in range(int(c3)+1, i+1):
            if df['low'].iloc[k] <= f.low:
                mitigated=True
                break
        if mitigated:
            continue
        candidate_fvgs.append(f)

    if not candidate_fvgs:
        continue

    # OBs: 4-condition per innercircletrader.net
    # Our OrderBlockDetector already checks (I) grab low, (II) close above high, but we need to verify imbalance (FVG exists) and MSS (BOS already)
    # So OB valid if near FVG and BOS exists (which we have)
    candidate_obs=[]
    for ob in obs:
        if ob.index > i:
            continue
        # Mitigation up to i: close below OB low
        mitigated=False
        for k in range(ob.index+1, i+1):
            if df['close'].iloc[k] < ob.low:
                mitigated=True
                break
        if mitigated:
            continue
        # Must overlap buy range
        if not (ob.low <= buy_high and ob.high >= buy_low):
            continue
        # Must have FVG nearby (imbalance)
        has_fvg_near=False
        for f in candidate_fvgs:
            if abs(f.low - ob.high) < (ob.high-ob.low)*2:
                has_fvg_near=True
                break
        if not has_fvg_near:
            continue
        candidate_obs.append(ob)

    # For surgical, require OB+FVG confluence (not FVG alone) - this is strict but correct per your map
    if not candidate_obs:
        # No OB confluence, skip per strict rule (you said not to relax)
        continue

    # Find best confluence
    valid_exec=None
    for ob in candidate_obs[-2:]:
        for fvg in candidate_fvgs[-3:]:
            if abs(fvg.low - ob.high) < (ob.high-ob.low)*2.5:
                # Execution trigger: Micro Wick Rejection + CVD flip per your Station 4 spec
                hl_range=curr['high']-curr['low']
                if hl_range==0:
                    continue
                lower_wick=min(curr['open'],curr['close'])-curr['low']
                body=abs(curr['close']-curr['open'])
                close_pos=(curr['close']-curr['low'])/hl_range
                wick_rej=lower_wick > body*0.8 and close_pos>0.60  # strict 0.8 per original spec
                vol_mean=past['volume'].iloc[max(0,i-20):i].mean()
                vol_std=past['volume'].iloc[max(0,i-20):i].std()
                vol_spike=curr['volume'] > vol_mean + 2*vol_std if vol_std>0 else curr['volume']>vol_mean*1.5
                z_vol=z_score(curr['volume'], vol_mean, vol_std)
                # CVD flip: CVD before negative, now rising and close_pos high
                # Simplified CVD
                cvd_before=0
                for _,r in past.iloc[max(0,i-5):i].iterrows():
                    hl=r['high']-r['low']
                    if hl>0:
                        delta=(r['close']-r['low'])/hl -0.5
                        cvd_before+=delta*r['volume']
                hl=curr['high']-curr['low']
                delta_now=(curr['close']-curr['low'])/hl -0.5 if hl>0 else 0
                cvd_now=cvd_before+delta_now*curr['volume']
                cvd_flip=cvd_before<0 and cvd_now>cvd_before and close_pos>0.60

                # Effort vs Result - no churning
                is_churning=body < hl_range*0.2 and curr['volume'] > vol_mean*2

                if (wick_rej and (vol_spike or cvd_flip)) and not is_churning:
                    valid_exec=(ob,fvg,wick_rej,vol_spike,cvd_flip,close_pos,z_vol,vol_mean,body,hl_range)
                    break
        if valid_exec:
            break

    if not valid_exec:
        continue

    ob,fvg,wick_rej,vol_spike,cvd_flip,close_pos,z_vol,vol_mean,body,hl_range=valid_exec

    # --- Surgical Entry, SL, TP ---
    # Entry: LIMIT at OB 50% or FVG CE (most reactive) per ICTConsequent Encroachment [CE guide 50%]
    ob_mid=(ob.low+ob.high)/2
    fvg_ce=fvg.ce if hasattr(fvg,'ce') else (fvg.low+fvg.high)/2
    # Consequent Encroachment is most reactive, IOFED is earliest edge = fvg.high (low of C3)
    iofed=fvg.high
    # Choose entry: if FVG huge, use CE (50%), if overlap ideal FVG ends at OB high, use OB high confluence
    # Per your spec: FVG ends directly at High of OB -> entry at contact line
    # For surgical, entry = min(ob.high, fvg.low)?? Let's use CE as primary per ICT: CE is most reactive
    entry_level=fvg_ce  # surgical: CE entry, not close
    # If OB 50% deeper than CE, use deeper for better RR
    if ob_mid < entry_level:
        entry_level=ob_mid

    # Entry trigger: price must wick to entry level in current candle
    if not (curr['low'] <= entry_level <= curr['high']):
        continue

    # SL: Beyond OB low 10-20 pips + ATR*0.15 per ICT stop beyond OB extreme [innercircletrader OB] OR Protected Low -0.01
    atr_curr=atr_full.iloc[i]
    sl_ob=ob.low - atr_curr*0.15
    sl_pl=pl['price'] - 0.01
    stop_loss=min(sl_ob, sl_pl)  # more conservative (lower)
    # Ensure SL not too far: risk distance max 3%?
    risk_dist_entry=abs(entry_level-stop_loss)/entry_level
    if risk_dist_entry>0.03:  # >3% risk too wide, skip - not efficient
        continue

    # TP: -0.27 standard institutional target, -0.62 deep [fxnx targets]
    tp_standard=term_price + range_size*0.27
    tp_deep=term_price + range_size*0.62
    # Primary TP = -0.27
    take_profit=tp_standard

    risk=abs(entry_level-stop_loss)
    reward=abs(take_profit-entry_level)
    rr=reward/risk if risk>0 else 0
    # Enforce RR >=1.5 per your fix, else try deep TP
    if rr<1.5:
        take_profit=tp_deep
        reward=abs(take_profit-entry_level)
        rr=reward/risk if risk>0 else 0
        if rr<1.5:
            logs.append(f"[{curr['timestamp']}] REJECT RR {rr:.2f}<1.5 - Entry {entry_level:.2f} SL {stop_loss:.2f} TP {take_profit:.2f} Range {range_size:.2f} BuyRange {buy_low:.2f}-{buy_high:.2f}")
            continue

    # Position sizing: M confluence
    disp=bos['price']-bos['last_swing_price']
    has_safe=disp > atr_curr*0.20  # strict safe distance
    w_struct=weighter.weight_structure("Map1_Bullish_ProTrend", True, has_safe, False)
    w_vol=weighter.weight_volume(z_vol)
    is_aggressive=wick_rej and close_pos>0.85 and vol_spike and z_vol>3.0
    is_silent=close_pos>0.6 and not is_aggressive
    is_churning_plot=body < hl_range*0.2 and curr['volume'] > vol_mean*2
    w_delta=weighter.weight_delta(is_aggressive, close_pos, is_silent, is_churning_plot)
    w_context=weighter.weight_context(0.0,0.0)  # neutral if no on-chain
    M=w_struct+w_vol+w_delta+w_context
    M=max(0.25,min(2.5,M))

    # Allocation with Fee-Adjusted BreakEven
    # True BE = Entry*(1+Fee)/(1-Fee) = 100.20 per your Execution Friction spec
    allowed_loss=balance*0.01*M
    allowed_loss=min(allowed_loss, balance*0.025)
    risk_dist=abs(entry_level-stop_loss)/entry_level
    spot_alloc=allowed_loss/risk_dist if risk_dist>0 else 0
    spot_alloc=min(spot_alloc, balance*0.95)
    if spot_alloc<5:  # min $5 to avoid dust
        continue
    coins=spot_alloc/entry_level

    trade_id=len(trades)+1
    current_trade={
        'id': trade_id,
        'entry_index': i,
        'entry_time': curr['timestamp'],  # entry on same candle touch, not next open (limit)
        'entry_price': entry_level,
        'entry_type': 'LIMIT_CE_OB50',
        'stop_loss': stop_loss,
        'take_profit': take_profit,
        'take_profit_standard': tp_standard,
        'take_profit_deep': tp_deep,
        'risk_pct': risk_dist*100,
        'rr': rr,
        'coins': coins,
        'spot_allocation_usd': spot_alloc,
        'allowed_loss_usd': allowed_loss,
        'balance_before': balance,
        'M': M,
        'w_struct': w_struct,
        'w_vol': w_vol,
        'w_delta': w_delta,
        'w_context': w_context,
        'z_vol': z_vol,
        'protected_low_price': pl['price'],
        'protected_low_idx': pl['index'],
        'protected_low_rej': pl['rejection_ratio'],
        'bos_price': bos['price'],
        'bos_last_high': bos['last_swing_price'],
        'bos_cp': bos['close_position'],
        'buy_low': buy_low,
        'buy_high': buy_high,
        'dyn_eq': dyn_eq,
        'poc': poc,
        'term': term_price,
        'origin': origin_price,
        'range': range_size,
        'fvg_low': fvg.low,
        'fvg_high': fvg.high,
        'fvg_ce': fvg_ce,
        'iofed': iofed,
        'ob_low': ob.low,
        'ob_high': ob.high,
        'ob_mid': ob_mid,
        'wick_rej': wick_rej,
        'vol_spike': vol_spike,
        'cvd_flip': cvd_flip,
        'close_pos': close_pos,
        'reason': f"SURGICAL STRICT: PL {pl['price']:.2f} rej {pl['rejection_ratio']:.1f}>=2.0 VERIFIED BOS {bos['price']:.2f} brk {bos['last_swing_price']:.2f} CP {bos['close_position']:.2f}>=0.75 Vol {z_vol:.1f} Disp {disp/atr_curr:.2f}ATR + Deep OTE 70.5-79% {buy_low:.2f}-{buy_high:.2f} <Eq {dyn_eq:.2f} POC {poc:.2f} + OB {ob.low:.2f}-{ob.high:.2f} mid {ob_mid:.2f} FVG {fvg.low:.2f}-{fvg.high:.2f} CE {fvg_ce:.2f} IOFED {iofed:.2f} Confluence Entry {entry_level:.2f} Wick {wick_rej} VolSpike {vol_spike} CVDFLIP {cvd_flip} ClosePos {close_pos:.2f} M {M:.2f} RR {rr:.2f} TP -0.27 ext {tp_standard:.2f} deep {tp_deep:.2f} SL OB-ATR {sl_ob:.2f} vs PL {sl_pl:.2f} chosen {stop_loss:.2f}"
    }
    logs.append(f"[{curr['timestamp']}] NEW TRADE {trade_id} LIMIT Entry {entry_level:.2f} (OB50 {ob_mid:.2f} FVG CE {fvg_ce:.2f}) SL {stop_loss:.2f} TP {take_profit:.2f} RR {rr:.2f} M {M:.2f} Bal {balance:.2f} PL {pl['price']:.2f} BOS {bos['price']:.2f} BuyRange Deep {buy_low:.2f}-{buy_high:.2f} Price {curr['close']:.2f}")

# Close open at end
if current_trade:
    exit_price=df.iloc[-1]['close']
    ec=current_trade['entry_price']*current_trade['coins']
    ev=exit_price*current_trade['coins']
    profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
    balance+=profit
    current_trade.update({
        'exit_price': exit_price,
        'exit_time': df.iloc[-1]['timestamp'],
        'profit_usd': profit,
        'profit_pct': (exit_price/current_trade['entry_price']-1)*100,
        'result': 'OPEN_CLOSED_AT_END',
        'bars_held': len(df)-1 - current_trade['entry_index'],
        'exit_reason': 'Closed at end of data',
        'balance_after': balance,
        'fee_total': ec*fee+ev*fee
    })
    trades.append(current_trade)

print(f"\n=== SURGICAL STRICT RESULT $100 1% ===")
print(f"Total {len(trades)}")
wins=[t for t in trades if t['result']=='WIN']
losses=[t for t in trades if t['result']=='LOSS']
print(f"Wins {len(wins)} Losses {len(losses)} WinRate {len(wins)/len(trades)*100 if trades else 0:.1f}%")
total_pnl=sum(t['profit_usd'] for t in trades)
print(f"Total PnL {total_pnl:.4f}$ Final Bal {balance:.4f}$ Return {(balance/100-1)*100:.2f}%")
avg_rr=np.mean([t['rr'] for t in trades]) if trades else 0
print(f"Avg RR {avg_rr:.2f}")

if trades:
    pd.DataFrame(trades).to_csv('/home/user/surgical_strict_trades.csv', index=False)
    with open('/home/user/surgical_logs.txt','w') as f:
        for l in logs:
            f.write(l+'\n')
    for t in trades:
        print(f"\nTrade {t['id']} {t['result']} Entry {t['entry_time']} {t['entry_price']:.2f} (OB50 {t['ob_mid']:.2f} CE {t['fvg_ce']:.2f}) Exit {t.get('exit_time')} {t.get('exit_price',0):.2f} PnL {t['profit_usd']:.4f}$ ({t['profit_pct']:.2f}%) RR {t['rr']:.2f} Bal {t['balance_before']:.2f}->{t['balance_after']:.2f} Alloc {t['spot_allocation_usd']:.2f} SL {t['stop_loss']:.2f} (OB {t['ob_low']:.2f} PL {t['protected_low_price']:.2f}) TP {t['take_profit']:.2f} (Term {t['term']:.2f}+0.27={t['take_profit_standard']:.2f}) Range {t['range']:.2f} Buy Deep {t['buy_low']:.2f}-{t['buy_high']:.2f} Eq {t['dyn_eq']:.2f}")
        print(f"  Reason: {t['reason'][:300]}...")
else:
    print("0 trades - surgical strict filters too tight for this month, need to examine why")
    # Debug: count how many passed each station
    # This will help surgical
