"""
Relaxed but still Thinking Engine - $100 1% Risk - Produces Trades
- Protected Low (rejection >=1.0, not ghost/trap)
- BOS valid (CP >=0.60, vol 1.2x, disp ATR*0.10)
- Discount 50-79% wide OTE (balanced)
- Execution: FVG alone valid if inside buy range + wick OR vol spike (OB optional bonus)
- RR fix TP = term + range*0.27, enforce >=1.5
"""
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.orderblock_detector import OrderBlockDetector
from engine.core.position_sizing import ConfluenceWeighter
from engine.core.fvg_detector import FVGDetector

class BalancedBOS(BOSDetector):
    def __init__(self):
        super().__init__(atr_period=14, volume_lookback=20)
        self.close_pos_thresh = 0.55
        self.disp_factor = 0.08
        self.upper_wick_thresh = 0.75
    def calculate_volume_bollinger(self, df, idx):
        start=max(0,idx-20)
        vol_mean=df['volume'].iloc[start:idx].mean() if idx>start else df['volume'].mean()
        curr=df['volume'].iloc[idx]
        is_outlier=curr>vol_mean*1.15
        return {'is_outlier':is_outlier,'mean':vol_mean,'upper_band':vol_mean*1.15,'current':curr,'ratio':curr/vol_mean if vol_mean>0 else 0,'std':df['volume'].iloc[start:idx].std() if idx>start else 0}

def z_score(curr,mean,std):
    if std==0 or pd.isna(std): return 0
    return (curr-mean)/std

def calc_atr(df,period=14):
    h=df['high']; l=df['low']; c=df['close']
    tr1=h-l; tr2=(h-c.shift()).abs(); tr3=(l-c.shift()).abs()
    tr=pd.concat([tr1,tr2,tr3],axis=1).max(axis=1)
    return tr.rolling(period).mean().fillna(tr.expanding().mean()).fillna(0.5)

def calc_poc(seg,low_p,high_p,bins=20):
    edges=np.linspace(low_p,high_p,bins)
    vol_bins=np.zeros(bins-1)
    for _,row in seg.iterrows():
        typical=(row['high']+row['low']+row['close'])/3
        if low_p <= typical <= high_p:
            idx=np.digitize(typical,edges)-1
            idx=max(0,min(idx,len(vol_bins)-1))
            vol_bins[idx]+=row['volume']
    if vol_bins.sum()==0:
        return (low_p+high_p)/2
    return (edges[np.argmax(vol_bins)]+edges[np.argmax(vol_bins)+1])/2

df=pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df['timestamp']=pd.to_datetime(df['timestamp'])
df=df.sort_values('timestamp').reset_index(drop=True)
print(f"DF {len(df)}")

swing_det=ProtectedSwingDetector(pivot_length=2)
swing_sens=ProtectedSwingDetector(pivot_length=1)
swings_res=swing_det.analyze(df)
swings_sens_res=swing_sens.analyze(df)
all_swings=swings_sens_res['all_swings']

bos_det=BalancedBOS()
bos_res=bos_det.analyze(df, all_swings)
print(f"Protected {len(swings_res['protected_lows'])} True {len(swings_res['true_protected_lows'])} BOS valid {len(bos_res['valid_bos'])}")

fvg_det=FVGDetector(min_displacement_atr=0.8, min_gap_pct=0.03)  # relaxed
fvg_res=fvg_det.analyze(df)
fvgs_list=fvg_det.detect(df)
print(f"FVGDetector found {len(fvgs_list)} (relaxed)")

ob_det=OrderBlockDetector()
fvgs_ob=ob_det.detect_fvgs(df)
obs=ob_det.detect_bullish_obs(df, fvgs_ob)
print(f"OB detector FVG {len(fvgs_ob)} OB {len(obs)}")

# Use more permissive FVG list: combine both detectors for maximum coverage
all_fvgs_combined=fvgs_list + fvgs_ob
print(f"Combined FVGs {len(all_fvgs_combined)}")

weighter=ConfluenceWeighter()
atr_full=calc_atr(df)

initial_balance=100.0
balance=initial_balance
base_risk=1.0
fee=0.001

trades=[]
logs=[]
current_trade=None

# For bleeding check we need LinearRegression
for i in range(50, len(df)-1):
    curr=df.iloc[i]
    nxt=df.iloc[i+1]
    past=df.iloc[:i+1]

    if current_trade:
        if curr['low'] <= current_trade['stop_loss']:
            exit_price=current_trade['stop_loss']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({
                'exit_price':exit_price,
                'exit_time':curr['timestamp'],
                'profit_usd':profit,
                'profit_pct':(exit_price/current_trade['entry_price']-1)*100,
                'result':'LOSS',
                'bars_held':i-current_trade['entry_index'],
                'exit_reason':'SL Hit - Protected Low broken',
                'balance_after':balance,
                'fee_total': ec*fee + ev*fee
            })
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] SL {current_trade['id']} Loss {profit:.2f} Bal {balance:.2f}")
            current_trade=None
            continue
        if curr['high'] >= current_trade['take_profit']:
            exit_price=current_trade['take_profit']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({
                'exit_price':exit_price,
                'exit_time':curr['timestamp'],
                'profit_usd':profit,
                'profit_pct':(exit_price/current_trade['entry_price']-1)*100,
                'result':'WIN',
                'bars_held':i-current_trade['entry_index'],
                'exit_reason':'TP Hit - Term +0.27 ext',
                'balance_after':balance,
                'fee_total': ec*fee + ev*fee
            })
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] TP {current_trade['id']} Profit {profit:.2f} RR {current_trade['rr']:.2f} Bal {balance:.2f}")
            current_trade=None
            continue
        continue

    # Protected Low filter up to i-2
    recent_pl=[pl for pl in swings_res['all_swings'] if pl['type']=='low' and pl['index']<=i-2 and pl['index']>=i-150 and pl['protected'] and not pl['is_ghost'] and not pl['is_trap'] and pl['rejection_ratio'] and pl['rejection_ratio']>=0.8]
    if not recent_pl:
        recent_pl=[pl for pl in swings_res['true_protected_lows'] if pl['index']<=i-2 and pl['index']>=i-150]
    if not recent_pl:
        continue
    pl=recent_pl[-1]

    recent_bos=[b for b in bos_res['valid_bos'] if b['index']<=i and b['index']>pl['index'] and i-b['index']<=100]
    if not recent_bos:
        continue
    bos=recent_bos[-1]

    origin_idx=pl['index']
    origin_price=pl['price']
    term_price=past['high'].iloc[origin_idx:].max()
    range_size=term_price-origin_price
    if range_size<=0:
        continue

    # POC Eq
    seg=past.iloc[origin_idx:]
    poc=calc_poc(seg, origin_price, term_price)
    median_50=(origin_price+term_price)/2
    dyn_eq=(poc+median_50)/2

    if curr['close']>dyn_eq:
        continue

    # Wide OTE 50-79% to get trades (balanced)
    buy_low=term_price - range_size*0.79
    buy_high=term_price - range_size*0.50

    if not (buy_low <= curr['close'] <= buy_high) and not (buy_low <= curr['low'] <= buy_high):
        continue

    # Execution: FVG inside buy range
    # Collect FVGs up to i
    # Use fvgs_list (FVGDetector) for bullish FVGs
    candidate_fvgs=[]
    for f in fvgs_list:
        if f.index_end <= i and f.type=='bullish' and not f.mitigated:
            # Check if FVG inside buy range (overlap)
            if (buy_low <= f.low <= buy_high) or (buy_low <= f.high <= buy_high) or (f.low <= buy_high and f.high >= buy_low):
                # Check mitigation up to i: if low <= f.high? Actually bullish FVG mitigated when low <= f.low
                mitigated=False
                for k in range(f.index_end+1, i+1):
                    if df['low'].iloc[k] <= f.low:
                        mitigated=True
                        break
                if not mitigated:
                    candidate_fvgs.append(f)

    # Also include ob_det FVGs
    for f in fvgs_ob:
        if f.c1_idx <= i and not f.is_ghost:
            if (buy_low <= f.low <= buy_high) or (buy_low <= f.high <= buy_high) or (f.low <= buy_high and f.high >= buy_low):
                # mitigation check: low <= f.low ?
                mitigated=False
                if hasattr(f, 'c3_idx'):
                    c3=f.c3_idx if hasattr(f,'c3_idx') else f.c1_idx+2
                    for k in range(int(c3)+1, i+1):
                        if df['low'].iloc[k] <= f.low:
                            mitigated=True
                            break
                else:
                    for k in range(int(f.c1_idx)+3, i+1):
                        if df['low'].iloc[k] <= f.low:
                            mitigated=True
                            break
                if not mitigated:
                    candidate_fvgs.append(f)

    if not candidate_fvgs:
        continue

    # Pick most recent FVG
    fvg=candidate_fvgs[-1]
    # Try to find OB confluence for bonus
    ob_confluence=None
    recent_obs=[o for o in obs if o.index <= i]
    for ob in recent_obs[-5:]:
        # check not mitigated up to i
        mitigated=False
        for k in range(ob.index+1, i+1):
            if df['close'].iloc[k] < ob.low:
                mitigated=True
                break
        if mitigated:
            continue
        if abs(fvg.low - ob.high) < (ob.high-ob.low)*3 or (buy_low <= ob.low <= buy_high):
            ob_confluence=ob
            break

    # Execution trigger: Wick rejection OR Vol spike
    hl_range=curr['high']-curr['low']
    if hl_range==0:
        continue
    lower_wick=min(curr['open'],curr['close'])-curr['low']
    body=abs(curr['close']-curr['open'])
    close_pos=(curr['close']-curr['low'])/hl_range if hl_range>0 else 0
    wick_rej=lower_wick > body*0.45 and close_pos>0.50
    vol_mean=past['volume'].iloc[max(0,i-20):i].mean()
    vol_std=past['volume'].iloc[max(0,i-20):i].std()
    vol_spike=curr['volume'] > vol_mean*1.15
    z_vol=z_score(curr['volume'], vol_mean, vol_std)
    is_extreme_churn=body < hl_range*0.12 and curr['volume'] > vol_mean*2.2
    if is_extreme_churn:
        continue
    if not (wick_rej or vol_spike):
        continue

    # Confluence M
    atr_curr=atr_full.iloc[i]
    disp=bos['price']-bos['last_swing_price']
    has_safe=disp > atr_curr*0.08
    w_struct=weighter.weight_structure("Map1_Bullish_ProTrend", True, has_safe, False)
    w_vol=weighter.weight_volume(z_vol)
    is_aggressive=wick_rej and close_pos>0.80 and vol_spike and z_vol>1.8
    is_silent=close_pos>0.55 and not is_aggressive
    is_churning=body < hl_range*0.2 and curr['volume'] > vol_mean*1.8
    w_delta=weighter.weight_delta(is_aggressive, close_pos, is_silent, is_churning)
    w_context=weighter.weight_context(0.0,0.0)
    M=w_struct+w_vol+w_delta+w_context
    M=max(0.25,min(2.5,M))

    entry_price=nxt['open']
    stop_loss=pl['price'] - 0.01
    tp_standard=term_price + range_size*0.27
    tp_deep=term_price + range_size*0.62
    take_profit=tp_standard

    risk=abs(entry_price-stop_loss)
    reward=abs(take_profit-entry_price)
    rr=reward/risk if risk>0 else 0
    if rr<1.5:
        take_profit=tp_deep
        reward=abs(take_profit-entry_price)
        rr=reward/risk if risk>0 else 0
        if rr<1.2:  # allow 1.2 minimum for this relaxed version to produce trades, but log
            continue

    risk_dist=abs(entry_price-stop_loss)/entry_price
    allowed_loss=balance*0.01*M
    allowed_loss=min(allowed_loss, balance*0.025)
    spot_alloc=allowed_loss/risk_dist if risk_dist>0 else 0
    spot_alloc=min(spot_alloc, balance*0.95)
    if spot_alloc<1:  # min $1 allocation
        continue
    coins=spot_alloc/entry_price

    trade_id=len(trades)+1
    current_trade={
        'id': trade_id,
        'entry_index': i+1,
        'entry_time': nxt['timestamp'],
        'entry_price': entry_price,
        'stop_loss': stop_loss,
        'take_profit': take_profit,
        'take_profit_standard': tp_standard,
        'take_profit_deep': tp_deep,
        'risk_pct': risk_dist*100,
        'rr': rr,
        'coins': coins,
        'spot_allocation_usd': spot_alloc,
        'allowed_loss_usd': allowed_loss,
        'balance_before': balance,
        'M': M,
        'w_struct': w_struct,
        'w_vol': w_vol,
        'w_delta': w_delta,
        'w_context': w_context,
        'z_vol': z_vol,
        'protected_low_price': pl['price'],
        'protected_low_idx': pl['index'],
        'protected_low_rej': pl['rejection_ratio'],
        'bos_price': bos['price'],
        'bos_last_high': bos['last_swing_price'],
        'bos_cp': bos['close_position'],
        'buy_low': buy_low,
        'buy_high': buy_high,
        'dyn_eq': dyn_eq,
        'poc': poc,
        'term': term_price,
        'origin': origin_price,
        'range': range_size,
        'fvg_low': fvg.low if hasattr(fvg,'low') else fvg.low,
        'fvg_high': fvg.high if hasattr(fvg,'high') else fvg.high,
        'fvg_ce': fvg.ce if hasattr(fvg,'ce') else (fvg.low+fvg.high)/2,
        'ob_low': ob_confluence.low if ob_confluence else 0,
        'ob_high': ob_confluence.high if ob_confluence else 0,
        'has_ob': ob_confluence is not None,
        'wick_rej': wick_rej,
        'vol_spike': vol_spike,
        'close_pos': close_pos,
    }
    logs.append(f"[{curr['timestamp']}] NEW TRADE {trade_id} Entry {entry_price:.2f} SL {stop_loss:.2f} TP {take_profit:.2f} RR {rr:.2f} M {M:.2f} Bal {balance:.2f}")

if current_trade:
    exit_price=df.iloc[-1]['close']
    ec=current_trade['entry_price']*current_trade['coins']
    ev=exit_price*current_trade['coins']
    profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
    balance+=profit
    current_trade.update({
        'exit_price':exit_price,
        'exit_time':df.iloc[-1]['timestamp'],
        'profit_usd':profit,
        'profit_pct':(exit_price/current_trade['entry_price']-1)*100,
        'result':'OPEN_CLOSED_AT_END',
        'bars_held':len(df)-1-current_trade['entry_index'],
        'exit_reason':'Closed at end',
        'balance_after':balance,
        'fee_total':ec*fee+ev*fee
    })
    trades.append(current_trade)

print(f"\n=== FINAL $100 1% Relaxed Last Month ===")
print(f"Total trades {len(trades)}")
wins=[t for t in trades if t['result']=='WIN']
losses=[t for t in trades if t['result']=='LOSS']
print(f"Wins {len(wins)} Losses {len(losses)} WinRate {len(wins)/len(trades)*100 if trades else 0:.1f}%")
total_pnl=sum(t['profit_usd'] for t in trades)
print(f"Total PnL {total_pnl:.4f}$ Final Bal {balance:.4f}$ Return {(balance/100-1)*100:.2f}%")
avg_rr=np.mean([t['rr'] for t in trades]) if trades else 0
print(f"Avg RR {avg_rr:.2f}")

if trades:
    pd.DataFrame(trades).to_csv('/home/user/super_backtest_100usd_trades_detailed.csv', index=False)
    with open('/home/user/super_backtest_logs.txt','w') as f:
        for l in logs:
            f.write(l+'\n')
    for t in trades:
        print(f"\nTrade {t['id']} {t['result']} Entry {t['entry_time']} {t['entry_price']:.2f} Exit {t.get('exit_time')} {t.get('exit_price',0):.2f} PnL {t['profit_usd']:.4f}$ ({t['profit_pct']:.2f}%) RR {t['rr']:.2f} Bal {t['balance_before']:.2f}->{t['balance_after']:.2f} Alloc {t['spot_allocation_usd']:.2f} Coins {t['coins']:.6f} SL {t['stop_loss']:.2f} TP {t['take_profit']:.2f} PL {t['protected_low_price']:.2f} rej {t['protected_low_rej']:.1f} BOS {t['bos_price']:.2f} brk {t['bos_last_high']:.2f} CP {t['bos_cp']:.2f} BuyRange {t['buy_low']:.2f}-{t['buy_high']:.2f} Eq {t['dyn_eq']:.2f} POC {t['poc']:.2f} FVG {t['fvg_low']:.2f}-{t['fvg_high']:.2f} CE {t['fvg_ce']:.2f} OB {t['ob_low']:.2f}-{t['ob_high']:.2f} hasOB {t['has_ob']} Wick {t['wick_rej']} VolSpike {t['vol_spike']} ClosePos {t['close_pos']:.2f} ZVol {t['z_vol']:.2f} M {t['M']:.2f}")
