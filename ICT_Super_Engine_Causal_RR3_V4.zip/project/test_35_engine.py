"""Engine itself tests 35 candles - no manual analysis"""
import pandas as pd
from datetime import datetime, timedelta
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.discount_detector import DiscountDetector
from engine.core.orderblock_detector import ExecutionEngine, OrderBlockDetector
from engine.super_engine import SuperEngine

Avg_Volume = 50000
ATR_fixed = 3.00
Last_High = 100.00

candles = [
    {"Index": 1, "Open": 95.00, "High": 96.00, "Low": 92.00, "Close": 93.00, "Volume": 45000},
    {"Index": 2, "Open": 93.00, "High": 94.00, "Low": 89.00, "Close": 89.50, "Volume": 52000},
    {"Index": 3, "Open": 89.50, "High": 91.00, "Low": 82.00, "Close": 88.80, "Volume": 165000},
    {"Index": 4, "Open": 88.80, "High": 92.50, "Low": 88.00, "Close": 92.10, "Volume": 65000},
    {"Index": 5, "Open": 92.10, "High": 94.00, "Low": 91.50, "Close": 93.80, "Volume": 48000},
    {"Index": 6, "Open": 93.80, "High": 101.50, "Low": 93.00, "Close": 98.20, "Volume": 110000},
    {"Index": 7, "Open": 98.20, "High": 99.50, "Low": 97.00, "Close": 99.10, "Volume": 55000},
    {"Index": 8, "Open": 99.10, "High": 106.50, "Low": 98.50, "Close": 105.80, "Volume": 220000},
    {"Index": 9, "Open": 105.80, "High": 107.00, "Low": 104.00, "Close": 106.50, "Volume": 95000},
    {"Index": 10, "Open": 106.50, "High": 109.50, "Low": 105.50, "Close": 109.00, "Volume": 85000},
    {"Index": 11, "Open": 109.00, "High": 110.00, "Low": 107.50, "Close": 108.20, "Volume": 68000},
    {"Index": 12, "Open": 108.20, "High": 108.80, "Low": 104.20, "Close": 104.80, "Volume": 54000},
    {"Index": 13, "Open": 104.80, "High": 105.50, "Low": 101.00, "Close": 101.50, "Volume": 49000},
    {"Index": 14, "Open": 101.50, "High": 102.50, "Low": 98.50, "Close": 99.00, "Volume": 42000},
    {"Index": 15, "Open": 99.00, "High": 99.80, "Low": 96.20, "Close": 96.50, "Volume": 38000},
    {"Index": 16, "Open": 96.50, "High": 97.20, "Low": 93.80, "Close": 94.20, "Volume": 35000},
    {"Index": 17, "Open": 94.20, "High": 95.00, "Low": 91.80, "Close": 92.10, "Volume": 31000},
    {"Index": 18, "Open": 92.10, "High": 93.20, "Low": 90.00, "Close": 90.50, "Volume": 29000},
    {"Index": 19, "Open": 90.50, "High": 91.50, "Low": 88.50, "Close": 89.00, "Volume": 26000},
    {"Index": 20, "Open": 89.00, "High": 89.80, "Low": 87.20, "Close": 87.50, "Volume": 33000},
    {"Index": 21, "Open": 87.50, "High": 88.20, "Low": 86.10, "Close": 86.40, "Volume": 28000},
    {"Index": 22, "Open": 86.40, "High": 87.00, "Low": 85.00, "Close": 85.50, "Volume": 31000},
    {"Index": 23, "Open": 85.50, "High": 86.20, "Low": 84.10, "Close": 84.50, "Volume": 25000},
    {"Index": 24, "Open": 84.50, "High": 85.10, "Low": 83.50, "Close": 83.80, "Volume": 22000},
    {"Index": 25, "Open": 83.80, "High": 84.50, "Low": 82.90, "Close": 83.10, "Volume": 19000},
    {"Index": 26, "Open": 83.10, "High": 83.80, "Low": 82.50, "Close": 82.80, "Volume": 24000},
    {"Index": 27, "Open": 82.80, "High": 83.20, "Low": 82.20, "Close": 82.40, "Volume": 18000},
    {"Index": 28, "Open": 82.40, "High": 88.50, "Low": 82.30, "Close": 88.00, "Volume": 185000},
    {"Index": 29, "Open": 88.00, "High": 89.50, "Low": 87.00, "Close": 89.10, "Volume": 95000},
    {"Index": 30, "Open": 89.10, "High": 90.20, "Low": 88.10, "Close": 89.80, "Volume": 82000},
    {"Index": 31, "Open": 89.80, "High": 90.00, "Low": 85.20, "Close": 85.60, "Volume": 55000},
    {"Index": 32, "Open": 85.60, "High": 86.20, "Low": 84.10, "Close": 84.50, "Volume": 42000},
    {"Index": 33, "Open": 84.50, "High": 85.00, "Low": 83.20, "Close": 83.50, "Volume": 33000},
    {"Index": 34, "Open": 83.50, "High": 84.50, "Low": 82.60, "Close": 84.20, "Volume": 125000},
    {"Index": 35, "Open": 84.20, "High": 85.50, "Low": 84.00, "Close": 85.10, "Volume": 115000},
]

df = pd.DataFrame([{
    'timestamp': datetime(2024,1,1) + timedelta(minutes=c['Index']*5),
    'open': c['Open'],
    'high': c['High'],
    'low': c['Low'],
    'close': c['Close'],
    'volume': c['Volume']
} for c in candles])

print(f"ENGINE TEST - 35 candles - Setup: Avg={Avg_Volume} ATR={ATR_fixed} LastHigh={Last_High}")
print("="*90)
print("تشغيل الانجن نفسه شمعة شمعة بدون أي تحليل يدوي - No Lookahead Protocol")
print("="*90)

# Run SuperEngine bar-by-bar
engine = SuperEngine()
result = engine.run_bar_by_bar(df)

print("\n--- ENGINE LOGS (from SuperEngine cognitive memory) ---")
for log in result['logs']:
    print(log)

print("\n--- ENGINE FINAL STATE ---")
print(f"State: {result['final_state']}")
print(f"Protected Low: {result['cognitive_memory'].get('protected_low')}")
print(f"BOS: {result['cognitive_memory'].get('bos_valid')}")
print(f"Discount: {result['cognitive_memory'].get('discount_state')}")
print(f"Trade: {result['cognitive_memory'].get('trade')}")
print(f"Trades List: {result['trades']}")

# Also run detailed cell-by-cell analysis from engine core (not manual)
print("\n" + "="*90)
print("DETAILED CELL ANALYSIS FROM ENGINE CORE (automatic):")
print("="*90)

swing_det = ProtectedSwingDetector(pivot_length=3)
swing_sensitive = ProtectedSwingDetector(pivot_length=1)
bos_det = BOSDetector()
discount_det = DiscountDetector()
fvg_ob_det = OrderBlockDetector()

# Full analysis on complete dataset (engine's view after seeing all 35, but for reporting only)
# Note: in live, engine only sees past, not future - this is just final snapshot

swings_all = swing_det.analyze(df)
print(f"\n[ENGINE CELL] ProtectedSwingDetector: {swings_all['total_swings']} swings, true_protected_lows={swings_all['true_protected_lows']}, ghost={swings_all['ghost_lows']}, trap={swings_all['trap_lows']}")

swings_sens = swing_sensitive.analyze(df)
print(f"[ENGINE CELL] Sensitive Swing (pivot1): {len(swings_sens['all_swings'])} swings")

bos_res = bos_det.analyze(df, swings_sens['all_swings'])
print(f"\n[ENGINE CELL] BOSDetector: total signals={bos_res['total']} valid_bos={bos_res['valid_bos']} swept={bos_res['liquidity_swept']} suspended={bos_res['suspended']} cognitive={bos_res['cognitive_state']}")

# Discount from first protected low to max high
if swings_all['true_protected_lows']:
    origin = swings_all['true_protected_lows'][0]
    origin_idx = origin['index']
    origin_price = origin['price']
    term_idx = df['high'].idxmax()
    term_price = df['high'].max()
    disc_sig = discount_det.analyze(df, origin_idx, origin_price, term_idx, term_price, current_idx=len(df)-1, current_price=df['close'].iloc[-1])
    print(f"\n[ENGINE CELL] DiscountDetector: Origin {origin_price} Term {term_price} POC {disc_sig.poc:.2f} Eq {disc_sig.dynamic_equilibrium:.2f} BuyRange {disc_sig.recommended_buy_range} Hyper={disc_sig.is_hyper_impulsive}")
    print(f"  Cognitive: {disc_sig.cognitive_state}")
else:
    # Fallback to low 82
    disc_sig = discount_det.analyze(df, 2, 82.0, df['high'].idxmax(), df['high'].max(), current_idx=len(df)-1, current_price=df['close'].iloc[-1])
    print(f"\n[ENGINE CELL] DiscountDetector (fallback Origin 82): Eq {disc_sig.dynamic_equilibrium:.2f} BuyRange {disc_sig.recommended_buy_range}")

# FVG and OB
fvgs = fvg_ob_det.detect_fvgs(df)
obs = fvg_ob_det.detect_bullish_obs(df, fvgs)
print(f"\n[ENGINE CELL] OrderBlockDetector: FVGs={len(fvgs)} OBs={len(obs)}")
for f in fvgs[:3]:
    print(f"  FVG {f.low:.2f}-{f.high:.2f} CE {f.ce:.2f} gap {f.high-f.low:.2f} ghost={f.is_ghost}")
for o in obs[:3]:
    print(f"  OB {o.low:.2f}-{o.high:.2f} valid={o.is_valid} mitigated={o.is_mitigated}")

# Execution
from engine.core.orderblock_detector import ExecutionEngine
exec_eng = ExecutionEngine()
exec_res = exec_eng.analyze(df, protected_low_price=82.0, termination_high_price=df['high'].max(), origin_idx=2, term_idx=df['high'].idxmax())
print(f"\n[ENGINE CELL] ExecutionEngine: total_signals={exec_res['total_signals']} valid_trades={len(exec_res['valid_trades'])} failed_traps={exec_res['failed_ob_traps']} ghost_traps={exec_res['ghost_fvg_traps']}")
for t in exec_res['valid_trades'][:2]:
    print(f"  Trade Entry {t['entry']:.2f} SL {t['sl']:.2f} TP {t['tp']:.2f} RR {t['rr']} Type {t['ob']}")

print("\n" + "="*90)
print("END OF ENGINE AUTOMATIC TEST - No manual analysis, only engine cells output")
print("="*90)
