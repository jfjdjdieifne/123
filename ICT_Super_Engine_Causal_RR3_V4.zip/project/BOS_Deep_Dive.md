# المحطة الثانية: كسر الهيكل للاستمرار BOS - بروتوكول فحص الطاقة الثلاثي

## المنظور الاستنتاجي: لماذا يحتاج المحرك لفهم المعركة؟

عند اقتراب السعر من `Last_Confirmed_Swing_High`، هذه المنطقة هي **خط الدفاع التحصيني** للبائعين.

- **فوق القمة مباشرة** توجد بركة سيولة شرائية ضخمة [ict liquidity]:
  - Short Sellers ستوباتهم = أوامر شراء اضطرارية فوق القمة
  - Breakout Traders أوامر شراء معلقة فوق القمة
- الحوت قد يدفع السعر لأعلى لثوانٍ فقط لتفعيل هذه الأوامر (يبيع عملاته للصغار)، ثم يهبط [liquidity sweep]

**وظيفة المحرك الذكي:** التمييز بين حوت **يصرف عملاته ويسرق السيولة** (فخ) وبين حوت **يمتلك نية حقيقية للاستقرار ومواصلة الصعود** (BOS حقيقي).

---

## آلية الاستخراج الذكي - بروتوكول فحص الطاقة الثلاثي (بدون ثوابت غبية)

### 1. فحص طاقة الإغلاق النسبي - Multi-Fractal Close Filter

**المعادلة:**
```
Close_Position = (Close - Low) / (High - Low)
```

**الاستنتاج:** إذا Close_Position >0.75 و Close > Last_High => المشترون حافظوا على سيطرتهم حتى الثواني الأخيرة.

**المصدر:** BOS يتطلب إغلاق جسم كامل فوق المستوى، ليس وِك [chartwhisperer: "Wicks are traps. Closes are facts"][edgeflo: "Body close beyond level"][kucoin: "full candle body close beyond previous swing"][quantum-algo: "body close beyond swing point — not just a wick"]

### 2. فحص شذوذ الحجم المتغير - Context-Aware Volume Profile

**الآلية:** إنشاء قناة انحراف معياري للحجم (Volume Bollinger Band) لآخر 50 شمعة:
```
Upper_Band = Mean(Volume last 50) + 2*Std
Volume Outlier = Current Volume > Upper_Band
```

**الاستنتاج:** حجم شاذ خارج القناة = سيولة لا يمكن أن تصدر عن تجزئة، بصمة حوت مؤسسي [chartwhisperer: "expanding volume, CVD confirmation"][algoalpha: "Volume above average confirming genuine participation"][strike: "Volume confirmation"]

- لا أستخدم رقم ثابت "حجم أكبر من 2000"، بل أحسب Bollinger ديناميكياً نسبياً للبيئة.

### 3. ميزان القوى الداخلي - Internal Delta Momentum (Effort vs Result)

**المعادلة:**
```
Effort_Vs_Result = (Close - Open) / Volume
```

**الاستنتاج:**
- جهد ضخم (حجم كبير) + نتيجة ضعيفة (جسم صغير وفشل في الإغلاق بعيداً فوق القمة) = Absorption أو Churning
- حوت يواجه جدار بيع شرس من حيتان آخرين، أو يقوم بالتصريف الخفي
- المصدر: [forexfactory: "strong positive delta for bullish break" - aggressive buyers needed][trendo: "Footprint, cumulative delta, volume profile show absorption - high volume but little price progress means smart money defending"]

---

## دليل تفكيك الخدع الفنية 2026

### الفخ الأول: الاختراق الكاذب المغطى بالإغلاق - Fake Close Trap

**السيناريو:** شمعة تخترق وتغلق فوق القمة بسنتات بجسم ممتلئ وفوليوم جيد، لكن الشمعة التالية تنهار.

**كشف المحرك - مسافة الأمان الديناميكية:**
```
Close - Last_High > ATR(14) * 0.2
```
يجب أن يبتعد الإغلاق مسافة كافية تثبت تحرر السعر من الجاذبية البيعية.

**المصدر:** [trendo: "Move size at least 1x ATR"][volumebreakout: "ATR-based breakout buffer - price must close beyond level with minimum volatility-adjusted distance"][quantum-algo: "displacement - large-bodied candles with small wicks"]

إذا أغلق قريباً جداً من خط القمة => حالة تجميد Suspended State بانتظار الشمعة التالية لتأكيد الاستقرار.

### الفخ الثاني: الجرف المتخفي - High Liquidity Sweep

**السيناريو:** تصعد الشمعة تضرب الستوبات فوق القمة وتغلق بذيل طويل جداً للأعلى وجسم صغير.

**كشف المحرك:**
```
upper_wick = High - max(Open,Close)
upper_wick_ratio = upper_wick / (High-Low)
is_sweep = upper_wick_ratio >0.6 or upper_wick > body*2
```
**الاستنتاج:** "هذا ليس تحطيماً للسقف؛ هذا الحوت استخدم الصغار كوقود"

**المصدر:** [quantum-algo: "Wick piercing = liquidity sweep, not BOS"][edgeflo: "Wick break does not count"][kucoin: "wick breach is often just a liquidity grab"]

المحرك يوسم القمة بـ [Liquidity Swept] ويستعد لهبوط حاد، يلغي فكرة الشراء.

---

## تحديث بنية الخلايا - Dynamic State Automation

```
[قمة قديمة معتمدة كمستهدف]
         │
         ▼
[تحقق الفلاتر الذكية: إغلاق قوي متفوق Close_Pos>0.75 + فوليوم شاذ خارج القناة + مسافة أمان ATR*0.2 + لا يوجد ذيل طويل + Effort vs Result قوي]
         │
         ▼
[تحديث الذاكرة الإدراكية: تفعيل وضع "البحث عن مناطق الخصم والدخول الديناميكية" SEARCH_DISCOUNT]
```

المحرك الآن لا يبحث عن صفقات، بل يحجز الأرباح ويستعد للمحطة القادمة: انتظار تراجع السعر لالتقاط الأنفاس.

---

## الاختبارات السلوكية - إثبات عملي

### REAL BOS - اختراق حقيقي:
- High 101.5, Low 98, Close 101.2, Open 98.2, Volume 5000 (5x avg)
- Close_Position = (101.2-98)/(101.5-98)=0.91 >0.75 ✅
- Volume Outlier 5x ✅
- Displacement 1.2 > ATR*0.2=0.3 ✅
- Upper wick 0.3 صغير ❌ ليس فخ
- **النتيجة: BOS_bullish VALID**

### FAKE CLOSE TRAP:
- High 100.3, Close 100.05 فوق قمة 100 بـ 0.05 فقط
- Displacement 0.05 < ATR*0.2=0.43
- **النتيجة: SUSPENDED - إغلاق مشكوك، حالة تجميد**

### LIQUIDITY SWEEP TRAP:
- High 102, Close 98.5, Body 0.5, Upper wick 3.5 ratio 0.77 >0.6
- **النتيجة: LIQUIDITY_SWEPT - الحوت ضرب الستوبات**

هذا يثبت أن الخلية تميز بين نية حقيقية وفخ.

---

## التكامل مع القاع المحمي

```
[قاع محمي حقيقي VERIFIED] -> [صعود] -> [BOS حقيقي VALID مع فلاتر ثلاثية] -> [تحديث فيبوناتشي من القاع المحمي للقمة الجديدة] -> [منطقة Discount <50% + OTE 62-79%]
```

بدون BOS حقيقي، لا نرسم Premium/Discount جديد [premium/discount must be after BOS][5]

---

## القواعد المحفورة

- لا Lookahead: كل حسابات Avg_Wick, Volume Bollinger, Effort تستخدم فقط past candles
- لا أرقام ثابتة غبية: 0.75, 0.2 ATR, 2 Std هي نسب مثبتة وليست ثوابت سعرية
- فحص الجسم vs الذيول: Wicks are traps, Closes are facts [chartwhisperer]
