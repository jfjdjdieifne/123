"""Causal ICT map audit: every fact is only known after its confirmation bar.
Spot long only. Targets are pre-existing liquidity, never fabricated Fibonacci extensions.
"""
import pandas as pd, numpy as np, json
from dataclasses import dataclass

FEE=0.001; START=100.; MAX_RISK=1.; PIV15=3; PIV4=2
path='/home/user/project/btcusdt_15m_last_month.csv'
df=pd.read_csv(path); df.timestamp=pd.to_datetime(df.timestamp); df=df.sort_values('timestamp').reset_index(drop=True)

def atr(d,n=14):
 p=d.close.shift(); tr=pd.concat([d.high-d.low,(d.high-p).abs(),(d.low-p).abs()],axis=1).max(axis=1)
 return tr.rolling(n,min_periods=1).mean()
df['atr']=atr(df)
df4=df.set_index('timestamp').resample('4h').agg(open=('open','first'),high=('high','max'),low=('low','min'),close=('close','last'),volume=('volume','sum')).dropna().reset_index()
df4['atr']=atr(df4)

def confirmed_events(d,p):
 """Pivot k becomes known strictly at k+p; never before."""
 out={}
 for known in range(2*p,len(d)):
  k=known-p; w=d.iloc[k-p:k+p+1]
  ev=[]
  if d.low.iloc[k] == w.low.min(): ev.append(('low',k,float(d.low.iloc[k])))
  if d.high.iloc[k] == w.high.max(): ev.append(('high',k,float(d.high.iloc[k])))
  if ev: out[known]=ev
 return out
p15=confirmed_events(df,PIV15); p4=confirmed_events(df4,PIV4)

def pos(c): return (c.close-c.low)/(c.high-c.low) if c.high>c.low else .5
def lower_wick(c): return min(c.open,c.close)-c.low

def liquidity_targets(known_swings, entry, i):
 """Only confirmed swing highs available before entry; clustered highs = stronger pool."""
 highs=[x for x in known_swings if x['kind']=='high' and x['known']<i and x['price']>entry]
 levels=[]
 for x in highs:
  near=[y for y in highs if abs(y['price']-x['price']) <= max(x['atr'],y['atr'])*.25]
  levels.append({'price':x['price'],'kind':'equal_high_pool' if len(near)>=2 else 'buy_side_swing_liquidity','strength':min(3,len(near)),'known':x['known']})
 # dedupe levels; nearest objectively reachable liquidity first
 return sorted(levels,key=lambda z:z['price'])

# State that is built in time only
s15=[]; s4=[]; protected=[]; waves=[]; sweeps=[]; funnel={k:0 for k in ['bars','map1_context','protected_low','bos','discount_touch','micro_trigger','objective_target','net_rr3','cash_fit','filled']}
trades=[]; rejected=[]; balance=START; active=None

for i in range(100,len(df)-1):
 c=df.iloc[i]; funnel['bars']+=1
 # Feed 4H facts whose confirmation has closed by this 15m bar
 for j, evs in p4.items():
  if df4.timestamp.iloc[j] <= c.timestamp:
   for kind,k,price in evs:
    key=(kind,k)
    if not any(z['key']==key for z in s4): s4.append({'key':key,'kind':kind,'idx':k,'known_time':df4.timestamp.iloc[j],'price':price,'atr':float(df4.atr.iloc[k])})
 # Feed 15m pivots exactly at confirmation
 for kind,k,price in p15.get(i,[]): s15.append({'kind':kind,'idx':k,'known':i,'price':price,'atr':float(df.atr.iloc[k])})
 # Manage previously filled trade; same-bar ambiguity is avoided because entry is next bar open.
 if active:
  # conservative: if both crossed in a bar, SL wins
  hit_sl=c.low<=active['sl']; hit_tp=c.high>=active['tp']
  if hit_sl or hit_tp:
   exitp=active['sl'] if hit_sl else active['tp']; reason='SL' if hit_sl else 'TP'
   pnl=active['qty']*(exitp*(1-FEE)-active['entry']*(1+FEE)); balance+=pnl
   active.update(exit_time=str(c.timestamp),exit=exitp,result=reason,pnl=round(pnl,6),balance_after=round(balance,6),bars=i-active['entry_i'])
   trades.append(active); active=None
  continue
 # HTF map: last confirmed HL and HH, not a prediction
 highs=[z for z in s4 if z['kind']=='high']; lows=[z for z in s4 if z['kind']=='low']
 bullish_htf=len(highs)>=2 and len(lows)>=2 and highs[-1]['price']>highs[-2]['price'] and lows[-1]['price']>lows[-2]['price']
 # Map2 SFP only after 4h candle has CLOSED and its previous major low was known.
 completed4=df4[df4.timestamp+pd.Timedelta(hours=4)<=c.timestamp]
 if len(completed4):
  j=completed4.index[-1]; prior=[z for z in s4 if z['kind']=='low' and z['idx']<j]
  if prior:
   major=prior[-1]; hc=df4.iloc[j]
   base=df4.volume.iloc[max(0,j-50):j]; spike=hc.volume > base.mean()+2.5*base.std()
   if hc.low<major['price'] and hc.close>major['price'] and spike and not any(x['j']==j for x in sweeps): sweeps.append({'j':j,'low':float(hc.low),'major':major['price'],'time':hc.timestamp})
 # Protected low: confirmed pivot, rejection relative to only preceding 30 candles. It remains candidate until BOS.
 for z in [x for x in s15 if x['kind']=='low' and x['known']==i]:
  k=z['idx']; prior=df.iloc[max(0,k-30):k]; avg=np.mean([lower_wick(x) for _,x in prior.iterrows()]) if len(prior) else 0
  cc=df.iloc[k]
  if avg>0 and lower_wick(cc)>=2*avg and cc.volume>=prior.volume.mean(): protected.append({**z,'invalid':False,'bos':None})
 # invalidate candidates and confirm BOS causally
 for pl in protected:
  if pl['invalid'] or pl['bos']: continue
  if c.low < pl['price']: pl['invalid']=True; continue
  highs_after=[x for x in s15 if x['kind']=='high' and pl['known']<x['known']<i]
  if highs_after and c.close>highs_after[-1]['price'] and pos(c)>=.75 and c.close-highs_after[-1]['price']>=.2*c.atr:
   pl['bos']={'i':i,'term':float(c.high),'level':highs_after[-1]['price']}; waves.append(pl); funnel['bos']+=1
 # Map1 evaluation only in HTF bullish context
 if bullish_htf: funnel['map1_context']+=1
 if not bullish_htf or not waves: continue
 pl=waves[-1]; origin=pl['price']; term=max(pl['bos']['term'],float(df.high.iloc[pl['bos']['i']:i+1].max())); rng=term-origin
 if rng<=0: continue
 funnel['protected_low']+=1
 # ICT discount zone; this is a location gate, never modifies E/SL/TP.
 lo,hi=term-.79*rng,term-.50*rng
 if not(lo<=c.low<=hi or lo<=c.close<=hi): continue
 funnel['discount_touch']+=1
 # execution narrative: bullish rejection after liquidity discount; no proxy named CVD
 base=df.volume.iloc[max(0,i-20):i]; trigger=pos(c)>=.70 and lower_wick(c)>=abs(c.close-c.open)*.5 and c.volume>=base.mean()
 if not trigger: continue
 funnel['micro_trigger']+=1
 # Orders occur at NEXT open: no current candle fill fantasy.
 entry=float(df.open.iloc[i+1]); sl=min(origin-.01, float(c.low)-.15*c.atr)
 if sl>=entry: continue
 objectives=liquidity_targets(s15,entry,i)
 if not objectives:
  rejected.append({'time':str(c.timestamp),'reason':'NO_PREEXISTING_BUYSIDE_LIQUIDITY','entry':entry}); continue
 funnel['objective_target']+=1
 loss_coin=entry*(1+FEE)-sl*(1-FEE); min_tp=(entry*(1+FEE)+3*loss_coin)/(1-FEE)
 valid=[t for t in objectives if t['price']>=min_tp]
 if not valid:
  rejected.append({'time':str(c.timestamp),'reason':'NO_ICT_TARGET_AT_NET_3R','entry':entry,'sl':sl,'min_tp':min_tp,'nearest':objectives[0]['price']}); continue
 funnel['net_rr3']+=1
 target=valid[0]; cash=balance*.95; qty=min(MAX_RISK/loss_coin,cash/(entry*(1+FEE)))
 planned_loss=qty*loss_coin
 if qty<=0: continue
 funnel['cash_fit']+=1; funnel['filled']+=1
 netrr=(target['price']*(1-FEE)-entry*(1+FEE))/loss_coin
 active={'map':'MAP1_PRO_TREND','signal_time':str(c.timestamp),'entry_i':i+1,'entry_time':str(df.timestamp.iloc[i+1]),'entry':entry,'sl':sl,'tp':target['price'],'target_type':target['kind'],'target_strength':target['strength'],'qty':qty,'planned_loss':planned_loss,'net_rr':netrr,'origin':origin,'term':term,'ote_low':lo,'ote_high':hi,'balance_before':balance}

if active:
 exitp=float(df.close.iloc[-1]); pnl=active['qty']*(exitp*(1-FEE)-active['entry']*(1+FEE)); balance+=pnl; active.update(exit_time=str(df.timestamp.iloc[-1]),exit=exitp,result='EOD',pnl=pnl,balance_after=balance,bars=len(df)-1-active['entry_i']); trades.append(active)
report={'period':[str(df.timestamp.iloc[0]),str(df.timestamp.iloc[-1])],'candles_15m':len(df),'candles_4h':len(df4),'starting_balance':START,'ending_balance':round(balance,6),'funnel':funnel,'confirmed_swings_15m':len(s15),'confirmed_swings_4h':len(s4),'protected_low_candidates':len(protected),'causal_bos':len(waves),'closed_4h_sweeps':len(sweeps),'trades':trades,'rejected_rr_or_target':rejected[:100],'rules':'Strict causal pivots; next-bar-open entry; targets are pre-existing confirmed buy-side swing/equal-high liquidity; net fee-aware RR >=3; max planned loss $1; conservative SL-first OHLC exits.'}
open('/home/user/project/causal_narrative_rr3_results.json','w').write(json.dumps(report,indent=2,default=str))
print(json.dumps(report,indent=2,default=str))
