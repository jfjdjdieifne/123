# المحطة الثانية من الخريطة الثانية: CHoCH الفريم الصغير - الثورة الهيكلية

## المعنى السلوكي: لماذا ينتظر المحرك هذا الكسر؟

في عمق القاع السعري، تظل السيكولوجيا العامة هابطة ومذعورة. الصغار مستمرون في البيع عند كل ارتداد بسيط.

- **كتل الأوامر الحميمة Bearish Order Blocks:** البائعون المؤسسيون تركوا خلفهم قمم فرعية هابطة متتالية أثناء الانهيار
- **CHoCH الحقيقي:** هو اختراق صعودي لأحدث وآخر قمة فرعية هابطة **تسببت مباشرة** في تسجيل القاع السعري الأخير قبل حدوث الجرف HTF Sweep
- **السبب الميكانيكي الحركي:** اختراق هذه القمة بالذات يعني رقمياً استهلاك واستنزاف كافة أوامر البيع المعلقة للمؤسسات الهابطة، وبدء ضخ سيولة شرائية عدوانية Aggressive Buying قادرة على قلب اتجاه الفريم الصغير تماماً

**المصدر:** CHOCH = break of most recent lower high confirming long-term reversal [ICT abbreviations], Break of last lower high followed by higher highs and lows after CHOCH [tradingfinder], Change of Character is first structural break that signals trend may be reversing [3commas]

---

## آلية الاستخراج الرياضي الديناميكي OHLCV بدون أرقام ثابتة

بمجرد انتقال المحرك إلى فريم 15 دقيقة، يبدأ مصفوفة تحقق استنتاجية صارمة تعتمد على النسبية الهيكلية Structural Relativity

### 1. تحديد القمة الفاصلة الحتمية Invalidation High

المحرك لا ينظر لأي قمة عشوائية. يقوم بمسح الشموع تنازلياً من لحظة حدوث الجرف ويحدد السعر الدقيق لأعلى نقطة في الشمعة الهابطة التي سبقت موجة الانهيار الأخيرة مباشرة. يخزنها تحت اسم `LTF_Recent_Lower_High`

- هذا هو السقف الفرعي الذي يجب كسره
- ليس أي قمة داخلية صغيرة

### 2. فحص طاقة الاختراق الهيكلي CHoCH Validation Protocol

تأتي شمعة صاعدة عنيفة [Y] وتخترق مستوى LTF_Recent_Lower_High. يعلن المحرك نجاح CHoCH رقمياً إذا تحققت:

**شرط استقرار كامل الجسد Body Displacement Rule:**
```
Close[Y] > LTF_Recent_Lower_High
```
**المصدر الصارم ICT:** إذا اخترق الذيل High فقط وعاد السعر للإغلاق أسفلها، يلغى CHoCH فوراً. يجب أن يستقر جسم الشمعة بالكامل فوق السقف الفرعي.

**المصدر:** Require full candle body to close beyond protected swing point, not just wick, wicks are usually stop hunts [3commas][tradingfinder: always consider break valid only if it occurs with candle close, wicks merely as signs of liquidity][innercircletrader BOS vs CHOCH: body close confirmation]

**معادلة الزخم النسبية المتغيرة Momentum Slope:**
```
bull_slope = LinearRegression(close of bullish candles from target to Y)
bear_slope = LinearRegression(close of bearish collapsing before target)
momentum_ratio = |bull_slope| / |bear_slope|
must be >=2.0
```
يحسب زاوية صعود الشموع المخترقة مقارنة بزاوية هبوط الشموع السابقة. يجب أن يكون معدل التغير للخضراء أسرع بمرتين على الأقل من الحمراء المنهارة. هذا يثبت رقمياً حدوث اندفاع مالي طارئ وسريع Displacement.

**المصدر:** Displacement: fast, strong breaking candle, ideally volume spike, often leaving FVG [3commas][algostorm: Displacement validates importance, wide-range candles][innercircletrader MSS: displacement candle close]

---

## كتالوج فخاخ الفريم الصغير في القيعان

بما أننا نتداول على فريمات صغيرة 15M/5M ضد اتجاه عام هابط، فإن خوارزميات التداول المؤتمتة العكسية تصنع فخاخ تذبذب ميكانيكية شرسة

### الفخ الأول: الكسر الداخلي العشوائي Minor Internal Structure Trap

**السيناريو:** السعر يرتد صعوداً ويكسر قمة صغيرة جداً تشكلت بين شمعتين هابطتين داخل الموجة الانهيارية. تظن البوتات الكلاسيكية الغبية أن هذا CHoCH فتشتري، ثم يستأنف الانهيار بعنف.

**كيف يفلت المحرك؟** فلتر حماية يسمى فحص الأهمية الهيكلية Structural Significance Filter

```
Distance = Target_High - Sub_Low (المسافة بين القاع الفرعي والقمة المستهدفة)
Must be > ATR(14) * 1.5
```

إذا كانت أصغر، يصنفها كـ Internal Noise ضوضاء هيكلية داخلية ويتجاهلها تماماً؛ لأن الكسر الحقيقي يجب أن يكون لقمة رئيسية واضحة ومؤثرة في الدورة الصغرى للسعر.

```
القمة الرئيسية المستهدفة (LTF_Recent_Lower_High) ──────> ━━━━━━━━━━━━━ [BOS/CHoCH Line]
┃ ┃
فخ القمة الداخلية الصغيرة ───> ━━━━━━ (Noise) ┃ ┃
┃ ┃ ┃ ┃
القاع الرئيسي بعد الجرف────────────────────────────────────┛ ┗━━━━ [True CHoCH Close]
```

**المصدر:**
- Misinterpreting Internal Structure: break of minor internal is NOT CHoCH, only major swing points count [fxnx: The biggest mistake is confusing minor internal structure with major swing structure]
- Adaptive Swing Filter: newly confirmed pivot only replaces stored swing if distance from last opposite pivot exceeds ATR-relative threshold [in.tradingview choch scripts: displacement filter requires breaking close to clear swing level by minimum ATR multiple]
- Marking every minor lower-timeframe break as change of character produces reversal signals several times an hour, nearly all false [chartinglens]

### الفخ الثاني: الاختراق المستنزف بدون سيولة Illiquid Character Change

**السيناريو:** تغلق شمعة 15 دقيقة فوق القمة الفاصلة بالفعل وبجسم ممتلئ، لكن حجم التداول Volume[Y] ميت وصغير، ولا يوجد أي ارتفاع في دلتا السبوت التراكمية Spot CVD

**كيف يفلت؟** يحلل ميزان الجهد والنتيجة ديناميكياً: "السعر ارتفع فوق القمة فقط لأن البائعين انسحبوا مؤقتاً لتعبئة أوامر أعلى، وليس لأن الحوت ضخ سيولة شرائية جديدة لتغيير الاتجاه". يرفض CHoCH ويعيد تصنيفه كـ Exhaustion Break كسر إجهادي وينتظر دون تنفيذ أي عملية شراء.

**المصدر:**
- CHoCH confirmation: volume spike, ideally leaving FVG [3commas]
- CHoCH early warning not confirmation, always wait for displacement [trenddaytrader]
- LTF CHoCH is entry trigger only when inside HTF-aligned zone [quantum-algo]
- No-sweep CHoCH is lower quality, volume context [arongroups: Distinguishing major from minor CHoCH is crucial, as CHoCH at key areas with volume confirmation may signal reversal, while those in secondary zones usually indicate short-term pullbacks]

---

## بروتوكول تأصيل الذاكرة وانتقال الحالة

بمجرد إغلاق شمعة فريم 15 دقيقة مستوفية شروط CHoCH الصاعدة بنجاح ميكانيكي كامل (إغلاق جسم ممتلئ + فوليوم شاذ خارج الانحراف المعياري + زاوية صعود حادة)، يقوم المحرك فوراً بتحديث حالته الهيكلية:

```json
{
  "HTF_State": "Liquidity_Swept_At_4H_Low",
  "LTF_State": "CHoCH_Confirmed_Bullish",
  "Verified_LTF_Origin_Low": 82.05,
  "CHoCH_Breakout_Price": 88.50,
  "Adaptive_Engine_Status": "PREPARE_FOR_DISCOUNT_ARRAY_AND_OB_HUNTING"
}
```

---

## الاختبار السلوكي - Engine Output

**Valid CHoCH:**
- Index15 Close91.5 > Target 88.5
- Close Position >0.75, Volume Spike 150k vs avg 30k, Distance ATR ratio >1.5, Momentum Ratio 2.3x >=2
- **VALID CHoCH: اختراق القمة الفاصلة الحتمية التي تسببت مباشرة في القاع الأخير قبل الجرف**

**Internal Noise:**
- Qmmة صغيرة بين شمعتين هابطتين Distance 0.8 ATR <1.5 => **INTERNAL_NOISE - تجاهل**

**Wick Only:**
- High > Target لكن Close < Target => **WICK_ONLY - يلغى CHoCH فوراً**

**Exhaustion Break:**
- Close > Target بجسم ممتلئ لكن Volume ميت وصغير ولا يوجد ارتفاع Spot CVD => **EXHAUSTION_BREAK - كسر إجهادي**

**State Transition:**
- CHoCH Confirmed => PREPARE_FOR_DISCOUNT_ARRAY_AND_OB_HUNTING - الانتقال لمرحلة قنص الدخول في منطقة الخصم الفرعية (مثل الخريطة الأولى لكن على فريم صغير)

---

## التكامل مع HTF Sweep

```
[4H: رصد انهيار حاد نحو القاع التاريخي] -> [4H: SFP Valid Volume 2.5 StdDev + CVD Bullish Divergence] -> [Memory: Liquidity_Swept_At_4H_Low] -> [15M: Scan descending for LTF_Recent_Lower_High] -> [15M: CHoCH Valid Body Displacement + Momentum 2x + Distance>1.5 ATR + Volume Spike + CVD Rising] -> [Memory: CHoCH_Confirmed_Bullish 82.05->88.50] -> [15M Discount Array + OB Hunting]
```

هذا هو الفرق بين بوت غبي يكسر أي قمة داخلية وبين محرك ينتظر القمة الفاصلة الحتمية التي استنزفت أوامر البيع المؤسسية.
