"""
Backtest last month BTCUSDT 15m - No Lookahead, No Cheating
Bar-by-Bar: engine only sees past candles up to current bar, entry on next bar open, exit checked bar-by-bar
Detailed per trade: history, time, entry, exit, SL, TP, profit, session, timeframe, why
"""
import pandas as pd
import numpy as np
from datetime import datetime
from engine.final_integrated_engine import FinalIntegratedEngine

# Load data
df_15m = pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df_15m['timestamp'] = pd.to_datetime(df_15m['timestamp'])
df_15m = df_15m.sort_values('timestamp').reset_index(drop=True)

# Resample to 4H for HTF context
df_4h = df_15m.set_index('timestamp').resample('4h').agg({
    'open':'first',
    'high':'max',
    'low':'min',
    'close':'last',
    'volume':'sum'
}).dropna().reset_index()

df_daily = df_15m.set_index('timestamp').resample('1D').agg({
    'open':'first',
    'high':'max',
    'low':'min',
    'close':'last',
    'volume':'sum'
}).dropna().reset_index()

print(f"15M candles: {len(df_15m)} from {df_15m['timestamp'].iloc[0]} to {df_15m['timestamp'].iloc[-1]}")
print(f"4H candles: {len(df_4h)}")
print(f"Daily candles: {len(df_daily)}")

engine = FinalIntegratedEngine(base_risk_pct=1.0)

trades_detailed = []
logs_all = []
current_trade = None
trade_id = 0

# For tracking: we will simulate engine state bar-by-bar
# We need to maintain past data windows

for i in range(50, len(df_15m)-1):  # start after 50 candles for enough history
    past_15m = df_15m.iloc[:i+1].copy()
    current_candle = df_15m.iloc[i]
    next_candle = df_15m.iloc[i+1]
    
    # For 4H and Daily, find corresponding past up to current timestamp
    current_time = current_candle['timestamp']
    past_4h = df_4h[df_4h['timestamp'] <= current_time].copy()
    past_daily = df_daily[df_daily['timestamp'] <= current_time].copy()
    
    if len(past_4h) < 10 or len(past_daily) < 3:
        continue
    
    # Check if we are in trade - manage live trade
    if current_trade is not None:
        # Check if SL or TP hit on current candle (no lookahead - only current candle high/low)
        # SL is below entry, TP above
        # For long spot buy: SL is below, TP is above (termination high or bearish FVG)
        low = current_candle['low']
        high = current_candle['high']
        
        # Check SL first (worst case)
        if low <= current_trade['stop_loss']:
            # Stop hit - exit at stop price
            exit_price = current_trade['stop_loss']
            exit_time = current_candle['timestamp']
            profit_usd = (exit_price - current_trade['entry_price']) * current_trade['coins']
            profit_pct = (exit_price / current_trade['entry_price'] - 1) * 100
            
            current_trade['exit_price'] = exit_price
            current_trade['exit_time'] = exit_time
            current_trade['exit_reason'] = 'STOP_LOSS_HIT - Protected Low broken, whale surrendered, exit small loss 1-1.5% lifeline to prevent freezing'
            current_trade['profit_usd'] = profit_usd
            current_trade['profit_pct'] = profit_pct
            current_trade['result'] = 'LOSS'
            current_trade['bars_held'] = i - current_trade['entry_index']
            
            trades_detailed.append(current_trade)
            logs_all.append(f"[{current_time}] Trade {current_trade['id']} EXIT SL Hit: Entry {current_trade['entry_price']:.2f} SL {current_trade['stop_loss']:.2f} Exit {exit_price:.2f} Loss {profit_usd:.2f}$ ({profit_pct:.2f}%)")
            
            current_trade = None
            continue
        
        # Check TP
        if high >= current_trade['take_profit']:
            exit_price = current_trade['take_profit']
            exit_time = current_candle['timestamp']
            profit_usd = (exit_price - current_trade['entry_price']) * current_trade['coins']
            profit_pct = (exit_price / current_trade['entry_price'] - 1) * 100
            
            current_trade['exit_price'] = exit_price
            current_trade['exit_time'] = exit_time
            current_trade['exit_reason'] = 'TAKE_PROFIT_HIT - Termination Point / Bearish HTF FVG magnet reached, exit and secure profits'
            current_trade['profit_usd'] = profit_usd
            current_trade['profit_pct'] = profit_pct
            current_trade['result'] = 'WIN'
            current_trade['bars_held'] = i - current_trade['entry_index']
            
            trades_detailed.append(current_trade)
            logs_all.append(f"[{current_time}] Trade {current_trade['id']} EXIT TP Hit: Entry {current_trade['entry_price']:.2f} TP {current_trade['take_profit']:.2f} Exit {exit_price:.2f} Profit {profit_usd:.2f}$ ({profit_pct:.2f}%)")
            
            current_trade = None
            continue
        
        # If in trade, continue to next bar without new entry
        continue
    
    # Not in trade - look for new entry using engine (only past data)
    # We call engine's internal detectors but only on past data
    # For simplicity, use FinalIntegratedEngine's logic but we already have result from previous run? 
    # Instead, we will manually run the engine's run_bar_by_bar for this single bar? 
    # To avoid lookahead, we run engine on past_15m only up to i
    
    # We will use a simplified version: check if engine would trigger at this bar
    # For detailed, we call engine's detectors
    
    from engine.core.swing_detector import ProtectedSwingDetector
    from engine.core.bos_detector import BOSDetector
    from engine.core.discount_detector import DiscountDetector
    from engine.core.orderblock_detector import OrderBlockDetector
    
    # Station 1: Protected Low (using past_15m)
    swing_det = ProtectedSwingDetector(pivot_length=3)
    swings_res = swing_det.analyze(past_15m)
    true_lows = swings_res['true_protected_lows']
    
    if not true_lows:
        continue
    
    # Get most recent true protected low
    protected_low = true_lows[-1]
    # Must be recent (within last 100 bars) and not too old
    if i - protected_low['index'] > 100:
        continue
    
    # Station 2: BOS
    swing_sens = ProtectedSwingDetector(pivot_length=1)
    swings_sens = swing_sens.analyze(past_15m)
    bos_det = BOSDetector()
    bos_res = bos_det.analyze(past_15m, swings_sens['all_swings'])
    
    if not bos_res['valid_bos']:
        continue
    
    bos_valid = bos_res['valid_bos'][-1]
    # BOS must be after protected low
    if bos_valid['index'] <= protected_low['index']:
        continue
    
    # Must be recent (within last 50 bars after protected low)
    if i - bos_valid['index'] > 50:
        continue
    
    # Station 3: Discount
    origin_idx = protected_low['index']
    origin_price = protected_low['price']
    term_idx = bos_valid['index']
    term_price = past_15m['high'].iloc[origin_idx:term_idx+1].max() if origin_idx < term_idx else bos_valid['last_swing_price']
    
    discount_det = DiscountDetector()
    try:
        disc_sig = discount_det.analyze(past_15m, origin_idx, origin_price, term_idx, term_price, current_idx=i, current_price=current_candle['close'])
    except:
        continue
    
    # Must be in discount and not bleeding/induced trap
    if 'Price_In_Premium' in disc_sig.cognitive_state['Current_State']:
        continue
    if disc_sig.is_bleeding_trap or disc_sig.is_induced_trap:
        continue
    
    # Check if current price in buy range
    buy_low, buy_high = disc_sig.recommended_buy_range
    if not (buy_low <= current_candle['close'] <= buy_high or buy_low <= current_candle['low'] <= buy_high):
        # Also allow if close below buy_high and above buy_low? Already checked
        # If price not in buy range, skip
        if not (buy_low <= current_candle['close'] <= buy_high):
            # Allow if price is in discount but near buy range (within 0.5%)
            if abs(current_candle['close'] - buy_high) / buy_high > 0.01:
                continue
    
    # Station 4: OB/FVG Execution
    ob_det = OrderBlockDetector()
    fvgs = ob_det.detect_fvgs(past_15m)
    obs = ob_det.detect_bullish_obs(past_15m, fvgs)
    
    if not obs:
        continue
    
    # Find OB/FVG confluence near current price and in discount and buy range
    valid_exec = None
    for ob in obs:
        if ob.is_mitigated:
            continue
        # OB must be within discount buy range
        if not (buy_low <= ob.low <= buy_high or buy_low <= ob.high <= buy_high):
            # Allow if OB overlaps buy range
            if not (ob.low <= buy_high and ob.high >= buy_low):
                continue
        
        for fvg in fvgs:
            if fvg.is_ghost:
                continue
            # Check confluence: FVG near OB
            if abs(fvg.low - ob.high) < (ob.high - ob.low)*2:
                # Check execution trigger at current candle
                # Micro Wick Rejection: lower wick > body and close in upper half
                hl_range = current_candle['high'] - current_candle['low']
                if hl_range == 0:
                    continue
                lower_wick = min(current_candle['open'], current_candle['close']) - current_candle['low']
                body = abs(current_candle['close'] - current_candle['open'])
                close_pos = (current_candle['close'] - current_candle['low']) / hl_range
                
                wick_rejection = lower_wick > body*0.8 and close_pos > 0.6
                
                # CVD flip simplified: check last 5 candles bearish then bullish?
                # For this backtest, we approximate CVD flip via close > open and volume spike
                # Volume spike
                vol_mean = past_15m['volume'].iloc[max(0,i-20):i].mean()
                is_vol_spike = current_candle['volume'] > vol_mean*1.5
                
                # Effort matches result: not churning (body not tiny vs volume huge)
                is_churning = body < hl_range*0.2 and current_candle['volume'] > vol_mean*2
                
                if wick_rejection and is_vol_spike and not is_churning:
                    valid_exec = (ob, fvg)
                    break
        if valid_exec:
            break
    
    if not valid_exec:
        continue
    
    # All stations passed - Generate trade signal
    # Entry on next bar open (no lookahead - we use next_candle open)
    entry_price = next_candle['open']
    stop_loss = protected_low['price'] - 0.01  # 1 cent below protected low
    # Take profit = termination point (new high)
    take_profit = term_price
    
    # Risk calculation
    risk_pct = abs(entry_price - stop_loss) / entry_price * 100
    # Position sizing: base risk 1% * confluence multiplier (assume 1.5x for Map1)
    # For this backtest, assume total balance 10000, base 1% =100$, M=1.5 => allowed loss 150$
    # Spot allocation = allowed loss / risk_distance
    total_balance = 10000
    base_risk = 1.0
    M = 1.5
    allowed_loss = total_balance * (base_risk/100 * M)
    risk_distance = abs(entry_price - stop_loss) / entry_price
    spot_allocation_usd = allowed_loss / risk_distance if risk_distance>0 else 0
    coins = spot_allocation_usd / entry_price if entry_price>0 else 0
    
    trade_id += 1
    current_trade = {
        'id': trade_id,
        'entry_index': i+1,
        'entry_time': next_candle['timestamp'] if 'timestamp' in next_candle else df_15m['timestamp'].iloc[i+1],
        'entry_price': entry_price,
        'stop_loss': stop_loss,
        'take_profit': take_profit,
        'risk_pct': risk_pct,
        'coins': coins,
        'spot_allocation_usd': spot_allocation_usd,
        'allowed_loss_usd': allowed_loss,
        'confluence_multiplier': M,
        'protected_low': protected_low,
        'bos': bos_valid,
        'discount_eq': disc_sig.dynamic_equilibrium,
        'buy_range': disc_sig.recommended_buy_range,
        'ob': valid_exec[0].to_dict() if hasattr(valid_exec[0], 'to_dict') else valid_exec[0],
        'fvg': valid_exec[1].to_dict() if hasattr(valid_exec[1], 'to_dict') else valid_exec[1],
        'reason': f"Station1 Protected Low {protected_low['price']:.2f} VERIFIED + Station2 BOS Valid {bos_valid['price']:.2f} breaking {bos_valid['last_swing_price']:.2f} ClosePos {bos_valid['close_position']:.2f}>0.75 Vol Outlier + Station3 Discount Eq {disc_sig.dynamic_equilibrium:.2f} BuyRange {disc_sig.recommended_buy_range} Price in Discount + Station4 OB {valid_exec[0].low:.2f}-{valid_exec[0].high:.2f} + FVG {valid_exec[1].low:.2f}-{valid_exec[1].high:.2f} CE {valid_exec[1].ce:.2f} + Wick Rejection + Vol Spike + No Churning",
        'session': 'NY' if current_candle['timestamp'].hour in range(13,22) else 'London' if current_candle['timestamp'].hour in range(7,13) else 'Asian',
        'timeframe': '15M',
        'htf_context': f"Daily Bias BULLISH_REVERSION (assumed) + 4H SSL {disc_sig.discount_zone[0]:.2f} BSL {disc_sig.premium_zone[1]:.2f}"
    }
    
    logs_all.append(f"[{current_candle['timestamp']}] NEW TRADE {trade_id} SIGNAL: Entry next bar {entry_price:.2f} SL {stop_loss:.2f} ({risk_pct:.2f}%) TP {take_profit:.2f} OB {current_trade['ob']['low']:.2f}-{current_trade['ob']['high']:.2f} FVG CE {current_trade['fvg']['ce']:.2f} - {current_trade['reason'][:200]}")

# Final summary
print(f"\nTotal trades generated: {len(trades_detailed)}")
total_pnl = sum(t['profit_usd'] for t in trades_detailed)
total_wins = len([t for t in trades_detailed if t['result']=='WIN'])
total_losses = len([t for t in trades_detailed if t['result']=='LOSS'])
win_rate = total_wins / len(trades_detailed) *100 if trades_detailed else 0

print(f"Wins: {total_wins} Losses: {total_losses} WinRate: {win_rate:.1f}% PnL: {total_pnl:.2f}$")

# Save detailed trades to CSV
if trades_detailed:
    df_trades = pd.DataFrame(trades_detailed)
    df_trades.to_csv('/home/user/btcusdt_trades_last_month_detailed.csv', index=False)
    print("Saved trades to btcusdt_trades_last_month_detailed.csv")
    
    # Also save logs
    with open('/home/user/btcusdt_backtest_logs.txt','w') as f:
        for log in logs_all:
            f.write(log+'\n')
    print("Saved logs to btcusdt_backtest_logs.txt")

# Print last few trades detailed
for t in trades_detailed[-5:]:
    print(f"\n--- Trade {t['id']} ---")
    print(f"Entry Time: {t['entry_time']} Price: {t['entry_price']:.2f} Session: {t['session']} TF: {t['timeframe']}")
    print(f"Stop: {t['stop_loss']:.2f} ({t['risk_pct']:.2f}%) TP: {t['take_profit']:.2f}")
    print(f"Exit Time: {t.get('exit_time')} Price: {t.get('exit_price')} Reason: {t.get('exit_reason')}")
    print(f"Profit: {t.get('profit_usd',0):.2f}$ ({t.get('profit_pct',0):.2f}%) Result: {t.get('result')}")
    print(f"Coins: {t['coins']:.4f} Allocation: ${t['spot_allocation_usd']:.2f} Allowed Loss: ${t['allowed_loss_usd']:.2f} M: {t['confluence_multiplier']}")
    print(f"Protected Low: {t['protected_low']['price']:.2f} idx {t['protected_low']['index']} conf {t['protected_low']['confirmation_level']}")
    print(f"BOS: {t['bos']['price']:.2f} breaking {t['bos']['last_swing_price']:.2f} ClosePos {t['bos']['close_position']:.2f}")
    print(f"Discount Eq: {t['discount_eq']:.2f} BuyRange: {t['buy_range']}")
    print(f"OB: {t['ob']['low']:.2f}-{t['ob']['high']:.2f} FVG: {t['fvg']['low']:.2f}-{t['fvg']['high']:.2f} CE: {t['fvg']['ce']:.2f}")
    print(f"Reason: {t['reason']}")
