import pandas as pd
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.discount_detector import DiscountDetector
from engine.core.orderblock_detector import OrderBlockDetector

df_15m = pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df_15m['timestamp'] = pd.to_datetime(df_15m['timestamp'])
df_4h = df_15m.set_index('timestamp').resample('4h').agg({'open':'first','high':'max','low':'min','close':'last','volume':'sum'}).dropna().reset_index()
print(f"4H candles: {len(df_4h)}")

trades=[]
logs=[]
current_trade=None
trade_id=0

for i in range(20, len(df_4h)-1):
    past = df_4h.iloc[:i+1]
    curr = df_4h.iloc[i]
    nxt = df_4h.iloc[i+1]
    
    if current_trade:
        if curr['low'] <= current_trade['stop_loss']:
            exit_price = current_trade['stop_loss']
            profit_usd = (exit_price - current_trade['entry_price']) * current_trade['coins']
            profit_pct = (exit_price/current_trade['entry_price']-1)*100
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit_usd,'profit_pct':profit_pct,'result':'LOSS','exit_reason':'SL Hit'})
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] EXIT SL Trade {current_trade['id']} Entry {current_trade['entry_price']:.2f} SL {exit_price:.2f} Loss {profit_usd:.2f}$")
            current_trade=None
            continue
        if curr['high'] >= current_trade['take_profit']:
            exit_price = current_trade['take_profit']
            profit_usd = (exit_price - current_trade['entry_price']) * current_trade['coins']
            profit_pct = (exit_price/current_trade['entry_price']-1)*100
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit_usd,'profit_pct':profit_pct,'result':'WIN','exit_reason':'TP Hit'})
            trades.append(current_trade)
            logs.append(f"[{curr['timestamp']}] EXIT TP Trade {current_trade['id']} Entry {current_trade['entry_price']:.2f} TP {exit_price:.2f} Profit {profit_usd:.2f}$")
            current_trade=None
            continue
        continue
    
    # Look for entry
    swing_det = ProtectedSwingDetector(pivot_length=2)
    swings = swing_det.analyze(past)
    true_lows = swings['true_protected_lows']
    if not true_lows:
        continue
    protected_low = true_lows[-1]
    if i - protected_low['index'] > 30:
        continue
    
    swing_sens = ProtectedSwingDetector(pivot_length=1)
    swings_sens = swing_sens.analyze(past)
    bos_det = BOSDetector()
    bos_res = bos_det.analyze(past, swings_sens['all_swings'])
    if not bos_res['valid_bos']:
        continue
    bos_valid = bos_res['valid_bos'][-1]
    if bos_valid['index'] <= protected_low['index']:
        continue
    
    origin_idx = protected_low['index']
    origin_price = protected_low['price']
    term_price = past['high'].iloc[origin_idx:].max()
    
    discount_det = DiscountDetector()
    try:
        disc_sig = discount_det.analyze(past, origin_idx, origin_price, bos_valid['index'], term_price, current_idx=i, current_price=curr['close'])
    except:
        continue
    
    if 'Premium' in disc_sig.cognitive_state['Current_State']:
        continue
    
    buy_low, buy_high = disc_sig.recommended_buy_range
    if not (buy_low <= curr['close'] <= buy_high):
        continue
    
    ob_det = OrderBlockDetector()
    fvgs = ob_det.detect_fvgs(past)
    obs = ob_det.detect_bullish_obs(past, fvgs)
    
    valid=False
    ob_fvg=None
    for ob in obs:
        if ob.is_mitigated:
            continue
        for fvg in fvgs:
            if fvg.is_ghost:
                continue
            if abs(fvg.low - ob.high) < (ob.high-ob.low)*2:
                hl_range = curr['high']-curr['low']
                if hl_range==0:
                    continue
                lower_wick = min(curr['open'], curr['close'])-curr['low']
                body = abs(curr['close']-curr['open'])
                close_pos = (curr['close']-curr['low'])/hl_range
                wick_rej = lower_wick > body*0.8 and close_pos>0.6
                vol_mean = past['volume'].iloc[max(0,i-20):i].mean()
                vol_spike = curr['volume'] > vol_mean*1.2
                if wick_rej and vol_spike:
                    valid=True
                    ob_fvg=(ob,fvg)
                    break
        if valid:
            break
    
    if not valid:
        continue
    
    entry_price = nxt['open']
    stop_loss = protected_low['price'] - 0.01
    take_profit = term_price
    risk_pct = abs(entry_price-stop_loss)/entry_price*100
    total_balance=10000
    M=1.5
    allowed_loss= total_balance*0.01*M
    risk_dist= abs(entry_price-stop_loss)/entry_price
    spot_alloc= allowed_loss/risk_dist if risk_dist>0 else 0
    coins= spot_alloc/entry_price
    
    trade_id+=1
    current_trade={
        'id': trade_id,
        'entry_index': i+1,
        'entry_time': nxt['timestamp'],
        'entry_price': entry_price,
        'stop_loss': stop_loss,
        'take_profit': take_profit,
        'risk_pct': risk_pct,
        'coins': coins,
        'spot_allocation_usd': spot_alloc,
        'protected_low': protected_low,
        'bos': bos_valid,
        'discount_eq': disc_sig.dynamic_equilibrium,
        'buy_range': disc_sig.recommended_buy_range,
        'ob': ob_fvg[0],
        'fvg': ob_fvg[1],
        'reason': f"Protected {protected_low['price']:.2f} + BOS {bos_valid['price']:.2f} Eq {disc_sig.dynamic_equilibrium:.2f} OB {ob_fvg[0].low:.2f}-{ob_fvg[0].high:.2f} FVG CE {ob_fvg[1].ce:.2f}"
    }
    logs.append(f"[{curr['timestamp']}] NEW TRADE {trade_id} Entry next {entry_price:.2f} SL {stop_loss:.2f} TP {take_profit:.2f} OB {ob_fvg[0].low:.2f}-{ob_fvg[0].high:.2f} FVG CE {ob_fvg[1].ce:.2f}")

print(f"\nTotal trades: {len(trades)}")
for t in trades:
    print(f"Trade {t['id']} Entry {t['entry_time']} {t['entry_price']:.2f} SL {t['stop_loss']:.2f} TP {t['take_profit']:.2f} Exit {t.get('exit_time')} {t.get('exit_price')} {t.get('result')} {t.get('profit_usd'):.2f}$")
for log in logs:
    print(log)

if trades:
    import pandas as pd
    pd.DataFrame(trades).to_csv('/home/user/btcusdt_4h_trades.csv', index=False)
