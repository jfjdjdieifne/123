"""
FULL-CHEST CAPITAL DEPLOYMENT - Halal 100% Spot - No Margin
Per user diagnosis: Code suffers from fixed digital loss phobia, enters with $15 only leaving 85% idle
Solution: If muscle power Pass strict safety threshold, enter with FULL 100% cash (100$) without looking at tight SL

Math:
- Old: Size = Risk_USD / Risk_Distance => if SL 0.20% => 1/0.002=500$ but spot only 100$, filters shrink to 15$ => 15cents profit = financial paralysis
- New: If muscle power > threshold (displacement violent + CVD cumulative whale), Full Allocation 100%
  Loss = 100$ * risk_dist => if risk 0.40% => loss $0.40 (<$1 cap, acceptable)
  Profit = 100$ * reward_dist => if RR 3.02 => profit $1.20
  If risk 1.5% RR 4:1 => loss $1.50 profit $6

No fixed numbers? risk_min derived from $1/Balance =1%, reward_min = $3/Balance=3% but we allow loss up to 1.5$ if RR high, still halal spot
"""
import pandas as pd, numpy as np
from sklearn.linear_model import LinearRegression

def calc_atr(df,p=14):
    h=df['high']; l=df['low']; c=df['close']
    tr1=h-l; tr2=(h-c.shift()).abs(); tr3=(l-c.shift()).abs()
    tr=pd.concat([tr1,tr2,tr3],axis=1).max(axis=1)
    return tr.rolling(p).mean().fillna(tr.expanding().mean()).fillna(0.5)

def find_swings(df,pivot=3):
    lows=[]; highs=[]
    for i in range(pivot,len(df)-pivot):
        if df['low'].iloc[i]==df['low'].iloc[i-pivot:i+pivot+1].min():
            lows.append({'index':i,'price':df['low'].iloc[i]})
        if df['high'].iloc[i]==df['high'].iloc[i-pivot:i+pivot+1].max():
            highs.append({'index':i,'price':df['high'].iloc[i]})
    return lows,highs

def detect_fvgs(df,atr):
    fvgs=[]
    for i in range(1,len(df)-1):
        c1=df.iloc[i-1]; c2=df.iloc[i]; c3=df.iloc[i+1]
        if c1['high'] < c3['low'] and c2['close']>c2['open']:
            body=abs(c2['close']-c2['open'])
            if body>atr.iloc[i]*0.8:
                gap=c3['low']-c1['high']
                if gap/df['close'].iloc[i]*100>=0.03:
                    fvgs.append({'c1_idx':i-1,'c3_idx':i+1,'low':c1['high'],'high':c3['low'],'ce':(c1['high']+c3['low'])/2,'type':'bullish'})
    return fvgs

def detect_obs(df,fvgs,atr):
    obs=[]
    for i in range(1,len(df)-1):
        prev=df.iloc[i-1]; curr=df.iloc[i]
        if not (prev['close']<prev['open']): continue
        if not (curr['low']<prev['low']): continue
        if not (curr['close']>prev['high']): continue
        body=curr['close']-curr['open']
        if body < atr.iloc[i]*0.4: continue
        has_fvg=False
        for f in fvgs:
            if abs(f['c1_idx']-(i-1))<=3:
                has_fvg=True
                break
        if not has_fvg: continue
        obs.append({'index':i-1,'low':prev['low'],'high':prev['high'],'mid':(prev['low']+prev['high'])/2})
    return obs

def detect_bos(df,highs):
    bos=[]
    atr=calc_atr(df)
    for i in range(1,len(df)):
        recent=[h for h in highs if h['index']<i]
        if not recent: continue
        last=recent[-1]
        c=df.iloc[i]
        if c['high']<=last['price']: continue
        if c['close']<=last['price']: continue
        hl=c['high']-c['low']
        cp=(c['close']-c['low'])/hl if hl>0 else 0
        if cp<0.60: continue
        disp=c['close']-last['price']
        if disp < atr.iloc[i]*0.15: continue
        upper=c['high']-max(c['open'],c['close'])
        if upper/hl>0.70 if hl>0 else 0: continue
        bos.append({'index':i,'price':c['close'],'last_high':last['price']})
    return bos

def calc_cvd_series(df):
    cvd=[]
    run=0
    for _,row in df.iterrows():
        hl=row['high']-row['low']
        if hl>0:
            bf=(row['close']-row['low'])/hl
            d=(bf-0.5)*2*row['volume']
        else:
            d=0
        run+=d
        cvd.append(run)
    return pd.Series(cvd)

df15=pd.read_csv('/home/user/btcusdt_15m_last_month.csv')
df15['timestamp']=pd.to_datetime(df15['timestamp'])
df15=df15.sort_values('timestamp').reset_index(drop=True)
atr15=calc_atr(df15)
lows15,highs15=find_swings(df15,pivot=3)
fvgs=detect_fvgs(df15,atr15)
obs=detect_obs(df15,fvgs,atr15)
bos=detect_bos(df15,highs15)
cvd_series=calc_cvd_series(df15)
print(f"Lows {len(lows15)} Highs {len(highs15)} FVG {len(fvgs)} OB {len(obs)} BOS {len(bos)}")

balance=100.0
fee=0.001
trades=[]
current_trade=None

for i in range(100,len(df15)-1):
    curr=df15.iloc[i]
    past=df15.iloc[:i+1]
    atr_i=atr15.iloc[i]

    if current_trade:
        if curr['low'] <= current_trade['stop_loss']:
            exit_price=current_trade['stop_loss']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'LOSS','balance_after':balance})
            trades.append(current_trade)
            current_trade=None
            continue
        if curr['high'] >= current_trade['take_profit']:
            exit_price=current_trade['take_profit']
            ec=current_trade['entry_price']*current_trade['coins']
            ev=exit_price*current_trade['coins']
            profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
            balance+=profit
            current_trade.update({'exit_price':exit_price,'exit_time':curr['timestamp'],'profit_usd':profit,'profit_pct':(exit_price/current_trade['entry_price']-1)*100,'result':'WIN','balance_after':balance})
            trades.append(current_trade)
            current_trade=None
            continue
        continue

    # Protected low rej>=2.0
    recent_lows=[]
    for low in lows15:
        if low['index']>i-3 or low['index']<i-150:
            continue
        idx=low['index']
        if idx<30: continue
        candle=df15.iloc[idx]
        lower_wick=min(candle['open'],candle['close'])-candle['low']
        wicks=[]
        for j in range(max(0,idx-30),idx):
            c=df15.iloc[j]
            lw=min(c['open'],c['close'])-c['low']
            wicks.append(lw)
        avg_wick=np.mean(wicks) if wicks else 1
        rej=lower_wick/avg_wick if avg_wick>0 else 0
        if rej>=2.0:
            recent_lows.append({'index':idx,'price':low['price'],'rej':rej})
    if not recent_lows:
        continue
    pl=recent_lows[-1]

    bos_after=[b for b in bos if b['index']>pl['index'] and b['index']<=i and i-b['index']<=80]
    if not bos_after:
        continue
    bos_v=bos_after[-1]

    origin_idx=pl['index']
    origin_price=pl['price']
    term_price=past['high'].iloc[origin_idx:].max()
    range_size=term_price-origin_price
    if range_size<=0:
        continue

    num_candles=i-origin_idx
    atr_10=atr15.iloc[max(0,i-10):i+1].mean()
    disp_power = range_size / (num_candles * atr_10) if num_candles>0 and atr_10>0 else 0

    cvd_win=cvd_series.iloc[max(0,i-5):i+1]
    if len(cvd_win)>=2:
        x=np.arange(len(cvd_win)).reshape(-1,1)
        y=cvd_win.values
        try:
            m=LinearRegression().fit(x,y)
            cvd_slope=m.coef_[0]
        except:
            cvd_slope=0
    else:
        cvd_slope=0

    vol_mean=df15['volume'].iloc[max(0,i-50):i].mean()
    vol_std=df15['volume'].iloc[max(0,i-50):i].std()
    vol_z=(curr['volume']-vol_mean)/vol_std if vol_std>0 else 0

    # Muscle power
    cvd_norm=np.tanh(cvd_slope/1000)
    muscle_power = disp_power * (1+max(0,cvd_norm)) * (1+max(0,vol_z)/5)

    # Dynamic Discount - inversely proportional to muscle power
    discount_pct = 0.79 - muscle_power*0.10
    discount_pct = max(0.30, min(0.79, discount_pct))
    buy_low = term_price - range_size*discount_pct
    buy_high = term_price - range_size*max(0.10, discount_pct-0.10)

    if curr['close'] > buy_high and muscle_power<1.0:
        continue
    if not (buy_low <= curr['low'] <= buy_high or buy_low <= curr['close'] <= buy_high):
        # Allow if muscle strong and close below discount limit
        if not (muscle_power>2.0 and curr['close'] < term_price - range_size*0.40):
            continue

    # CVD window buffer 5 candles
    deltas=[]
    for k in range(max(0,i-5),i+1):
        row=df15.iloc[k]
        hl_r=row['high']-row['low']
        if hl_r>0:
            bf=(row['close']-row['low'])/hl_r
            d=(bf-0.5)*2*row['volume']
            deltas.append(d)
    sum_delta=sum(deltas)
    is_rising=deltas[-1]>deltas[0] if len(deltas)>=2 else False
    cvd_window=sum_delta>0 and is_rising

    if not cvd_window and muscle_power<1.5:
        continue

    # OB/FVG
    obs_valid=[ob for ob in obs if ob['index']<=i and (buy_low <= ob['low'] <= buy_high or buy_low <= ob['high'] <= buy_high or (ob['low'] <= buy_high and ob['high'] >= buy_low))]
    obs_unmit=[]
    for ob in obs_valid:
        mitig=False
        for k in range(ob['index']+1,i+1):
            if df15['close'].iloc[k] < ob['low']:
                mitig=True
                break
        if not mitig:
            obs_unmit.append(ob)

    fvgs_valid=[f for f in fvgs if f['c3_idx']<=i and f['type']=='bullish' and (buy_low <= f['low'] <= buy_high or buy_low <= f['high'] <= buy_high or (f['low'] <= buy_high and f['high'] >= buy_low))]
    fvgs_unmit=[]
    for f in fvgs_valid:
        mitig=False
        for k in range(f['c3_idx']+1,i+1):
            if df15['close'].iloc[k] <= f['low']:
                mitig=True
                break
        if not mitig:
            fvgs_unmit.append(f)

    if not obs_unmit and not fvgs_unmit:
        continue

    valid_exec=None
    for ob in obs_unmit[-2:]:
        for fvg in fvgs_unmit[-3:]:
            if abs(fvg['low'] - ob['high']) < (ob['high']-ob['low'])*3:
                hl=curr['high']-curr['low']
                if hl==0: continue
                lower_wick=min(curr['open'],curr['close'])-curr['low']
                body=abs(curr['close']-curr['open'])
                close_pos=(curr['close']-curr['low'])/hl
                wick_rej=lower_wick > body*0.8 and close_pos>0.60
                vol_upper=vol_mean+2*vol_std if vol_std>0 else vol_mean*1.5
                vol_spike=curr['volume']>vol_upper
                is_churn=body < hl*0.2 and curr['volume']>vol_mean*2
                if (wick_rej and (vol_spike or cvd_window)) and not is_churn:
                    valid_exec=(ob,fvg,wick_rej,vol_spike,close_pos,vol_z,muscle_power,cvd_slope,sum_delta)
                    break
        if valid_exec:
            break
    if not valid_exec and muscle_power>2.5 and fvgs_unmit:
        fvg=fvgs_unmit[-1]
        hl=curr['high']-curr['low']
        lower_wick=min(curr['open'],curr['close'])-curr['low']
        body=abs(curr['close']-curr['open'])
        close_pos=(curr['close']-curr['low'])/hl if hl>0 else 0
        wick_rej=lower_wick > body*0.5 and close_pos>0.55
        if wick_rej:
            ob={'low':fvg['low'],'high':fvg['high'],'mid':fvg['ce'],'index':fvg['c1_idx']}
            valid_exec=(ob,fvg,wick_rej,False,close_pos,vol_z,muscle_power,cvd_slope,0)

    if not valid_exec:
        continue

    ob,fvg,wick_rej,vol_spike,close_pos,vol_z,muscle_power,cvd_slope,sum_delta=valid_exec

    ob_mid=(ob['low']+ob['high'])/2
    fvg_ce=fvg['ce']
    entry_level=fvg_ce
    if ob_mid < entry_level:
        entry_level=ob_mid

    if not (curr['low'] <= entry_level <= curr['high']):
        continue

    sl_ob=ob['low'] - atr_i*0.15
    sl_pl=pl['price'] - 0.01
    stop_loss=min(sl_ob,sl_pl)
    risk_dist=abs(entry_level-stop_loss)/entry_level
    if risk_dist>0.03 or risk_dist<0.001:
        continue

    tp_deep=term_price + range_size*0.62
    take_profit=tp_deep
    risk=abs(entry_level-stop_loss)
    reward=abs(take_profit-entry_level)
    rr=reward/risk if risk>0 else 0
    if rr<2.5:
        continue

    # FULL-CHEST: Enter with 100% cash if muscle power Pass strict threshold
    muscle_threshold = 1.5  # per your behavioral rule: displacement violent + CVD cumulative whale > threshold
    if muscle_power < muscle_threshold:
        # muscle not strong enough, skip or use small size
        continue

    # Full allocation 100% (minus 5% fee buffer)
    allocation = balance * 0.995  # Full chest, leave 0.5% for fees
    coins = allocation / entry_level

    # Calculate actual $ loss/profit with full chest
    exit_val_sl = stop_loss * coins
    fee_entry = allocation * fee
    fee_exit_sl = exit_val_sl * fee
    net_loss = (entry_level - stop_loss)*coins + fee_entry + fee_exit_sl

    exit_val_tp = take_profit * coins
    fee_exit_tp = exit_val_tp * fee
    net_profit = (take_profit - entry_level)*coins - fee_entry - fee_exit_tp

    # Even with full chest, loss should be acceptable (<2$ for 100$ balance) - per your example 0.40$ or 1.50$
    # We allow loss up to $2 for full chest if RR high
    if net_loss > 2.5:
        # risk too wide for full chest, skip or reduce? For full-chest we allow up to $2.5
        continue

    # Profit must be >=3x loss for 3:1+ dollar
    if net_profit < 3*net_loss and net_profit < 3.0:
        # Require at least $3 profit or 3x loss
        if net_profit < 2.5:
            continue

    trade_id=len(trades)+1
    current_trade={
        'id':trade_id,
        'entry_index':i,
        'entry_time':curr['timestamp'],
        'entry_price':entry_level,
        'stop_loss':stop_loss,
        'take_profit':take_profit,
        'rr':rr,
        'coins':coins,
        'allocation':allocation,
        'balance_before':balance,
        'risk_dist':risk_dist*100,
        'reward_dist':abs(take_profit-entry_level)/entry_level*100,
        'net_loss':net_loss,
        'net_profit':net_profit,
        'pl_price':pl['price'],
        'bos_price':bos_v['price'],
        'range':range_size,
        'term':term_price,
        'buy_low':buy_low,
        'buy_high':buy_high,
        'discount_pct':discount_pct,
        'muscle_power':muscle_power,
        'vol_z':vol_z,
    }

# Close open
if current_trade:
    exit_price=df15.iloc[-1]['close']
    ec=current_trade['entry_price']*current_trade['coins']
    ev=exit_price*current_trade['coins']
    profit=(exit_price-current_trade['entry_price'])*current_trade['coins'] - ec*fee - ev*fee
    balance+=profit
    current_trade.update({'exit_price':exit_price,'exit_time':df15.iloc[-1]['timestamp'],'profit_usd':profit,'result':'OPEN_CLOSED','balance_after':balance})
    trades.append(current_trade)

print(f"\n=== FULL-CHEST 100% DEPLOYMENT - Last Month ===")
print(f"Total trades {len(trades)}")
wins=[t for t in trades if t.get('result')=='WIN']
losses=[t for t in trades if t.get('result')=='LOSS']
print(f"Wins {len(wins)} Losses {len(losses)} WR {len(wins)/len(trades)*100 if trades else 0:.1f}%")
total=sum(t.get('profit_usd',0) for t in trades)
print(f"PnL {total:.4f} Final Bal {balance:.4f} Return {(balance/100-1)*100:.2f}%")
if trades:
    print(f"Avg RR {sum(t['rr'] for t in trades)/len(trades):.2f} Avg net loss {sum(t['net_loss'] for t in trades)/len(trades):.2f}$ Avg net profit {sum(t['net_profit'] for t in trades)/len(trades):.2f}$")
    import pandas as pd
    pd.DataFrame(trades).to_csv('/home/user/full_chest_trades.csv', index=False)
    for t in trades:
        print(f"\nTrade {t['id']} Entry {t['entry_time']} {t['entry_price']:.2f} SL {t['stop_loss']:.2f} risk {t['risk_dist']:.2f}% TP {t['take_profit']:.2f} reward {t['reward_dist']:.2f}% RR {t['rr']:.2f} Alloc {t['allocation']:.2f}$ (100%) NetLoss {t['net_loss']:.2f}$ NetProfit {t['net_profit']:.2f}$ Bal {t['balance_before']:.2f}->{t.get('balance_after',0):.2f} {t.get('result')} PnL {t.get('profit_usd',0):.3f}$ Discount {t['discount_pct']*100:.0f}% Muscle {t['muscle_power']:.2f}x")
else:
    print("0 trades - even with full-chest, market didn't give muscle power > threshold with RR>=2.5")
