"""
Analyze why winning trades <1R and fix microscopically
"""
print("""
=== تحليل الخلل المجهري ليش الربح أقل من 1R ===

الخلل بالضبط:
- Trade 1: Entry 63391.80 SL 62664.79 Risk 727.01 TP 63513 Reward 121.2 RR 0.17
- Why? TP = term_price (max high from origin) = 63513, Entry 63391 is only 121$ below term (0.8% retracement from term, not 50-79%!)
- Entry at 99.17% retracement from term (almost at top), not 50-79%
- Risk = Entry - Origin = 40% range, Reward = Term - Entry = 0.8% range, RR tiny

Root cause:
- Buy range 50-79% = 64070-64223 for Trade1? Actually buy range 50-79% = 62842-63088, but entry 63391 is ABOVE buy range high 63088, outside, but allowed due to 0.5% buffer
- Term price = max high from origin to current, which is recent high very close to entry if market made new high just before entry
- TP = term_price (previous high) gives tiny reward if entry near term

Fix microscopically without losing accuracy:

1. Strictly enforce entry must be inside buy range 50-79% (or 70.5-79% deep for better RR), no buffer, no allowing low touches outside
2. TP should be beyond term using extension -0.27 and -0.62 per ICT:
   TP1 = Term + Range*0.27 (standard institutional expansion)
   TP2 = Term + Range*0.62 (deep)
   Then even entry at 50% retracement:
   Risk = 50% range, Reward = 50%+27% =77% range, RR=1.54
   Entry at 61.8%: Risk 38.2%, Reward 61.8%+27%=88.8%, RR=2.32
   Entry at 70.5%: Risk 29.5%, Reward 70.5%+27%=97.5%, RR=3.30
   Entry at 79%: Risk 21%, Reward 79%+27%=106%, RR=5.04
   With TP2 extension 0.62: RR even higher 1:3 to 1:5

3. Enforce deep discount only 70.5-79% for RR>2, not shallow 50-61.8% which gives RR 1-1.6 with TP at term

4. Add RR filter: reject trade if RR<1.5 after calculating extended TP

This keeps microscopic accuracy (still requires Protected Low VERIFIED, BOS Body Close, Discount OTE, OB Double Immunity, FVG, Wick OR Vol) but ensures winning trades >1R

Implementation in final_integrated_engine_rr_fixed.py:
- Buy range 50-79% wide (or deep 70.5-79% for better RR)
- TP = term + range*0.27 (standard) and term + range*0.62 (deep)
- Enforce RR>=1.5
- Strictly enforce entry inside buy range, no buffer

Test result:
- Strict engine 15M 2881 candles: 0 trades (protected lows 79, BOS 17, FVG 39, OB 6 but state management narrow)
- Balanced engine 500 candles 15M: 6 trades with RR<1 (RR 0.17,0.41,0.008,0.14,0.36,0.39) - one loss wipes 3-4 wins
- Fixed RR engine 500 candles 15M: With buy range 50-79% wide and TP term+0.27*range and RR>=1.5 filter -> 0 trades (because entry shallow near term gives RR<1.5 even with extension 0.27, need deeper entry or extension 0.62)
- Need deep OTE 70.5-79% + TP term+0.62*range to get RR>1.5
""")

# Quick calc for RR examples
for retracement in [0.50, 0.618, 0.705, 0.79]:
    risk = retracement  # Actually risk = retracement? Let's define properly:
    # Origin 0%, Term 100%, Entry at retracement X% from Term down: Entry = Term - Range*X%
    # Risk = Entry - Origin = (Term - Range*X) - Origin = Range - Range*X = Range*(1-X)
    # Wait earlier we had risk = X%? Let's re-derive:
    # Origin 0, Term 100, Range 100
    # Entry at 50% retracement from Term: Entry = Term - Range*0.5 = 50, Risk = Entry - Origin = 50-0=50, Reward to Term = Term-Entry=50, RR=1
    # Entry at 61.8% retracement from Term: Entry = 100-61.8=38.2, Risk=38.2, Reward=61.8, RR=1.618
    # So Risk = 100 - retracement? Actually retracement from Term: Entry = Term - Range*retracement%
    # Risk = Entry - Origin = Term - Range*retracement - Origin = Range*(1-retracement)
    # Reward to Term = Term-Entry = Range*retracement
    # So RR = retracement / (1-retracement)
    # For 50%: RR=0.5/0.5=1
    # For 61.8%: RR=0.618/0.382=1.618
    # For 70.5%: RR=0.705/0.295=2.39
    # For 79%: RR=0.79/0.21=3.76
    # With extension 0.27: Reward = Range*retracement + Range*0.27 = Range*(retracement+0.27), RR=(retracement+0.27)/(1-retracement)
    # For 50%: (0.5+0.27)/0.5=1.54
    # For 61.8%: (0.618+0.27)/0.382=2.32
    # For 70.5%: (0.705+0.27)/0.295=3.30
    # For 79%: (0.79+0.27)/0.21=5.04
    # With extension 0.62: RR=(retracement+0.62)/(1-retracement)
    # For 50%: (1.12)/0.5=2.24
    # For 61.8%: (1.238)/0.382=3.24
    # For 70.5%: (1.325)/0.295=4.49
    # For 79%: (1.41)/0.21=6.71

for ret in [0.50, 0.618, 0.705, 0.79]:
    rr_term = ret/(1-ret)
    rr_027 = (ret+0.27)/(1-ret)
    rr_062 = (ret+0.62)/(1-ret)
    print(f"Retracement {ret*100:.1f}%: RR to Term {rr_term:.2f}, RR to Term+0.27 {rr_027:.2f}, RR to Term+0.62 {rr_062:.2f}")
