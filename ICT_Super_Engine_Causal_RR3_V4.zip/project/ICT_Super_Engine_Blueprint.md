# ICT Super Intelligence Engine - Blueprint V1.0
# مشروع العمر - ممنوع الأخطاء - تفكير عميق فقط

## القسم 1: التدقيق المصدري لخريطتك العامة

### تصحيح مفاهيم جوهرية قبل البناء:

**1. BOS vs CHoCH vs MSS - الفرق المصيري:**
- BOS (Break of Structure): كسر في اتجاه الترند الحالي = تأكيد استمرار [1](https://tradingfinder.com/education/forex/ict-break-structure-in-market/)
  - صاعد: كسر قمة سابقة = استمرار صاعد
  - هابط: كسر قاع سابق = استمرار هابط
- CHoCH (Change of Character): كسر عكس الترند الحالي = إنذار مبكر لاحتمال انعكاس [2](https://trenddaytrader.com/break-of-structure-vs-choch/)
  - في ترند صاعد: كسر آخر Higher Low
  - في ترند هابط: كسر آخر Lower High
- MSS (Market Structure Shift): نفس كسر CHoCH لكن مع Displacement قوي = تأكيد أن الانعكاس بدأ فعلاً [3](https://innercircletrader.net/tutorials/mss-vs-choch/)
  - القاعدة: MSS يكسر سوينغ عادي (إشارة قصيرة المدى)، CHoCH يكسر Higher Low / Lower High (تغيير ترند طويل المدى) [3]
  - التسلسل الحقيقي: Liquidity Sweep -> MSS -> CHoCH -> BOS جديد في الاتجاه الجديد

**2. Premium / Discount - التعريف الرياضي الدقيق:**
- من ICT الرسمي: ارسم فيبوناتشي من Swing Low الى Swing High (في الصاعد)
  - المنطقة فوق 50% = Premium (غالي) - تبحث عن بيع فقط [4](https://translate.google.com/translate?u=https%3A%2F%2Finnercircletrader.net%2Ftutorials%2Fict-premium-and-discount-zone-identification%2F&hl=th&sl=en&tl=th&client=srp)
  - المنطقة تحت 50% = Discount (رخيص) - تبحث عن شراء فقط [4]
- خطأ قاتل: ممنوع التداول بالـ Premium/Discount لوحده [5](https://innercircletrader.net/tutorials/ict-premium-and-discount-zone-identification/)
  - يجب دمجه مع تأكيد MSS على فريم أقل
- OTE (Optimal Trade Entry): ليست كل منطقة Discount متساوية. المنطقة 62% - 79% هي الأعلى احتمالاً [6](https://ictflow.com/blog/ict-premium-discount-zones)
  - 70.5% هي نقطة المنتصف الرياضي بين 61.8 و 79 [6]

**3. Liquidity - الميكانيكية الحقيقية:**
- Buy-Side Liquidity (BSL): ستوبات الشورت + أوامر اختراق الشراء فوق القمم [7](https://www.ictkillzone.com/ict-liquidity)
- Sell-Side Liquidity (SSL): ستوبات اللونغ + أوامر كسر البيع تحت القيعان [7]
- الميكانيكية: السعر ينجذب لمنطقة السيولة، يكنسها (Sweep)، يفعل الأوردرات، ثم ينعكس ليترك FVG [7]
- SFP (Swing Failure Pattern): كسر كاذب لقمة/قاع ثم إغلاق سريع داخل الرينج = فخ للريتيل [8](https://arongroups.co/technical-analyze/ict-swing-failure-pattern-sfp-trading-failed-highs-lows-forex/)

**4. FVG - التعريف الهندسي:**
- تشكيل 3 شموع، الفجوة بين هاي الشمعة 1 و لو الشمعة 3 (في الصاعد) [9](https://innercircletrader.net/tutorials/fair-value-gap-trading-strategy/)
- تعمل كمغناطيس للسعر لإعادة التوازن [9]
- ليست كل FVG ستمتلئ - خاصة Breakaway Gaps في الترند القوي [10](https://algostorm.com/ict-smc-key-concepts/)

### تدقيق خريطتيك:

**الخريطة الأولى (Bullish Pro-Trend): صحيحة 90% ولكن تحتاج تعديل:**
سرديتك: [قاع محمي] -> [BOS يكسر قمة] -> [قمة جديدة] -> [تراجع لـ Discount]
التعديل المصدري: بعد BOS يجب إعادة رسم فيبوناتشي من القاع الجديد الى القمة الجديدة، والمنطقة المسموحة فقط هي Discount + OTE + FVG/OB غير ملموس
دليلك: "بعد كل Break of Structure يجب تحديد Premium/Discount Zone جديدة" [5]

**الخريطة الثانية (Counter-Trend): ذكية جداً ولكن خطرة، تحتاج فلتر إضافي:**
سرديتك: [سوق هابط] -> [HTF Sweep] -> [CHoCH على LTF] -> [شراء سبوت خاطف] -> [خروج عند Bearish FVG على 4H]
هذا هو بالضبط مفهوم IRL vs ERL [7]:
- تشتري عند IRL (سيولة داخلية - FVG صغير) 
- تخرج عند ERL (سيولة خارجية - قمة/ Bearish FVG على 4H)
- ملاحظة: CHoCH وحده لا يكفي، 60-70% منه يفشل ويعود تراجع عميق [10] لذلك نحتاج Displacement قوي + MSS بعده

---

## القسم 2: هندسة الانجن الخارق - 6 طبقات تفكير

لن نبني بوت يقرأ مؤشرات. سنبني عقل يروي قصة.

### الطبقة 0: Deep Thinking Protocol (قاعدة تفكيرك التي طلبتها)
- ممنوع أي جواب بدون تفكير
- كل قرار = 3 أسئلة: لماذا حدثت هذه الشمعة؟ من يخسر هنا؟ أين ستذهب السيولة بعدها؟
- لا يوجد مؤشر واحد = دخول. يوجد قصة كاملة يجب أن تكتمل

### الطبقة 1: Data Integrity Layer (منع الغش)
- الكود سيمشي شمعة شمعة، لا يرى المستقبل أبداً
- كل متغير يملك timestamp
- في الباكتيست: `if current_bar_time > signal_bar_time: invalid`

### الطبقة 2: Structure Intelligence
- يكشف Swings الحقيقية (ليس كل قمة، فقط التي أخذت سيولة وكسرت هيكل)
- يصنف: BOS = continuation, MSS/CHoCH = potential reversal [1][3]
- يحدد HTF Bias (4H/Daily) = البوصلة التي لا نخالفها

### الطبقة 3: Liquidity Intelligence
- يرسم BSL/SSL تلقائياً فوق/تحت سوينغات واضحة [7]
- يكشف Sweep الحقيقي: wick فوق القمة + close تحت القمة = Sweep مؤكد
- يميز بين Sweep عادي و SFP [8]

### الطبقة 4: PD Array Intelligence
- FVG: يكتشفها هندسياً (High[0] < Low[2] للصاعد) [9]
- Order Block: آخر شمعة هابطة قبل صعود عنيف كسر هيكل (يجب أن يكون سبب BOS/MSS)
- Consequent Encroachment (CE): منتصف FVG = 50% منه = نقطة الدخول المثالية
- BPR, Inversion FVG, Breaker: للخروج فقط

### الطبقة 5: Narrative Engine (العقل الخارق)
هذا هو الفرق. البوت لن يقول "BOS + FVG = Buy"
سيقول:

> "القصة: السوق العام على 4H هابط عنيف، وصلنا لمنطقة بيع تاريخية شهري. شمعة Daily كسرت القاع بذيل طويل جداً (HTF Sweep) و Coinglass أظهر تصفية مليار. هذا يعني الحوت ابتلع سيولة الذعر. انتقلت لـ 15M، رأيت MSS صاعد قوي مع Displacement (شمعة جسم كبير). هذا يعني الثورة بدأت. الآن السعر يتراجع بهدوء ليملأ FVG صاعد تركها أثناء الصعود - هذه هي منطقة خصم الحوت (OTE 62-79%). سأشتري سبوت هناك، لأن القصة مكتملة: تصفية + كنس + تغيير سلوك + تراجع للوقود. هدفي ليس قمة جديدة، هدفي أول Bearish FVG على 4H لأنه مقاومة حيتان ستصد السعر."

هذا التفكير يربط 5 فريمات و 4 مفاهيم ببعضها بمنطق سببي.

### الطبقة 6: Decision & Risk Engine (سبوت فقط)
- فلتر: لا شراء إلا إذا HTF Sweep أو HTF Discount + LTF MSS/CHoCH + LTF FVG/OB
- خروج: 100% عند Bearish FVG / Bearish OB على 4H (لأنك سبوت في سوق هابط)
- لا شورت، لا فيوتشر، لا ستوب ماركت - فقط سبوت شراء وخروج

---

## القسم 3: No Lookahead Protocol (للباكتيست الحي)

```python
# القاعدة الذهبية:
for i in range(len(candles)):
    current_candle = candles[i]  # انا هنا فقط
    # ممنوع استخدام candles[i+1] حتى لو موجود في الداتا
    # كل إشارة دخول يجب أن تنتظر إغلاق الشمعة الحالية
    # الدخول يكون على افتتاح الشمعة القادمة فقط
    # النجاح/الفشل يحسب بعد الدخول، وليس قبله
```

سنطبق Walk-Forward وليس Vectorized Backtest.

---

## التقنية المقترحة:
- Python 3.11 + Pandas + NumPy (للمنطق)
- CCXT للبيانات الحية (Binance Spot)
- لا مكتبات جاهزة لـ SMC - سنكتب المنطق يدوياً لضمان الفهم
- ملفات منفصلة لكل طبقة تفكير

الخطوة القادمة: اشرح لي أول نقطة بالتفصيل الممل (مثلاً كيف تحدد القاع المحمي أو كيف تكشف الـ BOS الحقيقي وليس الكاذب)، وانا سأحولها لانجن ذكي يفكر.
