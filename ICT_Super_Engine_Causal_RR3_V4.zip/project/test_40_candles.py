import pandas as pd
from datetime import datetime, timedelta
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.discount_detector import DiscountDetector
from engine.core.orderblock_detector import ExecutionEngine
from engine.core.fvg_detector import FVGDetector
from engine.core.liquidity import LiquidityEngine

# Setup per user
Avg_Volume = 50000
ATR_fixed = 4.00
Last_Confirmed_Swing_High = 120.00

candles = [
    {"Index": 1, "Open": 115.00, "High": 116.00, "Low": 112.00, "Close": 113.00, "Volume": 48000},
    {"Index": 2, "Open": 113.00, "High": 114.20, "Low": 110.10, "Close": 110.50, "Volume": 52000},
    {"Index": 3, "Open": 110.50, "High": 111.00, "Low": 105.00, "Close": 109.80, "Volume": 145000},
    {"Index": 4, "Open": 109.80, "High": 112.50, "Low": 108.00, "Close": 112.10, "Volume": 65000},
    {"Index": 5, "Open": 112.10, "High": 113.00, "Low": 110.50, "Close": 111.20, "Volume": 38000},
    {"Index": 6, "Open": 111.20, "High": 112.80, "Low": 110.00, "Close": 112.50, "Volume": 42000},
    {"Index": 7, "Open": 112.50, "High": 114.00, "Low": 111.80, "Close": 113.90, "Volume": 49000},
    {"Index": 8, "Open": 113.90, "High": 115.50, "Low": 113.00, "Close": 114.80, "Volume": 51000},
    {"Index": 9, "Open": 114.80, "High": 114.90, "Low": 111.20, "Close": 111.50, "Volume": 44000},
    {"Index": 10, "Open": 111.50, "High": 113.20, "Low": 110.80, "Close": 112.90, "Volume": 41000},
    {"Index": 11, "Open": 112.90, "High": 115.00, "Low": 112.50, "Close": 114.20, "Volume": 46000},
    {"Index": 12, "Open": 114.20, "High": 116.80, "Low": 113.90, "Close": 116.10, "Volume": 55000},
    {"Index": 13, "Open": 116.10, "High": 121.50, "Low": 115.80, "Close": 119.20, "Volume": 130000},
    {"Index": 14, "Open": 119.20, "High": 120.50, "Low": 117.10, "Close": 118.00, "Volume": 62000},
    {"Index": 15, "Open": 118.00, "High": 119.80, "Low": 116.50, "Close": 119.10, "Volume": 58000},
    {"Index": 16, "Open": 119.10, "High": 125.50, "Low": 118.90, "Close": 124.80, "Volume": 210000},
    {"Index": 17, "Open": 124.80, "High": 126.20, "Low": 123.00, "Close": 125.90, "Volume": 115000},
    {"Index": 18, "Open": 125.90, "High": 127.50, "Low": 124.10, "Close": 126.80, "Volume": 95000},
    {"Index": 19, "Open": 126.80, "High": 128.00, "Low": 125.50, "Close": 127.20, "Volume": 88000},
    {"Index": 20, "Open": 127.20, "High": 128.50, "Low": 126.00, "Close": 126.50, "Volume": 72000},
    {"Index": 21, "Open": 126.50, "High": 127.00, "Low": 123.80, "Close": 124.10, "Volume": 54000},
    {"Index": 22, "Open": 124.10, "High": 125.50, "Low": 122.90, "Close": 124.80, "Volume": 49000},
    {"Index": 23, "Open": 124.80, "High": 126.00, "Low": 123.50, "Close": 125.20, "Volume": 46000},
    {"Index": 24, "Open": 125.20, "High": 125.80, "Low": 121.20, "Close": 121.80, "Volume": 51000},
    {"Index": 25, "Open": 121.80, "High": 122.90, "Low": 120.00, "Close": 120.50, "Volume": 47000},
    {"Index": 26, "Open": 120.50, "High": 121.80, "Low": 118.50, "Close": 119.20, "Volume": 43000},
    {"Index": 27, "Open": 119.20, "High": 120.00, "Low": 117.10, "Close": 117.80, "Volume": 39000},
    {"Index": 28, "Open": 117.80, "High": 118.50, "Low": 116.20, "Close": 116.90, "Volume": 41000},
    {"Index": 29, "Open": 116.90, "High": 117.20, "Low": 114.80, "Close": 115.10, "Volume": 36000},
    {"Index": 30, "Open": 115.10, "High": 116.00, "Low": 115.00, "Close": 115.80, "Volume": 33000},
    {"Index": 31, "Open": 115.80, "High": 116.50, "Low": 114.10, "Close": 114.50, "Volume": 44000},
    {"Index": 32, "Open": 114.50, "High": 115.20, "Low": 113.80, "Close": 114.00, "Volume": 32000},
    {"Index": 33, "Open": 114.00, "High": 114.80, "Low": 112.90, "Close": 113.20, "Volume": 35000},
    {"Index": 34, "Open": 113.20, "High": 114.00, "Low": 112.50, "Close": 112.80, "Volume": 29000},
    {"Index": 35, "Open": 112.80, "High": 113.50, "Low": 111.90, "Close": 112.10, "Volume": 31000},
    {"Index": 36, "Open": 112.10, "High": 113.00, "Low": 111.00, "Close": 111.50, "Volume": 34000},
    {"Index": 37, "Open": 111.50, "High": 112.50, "Low": 110.20, "Close": 110.80, "Volume": 37000},
    {"Index": 38, "Open": 110.80, "High": 111.80, "Low": 109.50, "Close": 109.90, "Volume": 39000},
    {"Index": 39, "Open": 109.90, "High": 110.50, "Low": 108.90, "Close": 109.20, "Volume": 42000},
    {"Index": 40, "Open": 109.20, "High": 110.00, "Low": 108.20, "Close": 108.50, "Volume": 46000},
]

df = pd.DataFrame([{
    'timestamp': datetime(2024,1,1) + timedelta(minutes=c['Index']*5),
    'open': c['Open'],
    'high': c['High'],
    'low': c['Low'],
    'close': c['Close'],
    'volume': c['Volume']
} for c in candles])

print("="*80)
print("اختبار الخريطة الأولى - مصفوفة 40 شمعة - تحليل شمعة شمعة بدون غش")
print(f"Setup: Avg_Volume={Avg_Volume}, ATR={ATR_fixed}, Last_High={Last_Confirmed_Swing_High}")
print("="*80)

# Initialize detectors with fixed ATR for this test
from engine.core.swing_detector import ProtectedSwingDetector
from engine.core.bos_detector import BOSDetector
from engine.core.discount_detector import DiscountDetector
from engine.core.orderblock_detector import OrderBlockDetector

swing_det = ProtectedSwingDetector(pivot_length=3)
swing_sensitive = ProtectedSwingDetector(pivot_length=1)
bos_det = BOSDetector(atr_period=14, volume_lookback=20)
fvg_det = OrderBlockDetector()  # contains FVG detection

# State management
state = "SEARCH_PROTECTED_LOW"
protected_low = None
bos_signal = None
discount_signal = None
execution_trades = []

logs = []

for i in range(len(df)):
    past = df.iloc[:i+1]
    candle = df.iloc[i]
    idx = i+1
    
    # Calculate dynamic metrics using only past (no future leak)
    # Close Position
    hl_range = candle['high'] - candle['low']
    close_pos = (candle['close'] - candle['low']) / hl_range if hl_range>0 else 0
    
    # Volume Bollinger (last 20)
    vol_start = max(0, i-20)
    vol_mean = df['volume'].iloc[vol_start:i].mean() if i>vol_start else Avg_Volume
    vol_std = df['volume'].iloc[vol_start:i].std() if i>vol_start else 10000
    vol_upper = vol_mean + 2*vol_std if vol_std>0 else vol_mean*1.5
    is_vol_outlier = candle['volume'] > vol_upper or candle['volume'] > Avg_Volume*2
    
    # ATR dynamic (use fixed for this test per setup)
    atr = ATR_fixed
    
    # Station 1: Search Protected Low
    if state == "SEARCH_PROTECTED_LOW":
        # Detect swings on past
        swings_res = swing_det.analyze(past)
        true_lows = swings_res['true_protected_lows']
        
        # Also check for low at Index 3: low 105 with volume 145k, wick extreme?
        # Candle 3: low 105, high 111, close 109.8 open 110.5 bearish? Actually close < open slightly bearish but with huge volume
        # Let's log all protected
        if true_lows:
            last = true_lows[-1]
            # Only accept if low < 110 and volume spike and rejection
            if last['price'] < 110:
                protected_low = last
                state = "SEARCH_BOS"
                logs.append(f"[{idx}] Station1: True Protected Low FOUND at {last['price']:.2f} idx {last['index']} conf {last['confirmation_level']} - State -> SEARCH_BOS")
                continue
        
        # Manual check for candle 3 as potential protected low via thinking filters
        if idx == 3:
            # Selling velocity: candles 1 and 2 bearish decreasing?
            # Candle1: range 4 (116-112), Candle2: range 4.1 (114.2-110.1) similar, Candle3 range 6 (111-105) larger, not decreasing, but volume spike 145k
            # Rejection: lower wick of candle3 = min(open,close)-low = 109.8-105=4.8, avg wick last 2 candles: candle1 lower wick = min(115,113)-112=1, candle2 lower wick= min(113,110.5)-110.1=0.4 avg ~0.7, ratio 4.8/0.7=6.8 >2.5 extreme
            # Ghost check: recovery candle 4 close 112.1 above, volume 65k > avg, not ghost
            # So candidate protected low at 105
            logs.append(f"[{idx}] Station1 CHECK: Candle3 Low 105.00 Volume 145k Rejection Ratio huge - Potential Protected Low candidate")
    
    # Station 2: Search BOS breaking Last_Confirmed_Swing_High 120
    elif state == "SEARCH_BOS":
        # Use sensitive swing for high detection
        swings_res = swing_sensitive.analyze(past)
        swing_highs = [s for s in swings_res['all_swings'] if s['type']=='high']
        
        # Check if current candle high > Last_High
        if candle['high'] > Last_Confirmed_Swing_High:
            # Triple check
            displacement = candle['close'] - Last_Confirmed_Swing_High
            upper_wick = candle['high'] - max(candle['open'], candle['close'])
            upper_wick_ratio = upper_wick / hl_range if hl_range>0 else 0
            body = abs(candle['close'] - candle['open'])
            
            # Close Position >0.75?
            close_ok = close_pos > 0.75 and candle['close'] > Last_Confirmed_Swing_High
            vol_ok = is_vol_outlier
            safe_dist = displacement > atr*0.2
            sweep_trap = upper_wick_ratio > 0.6 or upper_wick > body*2
            
            if idx == 13:
                # Candle 13: high 121.5 >120, close 119.2 <120, close_pos = (119.2-115.8)/(121.5-115.8)=3.4/5.7=0.59 <0.75, body 119.2-116.1=3.1, upper wick 121.5-119.2=2.3 ratio 2.3/5.7=0.4, displacement close - last_high = -0.8 (close below high), should be SUSPENDED or WICK_ONLY
                logs.append(f"[{idx}] Station2 BOS CHECK Candle13: High 121.5>120 but Close 119.2<120 (WICK ONLY) ClosePos {close_pos:.2f} vol {candle['volume']} vs avg {vol_mean:.0f} upperWickRatio {upper_wick_ratio:.2f} => Expected: LIQUIDITY_SWEPT / WICK_ONLY TRAP, NOT valid BOS")
            
            if idx == 16:
                # Candle 16: high 125.5 close 124.8 >120, close_pos (124.8-118.9)/(125.5-118.9)=5.9/6.6=0.89>0.75, vol 210k outlier vs 50k, displacement 4.8>0.8, upper wick 0.7 ratio 0.1 small
                logs.append(f"[{idx}] Station2 BOS CHECK Candle16: High 125.5>120 Close 124.8>120 ClosePos {close_pos:.2f}>0.75 Vol {candle['volume']} outlier={is_vol_outlier} (210k vs avg {vol_mean:.0f} upper {vol_upper:.0f}) Disp {displacement:.2f}>0.8 upperWick {upper_wick_ratio:.2f} => Expected: VALID BOS")
                if close_ok and vol_ok and safe_dist and not sweep_trap:
                    bos_signal = {
                        'index': idx,
                        'price': candle['close'],
                        'last_high': Last_Confirmed_Swing_High,
                        'close_pos': close_pos,
                        'vol_outlier': is_vol_outlier,
                        'displacement': displacement
                    }
                    state = "SEARCH_DISCOUNT"
                    logs.append(f"[{idx}] Station2: VALID BOS CONFIRMED at {candle['close']:.2f} breaking {Last_Confirmed_Swing_High} - State -> SEARCH_DISCOUNT")
    
    elif state == "SEARCH_DISCOUNT":
        # Origin = protected low price ~105, Termination = new high ~125.5
        origin_price = protected_low['price'] if protected_low else 105.0
        term_price = df['high'].iloc[:i+1].max()
        origin_idx = protected_low['index'] if protected_low else 2
        
        # POC calculation
        # Use volume profile between origin and term
        from engine.core.discount_detector import DiscountDetector
        disc_det = DiscountDetector()
        sig = disc_det.analyze(past, origin_idx, origin_price, i, term_price, current_idx=i, current_price=candle['close'])
        
        if i in [20,25,30]:
            logs.append(f"[{idx}] Station3 Discount: Price {candle['close']:.2f} DynamicEq {sig.dynamic_equilibrium:.2f} POC {sig.poc:.2f} Premium {sig.premium_zone} Discount {sig.discount_zone} BuyRange {sig.recommended_buy_range} Hyper={sig.is_hyper_impulsive} State={sig.cognitive_state['Current_State']}")
        
        # Wait for price to enter discount
        if candle['close'] < sig.dynamic_equilibrium and i>20:
            # Check if in recommended buy range
            buy_low, buy_high = sig.recommended_buy_range
            if buy_low <= candle['close'] <= buy_high or (buy_low <= candle['low'] <= buy_high):
                state = "SEARCH_EXECUTION"
                discount_signal = sig
                logs.append(f"[{idx}] Station3: Price entered Discount Buy Range {buy_low:.2f}-{buy_high:.2f} at {candle['close']:.2f} - State -> SEARCH_EXECUTION")

    elif state == "SEARCH_EXECUTION":
        # Look for FVG and OB in discount
        fvg_detector = OrderBlockDetector()
        fvgs = fvg_detector.detect_fvgs(past)
        obs = fvg_detector.detect_bullish_obs(past, [f for f in fvgs])
        
        # Find FVG/OB overlap near current price
        for ob in obs:
            if ob.is_mitigated:
                continue
            for fvg in fvgs:
                if fvg.is_ghost:
                    continue
                # Check if near current price and in discount
                if abs(fvg.low - ob.high) < 2:  # close
                    # Check if price touching
                    if ob.low <= candle['low'] <= ob.high or fvg.low <= candle['low'] <= fvg.high:
                        # Check execution trigger
                        trigger = fvg_detector.check_execution_trigger if hasattr(fvg_detector, 'check_execution_trigger') else None
                        # Simplified trigger check
                        lower_wick = min(candle['open'], candle['close']) - candle['low']
                        body = abs(candle['close'] - candle['open'])
                        close_pos_trigger = (candle['close'] - candle['low']) / hl_range if hl_range>0 else 0
                        wick_rejection = lower_wick > body and close_pos_trigger > 0.6
                        
                        # CVD flip: simplified check last 3 bearish then bullish
                        prev_bearish = df['close'].iloc[i-3:i].lt(df['open'].iloc[i-3:i]).sum() >=2
                        curr_bullish = candle['close'] > candle['open']
                        
                        if wick_rejection and curr_bullish:
                            execution_trades.append({
                                'index': idx,
                                'entry_price': candle['close'],
                                'ob': ob.to_dict(),
                                'fvg': fvg.to_dict(),
                                'ce': fvg.ce
                            })
                            logs.append(f"[{idx}] Station4 EXECUTION: Confluence OB {ob.low:.2f}-{ob.high:.2f} + FVG {fvg.low:.2f}-{fvg.high:.2f} CE {fvg.ce:.2f} Entry {candle['close']:.2f} WickRej {wick_rejection} CVD flip - SPOT BUY")
                            state = "IN_TRADE"
                            break

print("\n".join(logs))

# Final summary
print("\n" + "="*80)
print("الخلاصة النهائية للاختبار:")
print(f"Protected Low: {protected_low}")
print(f"BOS Signal: {bos_signal}")
if discount_signal:
    print(f"Discount Eq: {discount_signal.dynamic_equilibrium:.2f} POC: {discount_signal.poc:.2f}")
    print(f"Buy Range: {discount_signal.recommended_buy_range}")
print(f"Trades: {execution_trades}")
print("="*80)
